﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class UserInfo
    {
        public long User_ID { get; set; }
        public double User_Balance { get; set; }
        public string? User_Username { get; set; }
        public string? User_Email { get; set; }
        public string? User_Password { get; set; }
        public DateTime? User_DateOFBirth { get; set; }
    }
}
