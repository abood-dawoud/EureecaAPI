﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class UserDetails
    {
        public int UserId { get; set; }
        public int CustomForumId { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Street { get; set; }
        public string PostCode { get; set; }
        public string Phone { get; set; }
        public string Country { get; set; }
        public int CountryId { get; set; }
        public int Followers { get; set; }
        public int Following { get; set; }
        public string UserType { get; set; }
        public int UserTypeId { get; set; }
        public string UserImage { get; set; }
        public string BadgeName { get; set; }
        public string BadgeImage { get; set; }
        public bool IsExpert { get; set; }
        public bool IsFollowed { get; set; }
        public bool CanFollow { get; set; }
        public int UserConnectionId { get; set; }
        public string UserProfileSummary { get; set; }
        public string ExpertImage { get; set; }
    }
}
