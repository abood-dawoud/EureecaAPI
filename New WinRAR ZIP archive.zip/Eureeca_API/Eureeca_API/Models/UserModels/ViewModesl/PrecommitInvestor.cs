﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class PrecommitInvestor : ProposalInvestor
    {
        public bool CanFollow { get; set; }
        public bool IsFollowed { get; set; }
        public string InvestmentAmountConverted { get; set; }
    }
}
