﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class InvestorFilter
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public int FnudType { get; set; }

        public InvestorFilter(int id, string text, int fundType)
        {
            Id = id;
            Text = text;
            FnudType = fundType;
        }
    }
}
