﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class UserPrecommittedProposalModel
    {
        public string ProfilePitchTitle { get; set; }
        public string PreComInvestmentStatus { get; set; }
        public string PreComInvestmentAmount { get; set; }
    }
}
