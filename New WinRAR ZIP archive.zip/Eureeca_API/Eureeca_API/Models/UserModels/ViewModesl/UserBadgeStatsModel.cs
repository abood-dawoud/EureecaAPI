﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class UserBadgeStatsModel
    {
        public string ExpertIcon { get; set; }
        public string PlatinumIcon { get; set; }
        public int AmountToBe { get; set; }
        public int Percent { get; set; }
        public int Current { get; set; }
        public string Needed { get; set; }
    }
}