﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class Investors
    {
        public string UserId { get; set; }
        public string UserPicture { get; set; }
        public bool UserIsFeaturedInvestor { get; set; }
        public string UserName { get; set; }
        public string ProfileFirstName { get; set; }
        public string ProfileLastName { get; set; }
        public string LastInvestmentAmount { get; set; }
        public string LastInvestmentDate { get; set; }
        public string FollowingNumber { get; set; }
        public string FollowersNumber { get; set; }
        public string MaxInvestmentAmount { get; set; }
        public string ProfileObjectTitle { get; set; }
        public string MasterImageUrlBig { get; set; }
        public string ExpertImage { get; set; }
        public string FeaturedImage { get; set; }
        public string MasterImageUrl { get; set; }
        public bool HasBadge { get; set; }
        public string LastInvestmentPitchTitle { get; set; }
        public string LastInvestmentPitchId { get; set; }
        public bool IsExpert { get; set; }
        public bool CanFollow { get; set; }
        public List<RecentlyFollowed> RecentFollowed { get; set; }
        public List<RecentInvestments> InvestmentList { get; set; }

    }
}
