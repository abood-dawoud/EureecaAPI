﻿using Eureeca_API.Models.GeneralModels.ViewModels;

namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class PendingInvestmentsPercentageModel : PagingGeneralResponse
    {
        public int TotalInvestments { get; set; }
        public List<PendingInvestmentsPercentage> PendingInvestmentsPercentageList { get; set; }

        public PendingInvestmentsPercentageModel(int code, bool success, int recordCount, bool hasMore, int currentPageIndex, int totalInvestments, List<PendingInvestmentsPercentage> pendingInvestmentsPercentageList)
        {
            Code = code;
            Success = success;
            RecordCount = recordCount;
            HasMore = hasMore;
            CurrentPageIndex = currentPageIndex;
            PendingInvestmentsPercentageList = pendingInvestmentsPercentageList;
            TotalInvestments = totalInvestments;
        }
    }

    public class PendingInvestmentsPercentage
    {
        public int PitchID { get; set; }
        public string PitchClosingDate { get; set; }
        public string InvestmentPercentage { get; set; }
        public string ProfilePitchTitle { get; set; }
    }
}