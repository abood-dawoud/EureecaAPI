﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class UserCommunityModel
    {
        public List<UserCommunityFollower> UserCommunityFollowers { get; set; }
        public List<UserCommunityFollowing> UserCommunityFollowings { get; set; }
        public List<UserCommunityContact> UserCommunityContacts { get; set; }
        public List<UserCommunityMemberToFollow> UserCommunityMembersToFollow { get; set; }
    }

    public class UserCommunityFollower
    {
        public int RowNumber { get; set; }
        public int UserConnectionID { get; set; }
        public string Username { get; set; }
        public string UserPicture { get; set; }
        public int UserID { get; set; }
        public bool CanFollow { get; set; }
        public string ProfileObject { get; set; }
    }

    public class UserCommunityFollowing
    {
        public int RowNumber { get; set; }
        public int UserConnectionID { get; set; }
        public string Username { get; set; }
        public string UserPicture { get; set; }
        public int UserID { get; set; }
        public bool CanFollow { get; set; }
        public string ProfileObject { get; set; }
    }

    public class UserCommunityContact
    {
        public int RowNumber { get; set; }
        public string Username { get; set; }
        public string UserPicture { get; set; }
        public int UserID { get; set; }
        public string ProfileObject { get; set; }
    }

    public class UserCommunityMemberToFollow
    {
        public int RowNumber { get; set; }
        public string Username { get; set; }
        public string UserPicture { get; set; }
        public int UserID { get; set; }
        public string ProfileObject { get; set; }
    }

    public class UserCommunityUserData
    {
        public string UserPicture { get; set; }
        public string UserType { get; set; }
        public string Username { get; set; }
        public bool CanFollow { get; set; }
        public string CountryCode { get; set; }
        public string CountryName { get; set; }
        public int FollowersCount { get; set; }
        public int FollowingCount { get; set; }
        public string ObjectTitle { get; set; }
        public string ObjectImage { get; set; }
        public bool IsExpert { get; set; }
        public string ExpertTitle { get; set; }
        public string ExpertImage { get; set; }
    }
}
