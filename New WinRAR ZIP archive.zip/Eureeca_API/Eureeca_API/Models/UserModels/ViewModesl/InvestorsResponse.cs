﻿using Eureeca_API.Models.GeneralModels.ViewModels;

namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class InvestorsResponse : PagingGeneralResponse
    {
        public List<Investors> Investors { get; set; }

        public InvestorsResponse(int code, bool success, int recordCount, bool hasMore, int currentPageIndex, List<Investors> investors)
        {
            Code = code;
            Success = success;
            RecordCount = recordCount;
            HasMore = hasMore;
            CurrentPageIndex = currentPageIndex;
            Investors = investors;
        }
    }
}
