﻿using Eureeca_API.Models.GeneralModels.ViewModels;

namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class UserNotRefundedInvestmentsResponseModel : PagingGeneralResponse
    {
        public List<UserInvestedProposalModel> InvestedProposalList { get; set; }

        public UserNotRefundedInvestmentsResponseModel(int code, bool success, int recordCount, bool hasMore, int currentPageIndex, List<UserInvestedProposalModel> investedProposalList)
        {
            Code = code;
            Success = success;
            RecordCount = recordCount;
            HasMore = hasMore;
            CurrentPageIndex = currentPageIndex;
            InvestedProposalList = investedProposalList;
        }
    }
}
