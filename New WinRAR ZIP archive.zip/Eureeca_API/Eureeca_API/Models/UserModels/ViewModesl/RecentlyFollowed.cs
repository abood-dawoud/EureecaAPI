﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class RecentlyFollowed
    {
        public string UserId { get; set; }
        public string UserUserName { get; set; }
        public string ProfileFirstName { get; set; }
        public string ProfileLastName { get; set; }
    }
}
