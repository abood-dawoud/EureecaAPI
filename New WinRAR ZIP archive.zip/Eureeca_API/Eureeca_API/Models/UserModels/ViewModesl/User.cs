﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class User
    {
        public string Id { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Guid { get; set; }
        public string BadgeName { get; set; }
        public string BadgeImage { get; set; }
        public int LanguageId { get; set; }
        public int CurrencyId { get; set; }
        public int CountryId { get; set; }
        public bool IsPartner { get; set; }
        public int Type { get; set; }
        public string Image { get; set; }
        public bool IsKYCRequired { get; set; }
        public string KYCOverAllStatus { get; set; }

    }
}
