﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class Follower
    {
        public long UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string ProfileObject { get; set; }
        public string Username { get; set; }
        public string UserImage { get; set; }
        public bool CanFollow { get; set; }
        public bool IsFollowed { get; set; }

    }
}
