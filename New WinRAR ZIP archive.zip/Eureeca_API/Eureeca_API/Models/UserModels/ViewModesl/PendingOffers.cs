﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class PendingOffers
    {
        public int SumPendingOffers { get; set; }
        public string ResponseCode { get; set; }
        public string ResponseMsg { get; set; }

    }
}
