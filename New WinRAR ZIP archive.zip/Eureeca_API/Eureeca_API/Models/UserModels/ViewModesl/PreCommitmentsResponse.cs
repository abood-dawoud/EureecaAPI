﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class PreCommitmentsResponse
    {
        public int Code { get; set; }
        public bool Success { get; set; }
        public string TotalPreCommit { get; set; }
        public int TotalRows { get; set; }
        public bool HasMore { get; set; }
        public int CurrentPageIndex { get; set; }
        public List<PrecommitInvestor> PrecommitInvestors { get; set; }

        public PreCommitmentsResponse(int code, bool success, string totalPreCommit, int totalRows, bool hasMore, int currentPageIndex, List<PrecommitInvestor> precommitInvestors)
        {
            Code = code;
            Success = success;
            TotalPreCommit = totalPreCommit;
            TotalRows = totalRows;
            HasMore = hasMore;
            CurrentPageIndex = currentPageIndex;
            PrecommitInvestors = precommitInvestors;

        }
    }
}
