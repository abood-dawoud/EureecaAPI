﻿using Eureeca_API.Models.GeneralModels.ViewModels;

namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class EntrepreneursResponse : PagingGeneralResponse
    {
        public List<Entrepreneurs> Entrepreneurs { get; set; }

        public EntrepreneursResponse(int code, bool success, int recordCount, bool hasMore, int currentPageIndex, List<Entrepreneurs> entrepreneurs)
        {
            Code = code;
            Success = success;
            RecordCount = recordCount;
            HasMore = hasMore;
            CurrentPageIndex = currentPageIndex;
            Entrepreneurs = entrepreneurs;
        }
    }
}
