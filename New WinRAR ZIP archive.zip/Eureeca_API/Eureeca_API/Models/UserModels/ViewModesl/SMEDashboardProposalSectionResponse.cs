﻿using Eureeca_API.Models.PitchModels.ViewModels;

namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class SMEDashboardProposalSectionResponse
    {
        public bool IsProposalStarted { get; set; }
        public ProposalStatus ProposalStatus { get; set; }

    }
}
