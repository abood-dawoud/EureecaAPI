﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class InvestorClassification
    {
        public int ClassificationId { get; set; }
        public string ClassificationTitle { get; set; }
        public string ClassificationDescription { get; set; }

    }
}
