﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class Entrepreneurs
    {
        public int UserId { get; set; }
        public string ProfileObjectTitle { get; set; }
        public string ExpertImage { get; set; }
        public string MasterImageUrlBig { get; set; }
        public string FeaturedImage { get; set; }
        public string MasterImageUrl { get; set; }
        public int PitchDaysLeft { get; set; }
        public string FollowersNumber { get; set; }
        public string FollowingNumbers { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PitchId { get; set; }
        public string PitchTitle { get; set; }
        public string ProposalStatus { get; set; }
        public string PitchShortSummary { get; set; }
        public bool CanFollow { get; set; }
        public bool IsExpert { get; set; }
        public bool HasBadge { get; set; }
        public string UserPicture { get; set; }
        public bool UserIsFeaturedInvestor { get; set; }
        public List<ProposalInvestor> TopThreeInvestment { get; set; }
    }
}
