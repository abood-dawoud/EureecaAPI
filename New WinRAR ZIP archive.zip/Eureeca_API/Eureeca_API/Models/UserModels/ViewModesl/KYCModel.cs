﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class KYCModel
    {
        public bool UserCanPay { get; set; }
        public int KYCOverAllStatus { get; set; }
        public string KYCOverAllStatusText { get; set; }
        public string KYCDescription { get; set; }
        public int NeededDocCount { get; set; }
        public List<KYCDocument> kYCDocuments { get; set; }

    }
}
