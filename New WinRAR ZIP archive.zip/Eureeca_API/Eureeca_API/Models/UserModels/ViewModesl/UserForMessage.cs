﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class UserForMessage
    {
        public int UserId { get; set; }
        public string UserPicture { get; set; }
        public string UserName { get; set; }
        public string UserPhone { get; set; }
    }
}
