﻿using Eureeca_API.Models.GeneralModels.ViewModels;

namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class LoginResponse
    {
        public List<Agreement> LoginPopupMessages { get; set; }
        public int RedirectType { get; set; }
        public bool ShowPopup { get; set; }
        public bool IsAuthenticate { get; set; }
        public User UserModel { get; set; }
        public string Message { get; set; }

    }
}
