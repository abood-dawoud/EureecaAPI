﻿using System.Data;

namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class UploadKYCResponseModel
    {
        public DataRow User { get; set; }
        public string ImageName { get; set; }
        public string ObjectTitle { get; set; }
        public string AllUploadedDocs { get; set; }
        public int ResponseStatus { get; set; }
        public int OverallStatus { get; set; }

    }

}
