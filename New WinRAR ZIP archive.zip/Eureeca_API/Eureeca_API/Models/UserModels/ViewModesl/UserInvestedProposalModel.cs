﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class UserInvestedProposalModel
    {
        public int PitchID { get; set; }
        public string PitchClosingDate { get; set; }
        public string PitchBalance { get; set; }
        public string PitchBalanceStatus { get; set; }
        public string ProfilePitchTitle { get; set; }
        public double SoFarPercentage { get; set; }
        public string SoFarStatus { get; set; }
        public string PitchInvestors { get; set; }
        public bool HasExtraTime { get; set; }
        public bool IsClosed { get; set; }
        public int RemainingTime { get; set; }
        public string RemainingTimeUnit { get; set; }
        public string PitchFollowers { get; set; }
        public LeadInvestor LeadInvestor { get; set; }
    }

    public class LeadInvestor
    {
        public string Name { get; set; }
        public string Image { get; set; }
        public string InvestmentAmount { get; set; }
        public string URL { get; set; }
    }
}
