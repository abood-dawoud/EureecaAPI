﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class RecentInvestments
    {
        public string InvestmentId { get; set; }
        public string InvestmentPitchId { get; set; }
        public string InvestmentAmount { get; set; }
        public string PitchTilte { get; set; }
        public string TotalInvetments { get; set; }
        public bool PitchStatus { get; set; }
    }
}
