﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class UserCurrencies
    {
        public int Currency_ID { get; set; }
        public string User_Balance { get; set; }
        public string Modified_Date { get; set; }
        public string CurrencySymple { get; set; }
        public string Currency_App { get; set; }
    }
}
