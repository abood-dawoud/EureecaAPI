﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class UserInvestorPortfolioModel
    {
        public string TotalInvestmentsAmount { get; set; }
        public int PendingInvestmentsCount { get; set; }
        public List<InvestmentPercentPerCategory> InvestmentPercentsPerCategory { get; set; }
        public List<InvestmentPercentPerProposal> InvestmentPercentsPerProposal { get; set; }
        public List<InvestmentPercentPerStatus> InvestmentPercentsPerStatus { get; set; }
    }

    public class InvestmentPercentPerCategory
    {
        public string SectorPercent { get; set; }
        public string CategoryName { get; set; }
    }

    public class InvestmentPercentPerProposal
    {
        public string SectorPercent { get; set; }
        public int InvestmentAmount { get; set; }
        public string ProfilePitchTitle { get; set; }
    }

    public class InvestmentPercentPerStatus
    {
        public string SectorPercent { get; set; }
        public string InvestmentStatus { get; set; }
        public int ProposalsCount { get; set; }
    }
}
