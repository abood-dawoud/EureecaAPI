﻿using Eureeca_API.Models.GeneralModels.ViewModels;

namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class UserFollowedProposalsResponseModel : PagingGeneralResponse
    {
        public List<UserFollowedProposal> FollowedProposalsList { get; set; }

        public UserFollowedProposalsResponseModel(int code, bool success, int recordCount, bool hasMore, int currentPageIndex, List<UserFollowedProposal> followedProposalsList)
        {
            Code = code;
            Success = success;
            RecordCount = recordCount;
            HasMore = hasMore;
            CurrentPageIndex = currentPageIndex;
            FollowedProposalsList = followedProposalsList;
        }
    }
}
