﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class UserBalance
    {
        public int UserId { get; set; }
        public int CurrencyId { get; set; }
        public string CurrencyName { get; set; }
        public string CurrencySymbol { get; set; }
        public string Balance { get; set; }
       
    }
}
