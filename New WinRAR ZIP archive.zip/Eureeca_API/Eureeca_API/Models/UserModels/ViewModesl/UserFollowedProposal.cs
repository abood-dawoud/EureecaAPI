﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class UserFollowedProposal
    {
        public string ProfilePitchTitle { get; set; }
        public int Pitch_ID { get; set; }
        public double SoFarPercentage { get; set; }
        public int PitchInvestors { get; set; }
        public bool CanInvest { get; set; }
        public bool IsFollower { get; set; }
        public bool HasExtraTime { get; set; }
        public bool IsClosed { get; set; }
        public bool IsComingSoon { get; set; }
        public int CurrentBlocksCount { get; set; }
        public int ActivitiesLogActivityID { get; set; }
        public int ActivitiesLogPStage { get; set; }
        public int RemainingTime { get; set; }
        public string RemainingTimeUnit { get; set; }
    }
}
