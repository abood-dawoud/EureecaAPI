﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class ProposalInvestor
    {
        public long UserID { get; set; }
        public string UserImage { get; set; }
        public string ProfileFirstName { get; set; }
        public string ProfileLastName { get; set; }
        public string ProfileObject { get; set; }
        public string User_UserName { get; set; }
        public double Investment_Amount { get; set; }
        public string InvestmentAmountFormatted { get; set; }
        public string PitchName { get; set; }
        public bool CanFollow { get; set; }
        public bool IsFollowed { get; set; }

    }
}
