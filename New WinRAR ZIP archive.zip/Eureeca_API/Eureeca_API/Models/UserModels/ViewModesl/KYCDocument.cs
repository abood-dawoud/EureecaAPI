﻿using Eureeca_API.Enums;
using Eureeca_API.Interface;

namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class KYCDocument
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string BtnText { get; set; }
        public bool IsBtnVisible { get; set; }
        public int Status { get; set; }
        public string StatusText { get; set; }
        public string WhyText { get; set; }
        public bool IsWhyVisible { get; set; }
        public string Placeholder { get; set; }
        public string Tooltip { get; set; }
        public string WhatToDo { get; set; }
        public KYCDocType kYCFileType { get; set; }

    }
}
