﻿namespace Eureeca_API.Models.UserModels.ViewModesl
{
    public class KeyInvestor
    {
        public string user_FirstName { get; set; }
        public string user_LastName { get; set; }
        public long Pitch_ID { get; set; }
        public double Investment_Amount { get; set; }
        public string pitch_Name { get; set; }
        public string Pitch_Admin_Arabic_Title { get; set; }


    }
}
