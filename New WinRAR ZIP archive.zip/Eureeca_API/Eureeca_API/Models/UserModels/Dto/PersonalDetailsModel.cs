﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.UserModels.Dto
{
    public class PersonalDetailsModel
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Languages LangId { get; set; }
        public bool IsInvestor { get; set; }
        public bool IsEntrepreneur { get; set; }
        public string ProfileSummary { get; set; }
        public string StreetAddress { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string PostalCode { get; set; }
        public string Phone { get; set; }
        public IFormFile? Image { get; set; }
    }
}
