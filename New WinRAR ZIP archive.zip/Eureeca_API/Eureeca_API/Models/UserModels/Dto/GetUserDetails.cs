﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.UserModels.Dto
{
    public class GetUserDetails
    {
        public int UserId { get; set; }
        public int LoggedInUserId { get; set; }
        public Languages LangId { get; set; }

    }
}
