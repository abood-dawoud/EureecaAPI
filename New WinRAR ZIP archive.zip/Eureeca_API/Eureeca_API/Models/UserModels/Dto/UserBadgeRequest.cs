﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.UserModels.Dto
{
    public class UserBadgeRequest
    {
        public bool GetExpertStats { get; set; }
        public bool GetPlatinumStats { get; set; }
        public Currencies CurrencyId { get; set; }

    }
}
