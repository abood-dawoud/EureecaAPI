﻿namespace Eureeca_API.Models.UserModels.Dto
{
    public class FolowUserRequestModel
    {
        public int UserId { get; set; }
        public int FollowedUserId { get; set; }
        public int LangId { get; set; }
    }
}
