﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.UserModels.Dto
{
    public class ChangePrefferedCurrency
    {
        public Currencies CurrencyId { get; set; }
    }
}
