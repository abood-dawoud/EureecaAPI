﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.UserModels.Dto
{
    public class CurrencyUserGeneral : UserGeneral
    {
        public Currencies CurrencyId { get; set; }
    }
}
