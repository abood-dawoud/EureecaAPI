﻿using System.ComponentModel.DataAnnotations;

namespace Eureeca_API.Models.UserModels.Dto
{
    public class KYCRequiredFiles : UserGeneral
    {
        [Required]
        public int CountryId { get; set; }
    }
}
