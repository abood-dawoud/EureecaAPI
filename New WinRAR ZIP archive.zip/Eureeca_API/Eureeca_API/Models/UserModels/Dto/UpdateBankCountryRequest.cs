﻿namespace Eureeca_API.Models.UserModels.Dto
{
    public class UpdateBankCountryRequest
    {
        public int UserId { get; set; }
        public int LangId { get; set; }
        public string CountryCode { get; set; }
    }
}
