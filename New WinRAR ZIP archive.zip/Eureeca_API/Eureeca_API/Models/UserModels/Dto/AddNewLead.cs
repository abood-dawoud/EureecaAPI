﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.UserModels.Dto
{
    public class AddNewLead
    {
        public int PitchId { get; set; }
        public string Email { get; set; }
        public Languages LangId { get; set; }
        public int CountryId { get; set; }

    }
}
