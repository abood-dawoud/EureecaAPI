﻿namespace Eureeca_API.Models.UserModels.Dto
{
    public class UserFollowedProposalsRequestModel
    {
        public int PitchLanguageId { get; set; }
        public int SoryBy { get; set; }
        public int UserCountry { get; set; }
        public int PageNo { get; set; }
        public int PageSize { get; set; } = 10;
    }
}
