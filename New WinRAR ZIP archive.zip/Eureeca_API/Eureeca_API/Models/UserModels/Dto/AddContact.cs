﻿namespace Eureeca_API.Models.UserModels.Dto
{
    public class AddContact
    {
        public int TargetUserId { get; set; }
    }
}
