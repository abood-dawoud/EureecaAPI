﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.UserModels.Dto
{
    public class GetInvestors
    {
        public string ListInvestorShowFilter { get; set; }
        public string SortFilterId { get; set; }
        public int CountryId { get; set; }
        public int BadgeId { get; set; }
        public string InvestorName { get; set; }
        public int PageNo { get; set; }
        public int PageSize { get; set; }
        public Languages LangId { get; set; }
        public Currencies CurrencyId { get; set; }
        public string? UserId { get; set; }
    }
}
