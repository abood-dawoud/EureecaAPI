﻿
using Eureeca_API.Enums;
using System.ComponentModel.DataAnnotations;

namespace Eureeca_API.Models.UserModels.Dto
{
    public class UserGeneral
    {
        [Required]
        public int UserId { get; set; }
        [Required]
        public Languages LangId { get; set; }
    }
}
