﻿namespace Eureeca_API.Models.UserModels.Dto
{
    public class UserPendingInvestmentsPercentageRequestModel
    {
        public int PitchLanguageId { get; set; }
        public int CurrencyId { get; set; }
        public int PageNo { get; set; }
        public int PageSize { get; set; } = 10;
    }
}
