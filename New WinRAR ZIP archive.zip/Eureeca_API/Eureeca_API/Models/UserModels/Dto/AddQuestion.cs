﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.UserModels.Dto
{
    public class AddQuestion
    {
        public string QuestionText { get; set; }
        public int TopicId { get; set; }
        public Languages LangId { get; set; }
    }
}
