﻿namespace Eureeca_API.Models.UserModels.Dto
{
    public class LoginModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
