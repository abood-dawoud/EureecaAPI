﻿namespace Eureeca_API.Models.InvestmentModels.ViewModels
{
    public class QuickInvestResponseModel
    {
        public int ResponseStatus { get; set; }
        public bool IsInvestmentCompleted { get; set; }
        public string Message { get; set; }
    }
}
