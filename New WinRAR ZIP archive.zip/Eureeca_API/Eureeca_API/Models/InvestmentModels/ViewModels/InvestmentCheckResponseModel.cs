﻿namespace Eureeca_API.Models.InvestmentModels.ViewModels
{
    public class InvestmentCheckResponseModel
    {
        public string PitchRate { get; set; }
        public bool IsAllowedInvestment { get; set; }
        public string PreventionMessage { get; set; }
        public int PitchBalance { get; set; }
        public double PitchInvestmentRequired { get; set; }
        public string MsgType { get; set; }
        public int RemainAllowedInv { get; set; }
        public string NewAmount { get; set; }
        public bool HasMaxUserInvAmount { get; set; }
        public int MaxInvAmount { get; set; }
        public string TxtNumberShare { get; set; }
        public int InvestmentWayFlag { get; set; }
        public double DollarsShares { get; set; }
        public double AmountForInvest { get; set; }

    }
}
