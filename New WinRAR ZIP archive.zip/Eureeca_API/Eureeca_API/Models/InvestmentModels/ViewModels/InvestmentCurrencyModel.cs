﻿namespace Eureeca_API.Models.InvestmentModels.ViewModels
{
    public class InvestmentCurrencyModel
    {
        public int CurrencyId { get; set; }
        public string CurrencySymbol { get; set; }
        public string CurrencyName { get; set; }
        public string UserBalance { get; set; }
        public double PitchExchangeRate { get; set; }
        public bool IsInvestEnabled { get; set; } = true; //this for change the default value
    }
}
