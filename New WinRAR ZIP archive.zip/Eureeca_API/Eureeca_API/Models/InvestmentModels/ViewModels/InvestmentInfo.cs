﻿namespace Eureeca_API.Models.InvestmentModels.ViewModels
{
    public class InvestmentInfo
    {
        public List<int> QuickInvestList { get; set; }
        public List<float> EquityList { get; set; }
        public double CurrentDiscount { get; set; }
        public string CurrentDiscountSizeCurrency { get; set; }
        public InvestmentCurrencyModel Currency { get; set; }


    }
}
