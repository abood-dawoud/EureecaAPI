﻿using Eureeca_API.Models.GeneralModels.ViewModels;

namespace Eureeca_API.Models.InvestmentModels.ViewModels
{
    public class InvestmentInfoResponseModel
    {
        public int PitchId { get; set; }
        public string PitchTitle { get; set; }
        public int ResponseStatus { get; set; }
        public string MinimumInvestmentRequired { get; set; }
        public string Raised { get; set; }
        public int SumPendingPreInvestmentsAfterDiscount { get; set; }
        public double PitchInvestmentRequired { get; set; }
        public string Raising { get; set; }
        public List<InvestmentInfo> InvestmentInfoList { get; set; }
        public List<Agreement> Agreements { get; set; }
        public bool ShowMalaysianWarning { get; set; }
        public string MalaysianWarning { get; set; }
        public bool HasDiscount { get; set; }
        public bool IsInvestmentPrevented { get; set; }
        public string PreventionReason { get; set; }
        public bool UserHasBalance { get; set; }
    }
}
