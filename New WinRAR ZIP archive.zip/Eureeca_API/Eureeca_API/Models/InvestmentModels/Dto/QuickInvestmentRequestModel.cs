﻿namespace Eureeca_API.Models.InvestmentModels.Dto
{
    public class QuickInvestmentRequestModel
    {
        public int Amount { get; set; }
        public int LangId { get; set; }
        public int CurrencyId { get; set; }
        public int ProposalId { get; set; }
        public int UserId { get; set; }
        public bool PreCommitProcess { get; set; }
        public bool SendInvestmentEmails { get; set; }
    }
}
