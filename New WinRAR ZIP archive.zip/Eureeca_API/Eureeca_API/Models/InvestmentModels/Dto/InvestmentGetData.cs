﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.InvestmentModels.Dto
{
    public class InvestmentGetData
    {
        public int PitchId { get; set; }
        public int UserId { get; set; }
        public Currencies CurrencyId { get; set; }
        public Languages LangId { get; set; }
    }
}
