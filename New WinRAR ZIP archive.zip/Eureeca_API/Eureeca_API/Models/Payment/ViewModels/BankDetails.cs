﻿namespace Eureeca_API.Models.Payment.ViewModels
{
    public class BankDetails
    {
        public int AccountId { get; set; }
        public int AccountBankId { get; set; }
        public int AccountCurrencyId { get; set; }
        public string AccountNumber { get; set; }
        public string AccountArchived { get; set; }
        public string AccountSortCode { get; set; }
        public string AccountSwift { get; set; }
        public string AccountIban { get; set; }
        public string AccountInstitution { get; set; }
        public int BankId { get; set; }
        public string BankName { get; set; }
        public string AccountName { get; set; }
        public string AccountAddress { get; set; }
        public string BankAddress { get; set; }
    }
}
