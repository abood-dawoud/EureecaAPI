﻿using Eureeca_API.Models.GeneralModels.ViewModels;

namespace Eureeca_API.Models.Payment.ViewModels
{
    public class PaymentCurrency : CurrencyModel
    {
        public int Bank_Details_ID { get; set; }
    }
}
