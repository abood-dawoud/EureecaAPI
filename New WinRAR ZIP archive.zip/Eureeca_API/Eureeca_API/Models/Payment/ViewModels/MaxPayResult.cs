﻿namespace Eureeca_API.Models.Payment.ViewModels
{
    public class MaxPayResult
    {
        public bool IsExceededMaxPay { get; set; }
        public string MaxPaymentAmount { get; set; }
        public string AvailablePaymentDate { get; set; }
    }
}
