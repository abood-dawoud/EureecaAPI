﻿namespace Eureeca_API.Models
{
    public class PaymentMethods
    {
        public bool ShowBank { get; set; }
        public bool ShowStripe { get; set; }
        public bool ShowCheckout { get; set; }
        public bool  AllowCredit { get; set; }
        public bool  AllowDebit { get; set; }
        public bool ShowPaymentNote { get; set; }
        public string PaymentNote { get; set; }
        public double EureecaFee { get; set; }
        public double AmountWithFee { get; set; }
    }
}
