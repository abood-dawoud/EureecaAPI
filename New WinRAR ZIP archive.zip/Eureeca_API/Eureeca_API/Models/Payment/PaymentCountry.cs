﻿namespace Eureeca_API.Models.Payment
{
    public class PaymentCountry
    {
        public bool IsAllowedToPay { get; set; }
        public string Text { get; set; }
        public string ReadMoreDetails { get; set; }
        public string Details { get; set; }
    }
}
