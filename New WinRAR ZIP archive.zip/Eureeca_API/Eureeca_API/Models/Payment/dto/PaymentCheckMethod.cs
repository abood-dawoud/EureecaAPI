﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.Payment.dto
{
    public class PaymentCheckMethod
    {
        public int PaymentAmount { get; set; }
        public int ProposalId { get; set; }
        public Languages LangId { get; set; }
        public Currencies CurrencyId { get; set; }
        public int CountryId { get; set; }
    }
}
