﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.Payment.dto
{
    public class GetCurrencies
    {
        public int BankCountryId { get; set; }
        public Languages LangId { get; set; }
    }
}
