﻿namespace Eureeca_API.Models.Payment
{
    public class PaymentProposalListRequestModel
    {
        public int UserId { get; set; }
        public int LangId { get; set; }
        public int CountryId { get; set; }
        public int CurrencyId { get; set; }
    }
}
