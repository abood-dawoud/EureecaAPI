﻿using Eureeca_API.Models.GeneralModels.ViewModels;

namespace Eureeca_API.Models.Payment
{
    public class PaymentUserModel
    {
        public int UserId { get; set; }
        public string Phone { get; set; }
        public Country BankCountry { get; set; }
        public bool IsAllowToChangeHisBankCountry { get; set; } = true;
        public bool IsKYCRequired { get; set; } 
        public string KYCOverAllStatus { get; set; } 
        public PaymentCountry PaymentCountryProperties { get; set; }

    }
}
