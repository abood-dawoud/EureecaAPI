﻿namespace Eureeca_API.Models.Payment
{
    public class PaymentProposalList
    {
        public int ProposalId { get; set; }
        public string ProposalTitle { get; set; }
        public int ProposalCountry { get; set; }
        public string ProposalStatus { get; set; }
        public int MinimumInvestmentAmount { get; set; }
        public string MinimumInvestmentNote { get; set; }
        public bool ProposalPreventExeption { get; set; }
        public int OwnerId { get; set; }
    }
}
