﻿
using Eureeca_API.Enums;

namespace Eureeca_API.Models.PitchModels.RequestModel
{
    public class PitchFinancial
    {
        public int PitchId { get; set; }
        public Languages LangId { get; set; }
        public Currencies CurrencyId { get; set; }
    }
}
