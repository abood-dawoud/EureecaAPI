﻿using Eureeca_API.Enums;
using System.ComponentModel.DataAnnotations;

namespace Eureeca_API.Models.PitchModels.Dto
{
    public class PitchGeneral
    {
        [Required]
        public int PitchId { get; set; }
        [Required]
        public Languages LangId { get; set; }
    }
}
