﻿namespace Eureeca_API.Models.PitchModels.Dto
{
    public class AcceptRequest : ProccessRequest
    {
        public int RequestType { get; set; }

    }
}
