﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.PitchModels.Dto
{
    public class AddNewInterest
    {
        public int PitchId { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public int CountryId { get; set; }
        public Languages LangId { get; set; }

    }
}
