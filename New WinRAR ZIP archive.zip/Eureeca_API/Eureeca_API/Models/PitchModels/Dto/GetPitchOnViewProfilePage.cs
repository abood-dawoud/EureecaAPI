﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.PitchModels.Dto
{
    public class GetPitchOnViewProfilePage
    {
        public Languages LangId { get; set; }
        public int CountryId { get; set; }
        public int CurrecnyId { get; set; }
        public string LoggedinUserId { get; set; }
        public int UserId { get; set; }

    }
}
