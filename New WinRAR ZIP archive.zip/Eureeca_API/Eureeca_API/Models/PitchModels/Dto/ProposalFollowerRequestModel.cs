﻿namespace Eureeca_API.Models.PitchModels.Dto
{
    public class ProposalFollowerRequestModel
    {
        public int PitchId { get; set; }
        public int LangId { get; set; }
        public int? UserId { get; set; }
        public int PageNo { get; set; }
        public int PageSize { get; set; } = 10;


    }
}
