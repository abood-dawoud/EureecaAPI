﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.PitchModels.Dto
{
    public class RequestEarlyAccess
    {
        public int PitchId { get; set; }
        public Languages LangId { get; set; }
    }
}
