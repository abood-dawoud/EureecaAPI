﻿namespace Eureeca_API.Models.PitchModels.Dto
{
    public class ApproveAllUserRequest
    {
        public int ProposalId { get; set; }
        public int UserId { get; set; }
        public int LangId { get; set; }

    }
}
