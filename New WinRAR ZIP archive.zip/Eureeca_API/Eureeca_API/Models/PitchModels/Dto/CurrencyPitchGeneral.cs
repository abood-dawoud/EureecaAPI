﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.PitchModels.Dto
{
    public class CurrencyPitchGeneral : PitchGeneral
    {
        public Currencies CurrencyId { get; set; }
    }
}
