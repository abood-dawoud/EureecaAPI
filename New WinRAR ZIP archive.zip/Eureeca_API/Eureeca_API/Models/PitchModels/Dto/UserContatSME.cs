﻿namespace Eureeca_API.Models.PitchModels.Dto
{
    public class UserContatSME
    {
        public int PitchId { get; set; }
        public int UserId { get; set; }
        public int RequestType { get; set; }
    }
}
