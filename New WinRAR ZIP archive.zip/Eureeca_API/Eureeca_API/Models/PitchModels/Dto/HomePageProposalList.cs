﻿using Eureeca_API.Enums;
using Eureeca_API.Interface;

namespace Eureeca_API.Models.PitchModels.RequestModel
{
    public class HomePageProposalList
    {
        public Languages LangId { get; set; }
        public Currencies CurrencyId { get; set; }
        public int CountryId { get; set; }
        public string? UserId { get; set; }
    }
}
