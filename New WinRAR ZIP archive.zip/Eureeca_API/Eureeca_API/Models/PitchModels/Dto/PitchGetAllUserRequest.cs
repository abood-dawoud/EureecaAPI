﻿using Eureeca_API.Enums;
using System.ComponentModel.DataAnnotations;

namespace Eureeca_API.Models.PitchModels.Dto
{
    public class PitchGetAllUserRequest
    {
        [Required]
        public int ProposalId { get; set; }
        [Required]
        public Languages LangId { get; set; }
        [Required]
        public int PageNo { get; set; }
        public int PageSize { get; set; } = 10;
    }
}
