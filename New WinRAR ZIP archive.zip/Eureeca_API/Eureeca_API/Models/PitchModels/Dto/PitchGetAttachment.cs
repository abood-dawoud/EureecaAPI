﻿namespace Eureeca_API.Models.PitchModels.Dto
{
    public class PitchGetAttachment : PitchGeneral
    {
        public int UserId { get; set; }
    }
}
