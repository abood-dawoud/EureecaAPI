﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.PitchModels.Dto
{

    public class GetCompletedPitchListRequest
    {
        public Languages LangId { get; set; }
        public Currencies CurrencyId { get; set; }
        public int CountryId { get; set; }
        public int UserId { get; set; }
        public int CategoryID { get; set; }
        public PitchSorting Sorting { get; set; }
        public int TagID { get; set; }
        public int PageNo { get; set; }
        public int PageSize { get; set; }
    }
}