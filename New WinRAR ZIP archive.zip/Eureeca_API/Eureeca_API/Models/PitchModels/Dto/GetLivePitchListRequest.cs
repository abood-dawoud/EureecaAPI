﻿namespace Eureeca_API.Models.PitchModels.Dto
{
    public class GetLivePitchListRequest : GetCompletedPitchListRequest
    {
        public bool IsPublished { get; set; }
    }
}
