﻿namespace Eureeca_API.Models.PitchModels.Dto
{
    public class ProccessRequest
    {
        public int UserId { get; set; }
        public int RequestId { get; set; }
        public int ProposalId { get; set; }
        public int LangId { get; set; }
    }
}
