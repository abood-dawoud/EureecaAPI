﻿namespace Eureeca_API.Models.PitchModels.Dto
{
    public class AddUpdateRequestModel
    {
        public string Update { get; set; }
        public int PitchId { get; set; }
        public int LangId { get; set; }
    }
}
