﻿namespace Eureeca_API.Models.PitchModels.Dto
{
    public class FollowProposalRequestModel
    {
        public string UserId { get; set; }
        public string ProposalId { get; set; }
        public int LangId { get; set; }
    }
}
