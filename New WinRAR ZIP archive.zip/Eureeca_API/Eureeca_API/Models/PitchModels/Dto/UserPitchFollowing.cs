﻿namespace Eureeca_API.Models.PitchModels.Dto
{

    public class UserPitchFollowing
    {
        public string Profile_FirstName { get; set; }
        public string Profile_LastName { get; set; }
        public string User_Picture { get; set; }
        public long User_ID { get; set; }
        public DateTime? Investment_Date { get; set; }

    }
}