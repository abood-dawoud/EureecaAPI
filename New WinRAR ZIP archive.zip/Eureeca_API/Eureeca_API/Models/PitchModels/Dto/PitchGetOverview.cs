﻿using Eureeca_API.Enums;
using System.ComponentModel.DataAnnotations;

namespace Eureeca_API.Models.PitchModels.Dto
{
    public class PitchGetOverview : PitchGeneral
    {
        [Required]
        public Currencies CurrencyId { get; set; }
        [Required]
        public int CountryId { get; set; }
        public string? UserId { get; set; }

    }
}
