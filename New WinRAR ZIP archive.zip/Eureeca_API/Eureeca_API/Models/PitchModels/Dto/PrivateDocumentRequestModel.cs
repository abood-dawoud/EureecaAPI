﻿namespace Eureeca_API.Models.PitchModels.Dto
{
    public class PrivateDocumentRequestModel
    {
        public int PitchId { get; set; }
        public int UserId { get; set; }
        public string PitchTitle { get; set; }
    }
}
