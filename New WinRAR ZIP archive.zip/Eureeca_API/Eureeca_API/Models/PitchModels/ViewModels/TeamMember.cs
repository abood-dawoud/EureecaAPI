﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class TeamMember
    {
        public int Teams_Profile_ID { get; set; }
        public string Teams_Name { get; set; }
        public string Teams_Position { get; set; }
        public string Teams_Image { get; set; }
        public string Teams_Biography { get; set; }
    }
}
