﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class ProposalRequest
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string RequestTypeText { get; set; }
        public int Status { get; set; }
        public int RequestId { get; set; }
        public int RequestType { get; set; }
    }
}
