﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class PitchOverview
    {
        public int PitchId { get; set; }
        public string BackgroundImg { get; set; }
        public string Logo { get; set; }
        public string Stage { get; set; }
        public bool CanFollow { get; set; }
        public bool IsInvestEnabled { get; set; }
        public bool IsFollowed { get; set; }
        public bool HasDiscount { get; set; }
        public double CurrentTranchDiscount { get; set; }
        public double CurrentRemainingTrancheSize { get; set; }
        public List<PitchSecondayLocation> SecondayLocations { get; set; }
        public long InvestorsNumbers { get; set; }
        public decimal PreMoneyVal { get; set; }
        public string PreMoneyValText { get; set; }
        public string ClosingDate { get; set; }
        public string FacebookLink { get; set; }
        public string TwitterLink { get; set; }
        public string LinkedInLink { get; set; }
        public List<Tag> Tags { get; set; }
        public List<Badge> Badges { get; set; }
        public int HighestInvestment { get; set; }
        public string HighestInvestmentText { get; set; }
        public string CategoryName { get; set; }
        public string CategoryArName { get; set; }
        public string ShortSummary { get; set; }
        public string PitchTitle { get; set; }
        public string CountryId { get; set; }
        public string CountryName { get; set; }
        public string CountryFlag { get; set; }
        public bool IsAllowedSecondaryMarket { get; set; }
        public bool IsViewPrevented { get; set; }
        public double Equity { get; set; }
        public string AccessCode { get; set; }
        public int EarlyAccessMode { get; set; }
        public bool IsLanguageNotSupport { get; set; }
        public bool ShowMalaysianPopup { get; set; }
        public string MalaysianPopupText { get; set; }
        public int MalaysianPopupMessageType { get; set; }
        public int ProposalOwnerId { get; set; }
        public string ProposalOwnerFirstName { get; set; }
        public string ProposalOwnerLastName { get; set; }
        public string ProposalOwnerImage { get; set; }
        public string PitchPercantage { get; set; }
        public string OverfundingFormatted { get; set; }

    }
}
