﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class PitchScorePitchDetails
    {
        public string PitchTitle { get; set; }
        public string CreationDate { get; set; }
        public string ClosingDate { get; set; }
        public double Target { get; set; }
        public double PreMoney { get; set; }
        public double Equity { get; set; }
        public string ShortSummary { get; set; }
        public string Country { get; set; }
    }
}
