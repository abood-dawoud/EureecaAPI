﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class PitchBanner
    {
        public int PitchId { get; set; }
        public string PitchStatus { get; set; }
        public bool IsInvestEnabled { get; set; }
        public string PitchBannerTitle { get; set; }
        public string PitchBannerBody { get; set; }
        public string ImageURL { get; set; }
        public int RemainInvestorCount { get; set; }
        public List<Investor> Investors { get; set; }
    }
}
