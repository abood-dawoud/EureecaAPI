﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class HomePageProposals
    {
        public List<Pitch> LiveProposals { get; set; }
        public List<Pitch> EAProposals { get; set; }
    }
}
