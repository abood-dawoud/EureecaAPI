﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class ProposalBusinessDetails
    {
        public string WhyTxt { get; set; }
        public string WhyImage { get; set; }
        public string NotablePressTxt { get; set; }
        public string AtGlanceTitle1 { get; set; }
        public string AtGlaceDescription1 { get; set; }
        public string AtGlaceIcon1 { get; set; }
        public string AtGlanceTitle2 { get; set; }
        public string AtGlaceDescription2 { get; set; }
        public string AtGlaceIcon2 { get; set; }
        public string AtGlanceTitle3 { get; set; }
        public string AtGlaceDescription3 { get; set; }
        public string AtGlaceIcon3 { get; set; }
        public string IdeaTxt { get; set; }
        public string IdeaImage { get; set; }
        public string CompanyTxt { get; set; }
        public string CompanyImage { get; set; }
        public string MoneyText { get; set; }
        public string StratigyText { get; set; }
        public string KeyInvestorPerson { get; set; }
        public string KeyPressJornal { get; set; }



    }
}
