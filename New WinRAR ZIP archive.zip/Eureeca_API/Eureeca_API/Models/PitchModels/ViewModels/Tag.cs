﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class Tag
    {
        public int Id { get; set; }
        public string TagName { get; set; }
        public string TagArName { get; set; }
    }
}
