﻿using Eureeca_API.Models.UserModels.ViewModesl;

namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class Question
    {
        public int QuestionId { get; set; }
        public string QuestionText { get; set; }
        public string QuestionDate { get; set; }
        public User Questioner { get; set; }
        public int RelationToSME { get; set; }
        public string RelationToSMEWhenOther { get; set; }
        public List<Answer> Answers { get; set; }
    }
}
