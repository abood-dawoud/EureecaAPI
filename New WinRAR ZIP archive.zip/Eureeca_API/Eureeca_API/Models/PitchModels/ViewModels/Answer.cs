﻿using Eureeca_API.Models.UserModels.ViewModesl;

namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class Answer
    {
        public int AnswerId { get; set; }
        public string AnswerText { get; set; }
        public string AnswerDate { get; set; }
        public User Answerer { get; set; }

    }
}
