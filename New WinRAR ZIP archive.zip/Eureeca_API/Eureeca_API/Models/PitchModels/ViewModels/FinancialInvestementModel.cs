﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class FinancialInvestementModel
    {
        public string UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Picture { get; set; }
        public string Username { get; set; }
        public string UserObject { get; set; }
        public string UserScore { get; set; }
        public double InvestmentAmount { get; set; }
        public string InvestmentDate { get; set; }
        public string InvestmentPercent { get; set; }
        public int XAxis { get; set; }
        public double YAxis { get; set; }
    }
}
