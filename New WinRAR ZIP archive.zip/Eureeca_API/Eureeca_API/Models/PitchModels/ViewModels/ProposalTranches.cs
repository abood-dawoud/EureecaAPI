﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class ProposalTranches
    {
        public bool HasDiscount { get; set; }

        public double Tranch1Size { get; set; }
        public string Tranch1SharePrice { get; set; }
        public string Tranch1RemainingShares { get; set; }
        public string Tranch1Discount { get; set; }

        public double Tranch2Size { get; set; }
        public string Tranch2SharePrice { get; set; }
        public string Tranch2RemainingShares { get; set; }
        public string Tranch2Discount { get; set; }

        public double Tranch3Size { get; set; }
        public string Tranch3SharePrice { get; set; }
        public string Tranch3RemainingShares { get; set; }
        public string Tranch3Discount { get; set; }

        public double Tranch4Size { get; set; }
        public string Tranch4SharePrice { get; set; }
        public string Tranch4RemainingShares { get; set; }
        public string Tranch4Discount { get; set; }

        public int ActiveTranch { get; set; }

        public string EarlyAaccessTranchDiscountLbl { get; set; }
        public bool EarlyAaccessTranchDiscountLblVisibility { get; set; }
        public string EarlyAaccessTranchDiscountShares { get; set; }

    }
}
