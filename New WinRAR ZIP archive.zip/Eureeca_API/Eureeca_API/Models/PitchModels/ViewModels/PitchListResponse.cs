﻿using Eureeca_API.Models.GeneralModels.ViewModels;

namespace Eureeca_API.Models.PitchModels.ViewModels
{

    public class PitchListResponse : PagingGeneralResponse
    {
        public List<Pitch> Pitchs { get; set; }

        public PitchListResponse(int code, bool success, int recordCount, bool hasMore, int currentPageIndex, List<Pitch> completedPitchs)
        {
            Code = code;
            Success = success;
            RecordCount = recordCount;
            HasMore = hasMore;
            CurrentPageIndex = currentPageIndex;
            Pitchs = completedPitchs;
        }
    }
}