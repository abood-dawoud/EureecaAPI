﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class ProposalDoc
    {
        public string Id { get; set; }
        public string AttachementName { get; set; }
        public string AttachementTitle { get; set; }
        public bool IsPrivate { get; set; }
        public string Icon { get; set; }
        public string FileURL { get; set; }
        public string FileExtension { get; set; }

    }
}
