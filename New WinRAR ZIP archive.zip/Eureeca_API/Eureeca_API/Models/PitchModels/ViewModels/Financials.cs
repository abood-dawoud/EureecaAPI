﻿using Microsoft.AspNetCore.JsonPatch.Operations;

namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class Financials
    {
        public string BaseTarget { get; set; }
        public string Raised { get; set; }
        public string MinimumTarget { get; set; }
        public string TableTitle { get; set; }
        public string TableTitleForcast { get; set; }
        public string Currency { get; set; }
        public string RowTableIndex { get; set; }
        public List<string> Summary { get; set; }
        public List<FinancialForecastModel> FinancialForecastModels { get; set; }
        public List<FinancialInvestementModel> InvestmentChartData { get; set; }

    }
}
