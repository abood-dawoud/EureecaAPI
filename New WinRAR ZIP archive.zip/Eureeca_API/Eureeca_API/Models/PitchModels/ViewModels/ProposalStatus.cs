﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class ProposalStatus
    {
        public ProposalCheckList ProposalCheckList { get; set; }
        public SMEDashboardProposal Proposal { get; set; }



    }


    public class ProposalCheckList
    {
        public bool IsCheckListOnly { get; set; }
        public int CheckListStatus { get; set; }
        public string CheckListMessage { get; set; }
        public bool IsCheckListAccepted { get; set; }

    }

    public class SMEDashboardProposal
    {
        public int ProposalId { get; set; }
        public string ProposalTitle { get; set; }
        public int ProposalStatus { get; set; }
        public string ProposalStatusTxt { get; set; }
        public int InvestorNumber { get; set; }
        public string ProposalPercantage { get; set; }
        public string EquitySold { get; set; }
        public string SharesSold { get; set; }
        public int FollowersNumber { get; set; }
        public int CompletePercentage { get; set; }
        public string Raised { get; set; }
        public Investor MostRecentInvestor { get; set; }
        public Investor LeadInvestor { get; set; }

    }

    public class Investor
    {
        public int Id { get; set; }
        public string username { get; set; }
        public string InvestmentAmount { get; set; }
        public string InvestmentSince { get; set; }
        public string UserImage { get; set; }

    }

}
