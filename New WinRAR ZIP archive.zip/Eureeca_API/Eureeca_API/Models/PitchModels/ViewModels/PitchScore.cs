﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class PitchScore
    {
        public int PitchId { get; set; }
        public int HasPitchDeckRank { get; set; }
        public int FinancialsHasHistoricalsAndProjectionsRank { get; set; }
        public int CountryRank { get; set; }
        public int IsReligiouslyPoliticallySexuallyAffiliatedRank { get; set; }
        public int ProblemsInThePastRank { get; set; }
        public int RecognizableBuisnessRank { get; set; }
        public int HowComplicatedRank { get; set; }
        public int IsBadRank { get; set; }
        public int YearsInOperationRank { get; set; }
        public int IdeaRank { get; set; }
        public int TeamViewRank { get; set; }
        public int SucceedingRank { get; set; }
        public int ScalabilityRank { get; set; }
        public int BusinessIsAlreadyRevenueRank { get; set; }
        public int WebsiteRank { get; set; }
        public int HowMuchCompanyRaisingRank { get; set; }
        public float Score { get; set; }
        public string BDNotes { get; set; }
        public string PrefferedLinks { get; set; }
        public string RM { get; set; }
    }
}
