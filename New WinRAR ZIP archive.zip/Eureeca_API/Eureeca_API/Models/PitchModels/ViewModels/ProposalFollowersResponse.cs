﻿using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.UserModels.ViewModesl;

namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class ProposalFollowersResponse : PagingGeneralResponse
    {
        public List<Follower> ProposalFollowers { get; set; }

        public ProposalFollowersResponse(int code, bool success, int recordCount, bool hasMore, int currentPageIndex, List<Follower> proposalFollowers)
        {
            Code = code;
            Success = success;
            RecordCount = recordCount;
            HasMore = hasMore;
            CurrentPageIndex = currentPageIndex;
            ProposalFollowers = proposalFollowers;
        }
    }
}
