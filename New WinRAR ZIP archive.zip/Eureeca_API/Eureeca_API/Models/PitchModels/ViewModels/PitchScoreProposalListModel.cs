﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class PitchScoreProposalListModel
    {
        public int PitchId { get; set; }
        public string PitchTitle { get; set; }
        public string PitchScore { get; set; }
    }
}
