﻿using Eureeca_API.Models.PitchModels.Dto;

namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class Pitch
    {
        public long Pitch_ID { get; set; }
        public string? profile_country_name { get; set; }
        public string? country_flag { get; set; }
        public string? Profile_PitchCity { get; set; }
        public string? Pitch_Status { get; set; }
        public bool Pitch_HasDiscount { get; set; }
        public bool Pitch_IsInvestmentFrozen { get; set; }
        public string? Profile_PitchTitle { get; set; }
        public string? Profile_PitchShortSummary { get; set; }
        public int Profile_PitchOrder { get; set; }
        public string? SME_firstName { get; set; }
        public string? SME_lastName { get; set; }
        public string? Logo { get; set; }
        public string? VideoId { get; set; }
        public string? WidgetImage { get; set; }
        public long Followers { get; set; }
        public double Pitch_InvestmentRequired { get; set; }
        public string Pitch_InvestmentRequiredFormatted { get; set; }
        public double Pitch_Balance { get; set; }
        public string Pitch_BalanceFormatted { get; set; }
        public long Pitch_Investors { get; set; }
        public decimal Pitch_Post_Money_Val { get; set; }
        public List<Badge> Badges { get; set; }
        public string ProgressLbl { get; set; }
        public int offlineProgressWidth { get; set; }
        public int preRaisedProgressWidth { get; set; }
        public int InstitutionalProgressWidth { get; set; }
        public int progressWidth { get; set; }
        public bool viewTooltip { get; set; }
        public bool viewInstitutionalInvestmentNote { get; set; }
        public string PreRaisedTooltip { get; set; }
        public string privateToolTip { get; set; }
        public string crowdFundingTooltip { get; set; }
        public string InstitutionalInvestmentTooltip { get; set; }
        public string InstitutionalInvestmentSoFarNote { get; set; }
        public bool MinArrowVisiblity { get; set; }
        public int MinArrowDistance { get; set; }
        public string MinAmountText { get; set; }
        public string MinNote { get; set; }
        public bool isFollowed { get; set; }
        public bool canFollow { get; set; }
        public bool isInvestEnabled { get; set; }
        public double PreMoneyValuation { get; set; }
        public double EquityOffered { get; set; }
        public double HighestInvestment { get; set; }
        public double OverfundingTaget { get; set; }
        public bool EarlyAccessMode { get; set; }
        public string EarlyAccessCode { get; set; }
        public bool IsBlured { get; set; }
        public bool IsKYCBlured { get; set; }
        public bool IsConfidetnial { get; set; }
        public int SMEId { get; set; }

        public List<UserPitchFollowing> UserPitchFollowing { get; set; }
	}
}
