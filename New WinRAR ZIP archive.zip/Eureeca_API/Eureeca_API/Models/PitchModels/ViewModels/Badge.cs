﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class Badge
    {
        public int Badge_ID { get; set; }
        public string Badge_BGColor { get; set; }
        public string Badge_Name { get; set; }
        public string Badge_Description { get; set; }

    }
}
