﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class EOIProposal
    {
        public int PitchId { get; set; }
        public string PitchTitle { get; set; }
    }
}
