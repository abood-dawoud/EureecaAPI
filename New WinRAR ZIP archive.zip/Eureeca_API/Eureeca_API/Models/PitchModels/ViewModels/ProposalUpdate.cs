﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class PitchUpdate
    {
        public string PitchUpdate_Text { get; set; }
        public DateTime PitchUpdate_Date { get; set; }
    }
}
