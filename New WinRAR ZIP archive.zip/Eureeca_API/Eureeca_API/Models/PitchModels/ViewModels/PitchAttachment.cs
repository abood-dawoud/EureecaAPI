﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class PitchAttachment
    {
        public List<string> images { get; set; }
        public string videoDescription { get; set; }
        public string videoId { get; set; }
        public List<ProposalDoc> PrivateDoc { get; set; }
        public List<ProposalDoc> PublicDoc { get; set; }
        public bool IsPrivateDocAccessRequested { get; set; }
        public int PrivateDocAccessRequestStatus { get; set; }

    }
}
