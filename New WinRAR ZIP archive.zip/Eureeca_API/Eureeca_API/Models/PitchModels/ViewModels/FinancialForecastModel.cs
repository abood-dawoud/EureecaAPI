﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class FinancialForecastModel
    {
        public string Title { get; set; }
        public List<string> Data { get; set; }
        public bool IsSelected { get; set; }
    }
}
