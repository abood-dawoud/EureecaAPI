﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{

    public partial class Category
    {
        public long Category_ID { get; set; }
        public string Category_Name { get; set; }
        public string Category_Ar_Name { get; set; }
        public string Category_Sp_Name { get; set; }
    }
}