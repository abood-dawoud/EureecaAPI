﻿using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.UserModels.ViewModesl;

namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class ProposalInvestorsResponse : PagingGeneralResponse
    {
        public List<ProposalInvestor> ProposalInvestors { get; set; }

        public ProposalInvestorsResponse(int code, bool success, int recordCount, bool hasMore, int currentPageIndex, List<ProposalInvestor> proposalInvestors)
        {
            Code = code;
            Success = success;
            RecordCount = recordCount;
            HasMore = hasMore;
            CurrentPageIndex = currentPageIndex;
            ProposalInvestors = proposalInvestors;
        }
    }
}
