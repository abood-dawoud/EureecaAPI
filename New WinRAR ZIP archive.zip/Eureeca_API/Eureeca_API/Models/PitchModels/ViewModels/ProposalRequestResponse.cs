﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class ProposalRequestResponse
    {
        public int Code { get; set; }
        public bool Success { get; set; }
        public int TotalRows { get; set; }
        public bool HasMore { get; set; }
        public int CurrentPageIndex { get; set; }
        public bool EnableApprovaAllBtn { get; set; }
        public List<ProposalRequest> Requests { get; set; }

        public ProposalRequestResponse(int code, bool success, int totalRows, bool hasMore, int currentPageIndex, bool enableApprovaAllBtn, List<ProposalRequest> requests)
        {
            Code = code;
            Success = success;
            TotalRows = totalRows;
            HasMore = hasMore;
            CurrentPageIndex = currentPageIndex;
            EnableApprovaAllBtn = enableApprovaAllBtn;
            Requests = requests;

        }
    }
}
