﻿namespace Eureeca_API.Models.PitchModels.ViewModels
{
    public class PitchSecondayLocation
    {
        public int CountryId { get; set; }
        public string CountryName { get; set; }
        public string CountryFlag { get; set; }
    }
}
