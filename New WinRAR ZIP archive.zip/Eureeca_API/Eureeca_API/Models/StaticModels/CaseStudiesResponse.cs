﻿namespace Eureeca_API.Models.StaticModels
{
    public class CaseStudiesResponse
    {
        public string Title { get; set; }
        public string Subtitle { get; set; }
        public List<Object> ImageDetails { get; set; }
    }
}
