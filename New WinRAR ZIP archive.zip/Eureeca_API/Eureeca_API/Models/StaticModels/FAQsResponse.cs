﻿namespace Eureeca_API.Models.StaticModels
{
    public class FAQsResponse
    {
        public string FAQTitle { get; set; }
        public string General { get; set; }
        public string Entrepreneurs { get; set; }
        public string Investors { get; set; }
        public string FAQSearchPlaceholder { get; set; }
        public string CategoryBrowse { get; set; }
        public List<object> GeneralFAQs { get; set;}
        public List<object> EntrepreneurFAQs { get; set;}
        public List<object> InvestorFAQs { get; set;}
    }
}
