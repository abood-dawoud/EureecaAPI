﻿namespace Eureeca_API.Models.StaticModels
{
    public class AboutUsResponse
    {
        public string Title { get; set; }
        public string Subtitle { get; set; }
        public string Content { get; set; }
        public string VideoId { get; set; }
    }
}
