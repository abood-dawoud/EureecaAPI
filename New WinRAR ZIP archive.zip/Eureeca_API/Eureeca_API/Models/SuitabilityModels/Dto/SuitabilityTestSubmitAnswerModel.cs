﻿namespace Eureeca_API.Models.SuitabilityModels.Dto
{
    public class SuitabilityTestSubmitAnswerModel
    {
        public int UserId { get; set; }
        public int CountryId { get; set; }
        public List<SuitabilityAnswer> Answers { get; set; }
        public int LangId { get; set; }
    }
}
