﻿namespace Eureeca_API.Models.SuitabilityModels.Dto
{
    public class SuitabilityAnswer
    {
        public int QuestionId { get; set; }
        public int AnswerId { get; set; }
    }
}
