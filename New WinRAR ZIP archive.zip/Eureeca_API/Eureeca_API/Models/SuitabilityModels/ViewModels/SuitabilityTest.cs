﻿namespace Eureeca_API.Models.SuitabilityModels.ViewModels
{
    public class SuitabilityTest
    {
        public int Id { get; set; }
        public string Question { get; set; }
        public string QuestionNote { get; set; }
        public string UserAnswer { get; set; }
        public string CorrectAnswer { get; set; }
        public string RefillMessage { get; set; }
        public bool ShowRefillMessage { get; set; }
        public List<SuitabilityTestAnswer> Answers { get; set; }

    }
}
