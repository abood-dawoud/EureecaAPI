﻿namespace Eureeca_API.Models.SuitabilityModels.ViewModels
{
    public class SuitabilityTestAnswer
    {
        public int AnswerId { get; set; }
        public string AnswerText { get; set; }
        public int Row { get; set; }
    }
}
