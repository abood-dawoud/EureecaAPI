﻿using Eureeca_API.Enums;
using Eureeca_API.Models.UserModels.ViewModesl;

namespace Eureeca_API.Models.SuitabilityModels.ViewModels
{
    public class SuitabilityTestSubmitAnswerResponse
    {
        public string Status { get; set; }
        public bool BtnTry { get; set; }
        public string FailTitle { get; set; }
        public string FailDesc1 { get; set; }
        public string FailDesc2 { get; set; }
        public string CurrentActivation { get; set; }

        public ResponseStatus ResponseStatus { get; set; }
        public User User { get; set; }

    }
}
