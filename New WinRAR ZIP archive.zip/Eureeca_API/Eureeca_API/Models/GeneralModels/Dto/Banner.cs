﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.GeneralModels.Dto
{
    public class Banner
    {
        public int CountryId { get; set; }
        public Languages LangId { get; set; }
        public Currencies CurrencyId { get; set; }
        public int UserId { get; set; }
    }
}
