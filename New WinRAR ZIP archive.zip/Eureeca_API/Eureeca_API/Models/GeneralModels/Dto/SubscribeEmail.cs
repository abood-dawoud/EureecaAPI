﻿using Eureeca_API.Enums;

namespace Eureeca_API.Models.GeneralModels.Dto
{
    public class SubscribeEmail
    {
        public Languages LangId { get; set; }
        public string Email { get; set; }
        public int CountryId { get; set; }

    }
}
