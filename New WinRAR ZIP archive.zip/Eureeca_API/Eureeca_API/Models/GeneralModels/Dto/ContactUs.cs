﻿namespace Eureeca_API.Models.GeneralModels.Dto
{
    public class ContactUs
    {
        public string Phone { get; set; }
        public string EmailContact { get; set; }
        public string ContactId { get; set; }
        public string Name { get; set; }
        public string Details { get; set; }
    }
}
