﻿namespace Eureeca_API.Models.GeneralModels.Dto
{
    public class GeoIPRequestModel
    {
        public string UserIP { get; set; }
        public int LangId { get; set; }
    }
}
