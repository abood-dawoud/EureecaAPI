﻿using System.ComponentModel.DataAnnotations;

namespace Eureeca_API.Models.GeneralModels.Dto
{
    public class Stats
    {
        public string? StatsId { get; set; }
        [Required]
        public int CurrencyId { get; set; }

    }
}
