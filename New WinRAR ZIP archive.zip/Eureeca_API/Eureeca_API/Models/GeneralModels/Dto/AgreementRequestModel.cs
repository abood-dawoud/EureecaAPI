﻿using Eureeca_API.Enums;
using System.ComponentModel.DataAnnotations;

namespace Eureeca_API.Models.GeneralModels.Dto
{
    public class AgreementRequestModel
    {
        [Required]
        public Languages LangId { get; set; }
        [Required]
        public int CountryId { get; set; }
    }
}
