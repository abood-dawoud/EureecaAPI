﻿namespace Eureeca_API.Models.GeneralModels.ViewModels
{
    public class PagingGeneralResponse
    {
        public int Code { get; set; }
        public bool Success { get; set; }
        public int RecordCount { get; set; }
        public bool HasMore { get; set; }
        public int CurrentPageIndex { get; set; }
    }
}
