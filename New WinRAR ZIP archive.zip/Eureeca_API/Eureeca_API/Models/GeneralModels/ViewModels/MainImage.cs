﻿namespace Eureeca_API.Models.GeneralModels.ViewModels
{
    public class MainImage
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Body { get; set; }
        public string ImageURL { get; set; }
        public bool ShowButtons { get; set; }
        public string CustomButtonTitle { get; set; }
        public string CustomButtonURL { get; set; }
    }
}
