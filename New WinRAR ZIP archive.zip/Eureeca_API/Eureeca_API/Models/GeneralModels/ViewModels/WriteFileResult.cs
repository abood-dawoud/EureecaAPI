﻿namespace Eureeca_API.Models.GeneralModels.ViewModels
{
    public class WriteFileResult
    {
        public string FileName { get; set; }
        public bool IsSaved { get; set; }
    }
}
