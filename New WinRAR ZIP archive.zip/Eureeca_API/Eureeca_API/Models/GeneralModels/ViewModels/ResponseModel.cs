﻿namespace Eureeca_API.Models.GeneralModels.ViewModels
{
    public class ResponseModel
    {
        public int code { get; set; }
        public string Message { set; get; }
        public bool success { set; get; }
        public List<object> data { get; set; }
    }
}
