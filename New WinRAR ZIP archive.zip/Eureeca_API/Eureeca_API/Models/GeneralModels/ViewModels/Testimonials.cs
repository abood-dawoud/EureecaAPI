﻿namespace Eureeca_API.Models.GeneralModels.ViewModels
{
    public class Testimonials
    {
        public string? Img_Name { get; set; }
        public string? Details { get; set; }
    }
}
