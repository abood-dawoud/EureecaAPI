﻿namespace Eureeca_API.Models.GeneralModels.ViewModels
{
    public class CurrencyModel
    {
        public int Currency_ID { get; set; }
        public int Currency_LangID { get; set; }
        public int Currency_Merchant { get; set; }
        public string Currency_Min { get; set; }
        public string? Currency_Symbol { get; set; }
        public string? Currency { get; set; }
        public double Currency_GlobalExchangeRate { get; set; }




    }
}
