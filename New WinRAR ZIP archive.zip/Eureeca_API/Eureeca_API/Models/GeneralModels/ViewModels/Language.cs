﻿namespace Eureeca_API.Models.GeneralModels.ViewModels
{
    public class Language
    {
        public int Language_ID { get; set; }
        public string? Language_Code { get; set; }
        public string? Language_Title { get; set; }
        public string? Language_FlagPath { get; set; }
    }
}
