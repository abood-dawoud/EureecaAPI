﻿namespace Eureeca_API.Models.GeneralModels.ViewModels
{
    public class News
    {
        public int News_ID { get; set; }
        public string News_Profile_Title { get; set; }
        public string News_Profile_Summary { get; set; }
        public string News_Profile_Image { get; set; }
        public DateTime? News_Profile_date { get; set; }
        public string News_Profile_Details { get; set; }
    }
}
