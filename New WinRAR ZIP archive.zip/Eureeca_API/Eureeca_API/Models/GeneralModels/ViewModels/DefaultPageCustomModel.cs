﻿using Eureeca_API.Models.UserModels.ViewModesl;

namespace Eureeca_API.Models.GeneralModels.ViewModels
{
    public class DefaultPageCustomModel
    {
        public List<News> News { get; set; }
        public List<KeyInvestor> KeyInvestors { get; set; }
        public List<Testimonials> Testimonials { get; set; }

    }
}
