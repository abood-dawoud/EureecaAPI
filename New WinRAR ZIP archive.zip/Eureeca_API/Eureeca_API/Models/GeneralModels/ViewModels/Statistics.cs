﻿namespace Eureeca_API.Models.GeneralModels.ViewModels
{
    public class Statistics
    {
        public string? Countries { get; set; }
        public string? ProposalsOverfunded { get; set; }
        public string? ActiveUsers { get; set; }
        public string? AverageInvestment { get; set; }
        public string? EureecaOverviewVideo { get; set; }


    }
}
