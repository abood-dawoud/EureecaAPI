﻿namespace Eureeca_API.Models.GeneralModels.ViewModels
{
    public class GeneralResponseMessage
    {
        public int Code { get; set; }
        public bool Success { get; set; }
        public string Title { get; set; }
        public string Message { get; set; }

        public GeneralResponseMessage(int code, bool success, string title, string message)
        {
            Code = code;
            Success = success;
            Title = title;
            Message = message;
        }

    }
}
