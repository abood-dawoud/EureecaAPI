﻿namespace Eureeca_API.Models.GeneralModels.ViewModels
{
    public class Agreement
    {
        public int MessageType { get; set; }
        public string MessageTypeLbl { get; set; }
        public bool HasIcon { get; set; }
        public string Title { get; set; }
        public string Details { get; set; }
        public bool IsAgreement { get; set; }
        public bool CanClose { get; set; }
        public bool HasCheckBox { get; set; }

    }
}
