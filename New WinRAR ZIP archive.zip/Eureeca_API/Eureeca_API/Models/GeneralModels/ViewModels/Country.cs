﻿namespace Eureeca_API.Models.GeneralModels.ViewModels
{
    public class Country
    {
        public int Country_ID { get; set; }
        public string? Country_Code { get; set; }
        public string? Country_Flag_URL { get; set; }
        public string? Country_Dialing_Code { get; set; }
        public int Country_KYC_Tire { get; set; }
        public string? Profile_Country_Name { get; set; }
        public int Profile_Order_Num { get; set; }


    }
}
