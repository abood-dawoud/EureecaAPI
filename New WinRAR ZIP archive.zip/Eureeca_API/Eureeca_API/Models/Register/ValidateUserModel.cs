﻿using System.ComponentModel.DataAnnotations;

namespace Eureeca_API.Models.Register
{
    public class ValidateUserModel
    {
        public string Username { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public int RegistrationType { get; set; }
        public int LangId { get; set; }
    }
}
