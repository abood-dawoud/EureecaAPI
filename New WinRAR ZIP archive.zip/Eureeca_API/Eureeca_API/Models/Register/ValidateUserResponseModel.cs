﻿namespace Eureeca_API.Models.Register
{
    public class ValidateUserResponseModel
    {
        public int Code { get; set; }
        public bool Success { get; set; }
        public string Message { get; set; }
        public string TextInput { get; set; }

        public ValidateUserResponseModel(int code, bool success, string message, string textInput)
        {
            Code = code;
            Success = success;
            Message = message;
            TextInput = textInput;
        }
    }
}
