﻿using Microsoft.AspNetCore.Mvc;

namespace Eureeca_API.Models.Register
{
    [BindProperties]
    public class RegistrationPrerequisitesModel
    {
        public int UserType { get; set; }
        public int CountryId { get; set; }
        public int LangId { get; set; }
    }
}
