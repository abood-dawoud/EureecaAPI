﻿namespace Eureeca_API.Models.Register
{
    public class RegisterUserRequestModel
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Country { get; set; }
        public string Nationality { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public int UserType { get; set; }
        public int Month { get; set; }
        public int Day { get; set; }
        public int Year { get; set; }
        public string CountryDialingCode { get; set; }
        public string Phone { get; set; }
        public string PromotionCode { get; set; }
        public int RegisterLanguage { get; set; }
        public bool UserIsPEP { get; set; }
        public string FacebookId { get; set; }
        public string LinkedInId { get; set; }
        public int RegType { get; set; }
        public bool IsPartner { get; set; }
    }
}
