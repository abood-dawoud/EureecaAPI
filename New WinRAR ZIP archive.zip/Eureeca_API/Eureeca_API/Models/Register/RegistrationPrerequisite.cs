﻿using Eureeca_API.Models.GeneralModels.ViewModels;

namespace Eureeca_API.Models.Register
{
    public class RegistrationPrerequisite
    {
        public bool IsEnabledToRegister { get; set; }
        public List<Agreement> RegistrationPopupMessages { get; set; }
        public int MinimumAge { get; set; }
    }
}
