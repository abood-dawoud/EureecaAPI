﻿using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.UserModels.ViewModesl;

namespace Eureeca_API.Models.InboxModels.ViewModels
{
    public class InboxMessagesResponse : PagingGeneralResponse
    {
        public List<InboxMessages> InboxMessages { get; set; }

        public InboxMessagesResponse(int code, bool success, int recordCount, bool hasMore, int currentPageIndex, List<InboxMessages> inboxMessages)
        {
            Code = code;
            Success = success;
            RecordCount = recordCount;
            HasMore = hasMore;
            CurrentPageIndex = currentPageIndex;
            InboxMessages = inboxMessages;
        }
    }
}
