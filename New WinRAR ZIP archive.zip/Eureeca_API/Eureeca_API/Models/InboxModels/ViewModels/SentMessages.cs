﻿namespace Eureeca_API.Models.InboxModels.ViewModels
{
    public class SentMessages
    {
        public string SentId { get; set; }
        public string SentDate { get; set; }
        public string SentReceiver { get; set; }
        public string SentSubject { get; set; }
        public string SentFlag { get; set; }
        public string ProfileFirstName { get; set; }
        public string ProfileLastName { get; set; }
    }
}
