﻿namespace Eureeca_API.Models.InboxModels.ViewModels
{
    public class InboxMessages
    {
        public string InboxId { get; set; }
        public string InboxDate { get; set; }
        public string InboxSubject { get; set; }
        public string InboxFlag { get; set; }
        public string InboxSender { get; set; }
        public string Unread { get; set; }
        public string ProfileFirstName { get; set; }
        public string ProfileLastName { get; set; }
    }
}
