﻿namespace Eureeca_API.Models.InboxModels.Dto
{
    public class SingleMessageRequestModel
    {
        public int MessageId { get; set; }
        public int UserId { get; set; }
    }
}
