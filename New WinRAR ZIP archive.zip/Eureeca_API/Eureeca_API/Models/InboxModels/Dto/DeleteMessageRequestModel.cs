﻿namespace Eureeca_API.Models.InboxModels.Dto
{
    public class DeleteMessageRequestModel
    {
        public int MessageId { get; set; }
        public int UserId { get; set; }
        public int LangId { get; set; }
        public string Pos { get; set; }
    }
}
