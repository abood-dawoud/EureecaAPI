﻿namespace Eureeca_API.Enums
{
    public enum MessageType
    {
        warning = 1,
        info = 2,
        error = 3,
        Agreement = 4,
    }
}
