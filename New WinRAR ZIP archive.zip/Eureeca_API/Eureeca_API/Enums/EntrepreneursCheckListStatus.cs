﻿namespace Eureeca_API.Enums
{
    public enum EntrepreneursCheckListStatus
    {
        New = 0,
        Submitted = 1,
        Accepted = 2,
        Rejected = 3,
        OnHold = 4
    };
}
