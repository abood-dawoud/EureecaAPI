﻿namespace Eureeca_API.Enums
{
    public enum UserActivationLevel
    {
        New = 0, //This status when the user failed and after period of time allowed to take the test again
        FirstFailure = 1,
        SecondFailure = 2,
        Success = 3
    };
}
