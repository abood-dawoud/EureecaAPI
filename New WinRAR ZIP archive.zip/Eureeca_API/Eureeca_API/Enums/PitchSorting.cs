﻿using System.ComponentModel;

namespace Eureeca_API.Enums
{

    public enum PitchSorting
    {
        [Description("Popularity")]
        Popularity,

        [Description("Date expiration")]
        DateExpiration,

        [Description("Amount Raised")]
        AmountRaised,

        [Description("Most Recent")]
        MostRecent,
    }
}