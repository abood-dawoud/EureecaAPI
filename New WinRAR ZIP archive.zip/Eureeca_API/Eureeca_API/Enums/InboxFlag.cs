﻿namespace Eureeca_API.Enums
{
    public enum InboxFlag
    {
        MessageNotRead = 0,
        MessageRead = 1
    };
}
