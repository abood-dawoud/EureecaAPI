﻿namespace Eureeca_API.Enums
{
    public enum PitchUpdateStatus
    {
        NotAccepted = 0,
        Accepted = 1,
        Rejected = 2,
        All = 3, //When need to return all updates status for admin.
    };
}
