﻿namespace Eureeca_API.Enums
{
    public enum RedirectType
    {
        AdminDashboard = 0,
        UserDashboard = 1,
        DefaultPage = 2,
        PreviousPage = 3,
        EarlyAccessPitch = 4,
        InActiveUser = 5,
        InvalidAuthentication = 6,
        Questionnaire = 7,
        Survey = 9,
        Alert_page = 10,
        Alert_PopUp = 11,
        RegulatorsAgreement = 12,
        AdminPreviousPageUrl = 13,
        SuitablityTest = 14,
    }
}
