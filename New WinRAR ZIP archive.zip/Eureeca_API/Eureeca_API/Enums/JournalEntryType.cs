﻿namespace Eureeca_API.Enums
{
    public enum JournalEntryType
    {
        JournalEntry = 1,
        BankEntry = 2,
        CreditCardEntry = 3,
        CreditCardSMEPaymentEntry = 4,
        BankEntryRefund = 5,
        CreditCardEntryRefund = 6,
        CreditCardSMEPaymentRefund = 7,
        IDealPaymentEntry = 8,
        IDealPaymentRefund = 9,
        Investment = 10,
        InvestmentRefund = 11,
        CashUPayment = 12,
        CashUPaymentRefund = 13,
        SecondaryMarketPayments = 14,
        StripeCreditCardEntry = 15,
        StripeCreditCardSMEPaymentEntry = 16,
        StripeCreditCardEntryRefund = 17,
        StripeCreditCardSMEPaymentRefund = 18
    };
}
