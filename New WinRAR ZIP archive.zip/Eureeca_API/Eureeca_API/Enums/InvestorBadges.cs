﻿namespace Eureeca_API.Enums
{
    public enum InvestorBadges
    {
        SilverInvestor = 1,
        GoldInvestor = 2,
        PlatinumInvestor = 3,
        DiamondInvestor = 4
    }
}
