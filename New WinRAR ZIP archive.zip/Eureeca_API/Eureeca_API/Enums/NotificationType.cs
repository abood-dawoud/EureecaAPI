﻿namespace Eureeca_API.Enums
{
    public enum NotificationType
    {
        CommentedOnMyProposal = 1,
        CommentedOnMyProfile = 2,
        FollowMe = 3,
        FollowMyProposal = 4,
        UpdatedProposal = 5,
        ProposalStatusChange = 6
    };
}
