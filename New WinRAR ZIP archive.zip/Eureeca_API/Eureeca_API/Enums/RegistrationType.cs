﻿namespace Eureeca_API.Enums
{
    public enum RegistrationType
    {
        Normal = 0,
        Facebook = 1,
        ArabicPopUp = 2,
        EnglishPopUp = 3,
        Campaign = 4,
        LinkedIn = 6
    };
}
