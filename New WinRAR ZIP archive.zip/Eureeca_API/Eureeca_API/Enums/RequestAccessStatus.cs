﻿namespace Eureeca_API.Enums
{
    public enum RequestAccessStatus
    {
        NotRequested = 0,
        Pending = 1,
        Rejected = 2,
        Accepted = 3
    }
}
