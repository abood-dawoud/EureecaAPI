﻿namespace Eureeca_API.Enums
{
    public enum UserStatus
    {
        New = 1,
        Active = 2,
        InActive = 3,
        Canceled = 4,
        Incomplete = 5,
        NotQualified = 6,
        NotVerified = 7
    }
}
