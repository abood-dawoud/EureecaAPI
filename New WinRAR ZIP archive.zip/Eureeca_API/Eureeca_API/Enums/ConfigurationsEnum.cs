﻿namespace Eureeca_API.Enums
{
    public enum ConfigurationsEnum
    {
        EmailsFooterText = 1,
        UseEmailsFooterText = 2,
        IssuerWounds = 3,
        ExpectedFailureRates = 4,
        IssuerDefaults = 5,
        IssuerBecomesInsolvent = 6,
        KYCReminderAllRequired = 7,
        KYCReminderAllLiveExpired = 8,
        KYCReminderAllLiveRejected = 9,
        Enable2M = 10,
        EnableFB = 11,
        EnableLinkedIn = 12
    };
}
