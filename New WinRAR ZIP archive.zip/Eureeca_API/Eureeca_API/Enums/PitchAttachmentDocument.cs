﻿namespace Eureeca_API.Enums
{
    public enum PitchAttachmentDocument
    {
        All = 1,
        PublicDocs = 2,
        PrivateDocs = 3
    };
}
