﻿namespace Eureeca_API.Enums
{
    public enum KYCUserDocsStatus
    //Its value for the doc or overall status can be changed after the admin processing the docs
    //Its value for overall status also can be changed in KYC Check required docs function
    {
        NotAccepted = 0, //For overall status this means that at least one of the docs was not accepted by the admin (Resubmit)
        Accepted = 1, //For overall status this means that all the docs were accepted by the admin
        PendingApproval = 2, //For overall status this means that all the docs were uploaded by the user but didn't processed by the admin or some of them accepted and others (pending) resubmitted by the user after the asmin failed them (In process) and the admin can process the docs only when overall status is inprocess
        NotUploaded = 3, //For overall status this means that at least one of the docs wwas not uploaded by the user
        Expired = 4 //For overall status this means that at least one of the docs was expired (Resubmit)
    };
}
