﻿namespace Eureeca_API.Enums
{
    public enum PitchAction
    {
        PublishedForFollowers = 0,
        CompletedWithoutOverfundingBalanceForFollowers = 1,
        ExtraCompletedForFollowers = 2,
        ExpiredForFollowers = 3,
        CompletedForFollowers = 4,
        OverfundingForFollowers = 5,
        OverfundedForFollowers = 6,
        MinimumFundedForFollowers = 7,
        ExpiredForInvestors = 8,
        OverfundingForInvestors = 9,
        MinimumFundedForInvestors = 10,
        CompletedForInvestors = 11,
        OverfundedForInvestors = 12,
        ExtraCompletedForInvestors = 13,
        PublishedForOwner = 14,
        PublishedForInvestor = 15,
        OverfundingForOwner = 16,
        OverfundingForInvestor = 17,
        InvestmentForUsers = 18,
        ExtendedForUsers = 19,
        ExtendedForOwner = 20,
        UpdateForUsers = 21,
        PublishedExpireSoon = 22,
        OvefundingExpireSoon = 23,
        ErrorInRefunding = 24,
        CancelledForUsers = 25,
        CancelledAndClosedForUsers = 26,
        UnableToInvest = 27,
        InvestmentRejection = 28,
        ApproveUpdate = 29,
        RejectUpdate = 30,
        rejectProposal = 31
    };
}
