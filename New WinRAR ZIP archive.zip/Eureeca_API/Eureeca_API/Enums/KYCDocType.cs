﻿namespace Eureeca_API.Enums
{
    public enum KYCDocType
    {
        PersonalPhote = 0,
        Passport = 1,
        ProofOfAddress = 2,
        SourceOfWealth = 3,
        CertificatedCopies = 4,
        PEPDoc = 5,
        Utility = 6,
        PaymentConfirmation = 7,
    }
}
