﻿namespace Eureeca_API.Enums
{
    public enum RegistrationErrorType
    {
        None = 0,
        ErrorInRegistration = 1,
        InvalidUserName = 2,
        InvalidUserFirstName = 3,
        InvalidUserLastName = 4,
        InvalidUserDOB = 5,
        InvalidUserType = 6,
        ExistUserName = 7,
        ExistUserEmail = 8,
        CheckAgreement = 9,
        InvalidUserEmail = 10
    };
}
