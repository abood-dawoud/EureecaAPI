﻿namespace Eureeca_API.Enums
{
    public enum PitchAttachmentType
    {
        All = 1,
        Video = 2,
        Image = 3,
        File = 4,
        ImagesAndVideos = 5
    };
}
