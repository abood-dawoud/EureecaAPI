﻿namespace Eureeca_API.Enums
{
    public enum UserAction
    {
        PitchInvestment = 0,
        AddCommentToUser = 1,
        AddCommentToProposal = 2,
        AddQuestionToUser = 3,
        AddQuestionToProposal = 4,
        AddAnswerToUser = 5,
        AddAnswerToProposal = 6,
        FollowUser = 7,
        FollowProposal = 8,
        OnlineCreditRequest = 9,
        OnlineCreditSuccess = 10,
        OnlineCreditFail = 11,
        OnlineRefund = 12,
        CreditHoldedAmounts = 13,
        BankTransferRequest = 14,
        BankTransferCredit = 15,
        BankTransferRefund = 16,
        ContactUs = 18,
        BecomePartner = 20,
        InvestmentInviteFriends = 24,
        TempGBPOnlineCreditSuccess = 25,
        TempEUROnlineCreditSuccess = 26,
        ApiError = 27,
        OnlinePaymentCaptured = 28,
        OnlineIDEALRequest = 29,
        OnlineIDEALFail = 30,
        OnlineIDEALRefund = 31,
        OnlinePaymentPending = 32,
        OnlinePaymentCanceled = 33,
        OnlinePaymentExpired = 34,
        OnlinePaymentDeclined = 35
    };
}
