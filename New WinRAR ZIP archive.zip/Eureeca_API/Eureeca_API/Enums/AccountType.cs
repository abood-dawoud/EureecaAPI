﻿namespace Eureeca_API.Enums
{
    public enum AccountType
    {
        User = 1,
        Proposal = 2,
        Bank = 3,
        Custom = 4
    };
}
