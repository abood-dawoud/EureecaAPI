﻿namespace Eureeca_API.Enums
{
    public enum Currencies
    {
        USD = 1,
        GBP = 2,
        AED = 3,
        EUR = 4,
        MYR = 5
    };
}
