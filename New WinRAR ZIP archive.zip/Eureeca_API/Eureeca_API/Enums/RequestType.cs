﻿namespace Eureeca_API.Enums
{
    public enum RequestType
    {
        MarketExpert = 0,
        UserPayment = 1, /* when the user requests to add his balance   */
        WithdrawUserBalance = 2, /* when the user requests to deduct(withdraw) his balance */
        ApplyOverSusbcription = 3, /* when the user requests to apply Overfunding at pitch */
        CancelOverSusbcription = 4, /* when the user requests to apply Overfunding at pitch */
        CreditCardPayment = 6,
        InvestmentPrevention = 7, /* when the user requests to allow him to invest   */
        ViewProposalPrevention = 8, /* when the user requests to allow him to view proposal  */
        ViewingProposalPrivateDocument = 9,  /* when the user requests to allow him to viewing proposal Private Document  */
        TempGBPCreditCardPayment = 10, /* when the user requests to add amount in GPB currency to his balance using Credit Card  */
        TempGBPBankTransferPayment = 11, /* when the user requests to add amount in GPB currency to his balance using bank transfer   */
        ViewingOpaqueProposal = 12,  /* when the user requests to allow him to viewing opaque proposal */
        RequestMeetingWithEnt = 13,
        RequestCallWithEnt = 14,
        RequestBusinessPlan = 15,
        TempEURCreditCardPayment = 16, /* when the user requests to add amount in GPB currency to his balance using Credit Card  */
        TempEURBankTransferPayment = 17, /* when the user requests to add amount in GPB currency to his balance using bank transfer   */
        TempAEDreditCardPayment = 19, /* when the user requests to add amount in GPB currency to his balance using Credit Card  */
        TempAEDBankTransferPayment = 20, /* when the user requests to add amount in GPB currency to his balance using bank transfer   */
        TempMYRCreditCardPayment = 21, /* when the user requests to add amount in GPB currency to his balance using Credit Card  */
        TempMYRBankTransferPayment = 22, /* when the user requests to add amount in GPB currency to his balance using bank transfer   */
        TempEURIDEALPayment = 18, /* when the user requests to add amount in EUR currency to his balance using Ideal API  */
        RequestAccessCode = 23,
        USDPaymentCashU = 25,
        EURPaymentCashU = 26,
        AEDPaymentCashU = 27,
        GBPPaymentCashU = 28,
        SecondaryMarketPayments = 29,
        USDStripe = 30,
        GBPStripe = 31,
        EURStripe = 32,
        AEDStripe = 33,
        MYRStripe = 34
    };
}
