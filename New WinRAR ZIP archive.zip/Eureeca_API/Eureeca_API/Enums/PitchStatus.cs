﻿namespace Eureeca_API.Enums
{
    public enum PitchStatus
    {
        NotReady = 0, // this is the fist state, before use submits 
        SubmittedForApproval = 1, //this is the sate after the user clicks on [Request to Publish]
        Published = 2, //this is the state after the admin clicks on [Approved to Publish]
        Cancelled = 3, //if the user or admin chooses clicks on Cancel Pitch, this will  
        Expired = 4, //will execute refund to investors, if the expire is reached before the requested amount is reached.
        Completed = 5, //this will hapen when the last investor makes the last payment that make the balance=invetmentrequired
        CompletedAndClosed = 6, //when the admin clicks on a button to close the pitch & sets the pending transactions to completed. this will also send an email to all followers and investors.
        ExpiredAndClosed = 7, //when the admin clicks on a button to close the expiration of pitcH. this will also send an email to all followers and investors.
        CancelledAndClosed = 8, //when the admin clicks on a button to close the cancellation of pitch. this will refund to investors and send an email to all followers and investors.
        ComingSoon = 9, //this is new state for coming soon pitches after click on [Request as Coming Soon Publish]
        EarlyAccess = 10, //this is the state after the admin approved the submitted for approval pitch status to be published at site as early access
        OverFunding = 11, //this is the state that indicates the pitch is in Overfunding status after the admin approved Overfunding offer
        OverFunded = 12, //when the Overfunding offer hits its amount target the status will be completed after investments or viewing the pitch
        MinimumFunded = 13 //when the pitch expired but it has minimum investmetn neeed and its balance greater than the minimum investmetn neeed
    }
}
