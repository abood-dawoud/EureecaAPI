﻿namespace Eureeca_API.Enums
{
    public enum UserType
    {
        Admin = 0,
        SystemAdmin = 1,
        Investor = 2,
        Enreprenuer = 3,
        InvestorAndEnreprenuer = 4,
        BIAdmin = 5
    };
}
