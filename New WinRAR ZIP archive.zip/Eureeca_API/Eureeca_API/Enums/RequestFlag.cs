﻿namespace Eureeca_API.Enums
{
    public enum RequestFlag
    {
        NotAcceptance = 0,
        Acceptance = 1
    };
}
