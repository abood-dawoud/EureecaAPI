﻿namespace Eureeca_API.Enums
{
    public enum ResponseStatus
    {
        NullUserId = 0,
        NullCountryId = 1,
        NullLangId = 2,
        NullKYCFile = 3,
        FileAlreadyExists = 3,
        FileDoesNotExist = 4,
        FileAlreadyUploaded = 5,
        EmptyDataTable = 6,
        CatchError = 7,
        NotSupportedFileExtension = 8,
        CanNotUploadFile = 9,
        EmptyPassportDocName = 10,
        EmptyPOADocName = 11,
        UserDoesNotExist = 12,
        SomeQuestionsNotAnswered = 13,
        NotAllowedTab = 14,
        InActiveOrCanceledUser = 15,
        InvestmentFrozen = 16,
        InvestmentPrevention = 17,
        FailedSuitability = 18,
        KYCNotVerified = 19,
        KYCIssue = 20,
        AnotherTransaction = 21,
        Success = 22,
    }
}
