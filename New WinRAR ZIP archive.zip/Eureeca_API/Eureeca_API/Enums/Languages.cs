﻿namespace Eureeca_API.Enums
{
    public enum Languages
    {
        English = 1,
        Arabic = 2,
        Spanish = 3
    }
}
