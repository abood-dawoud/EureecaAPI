﻿namespace Eureeca_API.Enums
{
    public enum LeadSource
    {
        HupSpot = 1,
        Admin = 2,
        MailChimp = 3,
        EarlyAccessPage = 4
    };
}
