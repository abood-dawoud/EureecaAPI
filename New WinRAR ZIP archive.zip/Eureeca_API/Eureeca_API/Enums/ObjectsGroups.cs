﻿namespace Eureeca_API.Enums
{
    public enum ObjectsGroups
    {
        Badges = 1
    }
}
