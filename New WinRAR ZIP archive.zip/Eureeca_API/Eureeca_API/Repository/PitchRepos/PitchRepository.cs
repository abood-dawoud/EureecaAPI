﻿using Eureeca_API.Interface;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Globalization;
using Microsoft.Extensions.Localization;
using Tools = Eureeca_API.General.Tools;
using Eureeca_API.General;
using Eureeca_API.Enums;
using Eureeca_API.Models.PitchModels.ViewModels;
using Eureeca_API.Interface.CountryBasedInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Interface.InboxInterface;
using Eureeca_API.Models.PitchModels.Dto;
using Eureeca_API.Models.UserModels.ViewModesl;
using Newtonsoft.Json;

namespace Eureeca_API.Repository.PitchRepos
{
    public class PitchRepository : IPitch
    {
        private readonly IConfiguration _config;
        private readonly string _connectionString;
        private readonly IUser _user;
        private readonly ICountryBasedControl _countryBasedControlRepository;
        private readonly IPitchAttachements _pitchAttachementsRepository;
        private readonly IMessage _message;
        private readonly IPitchLikeFollower _pitchLikeFollower;
        private readonly ITopic _topicRepository;
        private readonly IKYC _kyc;
        private readonly IStringLocalizer<Resources.PitchRepository> _stringLocalizer;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;

        public PitchRepository(ITopic topic, ICountryBasedControl countryBasedControlRepository, IUser user, IPitchAttachements pitchAttachements, IMessage message, IPitchLikeFollower pitchLikeFollower, IStringLocalizer<Resources.PitchRepository> pitchRepositoryLocalizer, IConfiguration config, IKYC kyc)
        {
            _config = config;
            _connectionString = config.GetConnectionString("dbConnection");
            _countryBasedControlRepository = countryBasedControlRepository;
            _user = user;
            _pitchAttachementsRepository = pitchAttachements;
            _message = message;
            _pitchLikeFollower = pitchLikeFollower;
            _topicRepository = topic;
            _kyc = kyc;
            _stringLocalizer = pitchRepositoryLocalizer;
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }
        /// <summary>
        /// This method is used to get home EA proposals.
        /// </summary>
        /// <param name="langId"></param>
        /// <param name="currencyId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetHomeEAProposals(int langId, int currencyId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Pitch_GetHomeEAProposals", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@Profile_LanguageID", langId));
                        cmd.Parameters.Add(new SqlParameter("@CurrencyID", currencyId));
                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(cmd);

                        DataTable DT = new DataTable();

                        DA.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        /// <summary>
        /// This method is used to Get Home Live proposals.
        /// </summary>
        /// <param name="langId"></param>
        /// <param name="currencyId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetHomeLiveProposals(int langId, int currencyId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Pitch_GetHomePagePitches", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@Profile_LanguageID", langId));
                        cmd.Parameters.Add(new SqlParameter("@CurrencyID", currencyId));
                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(cmd);

                        DataTable DT = new DataTable();

                        DA.Fill(DT);

                        return DT;

                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to get Proposal by Id.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public Pitch PitchGetPitchById(long proposalId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Pitch_GetPitchDetails", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@Pitch_ID", proposalId));
                        cmd.Parameters.Add(new SqlParameter("@Profile_LanguageID", 1));
                        sql.Open();
                        Pitch? response = null;
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return MapToValue(reader);
                            }
                            // response = MapToValue(reader);
                            return null;
                        }

                        // return response;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        /// <summary>
        /// This method is used to check if the proposal view is prevented.
        /// </summary>
        /// <param name="drProposal"></param>
        /// <param name="countryId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public bool PitchIsProposalViewPrevented(DataRow drProposal, int countryId, string userId)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(drProposal["Pitch_Country"].ToString()))
                {
                    //Restrict KSA IP/countries from access/receiving info on Guzzle.  Pitch_ID=10656 ticket id=8865
                    if (drProposal["Pitch_ID"].ToString() == "10656" && countryId == 193)
                        return true;
                    if (!string.IsNullOrWhiteSpace(drProposal["Pitch_Prevent_Exeption"].ToString()) && !Convert.ToBoolean(drProposal["Pitch_Prevent_Exeption"].ToString()))
                    {
                        int groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.ViewProposal_Prevent, countryId, int.Parse(drProposal["Pitch_Country"].ToString()));
                        if (groupId > 0)
                        {
                            if (userId == null)
                                return true;
                            else if (userId != drProposal["Pitch_UserID"].ToString() && !_user.UserIsAdmin(long.Parse(userId)))
                            {
                                DataTable dtUserRequst = _user.UserGetUserRequest((int)RequestType.ViewProposalPrevention, int.Parse(userId), int.Parse(drProposal["Pitch_ID"].ToString()));
                                if (dtUserRequst.Rows.Count == 0 || dtUserRequst.Rows.Count > 0 && !bool.Parse(dtUserRequst.Rows[0]["flag"].ToString()))
                                    return true;
                            }
                        }
                        else
                        {
                            groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControlbyPage(CountryBasedControls.ViewProposal_PreventByPage, int.Parse(drProposal["Pitch_ID"].ToString()), countryId);
                            if (groupId > 0)
                            {
                                if (userId == null)
                                    return true;
                                else if (userId != drProposal["Pitch_UserID"].ToString() && !_user.UserIsAdmin(long.Parse(userId)))
                                {
                                    DataTable dtUserRequst = _user.UserGetUserRequest((int)RequestType.ViewProposalPrevention, int.Parse(userId), int.Parse(drProposal["Pitch_ID"].ToString()));
                                    if (dtUserRequst.Rows.Count == 0 || dtUserRequst.Rows.Count > 0 && !bool.Parse(dtUserRequst.Rows[0]["flag"].ToString()))
                                        return true;
                                }
                            }
                        }
                    }
                    else return false;
                }
                return false;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to check if the propsal is expired.
        /// </summary>
        /// <param name="langId"></param>
        /// <param name="PID"></param>
        /// <exception cref="Exception"></exception>
        public void PitchTestExpiration(int langId, int PID)
        {
            try
            {
                DataTable dtForComparingDate = PitchGetPitchNotLocalizedDetails(PID);
                if (dtForComparingDate.Rows.Count > 0)
                    if (dtForComparingDate.Rows[0]["Pitch_Status"].ToString() == "published" || dtForComparingDate.Rows[0]["Pitch_Status"].ToString() == "Overfunding")
                    {
                        DataTable userInfo = _user.UserSelectById(int.Parse(dtForComparingDate.Rows[0]["Pitch_UserID"].ToString()));

                        DateTimeFormatInfo dtfi = new DateTimeFormatInfo();
                        dtfi.ShortDatePattern = "MM/dd/yyyy";
                        dtfi.DateSeparator = "/";
                        string sNow = DateTime.Now.ToString();
                        DateTime dNow = Convert.ToDateTime(sNow, dtfi);
                        string sClosingDate = dtForComparingDate.Rows[0]["Pitch_ClosingDate"].ToString();
                        DateTime dClosingDate = Convert.ToDateTime(sClosingDate, dtfi);
                        // Author:anas
                        // Date :10/7/2012
                        // check closing Date =15 days left send message to pitch owner

                        #region 15 Days Remaining
                        string daysLeft = PitchGetPitchDaysLeft(PID, bool.Parse(dtForComparingDate.Rows[0]["Pitch_IsExtended"].ToString()), dtForComparingDate.Rows[0]["Pitch_ClosingDate"].ToString()).ToString();
                        if (daysLeft == "15")
                        {
                            DataRow drAdmin = _user.UserGetSystemAdmin();
                            DataTable dtAdmins = _user.UserGetAdmins();

                            DataTable dtPitchDetails = PitchGetDedicatedPitchDetails(PID, 1);
                            if (dtPitchDetails.Rows.Count == 0)
                            {
                                dtPitchDetails = PitchGetDedicatedPitchDetails(PID, 2);
                                if (dtPitchDetails.Rows.Count == 0)
                                    dtPitchDetails = PitchGetDedicatedPitchDetails(PID, 3);
                            }

                            if (dtForComparingDate.Rows[0]["Pitch_Status"].ToString() == "published")
                            {
                                if (Convert.ToBoolean(dtForComparingDate.Rows[0]["Pitch_ExpirationNotificationFlag"].ToString()) == false)
                                {
                                    _message.MessageSendProposalActionsEmail(drAdmin, dtAdmins, dtPitchDetails.Rows[0], userInfo.Rows[0], "", PitchAction.PublishedExpireSoon);

                                    PitchUpdateExpirationEmailNotificationFlag(PID);
                                }
                            }
                            else if (dtForComparingDate.Rows[0]["Pitch_Status"].ToString() == "Overfunding")
                            {
                                if (Convert.ToBoolean(dtForComparingDate.Rows[0]["Pitch_ExpirationNotificationFlag"].ToString()) == false)
                                {
                                    _message.MessageSendProposalActionsEmail(drAdmin, dtAdmins, dtPitchDetails.Rows[0], userInfo.Rows[0], "", PitchAction.OvefundingExpireSoon);
                                    PitchUpdateExpirationEmailNotificationFlag(PID);
                                }
                            }
                        }

                        #endregion

                        if (dClosingDate < dNow)
                            if (dtForComparingDate.Rows[0]["Pitch_Status"].ToString() == "Overfunding")
                            {
                                if (float.Parse(dtForComparingDate.Rows[0]["Pitch_Balance"].ToString()) > float.Parse(dtForComparingDate.Rows[0]["Pitch_InvestmentRequired"].ToString()))
                                    PitchUpdatePitchStatus(PID, "Overfunded");
                                else
                                    PitchUpdatePitchStatus(PID, "completed");

                                PitchStatusChanged(langId, PID, "Overfunding", "completed");
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(dtForComparingDate.Rows[0]["Pitch_HasMinInvestmentRequired"].ToString()) && bool.Parse(dtForComparingDate.Rows[0]["Pitch_HasMinInvestmentRequired"].ToString()))
                                {
                                    if (float.Parse(dtForComparingDate.Rows[0]["Pitch_Balance"].ToString()) >= float.Parse(dtForComparingDate.Rows[0]["Pitch_MinInvestmentRequired"].ToString()))
                                    {
                                        PitchUpdatePitchStatus(PID, "Minimum-Funded");
                                        PitchStatusChanged(langId, PID, dtForComparingDate.Rows[0]["Pitch_Status"].ToString(), "Minimum-Funded");
                                    }
                                    else
                                    {
                                        PitchUpdatePitchStatus(PID, "expired");
                                        PitchStatusChanged(langId, PID, dtForComparingDate.Rows[0]["Pitch_Status"].ToString(), "expired");
                                    }
                                }
                                else
                                {
                                    PitchUpdatePitchStatus(PID, "expired");
                                    PitchStatusChanged(langId, PID, dtForComparingDate.Rows[0]["Pitch_Status"].ToString(), "expired");
                                }
                            }
                    }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        /// <summary>
        /// This method is used to check pitch localized detail.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetPitchNotLocalizedDetails(int proposalId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Pitch_getPitchNotLocalizedDetails", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@Pitch_ID", proposalId);
                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(cmd);
                        DataTable DT = new DataTable();
                        DA.Fill(DT);
                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to get dedicated pitch details by language.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="langId"></param>
        /// <param name="currencyId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetDedicatedPitchDetailsByLang(int proposalId, int langId, int? currencyId = 0)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Pitch_GetPitchDetails", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@Pitch_ID", proposalId);
                        cmd.Parameters.AddWithValue("@Profile_LanguageID", langId);
                        SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", DBNull.Value);
                        if (currencyId != 0)
                            paramCurrencyId.Value = currencyId;
                        cmd.Parameters.Add(paramCurrencyId);

                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(cmd);
                        DataTable DT = new DataTable();
                        DA.Fill(DT);
                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        /// <summary>
        /// This method is used to check days left in propsal expiry.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="isExtended"></param>
        /// <param name="closingDate"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public decimal PitchGetPitchDaysLeft(int proposalId, bool isExtended, string closingDate)
        {
            try
            {
                DateTimeFormatInfo dtfi = new DateTimeFormatInfo();
                dtfi.ShortDatePattern = "MM/dd/yyyy";
                dtfi.DateSeparator = "/";

                // String sNow = Convert.ToString(DateTime.Now);
                DateTime dNow = Convert.ToDateTime(DateTime.Now, dtfi);


                DateTime dClosingDate = Convert.ToDateTime(closingDate, dtfi);


                double daysLeft = double.Parse((dClosingDate - dNow).Days.ToString());
                double hoursLeft = double.Parse(((dClosingDate - dNow).Hours / 24.0).ToString());
                double minutesLeft = double.Parse(((dClosingDate - dNow).Minutes / (24.0 * 60.0)).ToString());
                double secondsLeft = double.Parse(((dClosingDate - dNow).Seconds / (24.0 * 60.0 * 60.0)).ToString());

                decimal remainDays = Math.Ceiling(decimal.Parse((daysLeft + hoursLeft + minutesLeft + secondsLeft).ToString()));

                if ((proposalId == 128 || proposalId == 146) && !isExtended && remainDays < 2 && DateTime.Now.Hour >= 8)
                {
                    ProposalExtendPitch(proposalId, dClosingDate.AddDays(30).ToShortDateString());
                    return remainDays;
                }
                else
                {
                    if (remainDays > 0)
                        return remainDays;
                    else
                        return 0;
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }


        }
        /// <summary>
        /// This method is used for notification flag for Pitch update expiration email.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <exception cref="Exception"></exception>
        public void PitchUpdateExpirationEmailNotificationFlag(int proposalId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Pitch_UpdateExirationEmailNotificationFlag", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@PID", proposalId);
                        sql.Open();

                        SqlDataReader data = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to extend the proposal.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="pitchClosingDate"></param>
        /// <exception cref="Exception"></exception>
        public void ProposalExtendPitch(int proposalId, string pitchClosingDate)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Pitch_ExtendPitch", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@Pitch_ID", proposalId);
                        cmd.Parameters.AddWithValue("@Pitch_ClosingDate", pitchClosingDate);

                        sql.Open();
                        SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                    }

                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }


        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="reader"></param>
        /// <returns></returns>
        private Pitch MapToValue(SqlDataReader reader)
        {
            return new Pitch()
            {
                Pitch_ID = (long)reader["Pitch_ID"],
                //Pitch_Name = reader["Profile_PitchTitle"].ToString()
            };
        }
        /// <summary>
        /// This method is used to Get proposal details.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="langId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetDedicatedPitchDetails(int proposalId, int langId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("Pitch_GetPitchDetails", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;

                        comm.Parameters.AddWithValue("@Pitch_ID", proposalId);
                        comm.Parameters.AddWithValue("@Profile_LanguageID", langId);
                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(comm);

                        DataTable DT = new DataTable();
                        DA.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to Get owner of Pitch.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataRow PitchGetPitchOwner(int proposalId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    {
                        using (SqlCommand comm = new SqlCommand("Pitch_GetPitchOwner", sql))
                        {
                            comm.CommandType = CommandType.StoredProcedure;

                            comm.Parameters.AddWithValue("@Pitch_ID", proposalId);
                            sql.Open();

                            SqlDataAdapter DA = new SqlDataAdapter(comm);

                            DataTable DT = new DataTable();
                            DA.Fill(DT);

                            return DT.Rows[0];
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        /// <summary>
        /// this method is used to update Pitch status.
        /// </summary>
        /// <param name="pitchId"></param>
        /// <param name="pitchStatus"></param>
        /// <exception cref="Exception"></exception>
        public void PitchUpdatePitchStatus(int pitchId, string pitchStatus)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Pitch_UpdatePitchStatus", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Pitch_ID", pitchId);
                        cmd.Parameters.AddWithValue("@Pitch_Status", pitchStatus);
                        sql.Open();
                        SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        /// <summary>
        /// This method is used to check pitch status.
        /// </summary>
        /// <param name="langId"></param>
        /// <param name="proposalId"></param>
        /// <param name="currentPitchStatus"></param>
        /// <param name="newPitchStatus"></param>
        /// <param name="drProposal"></param>
        /// <exception cref="Exception"></exception>
        public void PitchStatusChanged(int langId, int proposalId, string currentPitchStatus, string newPitchStatus, DataRow drProposal)
        {
            try
            {
                //DataRow drProposal = getDedicatedPitchDetails(PID, Languages.English).Rows[0];
                string pitchTitle = drProposal["Profile_PitchTitle"].ToString();
                string ownerFirstName = _user.UserSelectById(int.Parse(drProposal["Pitch_UserID"].ToString())).Rows[0]["Profile_FirstName"].ToString();

                if (currentPitchStatus == "not ready" && newPitchStatus == "submitted For Approval")
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.NotReady, PitchStatus.SubmittedForApproval);
                else if (currentPitchStatus == "not ready" && newPitchStatus == "coming soon")
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.NotReady, PitchStatus.ComingSoon);
                else if (currentPitchStatus == "coming soon" && newPitchStatus == "Early Access")
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.ComingSoon, PitchStatus.EarlyAccess);
                else if (currentPitchStatus == "submitted For Approval" && newPitchStatus == "Early Access")
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.SubmittedForApproval, PitchStatus.EarlyAccess);
                else if (currentPitchStatus == "Early Access" && newPitchStatus == "submitted For Approval")
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.EarlyAccess, PitchStatus.SubmittedForApproval);
                else if (currentPitchStatus == "submitted For Approval" && newPitchStatus == "published")
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.SubmittedForApproval, PitchStatus.Published);
                else if (currentPitchStatus == "Early Access" && newPitchStatus == "published")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.EarlyAccess, PitchStatus.Published);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.PublishedForFollowers);
                }
                else if (currentPitchStatus == "published" && newPitchStatus == "expired")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.Published, PitchStatus.Expired);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.ExpiredForFollowers);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetAllInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.ExpiredForInvestors);
                }
                else if (currentPitchStatus == "published" && newPitchStatus == "Minimum-Funded")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.Published, PitchStatus.MinimumFunded);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.MinimumFundedForFollowers);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetAllInvestors(proposalId, langId), pitchTitle, "", ownerFirstName, PitchAction.MinimumFundedForInvestors);
                }
                else if (currentPitchStatus == "published" && newPitchStatus == "completed")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.Published, PitchStatus.Completed);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.CompletedForFollowers);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetAllInvestors(proposalId, langId), pitchTitle, "", ownerFirstName, PitchAction.CompletedForInvestors);
                }
                else if (currentPitchStatus == "published" && newPitchStatus == "cancelled")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.Published, PitchStatus.Cancelled);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersAndInvestors(proposalId, langId), pitchTitle, proposalId.ToString(), "", PitchAction.CancelledForUsers);
                }
                else if (currentPitchStatus == "cancelled" && newPitchStatus == "cancelled and closed")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.Cancelled, PitchStatus.CancelledAndClosed);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersAndInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.CancelledAndClosedForUsers);
                }
                else if (currentPitchStatus == "published" && newPitchStatus == "Overfunding")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.Published, PitchStatus.OverFunding);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.OverfundingForFollowers);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetAllInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.OverfundingForInvestors);
                }
                else if (currentPitchStatus == "Overfunding" && newPitchStatus == "Overfunded")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.OverFunding, PitchStatus.OverFunded);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.OverfundedForFollowers);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetAllInvestors(proposalId, langId), pitchTitle, "", ownerFirstName, PitchAction.OverfundedForInvestors);
                }
                else if (currentPitchStatus == "Overfunding" && newPitchStatus == "completed")
                {
                    float Pitch_Balance = float.Parse(drProposal["Pitch_Balance"].ToString()),
                       Pitch_InvestmentRequired = float.Parse(drProposal["Pitch_InvestmentRequired"].ToString());

                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.OverFunding, PitchStatus.Completed);

                    if (Pitch_Balance > Pitch_InvestmentRequired)
                    {
                        _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetAllInvestors(proposalId, langId), pitchTitle, "", ownerFirstName, PitchAction.ExtraCompletedForInvestors);
                        _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.ExtraCompletedForFollowers);
                    }
                    else
                    {
                        _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetAllInvestors(proposalId, langId), pitchTitle, "", ownerFirstName, PitchAction.CompletedForInvestors);
                        _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.CompletedWithoutOverfundingBalanceForFollowers);
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to check pitch status.
        /// </summary>
        /// <param name="langId"></param>
        /// <param name="proposalId"></param>
        /// <param name="currentPitchStatus"></param>
        /// <param name="newPitchStatus"></param>
        /// <exception cref="Exception"></exception>
        public void PitchStatusChanged(int langId, int proposalId, string currentPitchStatus, string newPitchStatus)
        {
            try
            {
                DataRow drProposal = PitchGetDedicatedPitchDetails(proposalId, 1).Rows[0];
                string pitchTitle = drProposal["Profile_PitchTitle"].ToString();
                string ownerFirstName = _user.UserSelectById(int.Parse(drProposal["Pitch_UserID"].ToString())).Rows[0]["Profile_FirstName"].ToString();

                if (currentPitchStatus == "not ready" && newPitchStatus == "submitted For Approval")
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.NotReady, PitchStatus.SubmittedForApproval);
                else if (currentPitchStatus == "not ready" && newPitchStatus == "coming soon")
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.NotReady, PitchStatus.ComingSoon);
                else if (currentPitchStatus == "coming soon" && newPitchStatus == "Early Access")
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.ComingSoon, PitchStatus.EarlyAccess);
                else if (currentPitchStatus == "submitted For Approval" && newPitchStatus == "Early Access")
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.SubmittedForApproval, PitchStatus.EarlyAccess);
                else if (currentPitchStatus == "Early Access" && newPitchStatus == "submitted For Approval")
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.EarlyAccess, PitchStatus.SubmittedForApproval);
                else if (currentPitchStatus == "submitted For Approval" && newPitchStatus == "published")
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.SubmittedForApproval, PitchStatus.Published);
                else if (currentPitchStatus == "Early Access" && newPitchStatus == "published")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.EarlyAccess, PitchStatus.Published);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.PublishedForFollowers);
                }
                else if (currentPitchStatus == "published" && newPitchStatus == "expired")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.Published, PitchStatus.Expired);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.ExpiredForFollowers);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetAllInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.ExpiredForInvestors);
                }
                else if (currentPitchStatus == "published" && newPitchStatus == "Minimum-Funded")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.Published, PitchStatus.MinimumFunded);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.MinimumFundedForFollowers);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetAllInvestors(proposalId, langId), pitchTitle, "", ownerFirstName, PitchAction.MinimumFundedForInvestors);
                }
                else if (currentPitchStatus == "published" && newPitchStatus == "completed")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.Published, PitchStatus.Completed);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.CompletedForFollowers);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetAllInvestors(proposalId, langId), pitchTitle, "", ownerFirstName, PitchAction.CompletedForInvestors);
                }
                else if (currentPitchStatus == "published" && newPitchStatus == "cancelled")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.Published, PitchStatus.Cancelled);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersAndInvestors(proposalId, langId), pitchTitle, proposalId.ToString(), "", PitchAction.CancelledForUsers);
                }
                else if (currentPitchStatus == "cancelled" && newPitchStatus == "cancelled and closed")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.Cancelled, PitchStatus.CancelledAndClosed);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersAndInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.CancelledAndClosedForUsers);
                }
                else if (currentPitchStatus == "published" && newPitchStatus == "Overfunding")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.Published, PitchStatus.OverFunding);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.OverfundingForFollowers);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetAllInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.OverfundingForInvestors);
                }
                else if (currentPitchStatus == "Overfunding" && newPitchStatus == "Overfunded")
                {
                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.OverFunding, PitchStatus.OverFunded);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.OverfundedForFollowers);
                    _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetAllInvestors(proposalId, langId), pitchTitle, "", ownerFirstName, PitchAction.OverfundedForInvestors);
                }
                else if (currentPitchStatus == "Overfunding" && newPitchStatus == "completed")
                {
                    float Pitch_Balance = float.Parse(drProposal["Pitch_Balance"].ToString()),
                       Pitch_InvestmentRequired = float.Parse(drProposal["Pitch_InvestmentRequired"].ToString());

                    _message.MessageSendPithStatusChangesEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), PitchGetPitchOwner(proposalId), drProposal, PitchStatus.OverFunding, PitchStatus.Completed);

                    if (Pitch_Balance > Pitch_InvestmentRequired)
                    {
                        _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetAllInvestors(proposalId, langId), pitchTitle, "", ownerFirstName, PitchAction.ExtraCompletedForInvestors);
                        _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.ExtraCompletedForFollowers);
                    }
                    else
                    {
                        _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetAllInvestors(proposalId, langId), pitchTitle, "", ownerFirstName, PitchAction.CompletedForInvestors);
                        _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersExceptInvestors(proposalId, langId), pitchTitle, "", "", PitchAction.CompletedWithoutOverfundingBalanceForFollowers);
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to get all pitch badges assigned.
        /// </summary>
        /// <param name="pageNo"></param>
        /// <param name="pageSize"></param>
        /// <param name="langId"></param>
        /// <param name="pitchID"></param>
        /// <param name="recordCount"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchBadgesAssignedGetAll(int pageNo, int pageSize, int langId, int pitchID, out int recordCount)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Pitch_Badges_Assigned_GetAll", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add(new SqlParameter("@PageNo", pageNo));
                        cmd.Parameters.Add(new SqlParameter("@PageSize", pageSize));
                        cmd.Parameters.Add(new SqlParameter("@Profile_LanguageID", langId));
                        SqlParameter paramPitchId = new SqlParameter("@Pitch_ID", DBNull.Value);
                        if (pitchID > 0)
                            paramPitchId.Value = pitchID;
                        cmd.Parameters.Add(new SqlParameter("@Pitch_ID", pitchID));

                        SqlParameter paramRecordCount = new SqlParameter("@RecordCount", SqlDbType.Int, 4);
                        paramRecordCount.Direction = ParameterDirection.Output;

                        cmd.Parameters.Add(paramRecordCount);

                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(cmd);

                        DataTable DT = new DataTable();

                        DA.Fill(DT);
                        recordCount = int.Parse(cmd.Parameters["@RecordCount"].Value.ToString());

                        return DT;

                    }

                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to Get pitch rate.
        /// </summary>
        /// <param name="PID"></param>
        /// <param name="Currency_ID"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetPitchRate(int PID, int Currency_ID)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("Pitch_GetPitchRate", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@PID", PID);
                        comm.Parameters.AddWithValue("@Currency_ID", Currency_ID);

                        SqlDataAdapter DA = new SqlDataAdapter(comm);

                        DataTable DT = new DataTable();
                        DA.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        /// <summary>
        /// This method is used to get pitch rate is double.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="currencyId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public double PitchGetPitchRateAsDouble(int proposalId, int currencyId)
        {
            try
            {
                double value = 0;
                DataTable dt = PitchGetPitchRate(proposalId, currencyId);
                if (dt.Rows.Count > 0)
                {
                    value = Convert.ToDouble(dt.Rows[0]["Pitch_Rate"]);
                }
                return value;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        #region Proposal details methods
        /// <summary>
        /// This method is used to get Pitch business profile.
        /// </summary>
        /// <param name="proposalID"></param>
        /// <param name="langId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchBusenissProfileGetAll(int proposalID, int langId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("Buseniss_Profile_The_Buseniss_GetAll", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;

                        comm.Parameters.AddWithValue("@BU_Pitch_ID", proposalID);
                        comm.Parameters.AddWithValue("@Profile_LangID", langId);
                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(comm);

                        DataTable DT = new DataTable();

                        DA.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to Get Followers.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="profileLanguageId"></param>
        /// <param name="typeToSelect"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetAllFollower(int proposalId, int profileLanguageId, int typeToSelect)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("GetPitchFollowerAll", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;

                        comm.Parameters.AddWithValue("@PID", proposalId);
                        comm.Parameters.AddWithValue("@Profile_LanguageID", profileLanguageId);
                        comm.Parameters.AddWithValue("@typeToSelect", typeToSelect);

                        SqlDataAdapter DA = new SqlDataAdapter(comm);
                        DataTable DT = new DataTable();
                        DA.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to get Team profile.
        /// </summary>
        /// <param name="teamProfileID"></param>
        /// <param name="lang"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetTeamProfile(int teamProfileID, int lang)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("Pitch_GetTeamProfile", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;

                        comm.Parameters.AddWithValue("@TeamProfileID", teamProfileID);
                        comm.Parameters.AddWithValue("@Teams_Profile_LanguageID", lang);

                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(comm);
                        DataTable DT = new DataTable();
                        DA.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to Get Teams for Pitch.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="lang"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetTeamsForPitch(int proposalId, int lang)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("Pitch_GetTeamsForPitch", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;

                        comm.Parameters.AddWithValue("@PID", proposalId);
                        comm.Parameters.AddWithValue("@Teams_Profile_LanguageID", lang);

                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(comm);
                        DataTable DT = new DataTable();
                        DA.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        /// <summary>
        /// his method is used to get pitch updates by language and status, pitchID = 0 for all pitches
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="lang"></param>
        /// <param name="status"></param>
        /// <returns>Data table of information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable PitchGetUpdates(int proposalId, int langId, PitchUpdateStatus status)
        {
            try
            {
                SqlParameter paramProposalId = new SqlParameter("@PitchID", proposalId);
                SqlParameter paraPitchUpdateStatus = new SqlParameter("@PitchUpdate_Status", (int)status);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                return _sqlHelper.GetDataTable(_connectionString, "Pitch_GetUpdates", paramProposalId, paraPitchUpdateStatus, paramLangId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to get Pitch number text.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="numberTextLangId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchNumberTextGetAll(int proposalId, int numberTextLangId)
        {
            try
            {
                SqlParameter paramProposalId = new SqlParameter("@Pitch_ID", proposalId);
                SqlParameter paramNumberTextLangId = new SqlParameter("@Number_Text_LangID", numberTextLangId);
                return _sqlHelper.GetDataTable(_connectionString, "NumberTextGetAll", paramProposalId, paramNumberTextLangId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        /// <summary>
        /// This method is used get all numbers for pitch.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchTheNumbersGetAll(int proposalId)
        {
            try
            {
                SqlParameter paramProposalId = new SqlParameter("@Pitch_ID", proposalId);
                return _sqlHelper.GetDataTable(_connectionString, "The_NumbersGetAll", paramProposalId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to get investors sorted by fund.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="fund"></param>
        /// <param name="lang"></param>
        /// <param name="currencyID"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetInvestorsForPitchByFund(int proposalId, int fund, int lang, int currencyID)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("Pitch_GetInvestorsForPitchByFund", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;

                        comm.Parameters.AddWithValue("@PID", proposalId);
                        comm.Parameters.AddWithValue("@Fund", fund);
                        comm.Parameters.AddWithValue("@Profile_LanguageID", lang);
                        comm.Parameters.AddWithValue("@CurrencyID", currencyID);
                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(comm);
                        DataTable DT = new DataTable();
                        DA.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to get Location of secondary country for pitch.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="languageID"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetPitchSecondaryCountryLocation(int proposalId, int languageID, string mode)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("Pitch_GetSecondaryCountryLocation", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@Pitch_ID", proposalId);
                        comm.Parameters.AddWithValue("@LanguageID", languageID);
                        comm.Parameters.AddWithValue("@Mode", mode);
                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(comm);
                        DataTable DT = new DataTable();
                        DA.Fill(DT);
                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to get tags for pitch.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetTags(int proposalId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("PTags_GetPitchTags", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@Pitch_ID", proposalId);

                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(comm);

                        DataTable DT = new DataTable();
                        DA.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to get category details.
        /// </summary>
        /// <param name="categoryId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetCategoryDeatils(int categoryId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("PCategory_GetPitchCategoryDeatils", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@Category_ID", categoryId);
                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(comm);

                        DataTable DT = new DataTable();
                        DA.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        /// <summary>
        /// This method is used to get investors sorted by fund for select.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="fund"></param>
        /// <param name="lang"></param>
        /// <param name="currencyID"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetInvestorsForPitchByFundForSlelct(int proposalId, int fund, int lang, int currencyID)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("Pitch_GetInvestorsForPitchByFundForSlelct", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;

                        comm.Parameters.AddWithValue("@PID", proposalId);
                        comm.Parameters.AddWithValue("@Fund", fund);
                        comm.Parameters.AddWithValue("@Profile_LanguageID", lang);
                        comm.Parameters.AddWithValue("@CurrencyID", currencyID);
                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(comm);
                        DataTable DT = new DataTable();
                        DA.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to get accepted question of topic.
        /// </summary>
        /// <param name="questionTopicId"></param>
        /// <param name="questionLanguageId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable QuestionGetAcceptedQuestionsOfTopic(int questionTopicId, int questionLanguageId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("QUESTION_getAcceptedQuestionsOfTopic", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@QUESTION_TOPIC_ID", questionTopicId);

                        if (questionLanguageId == -1)
                            cmd.Parameters.AddWithValue("@QUESTION_LANGUAGEID", DBNull.Value);
                        else
                            cmd.Parameters.AddWithValue("@QUESTION_LANGUAGEID", questionLanguageId);
                        sql.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        return dt;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This function will return the result with two decimal points without doing floor or ceiling like what we followed in all the site
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="currencyId"></param>
        /// <param name="type"></param>
        /// <param name="pitchId"></param>
        /// <returns>The amount after exchange</returns>
        public double PitchGetExactAmountAfterExchange(double amount, int currencyID, string type, int proposalId)
        {
            try
            {
                DataTable DTRate = PitchGetPitchRate(proposalId, currencyID);
                if (DTRate.Rows.Count > 0)
                {
                    if (type == "1")
                        return Math.Ceiling(double.Parse(DTRate.Rows[0]["Pitch_rate"].ToString()) * amount);
                    else if (type == "2")
                        return Math.Floor(amount / double.Parse(DTRate.Rows[0]["Pitch_rate"].ToString()));
                    else return -2;
                }

                else
                    return -3;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to get current tranchSize by balance after discount.
        /// </summary>
        /// <param name="drPitchDetails"></param>
        /// <param name="balanceAfterDiscount"></param>
        /// <param name="tranchDiscount"></param>
        /// <param name="currentRemainingTrancheSize"></param>
        /// <exception cref="Exception"></exception>
        public void PitchGetCurrentTrancheDiscAndRemSizeByBalanceAfterDiscount(DataRow drPitchDetails, float balanceAfterDiscount, out double tranchDiscount, out double currentRemainingTrancheSize)
        {
            try
            {
                double tranchSize1 = 0, tranchSize2 = 0, tranchSize3 = 0, tranchSize4 = 0, pitchTranchEdge1 = 0, pitchTranchEdge2 = 0, pitchTranchEdge3 = 0, pitchTranchEdge4 = 0;

                if (!string.IsNullOrEmpty(drPitchDetails["Pitch_TranchSize1"].ToString()))
                    tranchSize1 = double.Parse(drPitchDetails["Pitch_TranchSize1"].ToString());
                if (!string.IsNullOrEmpty(drPitchDetails["Pitch_TranchSize2"].ToString()))
                    tranchSize2 = double.Parse(drPitchDetails["Pitch_TranchSize2"].ToString());
                if (!string.IsNullOrEmpty(drPitchDetails["Pitch_TranchSize3"].ToString()))
                    tranchSize3 = double.Parse(drPitchDetails["Pitch_TranchSize3"].ToString());
                if (!string.IsNullOrEmpty(drPitchDetails["Pitch_TranchSize4"].ToString()))
                    tranchSize4 = double.Parse(drPitchDetails["Pitch_TranchSize4"].ToString());

                pitchTranchEdge1 = tranchSize1;
                pitchTranchEdge2 = pitchTranchEdge1 + tranchSize2;
                pitchTranchEdge3 = pitchTranchEdge2 + tranchSize3;
                pitchTranchEdge4 = pitchTranchEdge3 + tranchSize4;

                if (balanceAfterDiscount < pitchTranchEdge1)
                {
                    tranchDiscount = double.Parse(drPitchDetails["Pitch_TranchDiscount1"].ToString());
                    currentRemainingTrancheSize = pitchTranchEdge1 - balanceAfterDiscount;
                }
                else if (balanceAfterDiscount >= pitchTranchEdge1 && balanceAfterDiscount < pitchTranchEdge2)
                {
                    tranchDiscount = double.Parse(drPitchDetails["Pitch_TranchDiscount2"].ToString());
                    currentRemainingTrancheSize = pitchTranchEdge2 - balanceAfterDiscount;
                }
                else if (balanceAfterDiscount >= pitchTranchEdge2 && balanceAfterDiscount < pitchTranchEdge3)
                {
                    tranchDiscount = double.Parse(drPitchDetails["Pitch_TranchDiscount3"].ToString());
                    currentRemainingTrancheSize = pitchTranchEdge3 - balanceAfterDiscount;
                }
                else if (balanceAfterDiscount >= pitchTranchEdge3 && balanceAfterDiscount < pitchTranchEdge4)
                {
                    tranchDiscount = double.Parse(drPitchDetails["Pitch_TranchDiscount4"].ToString());
                    currentRemainingTrancheSize = pitchTranchEdge4 - balanceAfterDiscount;
                }
                else
                {
                    tranchDiscount = 0;
                    currentRemainingTrancheSize = 0;
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to get sum of pending pre investment pitch after discount.
        /// </summary>
        /// <param name="preComInvestmentProposalId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public int PitchGetSumPendingPreInvestmentsAfterDiscount(int preComInvestmentProposalId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("Pitch_GetSumPendingPreInvestmentsAfterDiscount", sql))
                    {

                        comm.CommandType = CommandType.StoredProcedure;
                        comm.Parameters.AddWithValue("@PreComInvestment_PitchID", preComInvestmentProposalId);
                        sql.Open();


                        return Convert.ToInt32(comm.ExecuteScalar());
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        #endregion
        /// <summary>
        /// This method is used to get proposal follow.
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="userId"></param>
        /// <param name="langId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public string ProposalFollow(string proposalId, string userId, int langId)
        {
            try
            {
                if (userId != null)
                {
                    DataTable dtConnection = _pitchLikeFollower.PitchgetUserIsLikeFollower(int.Parse(userId), int.Parse(proposalId));
                    bool follower = dtConnection.Rows.Count > 0 && bool.Parse(dtConnection.Rows[0]["PUConnection_FollowType"].ToString());

                    if (!follower)
                    {
                        _pitchLikeFollower.PitchUpdateUserFollowing(int.Parse(userId), int.Parse(proposalId), true);
                        DataTable dtPitchDetails = PitchGetDedicatedPitchDetails(int.Parse(proposalId), (int)Languages.English);
                        _user.UserAddNotification(userId, _user.UserGetPitchUserID(proposalId).ToString(), "", NotificationType.FollowMyProposal);
                        _message.MessageSendMessageForUserFollowers(_user.UserGetSystemAdmin(), _user.UserGetAllUserFollowersForUser(int.Parse(userId)), _user.UserSelectById(int.Parse(userId)).Rows[0], dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString(), int.Parse(proposalId), "", 0, UserAction.FollowProposal);

                        DataTable dtUser = _user.UserGetDetails(int.Parse(userId), langId);
                        if (dtUser != null && dtUser.Rows.Count > 0)
                        {
                            int lastFollowedProposalId = -1;
                            int beforeLastFollowedProposalId = -1;
                            int beforePenultimateFollowedProposalId = -1;

                            DataTable dtLastFollowedProposals = _user.UserGetLastFollowedProposals(int.Parse(userId), 3);
                            if (dtLastFollowedProposals.Rows.Count == 1)
                            {
                                lastFollowedProposalId = int.Parse(dtLastFollowedProposals.Rows[0]["PUConnection_PitchID"].ToString());
                            }
                            else if (dtLastFollowedProposals.Rows.Count == 2)
                            {
                                lastFollowedProposalId = int.Parse(dtLastFollowedProposals.Rows[0]["PUConnection_PitchID"].ToString());
                                beforeLastFollowedProposalId = int.Parse(dtLastFollowedProposals.Rows[1]["PUConnection_PitchID"].ToString());
                            }
                            else if (dtLastFollowedProposals.Rows.Count == 3)
                            {
                                lastFollowedProposalId = int.Parse(dtLastFollowedProposals.Rows[0]["PUConnection_PitchID"].ToString());
                                beforeLastFollowedProposalId = int.Parse(dtLastFollowedProposals.Rows[1]["PUConnection_PitchID"].ToString());
                                beforePenultimateFollowedProposalId = int.Parse(dtLastFollowedProposals.Rows[2]["PUConnection_PitchID"].ToString());
                            }

                            DataTable dtInvestorContactableBySME = _user.UserCheckInvestorContactableBySME(dtUser.Rows[0]["User_Email"].ToString(), int.Parse(proposalId));
                            if (dtInvestorContactableBySME.Rows.Count == 0 && (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "Early Access" || dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "published" || dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "Overfunding"))
                                return "0";
                            else
                                return "1";
                        }
                        else
                            return "-2";

                    }
                    else
                    {//UNFollow 
                        _pitchLikeFollower.PitchUpdateUserFollowing(int.Parse(userId), int.Parse(proposalId), false);
                        DataTable dtUser = _user.UserGetDetails(int.Parse(userId), langId);
                        if (dtUser != null && dtUser.Rows.Count > 0)
                        {
                            int lastFollowedProposalId = -1;
                            int beforeLastFollowedProposalId = -1;
                            int beforePenultimateFollowedProposalId = -1;

                            DataTable dtLastFollowedProposals = _user.UserGetLastFollowedProposals(int.Parse(userId), 3);
                            if (dtLastFollowedProposals.Rows.Count == 1)
                            {
                                lastFollowedProposalId = int.Parse(dtLastFollowedProposals.Rows[0]["PUConnection_PitchID"].ToString());
                            }
                            else if (dtLastFollowedProposals.Rows.Count == 2)
                            {
                                lastFollowedProposalId = int.Parse(dtLastFollowedProposals.Rows[0]["PUConnection_PitchID"].ToString());
                                beforeLastFollowedProposalId = int.Parse(dtLastFollowedProposals.Rows[1]["PUConnection_PitchID"].ToString());
                            }
                            else if (dtLastFollowedProposals.Rows.Count == 3)
                            {
                                lastFollowedProposalId = int.Parse(dtLastFollowedProposals.Rows[0]["PUConnection_PitchID"].ToString());
                                beforeLastFollowedProposalId = int.Parse(dtLastFollowedProposals.Rows[1]["PUConnection_PitchID"].ToString());
                                beforePenultimateFollowedProposalId = int.Parse(dtLastFollowedProposals.Rows[2]["PUConnection_PitchID"].ToString());
                            }

                            return "2";
                        }
                        else
                            return "-2";
                    }

                }
                else
                {
                    return "-2";
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to get top three investments for a pitch.
        /// </summary>
        /// <param name="pitchId"></param>
        /// <param name="langId"></param>
        /// <param name="currencyId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetTopThreeInvestment(int pitchId, int langId, int currencyId)
        {
            try
            {
                SqlParameter paramPitchId = new SqlParameter("@Pitch_ID", pitchId);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", currencyId);
                DataTable dtInvestment = _sqlHelper.GetDataTable(_connectionString, "User_GetTopThreeInvestment", paramLangId, paramPitchId, paramCurrencyId);
                return dtInvestment;

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get All pitch Investments and Investors details by page number
        /// </summary>
        /// <param name="pitchId"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="recordCount"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable PitchGetInvestorsByPage(int pitchId, int currencyId, int fund, int langId, int pageIndex, int pageSize, out int recordCount)
        {
            try
            {
                SqlParameter paramPitchId = new SqlParameter("@PID", pitchId);
                SqlParameter paramFund = new SqlParameter("@Fund", fund);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", currencyId);
                SqlParameter paramPageIndex = new SqlParameter("@PageNo", pageIndex);
                SqlParameter paramPageSize = new SqlParameter("@PageSize", pageSize);
                SqlParameter paramRecordCount = new SqlParameter("@RecordCount", SqlDbType.Int, 4);
                paramRecordCount.Direction = ParameterDirection.Output;
                DataTable dtInvestors = _sqlHelper.GetDataTable(_connectionString, "Pitch_GetInvestorsForPitchByFundForSelectByPage", out recordCount, paramPitchId, paramPageIndex, paramPageSize, paramRecordCount, paramFund, paramCurrencyId, paramLangId);
                recordCount = int.Parse(paramRecordCount.Value.ToString());
                return dtInvestors;

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to get All pitch Followers details by page number
        /// </summary>
        /// <param name="pitchId"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="recordCount"></param>
        /// <returns>Datatable of information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable PitchGetFollowersByPage(int pitchId, int pageIndex, int pageSize, out int recordCount)
        {
            try
            {
                SqlParameter paramPitchId = new SqlParameter("@PID", pitchId);
                SqlParameter paramPageIndex = new SqlParameter("@PageNo", pageIndex);
                SqlParameter paramPageSize = new SqlParameter("@PageSize", pageSize);
                SqlParameter paramRecordCount = new SqlParameter("@RecordCount", SqlDbType.Int, 4);
                paramRecordCount.Direction = ParameterDirection.Output;
                DataTable dtFollowers = _sqlHelper.GetDataTable(_connectionString, "Pitch_GetFollowersByPage", out recordCount, paramPitchId, paramPageIndex, paramPageSize, paramRecordCount);
                recordCount = int.Parse(paramRecordCount.Value.ToString());
                return dtFollowers;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// Get Home Page slider pitches
        /// </summary>
        /// <param name="langId"></param>
        /// <param name="currencyId"></param>
        /// <returns>Datatable of information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable PitchGetSortPitchHomePageSlider(int langId, int currencyId)
        {
            try
            {
                SqlParameter paramLanguageId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", currencyId);
                return _sqlHelper.GetDataTable(_connectionString, "Pitch_GetSortPitchHomePageSlider", paramLanguageId, paramCurrencyId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to view all pitch counter info like (investor count , like count , follow count..
        /// </summary>
        /// <param name="pitchId"></param>
        /// <returns>Datatable of information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable PitchGetCounter(int pitchId)
        {
            try
            {
                SqlParameter paramPitchId = new SqlParameter("@PID", pitchId);
                return _sqlHelper.GetDataTable(_connectionString, "GetPitchCounter", paramPitchId);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }

        }

        /// <summary>
        /// This method is used to get All actives and non active propsoals 
        /// </summary>
        /// <param name="langId"></param>
        /// <param name="searchText"></param>
        /// <param name="allActiveNotActiveProposals"></param>
        /// <returns>Datatable of information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable PitchGetAllEOIProposals(int langId, string searchText, bool allActiveNotActiveProposals)
        {
            try
            {
                SqlParameter paramLanguageId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramAllActiveNotActiveProposals = new SqlParameter("@AllActiveNotActiveProposals", allActiveNotActiveProposals);
                SqlParameter paramSearchText = new SqlParameter("@SearchText", null);
                if (!string.IsNullOrWhiteSpace(searchText))
                    paramSearchText.Value = searchText;
                return _sqlHelper.GetDataTable(_connectionString, "Pitch_GetAllEOIProposals", paramLanguageId, paramAllActiveNotActiveProposals, paramSearchText);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Check proposal view prevented
        /// </summary>
        public void PitchViewProposalPrevention(bool pitchPreventExeption, int countryId, int pitchCountry, int userId, int pitchOwnerId, int pitchId, out string preventionFlag1, out string preventionFlag2, out string preventionFlag3, out string preventionFlag4)
        {
            preventionFlag4 = preventionFlag3 = preventionFlag2 = preventionFlag1 = "0";
            if (!pitchPreventExeption) //Convert.ToBoolean(dtPitchDetails.Rows[0]["Pitch_Prevent_Exeption"].ToString())
            {
                int groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.ViewProposal_Prevent, countryId, pitchCountry); //int.Parse(dtPitchDetails.Rows[0]["Pitch_Country"].ToString())
                if (groupId > 0)
                {

                    if (userId == 0)
                    {
                        preventionFlag1 = "1";
                        return;
                    }
                    // Show login confirm to get access
                    // Page.ClientScript.RegisterStartupScript(GetType(), "Message", "apprise('<h4>The proposal is only available for viewing upon request, you must login into your account and request viewing access.<br /><br />Would you like to proceed to the Login page?</h4>', {'verify':true},function(r) {if(r){window.location = '" + ResolveUrl(System.Configuration.ConfigurationManager.AppSettings["loginPageURL"] + "?" + Mytools.GetURLLang("", "")) + "';}else window.location ='" + ResolveUrl("~/Default.aspx") + "'});", true);
                    else if (userId != pitchOwnerId && !_user.UserIsAdmin(userId) && !_user.UserIsBIAdmin(userId))
                    {
                        DataTable dtUserRequst = _user.UserGetUserRequest((int)RequestType.ViewProposalPrevention, userId, pitchId);
                        if (dtUserRequst.Rows.Count > 0)
                        {
                            bool flag = bool.Parse(dtUserRequst.Rows[0]["flag"].ToString());
                            bool rejectFlag = bool.Parse(dtUserRequst.Rows[0]["Reject_Flag"].ToString());

                            // pending  flag1
                            if (!flag && !rejectFlag)
                                preventionFlag2 = "1";
                            //flag 2
                            else if (rejectFlag)
                                preventionFlag3 = "1";
                        }
                        //flag3
                        else
                        {
                            preventionFlag4 = "1";
                            return;
                        }
                    }
                }
            }

        }
        /// <summary>
        /// This method is used to check prevention of view proposal.
        /// </summary>
        /// <param name="pitchPreventExeption"></param>
        /// <param name="countryId"></param>
        /// <param name="userId"></param>
        /// <param name="pitchOwnerId"></param>
        /// <param name="pitchId"></param>
        /// <returns></returns>
        public string PitchViewProposalPreventionByProposal(bool pitchPreventExeption, int countryId, int userId, int pitchOwnerId, int pitchId)
        {
            if (!pitchPreventExeption)
            {
                int groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControlbyPage(CountryBasedControls.ViewProposal_PreventByPage, pitchId, countryId);
                if (groupId > 0)
                {
                    if (userId == 0 && (userId == pitchOwnerId || _user.UserIsAdmin(userId) || _user.UserIsBIAdmin(userId)))
                    {

                        return "0";
                    }
                    else
                    {
                        return "1";
                    }

                }
                else return "0";
            }
            else
                return "0";
        }
        /// <summary>
        /// This method is used to check proposal viewing prevention by user kyc.
        /// </summary>
        /// <param name="pitchPreventExeption"></param>
        /// <param name="countryId"></param>
        /// <param name="pitchCountry"></param>
        /// <param name="userId"></param>
        /// <param name="pitchOwnerId"></param>
        /// <param name="pitchId"></param>
        /// <param name="pitchStatus"></param>
        /// <param name="userFormType"></param>
        /// <returns></returns>
        public string PitchCheckProposalViewingPreventionByUserKYC(bool pitchPreventExeption, int countryId, int pitchCountry, int userId, int pitchOwnerId, int pitchId, string pitchStatus, int userFormType)
        {
            if (!pitchPreventExeption) //Convert.ToBoolean(dtPitchDetails.Rows[0]["Pitch_Prevent_Exeption"].ToString())
            {
                if (userId == 0 && userId != pitchOwnerId && !_user.UserIsAdmin(userId) && !_user.UserIsBIAdmin(userId))
                {
                    if (pitchStatus == "published" || pitchStatus == "Overfunding" || pitchStatus == "Early Access")
                    {
                        int groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.ViewProposal_PreventByKYC, countryId, pitchCountry);//int.Parse(dtPitchDetails.Rows[0]["Pitch_Country"].ToString())
                        if (groupId > 0)
                        {
                            int neededDocs = 0;
                            int acceptedDocsFromNeeded = 0;

                            if (userFormType != (int)UserType.Enreprenuer && userFormType != (int)UserType.Admin && userFormType != (int)UserType.BIAdmin && userFormType != (int)UserType.SystemAdmin)
                            {
                                int[] array = new int[19];
                                DataTable dtUserCountry = _countryBasedControlRepository.CountryBasedGetCountryDetails(countryId, (int)Languages.English);
                                if (dtUserCountry.Rows.Count > 0)
                                    array = _kyc.KYCGetRequiredDocs(userId, int.Parse(dtUserCountry.Rows[0]["Country_KYC_Tire"].ToString()));

                                neededDocs = array[0];
                                acceptedDocsFromNeeded = array[18];
                            }

                            if (neededDocs - acceptedDocsFromNeeded > 0)
                                return "1";
                        }
                    }
                }
            }
            return "0";
        }
        /// <summary>
        /// This method is used to check if pitch profile is visible.
        /// </summary>
        /// <param name="pitchId"></param>
        /// <param name="langId"></param>
        /// <returns></returns>
        public bool PitchCheckProfileVisible(long pitchId, int langId)
        {
            try
            {
                SqlParameter paramPitchId = new SqlParameter("@Profile_PitchID", pitchId);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);

                int ReturnValue = _sqlHelper.ExecuteReader(_connectionString, "Pitch_CheckProfileVisible", paramPitchId, paramLangId);

                if (ReturnValue == 0 || ReturnValue == 2)
                    return false;

                return true;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }
        /// <summary>
        /// This method is used to update pitch status to viewed.
        /// </summary>
        /// <param name="pitchId"></param>
        /// <exception cref="Exception"></exception>
        public void PitchUpdatePitchViewed(int pitchId)
        {
            try
            {
                SqlParameter paramPitchId = new SqlParameter("@PID", pitchId);
                _sqlHelper.ExecuteReader(_connectionString, "updatePitchViewed", paramPitchId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }

        }
        /// <summary>
        /// This method is used to add update to the pitch.
        /// </summary>
        /// <param name="title"></param>
        /// <param name="pitchId"></param>
        /// <param name="text"></param>
        /// <param name="langId"></param>
        /// <returns></returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public int PitchAddPitchUpdate(string title, int pitchId, string text, int langId)
        {
            int updateId = 0;
            try
            {
                SqlParameter paramTitle = new SqlParameter("@PitchUpdate_Title", title);
                SqlParameter paramPitchId = new SqlParameter("@PitchUpdate_PitchID", pitchId);
                SqlParameter paramText = new SqlParameter("@PitchUpdate_Text", text);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramReturnValue = new SqlParameter("ReturnValue", SqlDbType.Int, 4);
                paramReturnValue.Direction = ParameterDirection.ReturnValue;
                _sqlHelper.ExecuteNonQuery(_connectionString, "Pitch_AddPitchUpdate", paramTitle, paramPitchId, paramText, paramLangId, paramReturnValue);
                updateId = (int)paramReturnValue.Value;
                return updateId;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to Add Pitch Update Attachment
        /// </summary>
        /// <param name="pitchUpdateId"></param>
        /// <param name="fileName"></param>
        /// <param name="description"></param>
        /// <param name="pitchUpdateAttachmentThumbnail"></param>
        /// <returns></returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public void PitchAddPitchUpdateAttachment(int pitchUpdateId, string fileName, string description, string pitchUpdateAttachmentThumbnail)
        {
            try
            {
                SqlParameter paramPitchUpdateId = new SqlParameter("@PitchUpdateAttachment_UpdateID", pitchUpdateId);
                SqlParameter paramFileName = new SqlParameter("@PitchUpdateAttachment_FileName", fileName);
                SqlParameter paramDescription = new SqlParameter("@PitchUpdateAttachment_Description", description);
                SqlParameter paramPitchUpdateAttachmentThumbnail = new SqlParameter("@PitchUpdateAttachment_Thumbnail", pitchUpdateAttachmentThumbnail);
                _sqlHelper.ExecuteReader(_connectionString, "Pitch_AddPitchUpdateAttachment", paramPitchUpdateId, paramFileName, paramDescription, paramPitchUpdateAttachmentThumbnail);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This method is used to get Pitch Details for Quick Invest
        /// </summary>
        /// <param name="pitchId"></param>
        /// <param name="langId"></param>
        /// <param name="currencyId"></param>
        /// <returns></returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public DataTable PitchDetailsForQuickInvest(int pitchId, int langId, int currencyId)
        {
            try
            {
                SqlParameter paramPitchId = new SqlParameter("@Pitch_ID", pitchId);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", currencyId);

                return _sqlHelper.GetDataTable(_connectionString, "Pitch_GetPitchDetails_QuickInvest", paramPitchId, paramLangId, paramCurrencyId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This method is used to get the shares offered after discount for amount of dollars
        /// </summary>
        /// <param name="dollarsAmount"></param>
        /// <param name="sharePrice"></param>
        /// <param name="proposalBalanceAD"></param>
        /// <param name="hasDiscount"></param>
        /// <param name="tranch1Size"></param>
        /// <param name="tranch1Discount"></param>
        /// <param name="tranch2Size"></param>
        /// <param name="tranch2Discount"></param>
        /// <param name="tranch3Size"></param>
        /// <param name="tranch3Discount"></param>
        /// <param name="tranch4Size"></param>
        /// <param name="tranch4Discount"></param>
        /// <returns></returns>
        public float PitchCalcSharesOfDollars(int dollarsAmount, float sharePrice, int proposalBalanceAD, bool hasDiscount, int tranch1Size, int tranch1Discount, int tranch2Size, int tranch2Discount, int tranch3Size, int tranch3Discount, int tranch4Size, int tranch4Discount)
        {
            try
            {
                if (hasDiscount)
                {
                    int remainSizeInTranche = 0, dollarsForTranche1 = 0, dollarsForTranche2 = 0, dollarsForTranche3 = 0, dollarsForTranche4 = 0, dollarsAfterTranche4 = 0;

                    if (proposalBalanceAD >= tranch1Size)
                    {
                        //inside T2
                        if (proposalBalanceAD >= tranch1Size + tranch2Size)
                        {
                            //inside T3
                            if (proposalBalanceAD >= tranch1Size + tranch2Size + tranch3Size)
                            {
                                //inside T4
                                if (proposalBalanceAD >= tranch1Size + tranch2Size + tranch3Size + tranch4Size)
                                {
                                    dollarsAfterTranche4 = dollarsAmount;
                                }
                                else
                                {
                                    remainSizeInTranche = tranch4Size - (proposalBalanceAD - tranch1Size - tranch2Size - tranch3Size);
                                    if (dollarsAmount > remainSizeInTranche)
                                    {
                                        dollarsForTranche4 = remainSizeInTranche;
                                        dollarsAmount = dollarsAmount - dollarsForTranche4;
                                        dollarsAfterTranche4 = dollarsAmount;
                                    }
                                    else
                                        dollarsForTranche4 = dollarsAmount;
                                }
                            }
                            else
                            {
                                //inside T3
                                remainSizeInTranche = tranch3Size - (proposalBalanceAD - tranch1Size - tranch2Size);
                                if (dollarsAmount > remainSizeInTranche)
                                {
                                    dollarsForTranche3 = remainSizeInTranche;
                                    dollarsAmount = dollarsAmount - dollarsForTranche3;
                                    if (dollarsAmount > tranch4Size)
                                    {
                                        dollarsForTranche4 = tranch4Size;
                                        dollarsAmount = dollarsAmount - dollarsForTranche4;
                                        dollarsAfterTranche4 = dollarsAmount;
                                    }
                                    else
                                        dollarsForTranche4 = dollarsAmount;
                                }
                                else
                                    dollarsForTranche3 = dollarsAmount;
                            }
                        }
                        else
                        {
                            //inside T2
                            remainSizeInTranche = tranch2Size - (proposalBalanceAD - tranch1Size);
                            if (dollarsAmount > remainSizeInTranche)
                            {
                                dollarsForTranche2 = remainSizeInTranche;
                                dollarsAmount = dollarsAmount - dollarsForTranche2;
                                if (dollarsAmount > tranch3Size)
                                {
                                    dollarsForTranche3 = tranch3Size;
                                    dollarsAmount = dollarsAmount - dollarsForTranche3;
                                    if (dollarsAmount > tranch4Size)
                                    {
                                        dollarsForTranche4 = tranch4Size;
                                        dollarsAmount = dollarsAmount - dollarsForTranche4;
                                        dollarsAfterTranche4 = dollarsAmount;
                                    }
                                    else
                                        dollarsForTranche4 = dollarsAmount;
                                }
                                else
                                    dollarsForTranche3 = dollarsAmount;
                            }
                            else
                                dollarsForTranche2 = dollarsAmount;
                        }
                    }
                    else
                    {
                        //inside T1
                        remainSizeInTranche = tranch1Size - proposalBalanceAD;
                        if (dollarsAmount > remainSizeInTranche)
                        {
                            dollarsForTranche1 = remainSizeInTranche;
                            dollarsAmount = dollarsAmount - dollarsForTranche1;
                            if (dollarsAmount > tranch2Size)
                            {
                                dollarsForTranche2 = tranch2Size;
                                dollarsAmount = dollarsAmount - dollarsForTranche2;
                                if (dollarsAmount > tranch3Size)
                                {
                                    dollarsForTranche3 = tranch3Size;
                                    dollarsAmount = dollarsAmount - dollarsForTranche3;
                                    if (dollarsAmount > tranch4Size)
                                    {
                                        dollarsForTranche4 = tranch4Size;
                                        dollarsAmount = dollarsAmount - dollarsForTranche4;
                                        dollarsAfterTranche4 = dollarsAmount;
                                    }
                                    else
                                        dollarsForTranche4 = dollarsAmount;
                                }
                                else
                                    dollarsForTranche3 = dollarsAmount;
                            }
                            else
                                dollarsForTranche2 = dollarsAmount;
                        }
                        else
                            dollarsForTranche1 = dollarsAmount;
                    }

                    float SharesForTranche1 = 0, SharesForTranche2 = 0, SharesForTranche3 = 0, SharesForTranche4 = 0, SharesAfterTranche4 = 0;

                    if (dollarsForTranche1 > 0)
                        SharesForTranche1 = Tools.Round2DP(dollarsForTranche1 / Tools.Round2DP(sharePrice - tranch1Discount / (float)100 * sharePrice));
                    if (dollarsForTranche2 > 0)
                        SharesForTranche2 = Tools.Round2DP(dollarsForTranche2 / Tools.Round2DP(sharePrice - tranch2Discount / (float)100 * sharePrice));
                    if (dollarsForTranche3 > 0)
                        SharesForTranche3 = Tools.Round2DP(dollarsForTranche3 / Tools.Round2DP(sharePrice - tranch3Discount / (float)100 * sharePrice));
                    if (dollarsForTranche4 > 0)
                        SharesForTranche4 = Tools.Round2DP(dollarsForTranche4 / Tools.Round2DP(sharePrice - tranch4Discount / (float)100 * sharePrice));
                    if (dollarsAfterTranche4 > 0)
                        SharesAfterTranche4 = Tools.Round2DP(dollarsAfterTranche4 / sharePrice);

                    return Tools.Round2DP(SharesForTranche1 + SharesForTranche2 + SharesForTranche3 + SharesForTranche4 + SharesAfterTranche4);
                }
                else
                    return Tools.Round2DP(dollarsAmount / sharePrice);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to get the sum of the pending PreInvestments of user in a desired currency which identify the user reserved balance in this currency
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="currencyId"></param>
        /// <returns>int</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public int PitchGetSumPendingPreInvestmentsForUserByCurrency(int userId, int currencyId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@PreComInvestment_UserID", userId);
                SqlParameter paramCurrencyId = new SqlParameter("@PreComInvestment_CurrecnyID", currencyId);
                return _sqlHelper.ExecuteScalar(_connectionString, "Pitch_GetSumPendingPreInvestmentsForUserByCurrency", paramUserId, paramCurrencyId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message);
            }

        }
        /// <summary>
        /// This method is used to get the User active live pitch
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public DataTable PitchGetUserActiveLiveOpenedPitch(int userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                return _sqlHelper.GetDataTable(_connectionString, "Pitch_getUserActiveLiveOpenedPitch", paramUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This method is used to get the current active pitch for this user
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public DataTable PitchGetUserActivePitch(int userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                return _sqlHelper.GetDataTable(_connectionString, "Pitch_getUserActivePitch", paramUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }


        /// <summary>
        /// This method is used to get the check list for a user
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public DataTable PitchGetCheckListApplication(int userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@CheckList_UserID", userId);
                return _sqlHelper.GetDataTable(_connectionString, "CheckList_Get_Application", paramUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }

        }

        ///  <summary>
        /// This method is used to get the most recent investment 
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="langId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetMostRecentInvestment(int proposalId, int langId)
        {
            try
            {
                SqlParameter paramProposalId = new SqlParameter("@Pitch_ID", proposalId);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetMostRecentInvestment", paramProposalId, paramLangId);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        ///  <summary>
        /// This method is used to the lead investment 
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="langId"></param>
        /// <param name="currencyId"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public DataTable PitchGetLeadInvestment(int proposalId, int langId, int currencyId)
        {
            try
            {
                SqlParameter paramProposalId = new SqlParameter("@Pitch_ID", proposalId);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", currencyId);

                return _sqlHelper.GetDataTable(_connectionString, "User_GetLeadInvestment", paramProposalId, paramLangId, paramCurrencyId);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to get days left to puplic pitch.
        /// </summary>
        /// <param name="DateConverted"></param>
        /// <returns></returns>
        public string PitchGetPublicDaysLeft(DateTime DateConverted)
        {

            DateTime end = DateTime.Now;
            DateTime start = DateConverted;
            int delta = (int)(end - start).TotalMinutes;
            int TimeParts2 = 0;
            string days = "";
            string days1 = "";


            if (delta < 1)
            {
                TimeParts2 = delta;
                days = _stringLocalizer["FewSecAgo"].Value;

            }
            if (delta >= 1 && delta < 60)
            {
                TimeParts2 = delta;
                days = TimeParts2.ToString();
                if (TimeParts2 == 1 || TimeParts2 == 2 || TimeParts2 > 10)
                    days1 = _stringLocalizer["MinAgo"].Value;
                else if (TimeParts2 > 2 && TimeParts2 <= 10)
                    days1 = _stringLocalizer["MinsAgo"].Value;

            }
            else if (delta >= 60 && delta < 2880)
            {

                TimeParts2 = delta / 60;
                days = TimeParts2.ToString();
                if (TimeParts2 == 1 || TimeParts2 > 10)
                    days1 = _stringLocalizer["HourAgo"].Value;
                else if (TimeParts2 >= 2 && TimeParts2 <= 10)
                    days1 = _stringLocalizer["HoursAgo"].Value;

            }
            else if (delta >= 2880 && delta < 43200)
            {
                TimeParts2 = delta / 24 / 60;
                days = TimeParts2.ToString();
                if (TimeParts2 == 1 || TimeParts2 == 2 || TimeParts2 > 10)
                    days1 = _stringLocalizer["DayAgo"].Value;
                else if (TimeParts2 > 2 && TimeParts2 <= 10)
                    days1 = _stringLocalizer["DaysAgo"].Value;

            }
            else if (delta >= 43200 && delta < 518400)
            {
                TimeParts2 = delta / 60 / 24 / 30;
                days = TimeParts2.ToString();
                if (TimeParts2 == 1 || TimeParts2 == 2 || TimeParts2 > 10)
                    days1 = _stringLocalizer["MonthAgo"].Value;
                else if (TimeParts2 > 2 && TimeParts2 <= 10)
                    days1 = _stringLocalizer["MonthsAgo"].Value;


            }
            else if (delta >= 518400)
            {
                TimeParts2 = delta / 60 / 24 / 30 / 12;
                days = TimeParts2.ToString();
                if (TimeParts2 == 1 || TimeParts2 == 2 || TimeParts2 > 10)
                    days1 = _stringLocalizer["YearAgo"].Value;
                else if (TimeParts2 > 2 && TimeParts2 <= 10)
                    days1 = _stringLocalizer["YearsAgo"].Value;
            }

            return days + " " + days1;
        }
        /// <summary>
        /// This method is used to get Status Number.
        /// </summary>
        /// <param name="pitchStatus"></param>
        /// <returns></returns>
        public int PitchGetStatusNumber(string pitchStatus)
        {
            switch (pitchStatus)
            {
                case "not ready":
                    return (int)PitchStatus.NotReady;
                case "submitted For Approval":
                    return (int)PitchStatus.SubmittedForApproval;
                case "published":
                    return (int)PitchStatus.Published;
                case "cancelled":
                    return (int)PitchStatus.Cancelled;
                case "expired":
                    return (int)PitchStatus.Expired;
                case "completed":
                    return (int)PitchStatus.Completed;
                case "completed and closed":
                    return (int)PitchStatus.CompletedAndClosed;
                case "expired and closed":
                    return (int)PitchStatus.ExpiredAndClosed;
                case "cancelled and closed":
                    return (int)PitchStatus.CancelledAndClosed;
                case "coming soon":
                    return (int)PitchStatus.ComingSoon;
                case "Early Access":
                    return (int)PitchStatus.EarlyAccess;
                case "Overfunding":
                    return (int)PitchStatus.OverFunding;
                case "Overfunded":
                    return (int)PitchStatus.OverFunded;
                case "Minimum-Funded":
                    return (int)PitchStatus.MinimumFunded;
                default:
                    return (int)PitchStatus.NotReady;

            }
        }

        /// <summary>
        /// This method is used to get the list of all pending investment of proposal
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="langId"></param>
        /// <param name="currencyId"></param>
        /// <returns>DataTable of all information</returns>
        /// <exception cref="Exception">Will Write the error in the error log file</exception>
        public DataTable PitchGetAllPendingPreInvestmentsPaging(int proposalId, int langId, int currencyId, int pageNo, int PageSize, out int recordCount)
        {
            try
            {
                SqlParameter paramProposalId = new SqlParameter("@PreComInvestment_PitchID", proposalId);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", currencyId);
                SqlParameter paramPageNo = new SqlParameter("@PageNo", pageNo);
                SqlParameter paramPageSize = new SqlParameter("@PageSize", PageSize);
                SqlParameter paramRecordCount = new SqlParameter("@RecordCount", SqlDbType.Int, 4);
                paramRecordCount.Direction = ParameterDirection.Output;
                DataTable dtPendingInvestment = _sqlHelper.GetDataTable(_connectionString, "Pitch_GetAllPendingPreInvestmentsPaging", paramProposalId, paramLangId, paramCurrencyId, paramPageNo, paramPageSize, paramRecordCount);
                recordCount = int.Parse(paramRecordCount.Value.ToString());
                return dtPendingInvestment;

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This method is used to get the list of all user requests of proposal
        /// </summary>
        /// <param name="proposalId"></param>
        /// <param name="langId"></param>
        /// <param name="requestType"></param>
        /// <param name="pageNo"></param>
        /// <param name="PageSize"></param>
        /// <param name="recordCount"></param>
        /// <returns>DataTable of All information</returns>
        /// <exception cref="Exception">Will Write the error in the error log file</exception>
        public DataTable PitchGetProposalRequestsPaging(int proposalId, int langId, int requestType, int pageNo, int PageSize, out int recordCount)
        {
            try
            {
                SqlParameter paramProposalId = new SqlParameter("@PitchID", proposalId);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramRequestType = new SqlParameter("@Request_Type", DBNull.Value);
                if (requestType > 0)
                    paramRequestType.Value = requestType;


                SqlParameter paramPageNo = new SqlParameter("@PageNo", pageNo);
                SqlParameter paramPageSize = new SqlParameter("@PageSize", PageSize);
                SqlParameter paramRecordCount = new SqlParameter("@RecordCount", SqlDbType.Int, 4);
                paramRecordCount.Direction = ParameterDirection.Output;
                DataTable dtPendingInvestment = _sqlHelper.GetDataTable(_connectionString, "GetProposalRequestsPaging", paramProposalId, paramLangId, paramRequestType, paramPageNo, paramPageSize, paramRecordCount);
                recordCount = int.Parse(paramRecordCount.Value.ToString());
                return dtPendingInvestment;

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This method is used to get the active proposals to show it in the proposal list on the payment journey
        /// </summary>
        /// <param name="LangId"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public DataTable PitchGetActivePitchesForPayment(int LangId)
        {
            try
            {
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", LangId);
                return _sqlHelper.GetDataTable(_connectionString, "Pitch_GetActivePitchesForPayment", paramLangId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Get top 6 investors for proposals dispalyed on the slider
        /// </summary>
        /// <param name="pitchId"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public DataTable PitchGetTop6InvestorsForSlider(int pitchId)
        {
            try
            {
                SqlParameter paramPitchId = new SqlParameter("@PID", pitchId);
                return _sqlHelper.GetDataTable(_connectionString, "Pitch_GetTop6InvestorsForSlider", paramPitchId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }




		/// <summary>
		/// This method is used to get all completed proposals.
		/// </summary>
		/// <returns></returns>
		/// <exception cref="Exception"></exception>
		public List<Pitch> PitchGetCompletedPitchsList(int langId, int currencyId, int countryId, int userId, int categoryID,
			string sorting, int tagID, int pageNo, int pageSize, string currencySymbol, out int recordCount)
		{
			recordCount = 0;
			try
			{
				List<Pitch> proposals = new List<Pitch>();

				var pitchList = Tools.ConvertDataTable<PitchGetAllPitchResult>(
					PitchGetAllCompletedPitchsByPaging(langId, categoryID, sorting, currencyId, tagID, pageNo, pageSize));

				return PreparePitcheListResult(langId, currencyId, countryId, userId, currencySymbol, ref recordCount, pitchList);

			}

			catch (Exception ex)
			{
				_errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
				throw new Exception(ex.Message + "\n" + ex.StackTrace);
			}
		}


		/// <summary>
		/// This method is used to get all Live proposals, set IsPublished false for early access,and true for published.
		/// </summary>
		/// <returns></returns>
		/// <exception cref="Exception"></exception>
		public List<Pitch> PitchGetLivePitchsList(int langId, int currencyId, int countryId, int userId, int categoryID,
			string sorting, int tagID, int pageNo, int pageSize, string currencySymbol, bool isPublished, out int recordCount)
		{
			recordCount = 0;
			try
			{
				var pitchList = Tools.ConvertDataTable<PitchGetAllPitchResult>(
					PitchGetAllLivePitchsByPaging(langId, categoryID, sorting, currencyId, isPublished, tagID, pageNo, pageSize));

				return PreparePitcheListResult(langId, currencyId, countryId, userId, currencySymbol, ref recordCount, pitchList);
			}

			catch (Exception ex)
			{
				_errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
				throw new Exception(ex.Message + "\n" + ex.StackTrace);
			}
		}

		/// <summary>
		/// Prepare the List of Proposals/Pitches 
		/// </summary>
		/// <param name="langId"></param>
		/// <param name="currencyId"></param>
		/// <param name="countryId"></param>
		/// <param name="userId"></param>
		/// <param name="currencySymbol"></param>
		/// <param name="recordCount"></param>
		/// <param name="pitchList"></param>
		/// <returns></returns>
		private List<Pitch> PreparePitcheListResult(int langId, int currencyId, int countryId, int userId, string currencySymbol,
			ref int recordCount, List<PitchGetAllPitchResult> pitchList)
		{
			List<Pitch> proposals = new List<Pitch>();

			if (pitchList.Count > 0)
			{
				recordCount = pitchList[0].TotalCount;

				foreach (var dr in pitchList)
				{
					if (PitchIsProposalViewPrevented(dr, countryId, userId))
						pitchList.Remove(dr);
				}

				foreach (var dr in pitchList)
				{
					var proposal = new Pitch()
					{
						Pitch_ID = dr.Pitch_ID,
						Profile_PitchCity = dr.Profile_PitchCity,
						Pitch_Status = dr.Pitch_Status,
						Pitch_HasDiscount = dr.Pitch_HasDiscount ?? false,
						Pitch_IsInvestmentFrozen = dr.Pitch_Is_Investment_Frozen ?? false,
						Profile_PitchShortSummary = dr.Profile_PitchShortSummary,
						Pitch_InvestmentRequired = dr.Pitch_InvestmentRequired ?? 0,
						Pitch_Balance = dr.Pitch_Balance ?? 0,
						Pitch_Investors = dr.Pitch_Investors ?? 0,
						Pitch_Post_Money_Val = dr.Pitch_Post_Money_Val ?? 0,
						Profile_PitchOrder = (int)(dr.RowNumber ?? 0)
					};

					proposal.Profile_PitchTitle = dr.Profile_PitchTitle1;
					proposal.Profile_PitchShortSummary = dr.Profile_PitchShortSummary;

					int pitchIDInt = (int)dr.Pitch_ID;

					// Updates the Pitch in DB based on the its expiration & statuses
					PitchTestExpiration(langId, pitchIDInt);

					#region badges

					DataTable dtBadges = PitchBadgesAssignedGetAll(1, 100, langId, pitchIDInt, out _);
					if (dtBadges.Rows.Count > 0)
					{
						var badgesData = dtBadges.Rows[0]["Badges"].ToString();
						if (!string.IsNullOrEmpty(badgesData))
							proposal.Badges = JsonConvert.DeserializeObject<List<Badge>>(badgesData) ?? new List<Badge>();
					}

					#endregion

					#region check when the user is loggedin

					proposal.isFollowed = false;
					proposal.canFollow = true;
					proposal.isInvestEnabled = true;


					DataTable dtConnection = _pitchLikeFollower.PitchgetUserIsLikeFollower(userId, pitchIDInt);
					bool follower = dtConnection.Rows.Count > 0 &&
									bool.Parse(dtConnection.Rows[0]["PUConnection_FollowType"].ToString() ?? "0");
					proposal.isFollowed = follower;

					if (userId == dr.Pitch_UserID)
					{
						proposal.canFollow = false;
					}

					int groupId =
						_countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControl(
							CountryBasedControls.Proposal_Widgets_Blur, countryId);
					if (groupId > 0 && (dr.Pitch_Status == "Early Access" || dr.Pitch_Status == "published"
																		  || dr.Pitch_Status == "Overfunding"))
						proposal.IsBlured = true;


					DataTable dtLoggedInUserInfo = _user.UserSelectById(userId);

					if (dtLoggedInUserInfo.Rows.Count > 0)
					{
						int userFormType = Convert.ToInt32(dtLoggedInUserInfo.Rows[0]["User_UserFormType"]);

						if ((dr.Pitch_Status != "published" && dr.Pitch_Status != "Overfunding"
															&& dr.Pitch_Status != "Early Access") ||
							(dtLoggedInUserInfo.Rows[0]["User_UserType"].ToString() != "2" &&
							 dtLoggedInUserInfo.Rows[0]["User_UserType"].ToString() != "4"))
						{
							proposal.isInvestEnabled = false;
						}

						if (userFormType == (int)UserType.Enreprenuer)
						{
							proposal.isInvestEnabled = false;
						}

						if (userFormType != (int)UserType.Enreprenuer && userFormType != (int)UserType.Admin &&
							userFormType != (int)UserType.BIAdmin && userFormType != (int)UserType.SystemAdmin)
						{
							KYCModel kycModel = _user.KYCGetRequiredFiles(userId, countryId);
							if (kycModel.KYCOverAllStatus != (int)KYCUserDocsStatus.Accepted && groupId > 0 &&
								(dr.Pitch_Status == "Early Access" || dr.Pitch_Status == "published" ||
								 dr.Pitch_Status == "Overfunding"))
								proposal.IsKYCBlured = true;
						}
					}

					var dtFollowingInvestedInAPitch =
						Tools.ConvertDataTable<UserPitchFollowing>(
							UserGetFollowingInvestedInAPitch(userId, pitchIDInt, langId));
					if (dtFollowingInvestedInAPitch.Count > 0)
					{
						foreach (var item in dtFollowingInvestedInAPitch)
						{
							if (string.IsNullOrEmpty(item.User_Picture) ||
								!File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") +
														  "User/thumbs/thumb_" + item.User_Picture)))
								item.User_Picture = _config.GetValue<string>("EnvironmentURL") + "/images/v2/Default.jpg";
							else
							{
								item.User_Picture = _config.GetValue<string>("AttachementsEnvironmentURL") +
													"User/Thumbs/Thumb_" + item.User_Picture;
							}
						}

						proposal.UserPitchFollowing = dtFollowingInvestedInAPitch;
					}

					#endregion

					proposal.profile_country_name = dr.Profile_PitchCity +
													(!String.IsNullOrEmpty(dr.Profile_PitchCity) ? ", " : "") +
													dr.profile_country_name;

					proposal.SME_firstName = dr.Profile_FirstName;
					proposal.SME_lastName = dr.Profile_LastName;

					proposal.PreMoneyValuation = dr.Pitch_Pre_Money_Val_Converted ?? 0;
					proposal.EquityOffered =
						!string.IsNullOrEmpty(dr.Pitch_EquityOffered) ? double.Parse(dr.Pitch_EquityOffered) : 0;
					proposal.HighestInvestment = dr.MaxInvAmount ?? 0;
					proposal.OverfundingTaget = dr.OverSubAmount ?? 0;

					proposal.EarlyAccessCode = dr.Pitch_AccessCode;
					proposal.EarlyAccessMode = Convert.ToBoolean(dr.Pitch_EarlyAccess_Access_Mode);


					#region Proposal widget Image

					proposal.WidgetImage = "";
					if (dr.Profile_PitchWidgetImageID.HasValue)
					{
						DataTable dtPitchAttachInf =
							_pitchAttachementsRepository.PitchGetAttachementDetails((int)dr.Profile_PitchWidgetImageID.Value);
						if (dtPitchAttachInf.Rows.Count > 0)
						{
							string? img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
							if (File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") +
														 "pitch/thumbs/thumb_" + img)))
								proposal.WidgetImage = _config.GetValue<string>("AttachementsEnvironmentURL") +
													   "pitch/thumbs/thumb_" + img;
							else
								proposal.WidgetImage = _config.GetValue<string>("EnvironmentURL") +
													   "Images/v2/pitchDefault.jpg";
						}
					}

					#endregion

					#region Proposal Main Image

					proposal.Logo = "";
					if (!string.IsNullOrEmpty(dr.Profile_PitchMainImage_Guid.Trim()))
					{
						string img = dr.Profile_PitchMainImage_Guid;
						if (File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") +
													 "pitch/thumbs/thumb_" + img)))
							proposal.Logo = _config.GetValue<string>("AttachementsEnvironmentURL") +
											"pitch/thumbs/thumb_" + img;
						else
							proposal.Logo = _config.GetValue<string>("EnvironmentURL") + "Images/v2/logoDefault.png";
					}

					#endregion


					#region set progress label

					if (!dr.Pitch_IsOpaque.HasValue || !dr.Pitch_IsOpaque.Value)
					{
						proposal.ProgressLbl = _stringLocalizer["Confidential_Request_access_code_to_view"].Value;
					}
					else
					{
						#region Check Pitch Status

						proposal.ProgressLbl = "";
						// using Math.Abs as the double comparison is not wokr exacty like int
						if (dr.Pitch_Status == "completed" || (dr.Pitch_Status == "completed and closed" &&
															   Math.Abs(
																   dr.Pitch_Balance ?? 0 - dr.Pitch_InvestmentRequired ?? 0) <
															   0.0001))
						{
							//100% funded and closed
							dr.Pitch_Status = _stringLocalizer["Funded1"].Value;
						}
						else if (dr.Pitch_Status == "Overfunding")
						{
							if (dr.Pitch_IsExtended.HasValue && dr.Pitch_IsExtended.Value)
							{
								proposal.ProgressLbl = _stringLocalizer["Overfunding1"].Value + " " +
													   Math.Floor(dr.Pitch_InvestedSoFar ?? 0) + " " +
													   _stringLocalizer["raisedpercent"].Value + " - " +
													   _stringLocalizer["Extra_Time"].Value;
							}
							else
							{
								proposal.ProgressLbl = _stringLocalizer["Overfunding1"].Value + " " +
													   (Math.Floor(dr.Pitch_InvestedSoFar ?? 0)) +
													   _stringLocalizer["raisedpercent"].Value;
							}
						}
						else if (dr.Pitch_Status == "Overfunded" || (dr.Pitch_Status == "completed and closed" &&
																	 dr.Pitch_Balance > dr.Pitch_InvestmentRequired))
						{
							proposal.ProgressLbl = _stringLocalizer.GetString("Closed1").Value + " " +
												   (Math.Floor(dr.Pitch_InvestedSoFar ?? 0)) + " " +
												   _stringLocalizer["FundPercent"].Value;
						}
						else if (dr.Pitch_Status == "Minimum-Funded" || (dr.Pitch_Status == "completed and closed" &&
																		 dr.Pitch_Balance < dr.Pitch_InvestmentRequired))
						{
							if (dr.Pitch_Status == "Minimum-Funded")
								proposal.ProgressLbl =
									_stringLocalizer["Closed1"].Value + " " + _stringLocalizer["Funded"].Value;
							else
								proposal.ProgressLbl = _stringLocalizer["Closed1"].Value + " " + "100%" + " " +
													   _stringLocalizer["Funded"].Value;

							proposal.MinArrowVisiblity = false;
						}
						else
						{
							if (dr.Pitch_IsExtended != null &&
								dr.Pitch_IsExtended.Value) //proposal with published status and has extended
							{
								proposal.ProgressLbl = _stringLocalizer["Progress"].Value + " " +
													   (Math.Floor(dr.Pitch_InvestedSoFar ?? 0)) + " " +
													   _stringLocalizer["raisedpercent"].Value + " - " +
													   _stringLocalizer["Extra_Time"].Value;
							}
							else
							{
								proposal.ProgressLbl = _stringLocalizer["Progress"].Value + " " +
													   (Math.Floor(dr.Pitch_InvestedSoFar ?? 0)) + " " +
													   _stringLocalizer["raisedpercent"].Value;
							}
						}
					}

					#endregion

					#endregion

					#region minimumArrow

					proposal.MinArrowDistance = 0;
					proposal.MinNote = "";
					proposal.MinAmountText = "";
					if (dr.Pitch_HasMinInvestmentRequired)
					{
						int minNeeded = dr.Pitch_MinInvestmentRequired ?? 0;
						double needed = dr.Pitch_InvestmentRequired ?? 0;
						var minNeededLeftMargin = Math.Ceiling(minNeeded * 100 / needed);
						proposal.MinArrowDistance = (int)minNeededLeftMargin;

						if (dr.Pitch_Status == "Minimum-Funded" || (dr.Pitch_Status == "completed and closed" &&
																	dr.Pitch_Balance < dr.Pitch_InvestmentRequired))
							proposal.MinArrowVisiblity = false;
						else
							proposal.MinArrowVisiblity = true;

						double rate = PitchGetPitchRateAsDouble(pitchIDInt, currencyId);
						string minAmount = "";
						if (langId == 2)
						{
							proposal.MinAmountText = $"{(dr.Pitch_MinInvestmentRequired * rate):n0}" + currencySymbol;
						}
						else
						{
							proposal.MinAmountText = currencySymbol + $"{dr.Pitch_MinInvestmentRequired * rate:n0}";
						}

						proposal.MinNote = _stringLocalizer["Please_note_this_proposal_has_a_minimum_target_of"].Value +
										   minAmount + _stringLocalizer["The_proposal_will_be_marked_as_successful"].Value;
					}
					else
					{
						proposal.MinArrowVisiblity = false;
					}

					#endregion

					if (langId == (int)Languages.Arabic && dr.Profile_LanguageID == (int)Languages.English)
					{
						proposal.Profile_PitchTitle = dr.Pitch_Admin_Arabic_Title;
						proposal.Profile_PitchShortSummary =
							"هذه الشركة متاحة باللغة الإنجليزية فقط، إضغط على عرض الشركة لعرض صفحة الشركة باللغة الإنجليزية";
					}

					proposal.country_flag = _config.GetValue<string>("AssetsEnvironmentURL") + "circle_flags/" +
											dr.Country_Flag_URL;

					#region progress values

					double pitchInvestedSoFar = dr.Pitch_InvestedSoFar ?? 0;
					double pitchOfflineSoFar = dr.Pitch_Offline_SoFar ?? 0;
					double pitchPreRaisedSoFar = dr.Pitch_PreRaised_SoFar ?? 0;
					double pitchInstitutionalSoFar = dr.Pitch_Institutional_SoFar ?? 0;

					string institutionalInvestmentSoFarNote = _stringLocalizer["InstitutionalInvestmentSoFar"].Value;

					string privateToolTip = "";
					string preRaisedTooltip = "";
					string institutionalInvestmentTooltip = "";
					string crowdFundingTooltip = "";
					proposal.viewInstitutionalInvestmentNote = false;

					double pitchCrowdFundingSoFar =
						pitchInvestedSoFar - pitchOfflineSoFar - pitchPreRaisedSoFar - pitchInstitutionalSoFar;

					if (pitchInvestedSoFar >= 100)
					{
						proposal.offlineProgressWidth = (int)(pitchOfflineSoFar / pitchInvestedSoFar * 100);
						proposal.preRaisedProgressWidth = (int)(pitchPreRaisedSoFar / pitchInvestedSoFar * 100);
						proposal.InstitutionalProgressWidth = (int)(pitchInstitutionalSoFar / pitchInvestedSoFar * 100);
						proposal.progressWidth = (int)(pitchCrowdFundingSoFar / pitchInvestedSoFar * 100);
					}
					else
					{
						if (dr.Pitch_Status == "Minimum-Funded" || (dr.Pitch_Status == "completed and closed" &&
																	dr.Pitch_Balance < dr.Pitch_InvestmentRequired))
						{
							proposal.offlineProgressWidth = (int)pitchOfflineSoFar;
							proposal.preRaisedProgressWidth = (int)pitchPreRaisedSoFar;
							proposal.InstitutionalProgressWidth = (int)pitchInstitutionalSoFar;
							proposal.progressWidth =
								(int)(100 - pitchOfflineSoFar - pitchPreRaisedSoFar - pitchInstitutionalSoFar);
						}
						else
						{
							proposal.offlineProgressWidth = (int)pitchOfflineSoFar;
							proposal.preRaisedProgressWidth = (int)pitchPreRaisedSoFar;
							proposal.InstitutionalProgressWidth = (int)pitchInstitutionalSoFar;
							proposal.progressWidth = (int)(pitchInvestedSoFar - pitchOfflineSoFar - pitchPreRaisedSoFar -
														   pitchInstitutionalSoFar);
						}
					}

					if (pitchOfflineSoFar > 0 || pitchPreRaisedSoFar > 0 || pitchInstitutionalSoFar > 0)
					{
						proposal.viewTooltip = true;

						string preRaisedCapital = _stringLocalizer["PreRaisedCapital"].Value;
						string offline = _stringLocalizer["Offline"].Value;
						string indtitutionalInvestment = _stringLocalizer["INSTITUTIONAL_INVESTMENT"].Value;
						string crowdFundedCapital = _stringLocalizer["CrowdFundedCapital"].Value;

						if (pitchOfflineSoFar > 0)
						{
							privateToolTip = Math.Floor(pitchOfflineSoFar) + "% " + offline;
						}

						if (pitchPreRaisedSoFar > 0)
						{
							preRaisedTooltip = Math.Floor(pitchPreRaisedSoFar) + "% " + preRaisedCapital;
						}

						if (pitchInstitutionalSoFar > 0)
						{
							institutionalInvestmentTooltip =
								Math.Floor(pitchInstitutionalSoFar) + "% " + indtitutionalInvestment;
							proposal.viewInstitutionalInvestmentNote = true;
						}

						crowdFundingTooltip =
							Math.Floor((pitchInvestedSoFar - pitchOfflineSoFar - pitchPreRaisedSoFar -
										pitchInstitutionalSoFar)) + "% " + crowdFundedCapital;
					}
					else
						proposal.viewTooltip = false;

					proposal.privateToolTip = privateToolTip;
					proposal.PreRaisedTooltip = preRaisedTooltip;
					proposal.crowdFundingTooltip = crowdFundingTooltip;
					proposal.InstitutionalInvestmentTooltip = institutionalInvestmentTooltip;
					proposal.InstitutionalInvestmentSoFarNote = institutionalInvestmentSoFarNote;

					#endregion

					proposals.Add(proposal);
				}
			}

			return proposals;
		}


		/// <summary>Get all Proposals to view in view proposal page</summary>
		/// 
		public DataTable PitchGetAllCompletedPitchsByPaging(int languageID, int categoryID, string sortBy, int currencyID, int tagID,
			int pageNo, int pageSize)
		{
			try
			{
				using (SqlConnection sql = new SqlConnection(_connectionString))
				{
					using (SqlCommand cmd = new SqlCommand("Pitch_GetAllCompletedPitchsByPaging", sql))
					{
						cmd.CommandType = CommandType.StoredProcedure;
						cmd.Parameters.AddWithValue("@Profile_LanguageID", languageID);
						cmd.Parameters.AddWithValue("@Category_ID", categoryID);
						cmd.Parameters.AddWithValue("@SortBy", sortBy);
						cmd.Parameters.AddWithValue("@CurrencyID", currencyID);
						cmd.Parameters.AddWithValue("@TagID", tagID);
						cmd.Parameters.AddWithValue("@PageNo", pageNo);
						cmd.Parameters.AddWithValue("@PageSize", pageSize);

						sql.Open();
						SqlDataAdapter da = new SqlDataAdapter(cmd);
						DataTable dt = new DataTable();
						da.Fill(dt);
						return dt;
					}
				}
			}
			catch (Exception ex)
			{
				_errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
				throw new Exception(ex.Message + "\n" + ex.StackTrace);
			}
		}


		/// <summary>Get all Proposals to view in view proposal page</summary>
		/// 
		public DataTable PitchGetAllLivePitchsByPaging(int languageID, int categoryID, string sortBy, int currencyID, bool isPublished, int tagID,
			int pageNo, int pageSize)
		{
			try
			{
				using (SqlConnection sql = new SqlConnection(_connectionString))
				{
					using (SqlCommand cmd = new SqlCommand("Pitch_GetAllLivePitchsByPaging", sql))
					{
						cmd.CommandType = CommandType.StoredProcedure;
						cmd.Parameters.AddWithValue("@Profile_LanguageID", languageID);
						cmd.Parameters.AddWithValue("@Category_ID", categoryID);
						cmd.Parameters.AddWithValue("@SortBy", sortBy);
						cmd.Parameters.AddWithValue("@CurrencyID", currencyID);
						cmd.Parameters.AddWithValue("@IsPublished", isPublished);
						cmd.Parameters.AddWithValue("@TagID", tagID);
						cmd.Parameters.AddWithValue("@PageNo", pageNo);
						cmd.Parameters.AddWithValue("@PageSize", pageSize);

						sql.Open();
						SqlDataAdapter da = new SqlDataAdapter(cmd);
						DataTable dt = new DataTable();
						da.Fill(dt);
						return dt;
					}
				}
			}
			catch (Exception ex)
			{
				_errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
				throw new Exception(ex.Message + "\n" + ex.StackTrace);
			}
		}

		/// <summary>This method is used to get All pitch categories</summary>
		public DataTable PitchGetAllPitchCategories(int languageID)
		{
			try
			{
				using (SqlConnection sql = new SqlConnection(_connectionString))
				{
					using (SqlCommand cmd = new SqlCommand("PCategory_GetAllPitchCategories", sql))
					{
						cmd.CommandType = CommandType.StoredProcedure;
						cmd.Parameters.AddWithValue("@LanguageID", languageID);

						sql.Open();
						SqlDataAdapter da = new SqlDataAdapter(cmd);
						DataTable dt = new DataTable();
						da.Fill(dt);
						return dt;
					}
				}
			}
			catch (Exception ex)
			{
				_errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
				throw new Exception(ex.Message + "\n" + ex.StackTrace);
			}
		}


		/// <summary>
		/// This method is used to check if the proposal view is prevented.
		/// </summary>
		/// <param name="drProposal"></param>
		/// <param name="countryId"></param>
		/// <param name="userId"></param>
		/// <returns></returns>
		/// <exception cref="Exception"></exception>
		public bool PitchIsProposalViewPrevented(PitchGetAllPitchResult drProposal, int countryId, int userId)
		{
			try
			{
				if (!string.IsNullOrWhiteSpace(drProposal.Pitch_Country.ToString()))
				{
					//Restrict KSA IP/countries from access/receiving info on Guzzle.  Pitch_ID=10656 ticket id=8865
					if ((drProposal.Pitch_ID.ToString() == "10656") && (countryId == 193))
						return true;
					if ((!string.IsNullOrWhiteSpace(drProposal.Pitch_Prevent_Exeption.ToString())) && (!(Convert.ToBoolean(drProposal.Pitch_Prevent_Exeption.ToString()))))
					{
						if (drProposal.Pitch_Country != null)
						{
							int groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.ViewProposal_Prevent, countryId, drProposal.Pitch_Country.Value);
							if (groupId > 0)
							{
								if (userId != drProposal.Pitch_UserID && !_user.UserIsAdmin(userId))
								{
									DataTable dtUserRequst = _user.UserGetUserRequest((int)RequestType.ViewProposalPrevention, userId, (int)drProposal.Pitch_ID);
									if (dtUserRequst.Rows.Count == 0 || (dtUserRequst.Rows.Count > 0 && !Boolean.Parse(dtUserRequst.Rows[0]["flag"].ToString() ?? "0")))
										return true;
								}
							}
							else
							{
								groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControlbyPage(CountryBasedControls.ViewProposal_PreventByPage, int.Parse(drProposal.Pitch_ID.ToString()), countryId);
								if (groupId > 0)
								{
									if (userId != drProposal.Pitch_UserID && !_user.UserIsAdmin(userId))
									{
										DataTable dtUserRequst = _user.UserGetUserRequest((int)RequestType.ViewProposalPrevention, userId, (int)drProposal.Pitch_ID);
										if (dtUserRequst.Rows.Count == 0 || (dtUserRequst.Rows.Count > 0 && !Boolean.Parse(dtUserRequst.Rows[0]["flag"].ToString() ?? "0")))
											return true;
									}
								}
							}
						}
					}
					else return false;
				}
				return false;
			}
			catch (Exception ex)
			{
				_errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
				throw new Exception(ex.Message + "\n" + ex.StackTrace);
			}
		}

		/// <summary>This method get Following users in my community who Invested In A given Pitch </summary>
		/// <param name="userId"></param>
		/// <param name="pitchId"></param>
		/// <param name="profileLanguageId"></param>
		public DataTable UserGetFollowingInvestedInAPitch(int userId, int pitchId, int profileLanguageId)
		{
			try
			{
				SqlParameter paramUid = new SqlParameter("@UID", userId);
				SqlParameter paramPitchID = new SqlParameter("@Pitch_ID", pitchId);
				SqlParameter paramProfileLanguageID = new SqlParameter("@Profile_LanguageID", profileLanguageId);
				return _sqlHelper.GetDataTable(_connectionString, "User_GetFollowingInvestedInAPitch", paramUid, paramPitchID, paramProfileLanguageID);
			}
			catch (Exception ex)
			{
				_errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
				throw new Exception(ex.Message + "\n" + ex.StackTrace);
			}
		}

        /// <summary>
        /// This Method is used to Get the current active pitch for this user and valid
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetUserActivePitchAndValid(int userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                return _sqlHelper.GetDataTable(_connectionString, "Pitch_getUserActivePitchAndValid", paramUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

    }
}