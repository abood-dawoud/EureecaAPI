﻿using Eureeca_API.General;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Models.PitchModels.ViewModels;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.PitchRepos
{
    public class PitchScoreRepository : IPitchScore
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;

        public PitchScoreRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }

        /// <summary>
        /// This method is used to add/ edit update the pitch score
        /// </summary>
        /// <param name="pitchId"></param>
        /// <param name="hasPitchDeckRank"></param>
        /// <param name="financialsHasHistoricalsAndProjectionsRank"></param>
        /// <param name="countryRank"></param>
        /// <param name="isReligiouslyPoliticallySexuallyAffiliatedRank"></param>
        /// <param name="problemsInThePastRank"></param>
        /// <param name="recognizableBuisnessRank"></param>
        /// <param name="howComplicatedRank"></param>
        /// <param name="isBadRank"></param>
        /// <param name="yearsInOperationRank"></param>
        /// <param name="ideaRank"></param>
        /// <param name="teamViewRank"></param>
        /// <param name="succeedingRank"></param>
        /// <param name="scalabilityRank"></param>
        /// <param name="businessIsAlreadyRevenueRank"></param>
        /// <param name="websiteRank"></param>
        /// <param name="howMuchCompanyRaisingRank"></param>
        /// <param name="score"></param>
        /// <returns>int</returns>
        /// <exception cref="Exception">Will write the error in the log file</exception>
        public int PitchScoreAddEdit(int pitchId, int hasPitchDeckRank, int financialsHasHistoricalsAndProjectionsRank,
            int countryRank, int isReligiouslyPoliticallySexuallyAffiliatedRank, int problemsInThePastRank, int recognizableBuisnessRank,
            int howComplicatedRank, int isBadRank, int yearsInOperationRank, int ideaRank, int teamViewRank,
            int succeedingRank, int scalabilityRank, int businessIsAlreadyRevenueRank, int websiteRank, int howMuchCompanyRaisingRank, float score, string BDNotes, string prefferedLinks, string RM)
        {
            try
            {
                SqlParameter paramPitchId = new SqlParameter("@PitchScore_PID", pitchId);
                SqlParameter paramHasPitchDeckRank = new SqlParameter("@PitchScore_HasPitchDeckRank", hasPitchDeckRank);
                SqlParameter paramFinancialsHasHistoricalsAndProjectionsRank = new SqlParameter("@PitchScore_FinancialsHasHistoricalsAndProjectionsRank", financialsHasHistoricalsAndProjectionsRank);
                SqlParameter paramCountryRank = new SqlParameter("@PitchScore_CountryRank", countryRank);
                SqlParameter paramIsReligiouslyPoliticallySexuallyAffiliatedRank = new SqlParameter("@PitchScore_IsReligiouslyPoliticallySexuallyAffiliatedRank", isReligiouslyPoliticallySexuallyAffiliatedRank);
                SqlParameter paramProblemsInPastRank = new SqlParameter("@PitchScore_ProblemsInThePastRank", problemsInThePastRank);
                SqlParameter paramRecognizableBuisnessRank = new SqlParameter("@PitchScore_RecognizableBuisnessRank", recognizableBuisnessRank);
                SqlParameter paramHowComplicatedRank = new SqlParameter("@PitchScore_HowComplicatedRank", howComplicatedRank);
                SqlParameter paramIsBadRank = new SqlParameter("@PitchScore_IsBadRank", isBadRank);
                SqlParameter paramYearsInOperationRank = new SqlParameter("@PitchScore_YearsOnOperationRank", yearsInOperationRank);
                SqlParameter paramIdeaRank = new SqlParameter("@PitchScore_IdeaRank", ideaRank);
                SqlParameter paramTeamViewRank = new SqlParameter("@PitchScore_TeamViewRank", teamViewRank);
                SqlParameter paramSucceedingRank = new SqlParameter("@PitchScore_SucceedingRank", succeedingRank);
                SqlParameter paramScalabilityRank = new SqlParameter("@PitchScore_ScalabilityRank", scalabilityRank);
                SqlParameter paramBusinessIsAlreadyRevenueRank = new SqlParameter("@PitchScore_BusinessIsAlreadyRevenueRank", businessIsAlreadyRevenueRank);
                SqlParameter paramWebsiteRank = new SqlParameter("@PitchScore_WebsiteRank", websiteRank);
                SqlParameter paramHowMuchCompanyRaisingRank = new SqlParameter("@PitchScore_HowMuchCompanyRaisingRank", howMuchCompanyRaisingRank);
                SqlParameter paramScore = new SqlParameter("@PitchScore_Score", score);
                SqlParameter paramBDNotes = new SqlParameter("@PitchScore_BDNotes", BDNotes);
                SqlParameter paramPrefferedLinks = new SqlParameter("@PitchScore_PrefferedLinks", prefferedLinks);
                SqlParameter paramRM = new SqlParameter("@PitchScore_RM", RM);
                return _sqlHelper.ExecuteNonQuery(_connectionString, "PitchScore_AddEdit", paramPitchId, paramHasPitchDeckRank,
                    paramFinancialsHasHistoricalsAndProjectionsRank, paramCountryRank,
                    paramIsReligiouslyPoliticallySexuallyAffiliatedRank, paramProblemsInPastRank,
                    paramRecognizableBuisnessRank, paramHowComplicatedRank, paramIsBadRank, paramYearsInOperationRank,
                    paramIdeaRank, paramTeamViewRank, paramSucceedingRank, paramScalabilityRank,
                    paramBusinessIsAlreadyRevenueRank, paramWebsiteRank, paramHowMuchCompanyRaisingRank, paramScore, paramBDNotes, paramPrefferedLinks, paramRM);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);

            }

        }

        /// <summary>
        /// Retuen the pitch score data, if param pitch id is null will return all Pitchs score
        /// </summary>
        /// <param name="pitchId"></param>
        /// <returns>List of pitch score object</returns>
        /// <exception cref="Exception">Will write the error in the log file</exception>
        public List<PitchScore> PitchScoreGetData(int? pitchId)
        {
            try
            {
                List<PitchScore> pitchScores = new List<PitchScore>();
                SqlParameter paramPitchId = new SqlParameter("PitchScore_PID", DBNull.Value);
                if (pitchId != 0)
                    paramPitchId.Value = pitchId;

                DataTable dtPitchScore = _sqlHelper.GetDataTable(_connectionString, "PitchScore_GetDataByPID", paramPitchId);
                if (dtPitchScore.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtPitchScore.Rows)
                    {
                        PitchScore pitchScore = new PitchScore();
                        pitchScore.PitchId = int.Parse(dr["PitchScore_PID"].ToString());
                        pitchScore.HasPitchDeckRank = int.Parse(dr["PitchScore_HasPitchDeckRank"].ToString());
                        pitchScore.FinancialsHasHistoricalsAndProjectionsRank = int.Parse(dr["PitchScore_FinancialsHasHistoricalsAndProjectionsRank"].ToString());
                        pitchScore.CountryRank = int.Parse(dr["PitchScore_CountryRank"].ToString());
                        pitchScore.IsReligiouslyPoliticallySexuallyAffiliatedRank = int.Parse(dr["PitchScore_IsReligiouslyPoliticallySexuallyAffiliatedRank"].ToString());
                        pitchScore.ProblemsInThePastRank = int.Parse(dr["PitchScore_ProblemsInThePastRank"].ToString());
                        pitchScore.RecognizableBuisnessRank = int.Parse(dr["PitchScore_RecognizableBuisnessRank"].ToString());
                        pitchScore.HowComplicatedRank = int.Parse(dr["PitchScore_HowComplicatedRank"].ToString());
                        pitchScore.IsBadRank = int.Parse(dr["PitchScore_IsBadRank"].ToString());
                        pitchScore.YearsInOperationRank = int.Parse(dr["PitchScore_YearsOnOperationRank"].ToString());
                        pitchScore.IdeaRank = int.Parse(dr["PitchScore_IdeaRank"].ToString());
                        pitchScore.TeamViewRank = int.Parse(dr["PitchScore_TeamViewRank"].ToString());
                        pitchScore.SucceedingRank = int.Parse(dr["PitchScore_SucceedingRank"].ToString());
                        pitchScore.ScalabilityRank = int.Parse(dr["PitchScore_ScalabilityRank"].ToString());
                        pitchScore.BusinessIsAlreadyRevenueRank = int.Parse(dr["PitchScore_BusinessIsAlreadyRevenueRank"].ToString());
                        pitchScore.WebsiteRank = int.Parse(dr["PitchScore_WebsiteRank"].ToString());
                        pitchScore.HowMuchCompanyRaisingRank = int.Parse(dr["PitchScore_HowMuchCompanyRaisingRank"].ToString());
                        pitchScore.Score = float.Parse(dr["PitchScore_Score"].ToString());
                        pitchScore.BDNotes = dr["PitchScore_BDNotes"].ToString();
                        pitchScore.PrefferedLinks = dr["PitchScore_PrefferedLinks"].ToString();
                        pitchScore.RM = dr["PitchScore_RM"].ToString();
                        pitchScores.Add(pitchScore);
                    }
                }


                return pitchScores;

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }



        }


        public DataTable PitchScoreProposalList(int langId, int pageNo, int pageSize, out int recordCount)
        {
            SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
            SqlParameter paramPageNo = new SqlParameter("@PageNo", pageNo);
            SqlParameter paramPageSize = new SqlParameter("@PageSize", pageSize);
            SqlParameter paramRecordCount = new SqlParameter("@RecordCount", SqlDbType.Int, 4);
            paramRecordCount.Direction = ParameterDirection.Output;

            DataTable dtList = _sqlHelper.GetDataTable(_connectionString, "PitchScore_GetPitchList", paramLangId, paramPageNo, paramPageSize, paramRecordCount);
            recordCount = int.Parse(paramRecordCount.Value.ToString());
            return dtList;

        }

    }
}
