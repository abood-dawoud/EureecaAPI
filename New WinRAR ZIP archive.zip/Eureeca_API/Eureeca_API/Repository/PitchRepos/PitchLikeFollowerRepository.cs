﻿using Eureeca_API.General;
using Eureeca_API.Interface.PitchInterface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.PitchRepos
{
    public class PitchLikeFollowerRepository : IPitchLikeFollower
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;

        public PitchLikeFollowerRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
        }
        public DataTable PitchGetFollowersExceptInvestors(int proposalId, int languageId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("Pitch_GetFollowersExceptInvestors", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;

                        comm.Parameters.AddWithValue("@PID", proposalId);
                        comm.Parameters.AddWithValue("@Profile_LanguageID", languageId);
                        SqlDataAdapter DA = new SqlDataAdapter(comm);

                        DataTable DT = new DataTable();
                        DA.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        public DataTable PitchGetAllInvestors(int proposalId, int languageId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("Pitch_GetAllInvestors", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;

                        comm.Parameters.AddWithValue("@PID", proposalId);
                        comm.Parameters.AddWithValue("@Profile_LanguageID", languageId);
                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(comm);

                        DataTable DT = new DataTable();
                        DA.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        public DataTable PitchGetFollowersAndInvestors(int proposalId, int languageId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("Pitch_GetFollowersAndInvestors", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;

                        comm.Parameters.AddWithValue("@PID", proposalId);
                        comm.Parameters.AddWithValue("@Profile_LanguageID", languageId);
                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(comm);

                        DataTable DT = new DataTable();
                        DA.Fill(DT);

                        return DT;
                    }

                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public DataTable PitchgetUserIsLikeFollower(int userId, int proposalId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("getUserIsLikeFollower", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;

                        comm.Parameters.AddWithValue("@UserID", userId);
                        comm.Parameters.AddWithValue("@PitchID", proposalId);
                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(comm);

                        DataTable DT = new DataTable();
                        DA.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public void PitchUpdateUserFollowing(int userId, int proposalId, bool followType)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Pitch_UpdateUserFollowing", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@UserID", userId);
                        cmd.Parameters.AddWithValue("@PitchID", proposalId);
                        cmd.Parameters.AddWithValue("@FollowType", followType);

                        sql.Open();
                        SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
    }
}
