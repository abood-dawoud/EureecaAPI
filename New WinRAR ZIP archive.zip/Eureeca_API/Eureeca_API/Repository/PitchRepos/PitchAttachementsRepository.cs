﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface.PitchInterface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.PitchRepos
{
    public class PitchAttachementsRepository : IPitchAttachements
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;

        public PitchAttachementsRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }

        public DataTable PitchGetAttachementDetails(int pitchAttachmentId)
        {
            try
            {
                SqlParameter paramPitchAttachmentId = new SqlParameter("@PitchAttachment_ID", pitchAttachmentId);
                return _sqlHelper.GetDataTable(_connectionString, "Pitch_GetPitchAttachmentDetails", paramPitchAttachmentId);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public DataTable PitchGetPitchAttachmentsByLangID(int pitchAttachmentPitchID, int profileLanguageId, PitchAttachmentType attachType)
        {
            try
            {
                SqlParameter paramPitchId = new SqlParameter("@PitchAttachment_PitchID", pitchAttachmentPitchID);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", profileLanguageId);
                SqlParameter paramAttachType = new SqlParameter("@Attach_Type", (int)attachType);

                return _sqlHelper.GetDataTable(_connectionString, "Pitch_GetPitchAttachments", paramPitchId, paramLangId, paramAttachType);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        /// <summary>
        /// This method is used to get pitch private attachments by language and attachment type
        /// </summary>
        /// <param name="PitchAttachment_PitchID"></param>
        /// <param name="lang"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable PitchGetPitchAttachmentDocs(int pitchID, int langId, PitchAttachmentDocument mode)
        {
            try
            {
                SqlParameter paramPitchId = new SqlParameter("@PitchAttachment_PitchID", pitchID);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramMode = new SqlParameter("@Mode", (int)mode);
                return _sqlHelper.GetDataTable(_connectionString, "Pitch_GetPitchAttachmentDocs", paramPitchId, paramLangId, paramMode);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to get pitch attachment details
        /// </summary>
        /// <param name="PitchAttachment_ID"></param>
        /// <returns>Datatable of information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable PitchAttachmentGetDetails(int pitchAttachmentId)
        {
            try
            {
                SqlParameter paramAttachmentId = new SqlParameter("@PitchAttachment_ID", pitchAttachmentId);
                return _sqlHelper.GetDataTable(_connectionString, "Pitch_GetPitchAttachmentDetails", paramAttachmentId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }



    }

}
