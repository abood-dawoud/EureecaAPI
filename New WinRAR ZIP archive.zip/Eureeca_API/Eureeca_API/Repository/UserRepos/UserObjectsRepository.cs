﻿using Eureeca_API.General;
using Eureeca_API.Interface.UserInterface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.UserRepos
{
    public class UserObjectsRepository : IUserObjects
    {
        private readonly string _connectionString;
        private readonly SqlHelper _sqlHelper;
        private readonly ErrHandler _errHandler;
        public UserObjectsRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }

        /// <summary>
        /// This method is used to get a user's enrollment group details (method moved from old class)
        /// </summary>
        /// <param name="userId">this is the user ID that we need to get his enrollment details(0 to pass NULL)</param>
        /// <param name="profileLanguageId">this is the language of the returned data</param>
        /// <param name="masterGroupId">this is the enrollment group</param>
        /// <returns>Data table of the user data</returns>
        /// <exception cref="Exception"></exception>
        public DataTable UserObjectsGetUserEnrollmentsByLang(int userId, int profileLanguageId, int masterGroupId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@Details_UserID", userId);
                SqlParameter paramProfileLanguageId = new SqlParameter("@Profile_LanguageID", profileLanguageId);
                SqlParameter paramMasterGroupId = new SqlParameter("@Master_GroupID", masterGroupId);

                return _sqlHelper.GetDataTable(_connectionString, "ObjectDetails_GetUserEnrollmentsByLang", paramUserId, paramProfileLanguageId, paramMasterGroupId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
    }
}