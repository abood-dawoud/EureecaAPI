﻿using Eureeca_API.General;
using Eureeca_API.Interface.UserInterface;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Data.Common;

namespace Eureeca_API.Repository.UserRepos
{
    public class CustomForumUserRepository : ICustomForumUser
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;

        public CustomForumUserRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("ForumCQAConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }
        /// <summary>
        /// This method is used to update user first and last name
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userFirstName"></param>
        /// <param name="userLastName"></param>
        /// <param name="userLanguage"></param>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public void ForumUpdateUserDetails(int userId, string userFirstName, string userLastName, int userLanguage)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@USER_ID", userId);
                SqlParameter paramFirstName = new SqlParameter("@USER_FIRST_NAME", userFirstName);
                SqlParameter paramLastName = new SqlParameter("@USER_LAST_NAME", userLastName);
                SqlParameter paramUserLanguage = new SqlParameter("@USER_LANGUAGEID", userLanguage);
                _sqlHelper.ExecuteReader(_connectionString, "USER_UpdateDetails", paramUserId, paramFirstName, paramLastName, paramUserLanguage);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="userFirstName"></param>
        /// <param name="userLastName"></param>
        /// <param name="userPicture"></param>
        /// <param name="userWallId"></param>
        /// <param name="userLanguageId"></param>
        /// <returns>The user id</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public int ForumAddUser(string userFirstName, string userLastName, string userPicture, int userWallId, int userLanguageId)
        {
            int userId = 0;
            try
            {
                SqlParameter paramUserFirstName = new SqlParameter("@USER_FIRST_NAME", userFirstName);
                SqlParameter paramUserLastName = new SqlParameter("@USER_LAST_NAME", userLastName);
                SqlParameter paramUserPicture = new SqlParameter("@USER_PICTURE", userPicture);
                SqlParameter paramUserWallId = new SqlParameter("@USER_WALL_ID", userWallId);
                SqlParameter paramUserLanguageId = new SqlParameter("@USER_LANGUAGEID", userLanguageId);
                SqlParameter paramReturnValue = new SqlParameter("ReturnValue", SqlDbType.Int, 4);
                paramReturnValue.Direction = ParameterDirection.ReturnValue;

                _sqlHelper.ExecuteNonQuery(_connectionString, "USER_addUser", paramUserFirstName, paramUserLastName, paramUserPicture, paramUserWallId, paramUserLanguageId, paramReturnValue);

                userId = (int)paramReturnValue.Value;

                return userId;

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get all details of dedicated user
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="langId"></param>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable ForumGetUserDetails(int userId, int langId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@USER_ID", userId);
                SqlParameter paramLanguageId = new SqlParameter("@USER_LANGUAGEID", langId);
                return _sqlHelper.GetDataTable(_connectionString, "USER_getUserDetails", paramUserId, paramLanguageId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }

        }
        /// <summary>
        /// This method is used to update user details
        /// </summary>
        /// <param name="userPicture"></param>
        /// <param name="userId"></param>
        /// <exception cref="Exception"></exception>
        public void ForumUpdateUserPicture(string userPicture, int userId)
        {
            try
            {
                userPicture = Tools.FilterHTML(userPicture);

                SqlParameter paramUserPicture = new SqlParameter("@USER_PICTURE", userPicture);
                SqlParameter paramUserId = new SqlParameter("@USER_ID", userId);

                _sqlHelper.ExecuteReader(_connectionString, "USER_updateUserPic", paramUserPicture, paramUserId);
                
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
            
        }

    }
}
