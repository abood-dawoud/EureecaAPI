﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Interface.AccountInterface;
using Eureeca_API.Interface.CountryBasedInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.SuitabilityModels.Dto;
using Eureeca_API.Models.SuitabilityModels.ViewModels;
using Eureeca_API.Models.UserModels.ViewModesl;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.Sheets.v4;
using Google.Apis.Sheets.v4.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Localization;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Data;
using System.Globalization;

namespace Eureeca_API.Repository.UserRepos
{
    public class UserRepository : IUser
    {
        private readonly string _connectionString;
        private readonly SqlHelper _sqlHelper;
        private readonly IStringLocalizer<Resources.UserRepository> _stringLocalizer;
        private readonly ICountryBasedControl _countryBasedControl;
        private readonly ICustomForumUser _customForumUser;
        //  private readonly IMessage _message;
        private readonly ILead _lead;
        private readonly IAlert _alert;
        private readonly ITopic _topic;
        private readonly IAccount _account;
        private readonly IConfiguration _config;
        private readonly ISuitabilityTest _suitabilityTest;
        private readonly IKYC _kyc;
        private readonly IAgreement _agreement;
        private readonly ISurvey _survey;
        private readonly ErrHandler _errHandler;
        private readonly IConfiguration _configuration;
        public UserRepository(IConfiguration config, IStringLocalizer<Resources.UserRepository> userRepositoryLocalizer, ICountryBasedControl countryBasedControl, ICustomForumUser customForumUser, ILead lead, IAlert alert, ITopic topic, IAccount account, ISuitabilityTest suitabilityTest, IKYC kyc, IAgreement agreement, ISurvey survey)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _stringLocalizer = userRepositoryLocalizer;
            _countryBasedControl = countryBasedControl;
            _customForumUser = customForumUser;
            // _message = message;
            _lead = lead;
            _alert = alert;
            _topic = topic;
            _account = account;
            _config = config;
            _suitabilityTest = suitabilityTest;
            _kyc = kyc;
            _agreement = agreement;
            _survey = survey;
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
            _configuration = config;
        }

        /// <summary>
        /// This method is used to get All active admins.
        /// </summary>
        /// <returns>Data table of all information.</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable UserGetAdmins()
        {
            try
            {
                return _sqlHelper.GetDataTable(_connectionString, "User_GetAdmins", null);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get System Admin
        /// </summary>
        /// <returns>Data row of all information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataRow UserGetSystemAdmin()
        {
            try
            {
                return _sqlHelper.GetDataTable(_connectionString, "User_getSystemAdmin", null).Rows[0];
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method used to return the system email
        /// </summary>
        /// <returns>string</returns>
        /// <exception cref="Exception">Will write the error in error log file</exception>
        public string UserGetSystemAdminEmail()
        {
            try
            {
                return _sqlHelper.GetDataTable(_connectionString, "User_getSystemAdmin", null).Rows[0]["User_Email"].ToString();
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// get user request details by type
        /// </summary>
        /// <param name="requestType">The request type will assign from the RequestType enum</param>
        /// <param name="userId">The user id </param>
        /// <param name="requestProposalId">The request proposal id</param>
        /// <returns>Data table of all information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable UserGetUserRequest(int requestType, int userId, int requestProposalId)
        {
            try
            {
                SqlParameter paramRequestType = new SqlParameter("@Request_Type", requestType);
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramRequestProposalId = new SqlParameter("@Request_PitchID", requestProposalId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetUserRequest", paramRequestType, paramUserId, paramRequestProposalId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to check the Admin user
        /// </summary>
        /// <param name="userId">the user id</param>
        /// <returns>Boolean if the user is admin or not</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public bool UserIsAdmin(long userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                return _sqlHelper.GetDataTable(_connectionString, "IsAdmin", paramUserId).Rows.Count > 0;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to check the if the user is BI admin
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>bool</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public bool UserIsBIAdmin(long userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                return _sqlHelper.GetDataTable(_connectionString, "IsBIAdmin", paramUserId).Rows.Count > 0;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method will return the user information depends on the id
        /// </summary>
        /// <param name="userId">the user id</param>
        /// <returns>Data table of all information.</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable UserSelectById(int userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                return _sqlHelper.GetDataTable(_connectionString, "User_SelectUserById", paramUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// this methods used to add user Notification
        /// </summary>
        /// <param name="userNotificationFromUserId">Sender user id</param>
        /// <param name="userNotificationToUserId">reciever user id</param>
        /// <param name="userNotificationNotes">notification note</param>
        /// <param name="userNotificationType">notification type will assign it's value from the NotificationType enum</param>
        /// <returns>int</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public int UserAddNotification(string userNotificationFromUserId, string userNotificationToUserId, string userNotificationNotes, NotificationType userNotificationType)
        {
            try
            {
                userNotificationNotes = Tools.FilterHTML(userNotificationNotes);
                SqlParameter paramUserNotificationFromUserId = new SqlParameter("@UserNotification_FromUserID", userNotificationFromUserId);
                SqlParameter paramUserNotificationToUserId = new SqlParameter("@UserNotification_ToUserID", userNotificationToUserId);
                SqlParameter paramUserNotificationNotes = new SqlParameter("@UserNotification_Notes", userNotificationNotes);
                SqlParameter paramUserNotificationType = new SqlParameter("@UserNotification_Type", userNotificationType);
                return _sqlHelper.ExecuteNonQuery(_connectionString, "User_AddNotification", paramUserNotificationFromUserId, paramUserNotificationToUserId, paramUserNotificationNotes, paramUserNotificationType);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        // this is for proposal details
        /// <summary>
        /// Get All Pitch Follower
        /// </summary>
        /// <param name="proposalId"></param>
        /// <returns>Data table of all information.</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable UserGetAllPitchFollower(string proposalId)
        {
            try
            {
                SqlParameter paramProposalId = new SqlParameter("@PID", proposalId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetAllPitchFollower", paramProposalId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get user details depending on the language
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="langId"></param>
        /// <returns>Data table of all information.</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable UserGetDetails(int userId, int langId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramProfileLangId = new SqlParameter("@Profile_LanguageID", langId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetUserDetails", paramUserId, paramProfileLangId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This function returned the list of objects for the user by there langauge
        /// </summary>
        /// <param name="userId">The user Id that we need to get his list of objects</param>
        /// <param name="profileLanguageId">The lang id </param>
        /// <param name="masterGroupId"></param>
        /// <returns>Data table of all information.</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable UserGetUserEnrollmentsByLang(long userId, int LangId, int masterGroupId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@Details_UserID", userId);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", LangId);
                SqlParameter paramMasterGroupId = new SqlParameter("@Master_GroupID", masterGroupId);
                return _sqlHelper.GetDataTable(_connectionString, "ObjectDetails_GetUserEnrollmentsByLang", paramUserId, paramLangId, paramMasterGroupId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        /// <summary>
        /// This method is used to get the user top followed proposals
        /// </summary>
        /// <param name="userId">The user ID that we need to get his last followed proposals</param>
        /// <param name="count">Count of last followed proposals to be retrieved</param>
        /// <returns>Data table of all information.</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable UserGetLastFollowedProposals(int userId, int count)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@UserID", userId);
                SqlParameter paramCount = new SqlParameter("@Count", count);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetLastFollowedProposals", paramUserId, paramCount);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        /// <summary>
        /// This method is used to check if the investor accept to be contacted by proposal SME or not
        /// </summary>
        /// <param name="email">This is the investor email</param>
        /// <param name="proposalId">This is the proposal ID that the investor take action</param>
        /// <returns>Data table of all information.</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable UserCheckInvestorContactableBySME(string email, int proposalId)
        {
            try
            {
                SqlParameter paramEmail = new SqlParameter("@Email", email);
                SqlParameter paramProposalId = new SqlParameter("@Pitch_ID", proposalId);
                return _sqlHelper.GetDataTable(_connectionString, "User_CheckInvestorContactableBySME", paramEmail, paramProposalId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get all folowers for the user
        /// </summary>
        /// <param name="userId">This is the user Id need to get his follower</param>
        /// <returns>Data table of all information.</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable UserGetAllUserFollowersForUser(int userId)
        {
            try
            {
                SqlParameter paramUserConnectionDestinationUserId = new SqlParameter("@UserConnection_DestinationUserID", userId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetAllUserFollowersForUser", paramUserConnectionDestinationUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to Get  Pitch User Id
        /// </summary>
        /// <param name="proposalId">This is the proposal id need to get his owner id</param>
        /// <returns>the user id of the proposal owner</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public int UserGetPitchUserID(string proposalId)
        {
            try
            {
                SqlParameter paramProposalId = new SqlParameter("@Pitch_ID", proposalId);
                return _sqlHelper.ExecuteScalar(_connectionString, "User_GetPitch_UserID", paramProposalId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        /// <summary>
        /// This method is used to return the user info depends on his username.
        /// </summary>
        /// <param name="username">The username need to get his information</param>
        /// <returns>Data table of all information.</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable SelectByUserName(string username)
        {
            try
            {
                SqlParameter param_User_Username = new SqlParameter("@User_Username", username);
                return _sqlHelper.GetDataTable(_connectionString, "User_SelectByUserName", param_User_Username);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to return the user info depends on his username.
        /// </summary>
        /// <param name="userEmail">The user email need to get his information</param>
        /// <returns>Data table of all information.</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable SelectUserByEmail(string userEmail)
        {
            try
            {
                SqlParameter param_User_Email = new SqlParameter("@User_Email", userEmail);
                return _sqlHelper.GetDataTable(_connectionString, "User_SelectUserByEmail", param_User_Email);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        /// <summary>
        /// This method is used to update user account information
        /// </summary>
        /// <param name="userId">This is the user id need to update his info</param>
        /// <param name="customForumUserId">this is the custom forum id</param>
        /// <param name="oldUsername">This is the old username</param>
        /// <param name="username">This is the username</param>
        /// <param name="password">This is the password</param>
        /// <param name="profileFirstName">This is the user first name</param>
        /// <param name="profileLastName">This is the user last name</param>
        /// <param name="gender">This is the user gender</param>
        /// <param name="userType">This is the user type</param>
        /// <param name="userFormType">This is the user form type</param>
        /// <param name="profileStreetAddress">This is the user street address</param>
        /// <param name="country">This is the user country</param>
        /// <param name="profileState">This is the user state</param>
        /// <param name="profileCity">This is the user city</param>
        /// <param name="profilePostalCode">This is the user postal code</param>
        /// <param name="phone">This is the user phone</param>
        /// <param name="email">This is the user email</param>
        /// <param name="profileBankName">This is the user bank name</param>
        /// <param name="userAccountNumber">This is the user account number</param>
        /// <param name="userSwiftIbanNumber">This is the user swift Iban number</param>
        /// <param name="profileBankAddress">This is the user bank address</param>
        /// <param name="userBankCountry">This is the user bank country</param>
        /// <param name="userStatus">This is the user status</param>
        /// <param name="userDateOFBirth">This is the user birthday date</param>
        /// <param name="userLanguageId">This is the user lang id</param>
        /// <param name="isProfileHidden">This is the user profile is hidden or not </param>
        /// <param name="profileLanguageId">This is the profile lang id </param>
        /// <param name="profileSummary">This is the user summary</param>
        /// <param name="userPicture">This is the user picture</param>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public void UserUpdateUserInfo(int userId, int customForumUserId, string oldUsername, string username,
        string password, string profileFirstName, string profileLastName, int gender, int userType, int userFormType, string profileStreetAddress,
        int country, string profileState, string profileCity, string profilePostalCode, string phone, string email,
        string profileBankName, string userAccountNumber, string userSwiftIbanNumber, string profileBankAddress, int userBankCountry,
        string userStatus, string userDateOFBirth, int userLanguageId, bool isProfileHidden, int profileLanguageId, string profileSummary,
        string userPicture)
        {
            try
            {

                oldUsername = Tools.FilterHTML(oldUsername);
                username = Tools.FilterHTML(username);
                profileFirstName = Tools.FilterHTML(profileFirstName);
                profileLastName = Tools.FilterHTML(profileLastName);
                profilePostalCode = Tools.FilterHTML(profilePostalCode);
                phone = Tools.FilterHTML(phone);
                profileState = Tools.FilterHTML(profileState);
                profileCity = Tools.FilterHTML(profileCity);
                email = Tools.FilterHTML(email);
                profileStreetAddress = Tools.FilterHTML(profileStreetAddress);
                profileBankName = Tools.FilterHTML(profileBankName);
                userAccountNumber = Tools.FilterHTML(userAccountNumber);
                userSwiftIbanNumber = Tools.FilterHTML(userSwiftIbanNumber);
                profileBankAddress = Tools.FilterHTML(profileBankAddress);
                profileSummary = Tools.FilterHTML(profileSummary);
                userPicture = Tools.FilterHTML(userPicture);

                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramProfileFirstName = new SqlParameter("@Profile_FirstName", profileFirstName);
                SqlParameter paramProfileLastName = new SqlParameter("@Profile_LastName", profileLastName);
                SqlParameter paramUsername = new SqlParameter("@User_Username", username);
                SqlParameter paramUserPassword = new SqlParameter("@User_Password", password);
                SqlParameter paramUserGender = new SqlParameter("@User_Gender", gender);
                SqlParameter paramUserType = new SqlParameter("@User_UserType", userType);
                SqlParameter paramUserFormType = new SqlParameter("@User_UserFormType", userFormType);
                SqlParameter paramProfileStreetAddress = new SqlParameter("@Profile_StreetAddress", profileStreetAddress);
                SqlParameter paramUserCountry = new SqlParameter("@User_Country", country);
                SqlParameter paramProfileState = new SqlParameter("@Profile_State", profileState);
                SqlParameter paramProfileCity = new SqlParameter("@Profile_City", profileCity);
                SqlParameter paramProfilePostalCode = new SqlParameter("@Profile_PostalCode", profilePostalCode);
                SqlParameter paramUserPhone = new SqlParameter("@User_Phone", phone);
                SqlParameter paramUserEmail = new SqlParameter("@User_Email", email);
                SqlParameter paramProfileBankName = new SqlParameter("@Profile_BankName", profileBankName);
                SqlParameter paramUserAccountNumber = new SqlParameter("@User_AccountNumber", userAccountNumber);
                SqlParameter paramUserSwiftIbanNumber = new SqlParameter("@User_SwiftIbanNumber", userSwiftIbanNumber);
                SqlParameter paramProfileBankAddress = new SqlParameter("@Profile_BankAddress", profileBankAddress);
                SqlParameter paramBankCountry = new SqlParameter("@User_BankCountry", userBankCountry);
                SqlParameter paramUserStatus = new SqlParameter("@User_Status", userStatus);
                SqlParameter paramUserDateOFBirth = new SqlParameter("@User_DateOFBirth", userDateOFBirth);
                SqlParameter paramUserLanguageId = new SqlParameter("@User_LanguageID", userLanguageId);
                SqlParameter paramUserIsProfileHidden = new SqlParameter("@User_IsProfileHidden", isProfileHidden);
                SqlParameter paramProfileLanguageID = new SqlParameter("@Profile_LanguageID", profileLanguageId);
                SqlParameter paramProfileSummary = new SqlParameter("@Profile_Summary", profileSummary);
                SqlParameter paramUserPicture = new SqlParameter("@User_Picture", userPicture);

                _sqlHelper.ExecuteNonQuery(_connectionString, "User_UpdateUserInfo", paramUserId, paramProfileFirstName, paramProfileLastName, paramUsername, paramUserPassword, paramUserGender, paramUserType, paramUserFormType, paramProfileStreetAddress, paramUserCountry, paramProfileState, paramProfileCity, paramProfilePostalCode, paramUserPhone, paramUserEmail, paramProfileBankName, paramUserAccountNumber, paramUserSwiftIbanNumber, paramProfileBankAddress, paramBankCountry, paramUserStatus, paramUserDateOFBirth, paramUserLanguageId, paramUserIsProfileHidden, paramProfileLanguageID, paramProfileSummary, paramUserPicture);


                /***************************append into file********************************************************/
                //String LoggingURL = System.Configuration.ConfigurationManager.AppSettings["LoggingPageURL"];
                //log.TrackingCredentials(LoggingURL, User_ID.ToString(), User_Password);
                /****************************************end********************************************************/
                _customForumUser.ForumUpdateUserDetails(customForumUserId, profileFirstName, profileLastName, profileLanguageId);
                UserupdateLastUpdateDate(userId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to update user last update date
        /// </summary>
        /// <param name="userId">This is the user id need to update his last update date</param>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public void UserupdateLastUpdateDate(int userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                _sqlHelper.ExecuteNonQuery(_connectionString, "User_UpdateUserLastUpdateDate", paramUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This is the method used to check and update the UK agreement flag
        /// </summary>
        /// <param name="username">This is the username need to update his UK agreement flag</param>
        /// <returns>bool value</returns>
        public bool UserCheckAndUpdateUKAgreementFlag(string username)
        {
            try
            {
                if (SelectUserByEmail(username).Rows.Count > 0 || SelectByUserName(username).Rows.Count > 0)
                {
                    DataTable dtUserInfo;
                    UserUpdateUKAgreementFlag(username);
                    if (SelectUserByEmail(username).Rows.Count > 0)
                        dtUserInfo = SelectUserByEmail(username);
                    else
                        dtUserInfo = SelectByUserName(username);
                    UserupdateLastUpdateDate(int.Parse(dtUserInfo.Rows[0]["User_ID"].ToString()));
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError("Failed UK Agreement :\n" + ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }

        /// <summary>
        /// This is the method used to update the UK agreement flag
        /// </summary>
        /// <param name="username">This is the username need to update his UK agreement flag</param>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public void UserUpdateUKAgreementFlag(string username)
        {
            try
            {
                SqlParameter paramUsername = new SqlParameter("@User_Username", username);
                _sqlHelper.ExecuteNonQuery(_connectionString, "User_UpdateUKAgreementFlag", paramUsername);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This methods used to add a new  PromotionCode
        /// </summary>
        /// <param name="userPromotionCodeUserId">This is the user id</param>
        /// <param name="userPromotionCodeValue">This is the promotion code value</param>
        /// <returns>A integer value</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public int UserAddPromotionCode(int userPromotionCodeUserId, string userPromotionCodeValue)
        {
            try
            {
                SqlParameter paramUserID = new SqlParameter("@UserPromotionCode_UserID", userPromotionCodeUserId);
                SqlParameter paramUserPromotionCodeValue = new SqlParameter("@UserPromotionCode_Value", userPromotionCodeValue);

                return _sqlHelper.ExecuteNonQuery(_connectionString, "AddUserPromotionCode", paramUserID, paramUserPromotionCodeValue);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        /// <summary>
        /// This is the method used to add user 
        /// </summary>
        /// <param name="userType">This is the user type of the user</param>
        /// <param name="username">This is the username of the user</param>
        /// <param name="profileFirstName">This is the user first name of the user</param>
        /// <param name="profileLastName">This is the user last name of the user</param>
        /// <param name="userCountry">This is the user country of the user</param>
        /// <param name="profilePostalCode">This is the user postal code of the user</param>
        /// <param name="userPhone">This is the user phone of the user</param>
        /// <param name="profileState">This is the user state of the user</param>
        /// <param name="profileCity">This is the user city of the user</param>
        /// <param name="userPassword">This is the user password of the user</param>
        /// <param name="userEmail">This is the user email of the user</param>
        /// <param name="userDateOFBirth">This is the user birthday date of the user</param>
        /// <param name="profileStreetAddress">This is the user street address of the user</param>
        /// <param name="userGuid">This is the user Guid of the user</param>
        /// <param name="profileLanguageId">This is the user language id of the user</param>
        /// <param name="isPartner">This is the is user partner or not</param>
        /// <param name="refferedByRef">This is the reffered by ref of the user</param>
        /// <param name="userNationality">This is the user nationality of the user</param>
        /// <param name="userIsPEP">This is the user is PEP</param>
        /// <returns>A integer value</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public int UserAddUser(int userType, string username, string profileFirstName, string profileLastName,
        int userCountry, string profilePostalCode, string userPhone, string profileState, string profileCity,
        string userPassword, string userEmail, string userDateOFBirth, string profileStreetAddress,
        string userGuid, int profileLanguageId, bool isPartner, string refferedByRef, int userNationality, bool userIsPEP)
        {
            try
            {
                SqlParameter paramUserType = new SqlParameter("@User_UserType", userType);
                SqlParameter paramUsername = new SqlParameter("@User_Username", username);
                SqlParameter paramProfileFirstName = new SqlParameter("@Profile_FirstName", profileFirstName);
                SqlParameter paramProfileLastName = new SqlParameter("@Profile_LastName", profileLastName);
                SqlParameter paramUserPassword = new SqlParameter("@User_Password", userPassword);
                SqlParameter paramUserEmail = new SqlParameter("@User_Email", userEmail);
                SqlParameter paramUserDateOFBirth = new SqlParameter("@User_DateOFBirth", userDateOFBirth);
                SqlParameter paramProfileStreetAddress = new SqlParameter("@Profile_StreetAddress", profileStreetAddress);
                SqlParameter paramProfilePostalCode = new SqlParameter("@Profile_PostalCode", profilePostalCode);
                SqlParameter paramUserPhone = new SqlParameter("@User_Phone", userPhone);
                SqlParameter paramProfileState = new SqlParameter("@Profile_State", profileState);
                SqlParameter paramProfileCity = new SqlParameter("@Profile_City", profileCity);
                SqlParameter paramUserCountry = new SqlParameter("@User_Country", userCountry);
                SqlParameter paramUserGuid = new SqlParameter("@User_guid", userGuid);
                SqlParameter paramProfileLanguageId = new SqlParameter("@Profile_LanguageID", profileLanguageId);
                SqlParameter paramIsPartner = new SqlParameter("@Is_Partner", isPartner);
                SqlParameter paramRefferedByRef = new SqlParameter("@RefferedByRef", refferedByRef);
                SqlParameter paramUserNationality = new SqlParameter("@User_Nationality", userNationality);
                SqlParameter paramUserIsPEP = new SqlParameter("@User_IsPEP", userIsPEP);
                SqlParameter paramReturnValue = new SqlParameter("ReturnValue", SqlDbType.Int, 4);
                paramReturnValue.Direction = ParameterDirection.ReturnValue;
                _sqlHelper.ExecuteNonQuery(_connectionString, "User_AddUser", paramUserType, paramUsername, paramProfileFirstName, paramProfileLastName, paramUserPassword, paramUserEmail, paramUserDateOFBirth, paramProfileStreetAddress, paramProfilePostalCode, paramUserPhone, paramProfileState, paramProfileCity, paramUserCountry, paramUserGuid, paramProfileLanguageId, paramIsPartner, paramReturnValue, paramRefferedByRef, paramUserNationality, paramUserIsPEP);
                return (int)paramReturnValue.Value;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to update user Form Type
        /// </summary>
        /// <param name="userId">This is the user id will update his form type</param>
        /// <param name="userFormType">This the user form type</param>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public void UserUpdateFormType(int userId, int userFormType)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramUserFormType = new SqlParameter("@User_UserFormType", userFormType);
                _sqlHelper.ExecuteNonQuery(_connectionString, "User_UpdateUserFormType", paramUserId, paramUserFormType);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to cancell the user by changing his user name and password and email and activation
        /// </summary>
        /// <param name="userId"><This is the user id will update his user status/param>
        /// <param name="userStatus">This is the user status</param>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public void UserUpdateUserStatus(int userId, UserStatus userStatus)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramUserStatus = new SqlParameter("@User_Status", userStatus);
                _sqlHelper.ExecuteNonQuery(_connectionString, "User_UpdateUserStatus", paramUserId, paramUserStatus);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to update user utm data
        /// </summary>
        /// <param name="userId">This is the user id need to update his UTM data</param>
        /// <param name="userUtmCampaign">This is the user utm campaign</param>
        /// <param name="userUtmSource">This is the user utm source</param>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public void UserUpdateUTMData(int userId, string userUtmCampaign, string userUtmSource)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramUserUtmCampaign = new SqlParameter("@User_utm_campaign", DBNull.Value);
                if (!string.IsNullOrWhiteSpace(userUtmCampaign))
                    paramUserUtmCampaign.Value = userUtmCampaign;
                SqlParameter paramUserUtmSource = new SqlParameter("@User_utm_source", DBNull.Value);
                if (!string.IsNullOrWhiteSpace(userUtmSource))
                    paramUserUtmSource.Value = userUtmSource;

                _sqlHelper.ExecuteNonQuery(_connectionString, "User_UpdateUTMData", paramUserId, paramUserUtmCampaign, paramUserUtmSource);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to update ForumTopicID in Eureeca user
        /// </summary>
        /// <param name="eureecaUserID">This is the eureeca user id need to update his forum topic id</param>
        /// <param name="customForumTopicID">This is the custome forum topic id</param>
        /// <param name="customForumUserID">This is the custome forum user id</param>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public void UserUpdateForumUserID(int eureecaUserID, int customForumTopicID, int customForumUserID)
        {
            try
            {
                SqlParameter param_EureecaUserID = new SqlParameter("@EureecaUserID", eureecaUserID);
                SqlParameter param_CustomForum_TopicID = new SqlParameter("@CustomForum_TopicID", customForumTopicID);
                SqlParameter param_CustomForum_UserID = new SqlParameter("@CustomForum_UserID", customForumUserID);
                _sqlHelper.ExecuteNonQuery(_connectionString, "USER_UPDATE_CUSTOMFORUM_TOPICID_USERID", param_EureecaUserID, param_CustomForum_TopicID, param_CustomForum_UserID);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// Update user flag (Agreed To Regulator Agreement) value
        /// </summary>
        /// <param name="userId">This is the user id need to update his regulate agreement flage</param>
        /// <param name="isAgreedToRegulatorAgreement"></param>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public void UserUpdateRegulatorAgreementFlag(long userId, bool isAgreedToRegulatorAgreement)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@UserID", userId);
                SqlParameter paramUserIsAgreedToRegulatorAgreement = new SqlParameter("@User_IsAgreedToRegulatorAgreement", isAgreedToRegulatorAgreement);
                _sqlHelper.ExecuteNonQuery(_connectionString, "User_UpdateRegulatorAgreementFlag", paramUserId, paramUserIsAgreedToRegulatorAgreement);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This is the method to get the country details
        /// </summary>
        /// <param name="countryId">This is the country id </param>
        /// <param name="profileLanguageId">This is the langauge id</param>
        /// <returns>Data table of all inforamtion</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable CountryBasedGetCountryDetails(int countryId, int profileLanguageId)
        {
            try
            {
                SqlParameter paramCountryId = new SqlParameter("@Country_ID", countryId);
                SqlParameter paramProfileLanguageId = new SqlParameter("@Profile_LanguageID", profileLanguageId);
                return _sqlHelper.GetDataTable(_connectionString, "GetCountryDetails", paramCountryId, paramProfileLanguageId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n Country_ID: " + countryId + "\n Profile_LanguageID: " + profileLanguageId);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This is method used to add the user to Google sheet
        /// </summary>
        /// <param name="id"></param>
        /// <param name="userName"></param>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        /// <param name="userType"></param>
        /// <param name="userFormType"></param>
        /// <param name="dateBirth"></param>
        /// <param name="signUpDate"></param>
        /// <param name="email"></param>
        /// <param name="gender"></param>
        /// <param name="phoneNumber"></param>
        /// <param name="city"></param>
        /// <param name="state"></param>
        /// <param name="country"></param>
        /// <param name="countryCode"></param>
        /// <param name="userBadge"></param>
        /// <param name="preferredLanguage"></param>
        public void AddUserToGoogleSheet(int id, string userName, string firstName, string lastName, string userType, string userFormType, string dateBirth, string signUpDate, string email, string gender, string phoneNumber, string city, string state, string country, string countryCode, string userBadge, string preferredLanguage)
        {
            //https://www.nuget.org/profiles/google-apis-packages
            //https://www.nuget.org/packages/Google.Apis.Sheets.v4/
            try
            {
                GoogleCredential credential; ;
                using (var stream = new FileStream(_config.GetValue<string>("EnvironmentPath") + "credentials.json", FileMode.Open, FileAccess.Read))
                {
                    string[] scopes = new string[] { SheetsService.Scope.Spreadsheets };
                    credential = GoogleCredential.FromStream(stream).CreateScoped(scopes);
                }
                SheetsService sheetsService = new SheetsService(new BaseClientService.Initializer { HttpClientInitializer = credential });

                ValueRange requestBody = new ValueRange();
                requestBody.Range = _config.GetValue<string>("SpreadSheetRange");
                requestBody.MajorDimension = "ROWS";
                requestBody.Values = new List<IList<object>> { new List<object>() { id, userName, firstName, lastName, userType, userFormType, dateBirth, signUpDate, email, gender, phoneNumber, city, state, country, countryCode, userBadge, preferredLanguage } };

                SpreadsheetsResource.ValuesResource.AppendRequest request = sheetsService.Spreadsheets.Values.Append(requestBody, _config.GetValue<string>("SpreadSheetID"), _config.GetValue<string>("SpreadSheetRange"));
                request.ValueInputOption = SpreadsheetsResource.ValuesResource.AppendRequest.ValueInputOptionEnum.USERENTERED; //insert the data in proper format. //RAW: The values the user has entered will not be parsed and will be stored as-is.
                request.InsertDataOption = SpreadsheetsResource.ValuesResource.AppendRequest.InsertDataOptionEnum.INSERTROWS; //Rows are inserted for the new data. //OVERWRITE: The new data overwrites existing data in the areas it is written. (Note: adding data to the end of the sheet will still insert new rows or columns so the data can be written.)

                AppendValuesResponse response = request.Execute();
            }
            catch (Exception ex)
            {
                _errHandler.WriteError("Error in adding user with ID: " + id + " and username: " + userName + " to google sheet:\n" + ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the user info depends on the username and password
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns>Data table of information</returns>
        public DataTable UserGetUserInfo(string username, string password)
        {
            try
            {
                SqlParameter paramUsername = new SqlParameter("@User_Username", username);
                SqlParameter paramUserPassword = new SqlParameter("@User_Password", password);
                return _sqlHelper.GetDataTable(_connectionString, "User_SelectAccountInfo", paramUsername, paramUserPassword);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }


        }

        /// <summary>
        /// This method is used to get user by guid
        /// </summary>
        /// <param name="userGuid"></param>
        /// <returns>Data table of all information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable UserSelectByUserGuid(string userGuid)
        {
            try
            {
                SqlParameter paramUserGuid = new SqlParameter("@User_Guid", userGuid);
                return _sqlHelper.GetDataTable(_connectionString, "User_SelectByUserGuid", paramUserGuid);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method used to check is the user classification allowed to a user.
        /// </summary>
        /// <param name="drUser"></param>
        /// <returns>A boolean value if the user is allowed or not</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public bool UserIsCategorizationAllowedForUser(DataRow drUser)
        {
            try
            {
                if (Convert.ToInt32(drUser["User_UserFormType"]) == (int)UserType.Enreprenuer)
                {
                    return false;
                }
                if (_countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Questionnaire_Categorization, int.Parse(drUser["User_Country"].ToString())) > 0 && string.IsNullOrEmpty(drUser["User_InvestorClassification"].ToString()))
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method used to return the user registration step
        /// </summary>
        /// <param name="dtUser">Data table of user info</param>
        /// <returns>A string if 0 -> classification tab, 2-> suitability tab</returns>
        public string UserGetLastTabsByDataTable(DataTable dtUser)
        {
            try
            {
                if (UserIsCategorizationAllowedForUser(dtUser.Rows[0]))
                    return "0";
                //else if (user.IsProfilingAllowedForUser(dtUser.Rows[0]))
                //    return "2";
                else if (UserIsSuitabilityTestAllowedForUser(dtUser.Rows[0]) >= 0)
                    return "2";

                else
                    return "3";

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return "0";
            }
        }

        /// <summary>
        /// This method used to check if the suitability test allowed to the user or not.
        /// </summary>
        /// <param name="drUser">Data table of user info</param>
        /// <returns>An integer value 
        /// -1 not allowed (passed before)
        /// 0 not allowed(not restrictred for country)
        /// 1 test
        /// 2 fail
        /// 3 fail with try
        /// </returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public int UserIsSuitabilityTestAllowedForUser(DataRow drUser)
        {
            /*
             -1 not allowed (passed before)
             0 not allowed (not restrictred for country)
             1 test
             2 fail
             3 fail with try
             */
            try
            {
                if (Convert.ToInt32(drUser["User_UserFormType"]) == (int)UserType.Enreprenuer)
                {
                    return -1;
                }

                if (drUser["User_Country"].ToString() != null)
                {
                    if (_countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Questionnaire, int.Parse(drUser["User_Country"].ToString())) > 0)
                    {
                        int activationLevel;
                        int Attempet_Number = int.Parse(drUser["User_Attempet_Number"].ToString());
                        if (string.IsNullOrEmpty(drUser["User_ActivationLevel"].ToString()))
                            activationLevel = 0;
                        else
                            activationLevel = int.Parse(drUser["User_ActivationLevel"].ToString());

                        int daysFromActivation = 0;
                        double hoursFromActivation = 0;

                        if (activationLevel != (int)UserActivationLevel.New)
                        {
                            DateTimeFormatInfo dtfi = new DateTimeFormatInfo();
                            dtfi.ShortDatePattern = "MM/dd/yyyy";
                            dtfi.DateSeparator = "/";
                            DateTime CurrentDate = Convert.ToDateTime(DateTime.Now.ToString(), dtfi);
                            DateTime ActivationDate = Convert.ToDateTime(drUser["User_ActivationDate"].ToString(), dtfi);
                            daysFromActivation = (CurrentDate - ActivationDate).Days;
                            hoursFromActivation = (CurrentDate - ActivationDate).TotalHours;
                        }
                        if (activationLevel == (int)UserActivationLevel.FirstFailure && hoursFromActivation >= 24 && Attempet_Number == 5)
                        {
                            UserUpdateAttempetNumber(int.Parse(drUser["User_ID"].ToString()));
                        }
                        if (activationLevel == (int)UserActivationLevel.SecondFailure && daysFromActivation >= 7 && Attempet_Number == 5)
                        {
                            UserUpdateAttempetNumber(int.Parse(drUser["User_ID"].ToString()));
                        }


                        if (activationLevel == (int)UserActivationLevel.Success)
                            return -1;
                        else if (activationLevel == (int)UserActivationLevel.FirstFailure && hoursFromActivation < 24 && int.Parse(drUser["User_Status"].ToString()) == (int)UserStatus.NotQualified)
                            return 2;
                        else if (activationLevel == (int)UserActivationLevel.SecondFailure && daysFromActivation < 7 && int.Parse(drUser["User_Status"].ToString()) == (int)UserStatus.NotQualified)
                            return 4;
                        else if (activationLevel == 0)
                            return 3;
                        else
                            return 1;
                    }
                    else
                        return 0;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// Update user Round Number value to be 0
        /// </summary>
        /// <param name="userId">This is the user id will update his attempt number</param>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public void UserUpdateAttempetNumber(long userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                _sqlHelper.ExecuteNonQuery(_connectionString, "User_Update_Attempet_Number", paramUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the suitability test for user
        /// </summary>
        /// <param name="langId"></param>
        /// <param name="countryId"></param>
        /// <param name="userId"></param>
        /// <returns>A list of questions and answers</returns>
        /// <exception cref="Exception"></exception>
        public List<SuitabilityTest> SuitabilityTestGetSuitabilityTest(int langId, string countryId, int userId)
        {
            try
            {
                List<SuitabilityTest> questions = new List<SuitabilityTest>();
                string countryCode = CountryBasedGetCountryDetails(int.Parse(countryId), langId).Rows[0]["Country_Code"].ToString();
                DataTable DTForms = _countryBasedControl.CountryBasedGetCurrencyCheckQuestion(Convert.ToInt32(CountryBasedControls.Questionnaire), countryCode);
                if (DTForms.Rows.Count > 0)
                {
                    DataTable dtFormQuestions = _suitabilityTest.SuitabilityTestGetQuestionsByForm(Convert.ToInt32(DTForms.Rows[0]["Form_ID"].ToString()));
                    DataTable dtUserAnswers = _suitabilityTest.SuitabilityTestGetUserAnswers(int.Parse(DTForms.Rows[0]["Form_ID"].ToString()), userId);
                    int questionRow = 0;
                    string questionnaireRepAnswerId = "";
                    string questionAnwersRight = "";

                    string langChar = "En";

                    if (langId == (int)Languages.English)
                    {
                        langChar = "En";
                    }
                    else if (langId == (int)Languages.Arabic)
                    {
                        langChar = "Ar";
                    }
                    else
                    {
                        langChar = "Sp";
                    }

                    foreach (DataRow r in dtFormQuestions.Rows)
                    {
                        SuitabilityTest suitabilityTest = new SuitabilityTest();

                        if (dtUserAnswers.Rows.Count > 0)
                        {
                            suitabilityTest.UserAnswer = questionnaireRepAnswerId = dtUserAnswers.Rows[questionRow]["Questionnaire_Rep_AnswerID"].ToString();
                        }
                        suitabilityTest.CorrectAnswer = questionAnwersRight = dtFormQuestions.Rows[questionRow]["Question_Anwers_Right"].ToString();


                        if (questionnaireRepAnswerId != "" && questionAnwersRight != "" && questionnaireRepAnswerId != questionAnwersRight)
                        {
                            suitabilityTest.ShowRefillMessage = true;
                            suitabilityTest.RefillMessage = _stringLocalizer["FailedAnswerNote"];
                        }
                        suitabilityTest.Id = int.Parse(r["Question_ID"].ToString());
                        suitabilityTest.Question = r["Question" + langChar + "_Text"].ToString();
                        suitabilityTest.QuestionNote = r["Question_" + langChar + "_Note"].ToString();

                        DataTable dtQuestionsAnswers = _suitabilityTest.SuitabilityTestGetAnswers(Convert.ToInt32(r["Question_ID"].ToString()));

                        List<SuitabilityTestAnswer> answers = new List<SuitabilityTestAnswer>();
                        foreach (DataRow r2 in dtQuestionsAnswers.Rows)
                        {
                            SuitabilityTestAnswer answer = new SuitabilityTestAnswer();
                            answer.AnswerId = int.Parse(r2["Anwers_ID"].ToString());
                            answer.AnswerText = r2["Anwers" + langChar + "_Text"].ToString();
                            answer.Row = int.Parse(r2["row"].ToString());
                            answers.Add(answer);
                        }

                        suitabilityTest.Answers = answers;
                        questions.Add(suitabilityTest);

                        questionRow++;
                    }
                }
                return questions;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to return the KYC required files
        /// </summary>
        /// <param name="userId">This is the user id need to get his KYC required files</param>
        /// <param name="countryId">This is the country id of the user</param>
        /// <returns>A KYC model contain all required files</returns>
        /// <exception cref="Exception"></exception>
        public KYCModel KYCGetRequiredFiles(int userId, int countryId)
        {
            try
            {
                KYCModel kYCModel = new KYCModel();
                List<KYCDocument> kYCDocuments = new List<KYCDocument>();
                int number = 0;
                string response = "";
                DataTable dtUserInfo = UserSelectById(userId);
                if (dtUserInfo != null && dtUserInfo.Rows.Count > 0)
                {
                    int user_type = Convert.ToInt32(dtUserInfo.Rows[0]["User_UserFormType"]);
                    if (user_type == (int)UserType.Enreprenuer || user_type == (int)UserType.Admin || user_type == (int)UserType.SystemAdmin || user_type == (int)UserType.BIAdmin)
                        response = "there is no KYC needed";

                    string userCountry = dtUserInfo.Rows[0]["User_Country"].ToString();
                    if (string.IsNullOrEmpty(userCountry))
                        userCountry = countryId.ToString();

                    DataTable dtUserCountry = CountryBasedGetCountryDetails(int.Parse(userCountry), (int)Languages.English);
                    if (dtUserCountry.Rows.Count > 0)
                    {
                        int[] array = new int[19];
                        array = _kyc.KYCGetRequiredDocs(int.Parse(dtUserInfo.Rows[0]["User_ID"].ToString()), int.Parse(dtUserCountry.Rows[0]["Country_KYC_Tire"].ToString()));
                        DataTable dtDocs = new DataTable();
                        dtDocs.Columns.Add(new DataColumn("liDocumnetsVisible", typeof(bool)));
                        dtDocs.Columns.Add(new DataColumn("KYCOverAllStatus", typeof(int)));
                        dtDocs.Columns.Add(new DataColumn("ltrKYCOverAllStatusText", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("KYCDescription", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("ltrPersonalPhotoStatusText", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("PersonalPhotoNeed", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("PersonalPhotoTitle", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("PersonalPhotoWhyVisible", typeof(bool)));
                        dtDocs.Columns.Add(new DataColumn("ltrPassportStatusText", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("PassportNeed", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("PassportTitle", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("PassportWhyVisible", typeof(bool)));
                        dtDocs.Columns.Add(new DataColumn("ltrProofStatusText", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("ProofNeed", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("ProofTitle", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("ProofWhyVisible", typeof(bool)));
                        dtDocs.Columns.Add(new DataColumn("ltrCertefiedStatusText", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("CertefiedNeed", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("CertefiedTitle", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("CertefiedWhyVisible", typeof(bool)));
                        dtDocs.Columns.Add(new DataColumn("ltrPEPStatusText", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("liPEPClass", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("PEPNeed", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("PEPTitle", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("PEPWhyVisible", typeof(bool)));
                        dtDocs.Columns.Add(new DataColumn("ltrSourceStatusText", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("lisourceClass", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("SourceNeed", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("SourceTitle", typeof(string)));
                        dtDocs.Columns.Add(new DataColumn("SourceWhyVisible", typeof(bool)));
                        dtDocs.Columns.Add(new DataColumn("ltrRealNeededDocsCountText", typeof(int)));
                        dtDocs.Columns.Add(new DataColumn("UserCanPay", typeof(bool)));

                        DataRow drDocs = dtDocs.NewRow();

                        int neededDocs = array[0];
                        int acceptedOrPendingDocsFromNeeded = array[1];
                        int personalPhotoNeeded = array[2];
                        int personalPhotoStatus = array[3];
                        int passportNeeded = array[4];
                        int passportStatus = array[5];
                        int utilityNeeded = array[6];
                        int utilityStatus = array[7];
                        int paymentConfirmNeeded = array[8];
                        int paymentConfirmationStatus = array[9];
                        int proofOfAddressNeeded = array[10];
                        int proofOfAddressStatus = array[11];
                        int sourceOfWealthNeeded = array[12];
                        int sourceOfWealthStatus = array[13];
                        int certefiedCopiesNeeded = array[14];
                        int certefiedCopiesStatus = array[15];
                        int PEPDocNeeded = array[16];
                        int PEPStatus = array[17];

                        if (neededDocs == 0)  //KYC not required
                        {
                            drDocs["ltrRealNeededDocsCountText"] = neededDocs;
                            kYCModel.NeededDocCount = neededDocs;

                            drDocs["liDocumnetsVisible"] = false;

                            drDocs["ltrKYCOverAllStatusText"] = _stringLocalizer["Your_are_all_set"].Value;
                            kYCModel.KYCOverAllStatusText = _stringLocalizer["Your_are_all_set"].Value;

                            drDocs["UserCanPay"] = true;
                            kYCModel.UserCanPay = true;


                            drDocs["KYCOverAllStatus"] = (int)KYCUserDocsStatus.Accepted;
                            kYCModel.KYCOverAllStatus = (int)KYCUserDocsStatus.Accepted;


                        }
                        else
                        {
                            drDocs["ltrRealNeededDocsCountText"] = neededDocs - acceptedOrPendingDocsFromNeeded;
                            kYCModel.NeededDocCount = neededDocs - acceptedOrPendingDocsFromNeeded;
                            drDocs["liDocumnetsVisible"] = true;

                            DataTable dtUserDocs = _kyc.KYCGetUserDocs(userId);
                            int Overall_Status = (int)KYCUserDocsStatus.NotUploaded;

                            if (dtUserDocs.Rows.Count > 0) //the user uploaded some/all needed docs before
                                Overall_Status = int.Parse(dtUserDocs.Rows[0]["Overall_Status"].ToString());
                            kYCModel.KYCOverAllStatus = Overall_Status;

                            KYCDocument doc = new KYCDocument();
                            #region Personal Photo
                            if (personalPhotoNeeded == 1)
                            {
                                if (personalPhotoStatus == (int)KYCUserDocsStatus.NotUploaded)
                                {
                                    //  name ,description, isWhyVisible, btnTet,isBtnVisible,status, statusText)

                                    drDocs["ltrPersonalPhotoStatusText"] = _stringLocalizer["Upload"];
                                    drDocs["PersonalPhotoNeed"] = "1";

                                    doc = KYCSetKYCDocument("Personal_Photo", "Personal_Photo_Desc", false, "Upload", true, personalPhotoStatus, "Not_Uploaded", KYCDocType.PersonalPhote);
                                    kYCDocuments.Add(doc);
                                }
                                else if (personalPhotoStatus == (int)KYCUserDocsStatus.PendingApproval)
                                {
                                    drDocs["ltrPersonalPhotoStatusText"] = _stringLocalizer["Pending_Approval"];
                                    drDocs["PersonalPhotoTitle"] = _stringLocalizer["Document_received_pending_approval"];

                                    doc = KYCSetKYCDocument("Personal_Photo", "Personal_Photo_Desc", false, "", false, personalPhotoStatus, "Pending_Approval", KYCDocType.PersonalPhote);
                                    doc.Tooltip = _stringLocalizer["Document_received_pending_approval"].Value;
                                    kYCDocuments.Add(doc);

                                }
                                else if (personalPhotoStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    drDocs["ltrPersonalPhotoStatusText"] = _stringLocalizer["Accepted"];
                                    drDocs["PersonalPhotoTitle"] = _stringLocalizer["Your_Passport_scan_was_accepted_by_eureeca"];

                                    doc = KYCSetKYCDocument("Personal_Photo", "Personal_Photo_Desc", false, "", false, personalPhotoStatus, "Accepted", KYCDocType.PersonalPhote);
                                    doc.Tooltip = _stringLocalizer["Your_Passport_scan_was_accepted_by_eureeca"].Value;
                                    kYCDocuments.Add(doc);

                                }
                                else if (personalPhotoStatus == (int)KYCUserDocsStatus.NotAccepted)
                                {
                                    drDocs["ltrPersonalPhotoStatusText"] = _stringLocalizer["Resubmit"];
                                    drDocs["PersonalPhotoNeed"] = "1";
                                    drDocs["PersonalPhotoWhyVisible"] = true;
                                    doc = KYCSetKYCDocument("Personal_Photo", "Personal_Photo_Desc", true, "Resubmit", true, personalPhotoStatus, "NotAccepted", KYCDocType.PersonalPhote);
                                    doc.WhatToDo = _stringLocalizer["What_Do_Photo_Rejected"];
                                    doc.WhyText = _stringLocalizer["Why_Photo_Rejected"];
                                    kYCDocuments.Add(doc);

                                }
                            }
                            else
                            {
                                if (personalPhotoStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    drDocs["ltrPersonalPhotoStatusText"] = _stringLocalizer["Accepted"];
                                    drDocs["PersonalPhotoTitle"] = _stringLocalizer["Your_Passport_scan_was_accepted_by_eureeca"];
                                    doc = KYCSetKYCDocument("Personal_Photo", "Personal_Photo_Desc", false, "", false, personalPhotoStatus, "Accepted", KYCDocType.PersonalPhote);
                                    doc.Tooltip = _stringLocalizer["Your_Passport_scan_was_accepted_by_eureeca"].Value;
                                    kYCDocuments.Add(doc);
                                }
                                else
                                {
                                    drDocs["ltrPersonalPhotoStatusText"] = _stringLocalizer["NotRequired"];
                                }
                            }
                            #endregion
                            #region Passport
                            if (passportNeeded == 1)
                            {
                                if (passportStatus == (int)KYCUserDocsStatus.NotUploaded)
                                {
                                    drDocs["ltrPassportStatusText"] = _stringLocalizer["Upload"];
                                    drDocs["PassportNeed"] = "1";
                                    doc = KYCSetKYCDocument("Passport_ID", "Scan_copy_of_the_full_ID_page", false, "Upload", true, passportStatus, "Not_Uploaded", KYCDocType.Passport);
                                    doc.Placeholder = _stringLocalizer["Passport_Name"];
                                    kYCDocuments.Add(doc);
                                }
                                else if (passportStatus == (int)KYCUserDocsStatus.PendingApproval)
                                {
                                    drDocs["ltrPassportStatusText"] = _stringLocalizer["Pending_Approval"];
                                    drDocs["PassportTitle"] = _stringLocalizer["Document_received_pending_approval"];
                                    doc = KYCSetKYCDocument("Passport_ID", "Scan_copy_of_the_full_ID_page", false, "", false, passportStatus, "Pending_Approval", KYCDocType.Passport);
                                    doc.Tooltip = _stringLocalizer["Document_received_pending_approval"];
                                    doc.Placeholder = _stringLocalizer["Passport_Name"];
                                    kYCDocuments.Add(doc);


                                }
                                else if (passportStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    drDocs["ltrPassportStatusText"] = _stringLocalizer["Accepted"];
                                    drDocs["PassportTitle"] = _stringLocalizer["Your_Passport_scan_was_accepted_by_eureeca"];
                                    doc = KYCSetKYCDocument("Passport_ID", "Scan_copy_of_the_full_ID_page", false, "", false, passportStatus, "Accepted", KYCDocType.Passport);
                                    doc.Tooltip = _stringLocalizer["Your_Passport_scan_was_accepted_by_eureeca"];
                                    kYCDocuments.Add(doc);

                                }
                                else if (passportStatus == (int)KYCUserDocsStatus.NotAccepted || passportStatus == (int)KYCUserDocsStatus.Expired)
                                {
                                    drDocs["ltrPassportStatusText"] = _stringLocalizer["Resubmit"];
                                    drDocs["PassportNeed"] = "1";
                                    drDocs["PassportWhyVisible"] = true;
                                    doc = KYCSetKYCDocument("Passport_ID", "Scan_copy_of_the_full_ID_page", true, "Resubmit", true, passportStatus, "NotAccepted", KYCDocType.Passport);
                                    doc.Placeholder = _stringLocalizer["Passport_Name"];
                                    doc.WhyText = _stringLocalizer["Expired_Passport"];
                                    doc.WhatToDo = _stringLocalizer["Passport_should_be_valid"];
                                    kYCDocuments.Add(doc);

                                }
                            }
                            else
                            {
                                if (passportStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    drDocs["ltrPassportStatusText"] = _stringLocalizer["Accepted"];
                                    drDocs["PassportTitle"] = _stringLocalizer["Your_Passport_scan_was_accepted_by_eureeca"];
                                    doc = KYCSetKYCDocument("Passport_ID", "Scan_copy_of_the_full_ID_page", false, "", false, passportStatus, "Accepted", KYCDocType.Passport);
                                    doc.Tooltip = _stringLocalizer["Your_Passport_scan_was_accepted_by_eureeca"];
                                    kYCDocuments.Add(doc);

                                }
                                else
                                {
                                    drDocs["ltrPassportStatusText"] = _stringLocalizer["NotRequired"];
                                }
                            }
                            #endregion
                            #region Proof_of_address
                            if (proofOfAddressNeeded == 1)
                            {
                                if (proofOfAddressStatus == (int)KYCUserDocsStatus.NotUploaded)
                                {
                                    drDocs["ltrProofStatusText"] = _stringLocalizer["Upload"];
                                    drDocs["ProofNeed"] = "1";
                                    doc = KYCSetKYCDocument("Proof_of_address", "Official_document_with_your_full_home_address", false, "Upload", true, proofOfAddressStatus, "Not_Uploaded", KYCDocType.ProofOfAddress);
                                    doc.Placeholder = _stringLocalizer["POA_Address"];
                                    kYCDocuments.Add(doc);

                                }
                                else if (proofOfAddressStatus == (int)KYCUserDocsStatus.PendingApproval)
                                {
                                    drDocs["ltrProofStatusText"] = _stringLocalizer["Pending_Approval"];
                                    drDocs["ProofTitle"] = _stringLocalizer["Document_received_pending_approval"];
                                    doc = KYCSetKYCDocument("Proof_of_address", "Official_document_with_your_full_home_address", false, "", false, proofOfAddressStatus, "Pending_Approval", KYCDocType.ProofOfAddress);
                                    doc.Tooltip = _stringLocalizer["Document_received_pending_approval"];
                                    kYCDocuments.Add(doc);

                                }
                                else if (proofOfAddressStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    drDocs["ltrProofStatusText"] = _stringLocalizer["Accepted"];
                                    drDocs["ProofTitle"] = _stringLocalizer["Your_Proof_of_address_scan_was_accepted_by_eureeca"];
                                    doc = KYCSetKYCDocument("Proof_of_address", "Official_document_with_your_full_home_address", false, "", false, proofOfAddressStatus, "Accepted", KYCDocType.ProofOfAddress);
                                    doc.Tooltip = _stringLocalizer["Your_Proof_of_address_scan_was_accepted_by_eureeca"];
                                    kYCDocuments.Add(doc);

                                }
                                else if (proofOfAddressStatus == (int)KYCUserDocsStatus.NotAccepted || proofOfAddressStatus == (int)KYCUserDocsStatus.Expired)
                                {
                                    drDocs["ltrProofStatusText"] = _stringLocalizer["Resubmit"];
                                    drDocs["ProofNeed"] = "1";
                                    drDocs["ProofWhyVisible"] = true;
                                    doc = KYCSetKYCDocument("Proof_of_address", "Official_document_with_your_full_home_address", true, "Resubmit", true, proofOfAddressStatus, "NotAccepted", KYCDocType.ProofOfAddress);
                                    doc.Placeholder = _stringLocalizer["POA_Address"];
                                    doc.WhyText = _stringLocalizer["Outdated_documents"];
                                    doc.WhatToDo = _stringLocalizer["Submit_any_of_the_following"];
                                    kYCDocuments.Add(doc);

                                }
                            }
                            else
                            {
                                if (proofOfAddressStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    drDocs["ltrProofStatusText"] = _stringLocalizer["Accepted"];
                                    drDocs["ProofTitle"] = _stringLocalizer["Your_Proof_of_address_scan_was_accepted_by_eureeca"];
                                    doc = KYCSetKYCDocument("Proof_of_address", "Official_document_with_your_full_home_address", false, "", false, proofOfAddressStatus, "Accepted", KYCDocType.ProofOfAddress);
                                    doc.Tooltip = _stringLocalizer["Your_Proof_of_address_scan_was_accepted_by_eureeca"];
                                    kYCDocuments.Add(doc);

                                }
                                else
                                {
                                    drDocs["ltrProofStatusText"] = _stringLocalizer["NotRequired"];
                                }
                            }
                            #endregion
                            #region Certefied_copies
                            if (certefiedCopiesNeeded == 1)
                            {
                                if (certefiedCopiesStatus == (int)KYCUserDocsStatus.NotUploaded)
                                {
                                    drDocs["ltrCertefiedStatusText"] = _stringLocalizer["Upload"];
                                    drDocs["CertefiedNeed"] = "1";
                                    doc = KYCSetKYCDocument("Certified_copies", "Proof_of_address_and_passport_certified_from_a_lawyer", false, "Upload", true, certefiedCopiesStatus, "Not_Uploaded", KYCDocType.CertificatedCopies);
                                    kYCDocuments.Add(doc);
                                }
                                else if (certefiedCopiesStatus == (int)KYCUserDocsStatus.PendingApproval)
                                {
                                    drDocs["ltrCertefiedStatusText"] = _stringLocalizer["Pending_Approval"];
                                    drDocs["CertefiedTitle"] = _stringLocalizer["Document_received_pending_approval"];
                                    doc = KYCSetKYCDocument("Certified_copies", "Proof_of_address_and_passport_certified_from_a_lawyer", false, "", false, certefiedCopiesStatus, "Pending_Approval", KYCDocType.CertificatedCopies);
                                    doc.Tooltip = _stringLocalizer["Document_received_pending_approval"];
                                    kYCDocuments.Add(doc);

                                }
                                else if (certefiedCopiesStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    drDocs["ltrCertefiedStatusText"] = _stringLocalizer["Accepted"];
                                    drDocs["CertefiedTitle"] = _stringLocalizer["Your_Certefied_copies_scan_was_accepted_by_eureeca"];
                                    doc = KYCSetKYCDocument("Certified_copies", "Proof_of_address_and_passport_certified_from_a_lawyer", false, "", false, certefiedCopiesStatus, "Accepted", KYCDocType.CertificatedCopies);
                                    doc.Tooltip = _stringLocalizer["Your_Certefied_copies_scan_was_accepted_by_eureeca"];
                                    kYCDocuments.Add(doc);

                                }
                                else if (certefiedCopiesStatus == (int)KYCUserDocsStatus.NotAccepted)
                                {
                                    drDocs["ltrCertefiedStatusText"] = _stringLocalizer["Resubmit"];
                                    drDocs["CertefiedNeed"] = "1";
                                    drDocs["CertefiedWhyVisible"] = true;
                                    doc = KYCSetKYCDocument("Certified_copies", "Proof_of_address_and_passport_certified_from_a_lawyer", true, "Resubmit", true, proofOfAddressStatus, "NotAccepted", KYCDocType.CertificatedCopies);
                                    doc.WhatToDo = _stringLocalizer["A_Lawyer_or_an_accountant_should"];
                                    doc.WhyText = _stringLocalizer["Not_from_a_lawyer_or_accountant"];
                                    kYCDocuments.Add(doc);

                                }
                            }
                            else
                            {
                                if (certefiedCopiesStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    drDocs["ltrCertefiedStatusText"] = _stringLocalizer["Accepted"];
                                    drDocs["CertefiedTitle"] = _stringLocalizer["Proof_of_address_and_passport_certified_from_a_lawyer"];
                                    doc = KYCSetKYCDocument("Certified_copies", "Your_Certefied_copies_scan_was_accepted_by_eureeca", false, "", false, certefiedCopiesStatus, "Accepted", KYCDocType.CertificatedCopies);
                                    doc.Tooltip = _stringLocalizer["Your_Certefied_copies_scan_was_accepted_by_eureeca"];
                                    kYCDocuments.Add(doc);

                                }
                                else
                                {
                                    drDocs["ltrCertefiedStatusText"] = _stringLocalizer["NotRequired"];
                                }
                            }
                            #endregion
                            #region PEP_Doc
                            if (PEPDocNeeded == 1)
                            {
                                if (PEPStatus == (int)KYCUserDocsStatus.NotUploaded)
                                {
                                    drDocs["ltrPEPStatusText"] = _stringLocalizer["Upload"];
                                    drDocs["PEPNeed"] = "1";
                                    doc = KYCSetKYCDocument("PEP_Doc_Title", "PEP_Doc_Desc", false, "Upload", true, PEPStatus, "Not_Uploaded", KYCDocType.PEPDoc);
                                    kYCDocuments.Add(doc);

                                }
                                else if (PEPStatus == (int)KYCUserDocsStatus.PendingApproval)
                                {
                                    drDocs["ltrPEPStatusText"] = _stringLocalizer["Pending_Approval"];
                                    drDocs["PEPTitle"] = _stringLocalizer["Document_received_pending_approval"];
                                    doc = KYCSetKYCDocument("PEP_Doc_Title", "PEP_Doc_Desc", false, "", false, PEPStatus, "Pending_Approval", KYCDocType.PEPDoc);
                                    doc.Tooltip = _stringLocalizer["Document_received_pending_approval"];
                                    kYCDocuments.Add(doc);

                                }
                                else if (PEPStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    drDocs["ltrPEPStatusText"] = _stringLocalizer["Accepted"];
                                    drDocs["PEPTitle"] = _stringLocalizer["Your_PEP_Doc_was_accepted_by_eureeca"];
                                    doc = KYCSetKYCDocument("PEP_Doc_Title", "PEP_Doc_Desc", false, "", false, PEPStatus, "Accepted", KYCDocType.PEPDoc);
                                    doc.Tooltip = _stringLocalizer["Your_PEP_Doc_was_accepted_by_eureeca"];
                                    kYCDocuments.Add(doc);

                                }
                                else if (PEPStatus == (int)KYCUserDocsStatus.NotAccepted)
                                {
                                    drDocs["ltrPEPStatusText"] = _stringLocalizer["Resubmit"];
                                    drDocs["PEPNeed"] = "1";
                                    drDocs["PEPWhyVisible"] = true;
                                    doc = KYCSetKYCDocument("PEP_Doc_Title", "PEP_Doc_Desc", true, "Resubmit", true, PEPStatus, "Not_Uploaded", KYCDocType.PEPDoc);
                                    doc.WhyText = _stringLocalizer["PEP_Doc_Failure_Reason"];
                                    doc.WhatToDo = _stringLocalizer["PEP_Doc_Failure_ToDo"];
                                    kYCDocuments.Add(doc);

                                }
                            }
                            else
                            {
                                if (PEPStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    drDocs["ltrPEPStatusText"] = _stringLocalizer["Accepted"];
                                    drDocs["PEPTitle"] = _stringLocalizer["Your_PEP_Doc_was_accepted_by_eureeca"];
                                    doc = KYCSetKYCDocument("PEP_Doc_Title", "PEP_Doc_Desc", false, "", false, PEPStatus, "Accepted", KYCDocType.PEPDoc);
                                    doc.Tooltip = _stringLocalizer["Your_PEP_Doc_was_accepted_by_eureeca"];
                                    kYCDocuments.Add(doc);

                                }
                                else
                                {
                                    drDocs["ltrPEPStatusText"] = _stringLocalizer["NotRequired"];
                                }
                            }
                            #endregion
                            #region Source_of_wealth
                            if (sourceOfWealthNeeded == 1)
                            {
                                if (sourceOfWealthStatus == (int)KYCUserDocsStatus.NotUploaded)
                                {
                                    drDocs["ltrSourceStatusText"] = _stringLocalizer["Upload"];
                                    drDocs["SourceNeed"] = "1";
                                    doc = KYCSetKYCDocument("Source_of_wealth", "Official_letter_from_emplyer", false, "Upload", true, sourceOfWealthStatus, "Not_Uploaded", KYCDocType.SourceOfWealth);
                                    kYCDocuments.Add(doc);

                                }
                                else if (sourceOfWealthStatus == (int)KYCUserDocsStatus.PendingApproval)
                                {
                                    drDocs["ltrSourceStatusText"] = _stringLocalizer["Pending_Approval"];
                                    drDocs["SourceTitle"] = _stringLocalizer["Document_received_pending_approval"];
                                    doc = KYCSetKYCDocument("Source_of_wealth", "Official_letter_from_emplyer", false, "", false, sourceOfWealthStatus, "Pending_Approval", KYCDocType.SourceOfWealth);
                                    doc.Tooltip = _stringLocalizer["Document_received_pending_approval"];
                                    kYCDocuments.Add(doc);

                                }
                                else if (sourceOfWealthStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    drDocs["ltrSourceStatusText"] = _stringLocalizer["Accepted"];
                                    drDocs["SourceTitle"] = _stringLocalizer["Your_Source_of_wealth_scan_was_accepted_by_eureeca"];
                                    doc = KYCSetKYCDocument("Source_of_wealth", "Official_letter_from_emplyer", false, "", false, sourceOfWealthStatus, "Accepted", KYCDocType.SourceOfWealth);
                                    doc.Tooltip = _stringLocalizer["Your_Source_of_wealth_scan_was_accepted_by_eureeca"];
                                    kYCDocuments.Add(doc);

                                }
                                else if (sourceOfWealthStatus == (int)KYCUserDocsStatus.NotAccepted)
                                {
                                    drDocs["ltrSourceStatusText"] = _stringLocalizer["Resubmit"];
                                    drDocs["SourceNeed"] = "1";
                                    drDocs["SourceWhyVisible"] = true;
                                    doc = KYCSetKYCDocument("Source_of_wealth", "Official_letter_from_emplyer", true, "Resubmit", true, sourceOfWealthStatus, "NotAccepted", KYCDocType.SourceOfWealth);
                                    doc.WhyText = _stringLocalizer["Not_officially_signed"];
                                    doc.WhatToDo = _stringLocalizer["Provide_a_letter_from"];
                                    kYCDocuments.Add(doc);

                                }
                            }
                            else
                            {
                                if (sourceOfWealthStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    drDocs["ltrSourceStatusText"] = _stringLocalizer["Accepted"];
                                    drDocs["SourceTitle"] = _stringLocalizer["Your_Source_of_wealth_scan_was_accepted_by_eureeca"];
                                    doc = KYCSetKYCDocument("Source_of_wealth", "Official_letter_from_emplyer", false, "", false, sourceOfWealthStatus, "Accepted", KYCDocType.SourceOfWealth);
                                    doc.Tooltip = _stringLocalizer["Your_Source_of_wealth_scan_was_accepted_by_eureeca"];
                                    kYCDocuments.Add(doc);

                                }
                                else
                                {
                                    drDocs["ltrSourceStatusText"] = _stringLocalizer["NotRequired"];
                                }
                            }
                            #endregion

                            drDocs["UserCanPay"] = false;
                            drDocs["KYCOverAllStatus"] = Overall_Status;

                            if (Overall_Status == (int)KYCUserDocsStatus.NotUploaded)
                            {
                                drDocs["ltrKYCOverAllStatusText"] = _stringLocalizer["Not_Uploaded"].Value;
                                drDocs["KYCDescription"] = _stringLocalizer["To_enable_you_to_use_all_the_features"];
                                kYCModel.KYCOverAllStatusText = _stringLocalizer["Not_Uploaded"].Value;
                                kYCModel.KYCDescription = _stringLocalizer["To_enable_you_to_use_all_the_features"].Value;
                            }
                            else if (Overall_Status == (int)KYCUserDocsStatus.PendingApproval)
                            {
                                drDocs["ltrKYCOverAllStatusText"] = _stringLocalizer["In_Process"];
                                drDocs["KYCDescription"] = _stringLocalizer["Over_All_Pending_Thanks"];
                                kYCModel.KYCOverAllStatusText = _stringLocalizer["In_Process"].Value;
                                kYCModel.KYCDescription = _stringLocalizer["Over_All_Pending_Thanks"].Value;

                                if (int.Parse(dtUserCountry.Rows[0]["Country_KYC_Tire"].ToString()) == 1)
                                {
                                    drDocs["KYCDescription"] += "<br /><br />" + _stringLocalizer["you_can_top_account"];
                                    kYCModel.KYCDescription += "/n/n" + _stringLocalizer["you_can_top_account"].Value;
                                    drDocs["UserCanPay"] = true;
                                    kYCModel.UserCanPay = true;
                                }
                                else if (int.Parse(dtUserCountry.Rows[0]["Country_KYC_Tire"].ToString()) == 2 || int.Parse(dtUserCountry.Rows[0]["Country_KYC_Tire"].ToString()) == 3)
                                {
                                    drDocs["KYCDescription"] += "<br /><br />" + _stringLocalizer["once_kyc_aproved"];
                                    kYCModel.KYCDescription += "/n/n" + _stringLocalizer["once_kyc_aproved"].Value;
                                }
                            }
                            else if (Overall_Status == (int)KYCUserDocsStatus.Accepted)
                            {
                                drDocs["ltrKYCOverAllStatusText"] = _stringLocalizer["Congratulations"];
                                drDocs["UserCanPay"] = true;
                                kYCModel.UserCanPay = true;
                                drDocs["KYCDescription"] = _stringLocalizer["Thank_you_for_uploading_your"];
                                kYCModel.KYCOverAllStatusText = _stringLocalizer["Congratulations"].Value;
                                kYCModel.KYCDescription = _stringLocalizer["Thank_you_for_uploading_your"].Value;


                            }
                            else if (Overall_Status == (int)KYCUserDocsStatus.NotAccepted)
                            {
                                drDocs["ltrKYCOverAllStatusText"] = _stringLocalizer["Resubmission_Required"];
                                drDocs["KYCDescription"] = _stringLocalizer["To_enable_you_to_use_all_the_features"];
                                kYCModel.KYCOverAllStatusText = _stringLocalizer["Resubmission_Required"].Value;
                                kYCModel.KYCDescription = _stringLocalizer["To_enable_you_to_use_all_the_features"].Value;

                            }
                            else if (Overall_Status == (int)KYCUserDocsStatus.Expired)
                            {
                                drDocs["ltrKYCOverAllStatusText"] = _stringLocalizer["Expired"];
                                drDocs["KYCDescription"] = _stringLocalizer["To_enable_you_to_use_all_the_features"];
                                kYCModel.KYCOverAllStatusText = _stringLocalizer["Expired"].Value;
                                kYCModel.KYCDescription = _stringLocalizer["To_enable_you_to_use_all_the_features"].Value;


                            }
                        }

                        dtDocs.Rows.Add(drDocs);
                        kYCModel.kYCDocuments = kYCDocuments;

                    }



                }
                else
                    number = 0;
                //return 0;

                return kYCModel;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        /// <summary>
        /// This method is used to set the KYC Document model data
        /// </summary>
        /// <param name="name"></param>
        /// <param name="description"></param>
        /// <param name="isWhyVisible"></param>
        /// <param name="btnTet"></param>
        /// <param name="isBtnVisible"></param>
        /// <param name="status"></param>
        /// <param name="statusText"></param>
        /// <returns>A KYC document object</returns>
        private KYCDocument KYCSetKYCDocument(string name, string description, bool isWhyVisible, string btnTet, bool isBtnVisible, int status, string statusText, KYCDocType kYCDocType)
        {
            KYCDocument doc = new KYCDocument();
            doc.Name = _stringLocalizer[name];
            doc.Description = _stringLocalizer[description];
            doc.IsWhyVisible = isWhyVisible;
            doc.BtnText = _stringLocalizer[btnTet];
            doc.Status = status;
            doc.StatusText = _stringLocalizer[statusText];
            doc.IsBtnVisible = isBtnVisible;
            doc.kYCFileType = kYCDocType;

            return doc;
        }
        public int UserGetUserConnectionId(string sourceUserId, string destinationUserId)
        {
            try
            {
                SqlParameter paramSourceUserId = new SqlParameter("@SourceUserID", sourceUserId);
                SqlParameter paramDestinationUserId = new SqlParameter("@DestinationUserID", destinationUserId);
                return _sqlHelper.ExecuteScalar(_connectionString, "User_GetUserConnectionID", paramSourceUserId, paramDestinationUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        public bool UserIsExpert(int userId)
        {
            try
            {
                int userTotalFollowing = UserGetTotalFollowing(userId);
                if (userTotalFollowing >= 200)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }
        public int UserGetTotalFollowing(int userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@UID", userId);
                return _sqlHelper.ExecuteScalar(_connectionString, "User_GetTotalFollowing", paramUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to Authintecate the user it will detect the redirect type
        /// </summary>
        /// <param name="dtUserInfo"></param>
        /// <param name="redirect"></param>
        /// <returns>Login response object</returns>
        public LoginResponse UserAuthenticateUser(DataTable dtUserInfo, out RedirectType redirect)
        {
            try
            {
                LoginResponse loginResponse = new LoginResponse();
                List<Agreement> agreements = new List<Agreement>();
                User user = new User();
                bool isKYCRequired = false;
                if (dtUserInfo.Rows.Count > 0)
                {

                    string userCountry = dtUserInfo.Rows[0]["User_Country"].ToString();

                    DataTable dtUserCountry = CountryBasedGetCountryDetails(int.Parse(userCountry), (int)Languages.English);
                    if (dtUserCountry.Rows.Count > 0)
                    {
                        KYCModel model = KYCGetRequiredFiles(int.Parse(dtUserInfo.Rows[0]["User_ID"].ToString()), int.Parse(userCountry));

                        if (model.KYCOverAllStatus != (int)KYCUserDocsStatus.Accepted && (int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) == (int)UserType.Investor || int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) == (int)UserType.InvestorAndEnreprenuer))
                            isKYCRequired = true;

                        user.KYCOverAllStatus = model.KYCOverAllStatusText;


                        int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Regulators_Agreements, int.Parse(userCountry));

                        if (groupId > 0 && !Convert.ToBoolean(dtUserInfo.Rows[0]["User_IsAgreedToRegulatorAgreement"]) && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.Admin && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.SystemAdmin && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.BIAdmin)
                        {
                            DataTable dtGroupData = _countryBasedControl.CountryBasedGetGroupData(groupId);
                            if (dtGroupData.Rows.Count > 0)
                            {
                                Agreement registrationRegulatorsAgreement = _agreement.AgreementGetRegistrationRegulatorsAgreement(int.Parse(userCountry), int.Parse(dtUserInfo.Rows[0]["User_LanguageID"].ToString()));
                                if (registrationRegulatorsAgreement != null)
                                    agreements.Add(registrationRegulatorsAgreement);
                            }
                            redirect = RedirectType.RegulatorsAgreement;
                            loginResponse.RedirectType = (int)RedirectType.RegulatorsAgreement;
                            loginResponse.IsAuthenticate = false;
                            loginResponse.ShowPopup = true;
                            loginResponse.Message = _stringLocalizer["LoginSuccess"].Value;
                        }
                        else
                        {
                            string userStatus = dtUserInfo.Rows[0]["User_Status"].ToString();

                            if (int.Parse(userStatus) == (int)UserStatus.Active)
                            {

                                if (int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) == (int)UserType.Admin || int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) == (int)UserType.SystemAdmin || int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) == (int)UserType.BIAdmin)
                                {
                                    redirect = RedirectType.AdminDashboard;
                                    loginResponse.IsAuthenticate = true;
                                    user = loginUser(dtUserInfo, isKYCRequired, model.KYCOverAllStatusText);
                                    loginResponse.Message = _stringLocalizer["LoginSuccess"].Value;
                                    loginResponse.UserModel = user;
                                    return loginResponse;

                                }
                                else
                                {
                                    if (UserIsCategorizationAllowedForUser(dtUserInfo.Rows[0]) || UserIsSuitabilityTestAllowedForUser(dtUserInfo.Rows[0]) > 0)
                                    {
                                        redirect = RedirectType.Questionnaire;
                                        string lastTab = UserGetLastTabsByDataTable(dtUserInfo);
                                        if (lastTab != null && lastTab == "0")
                                            loginResponse.RedirectType = (int)RedirectType.Questionnaire;
                                        else if (lastTab != null && lastTab == "2")
                                        {
                                            redirect = RedirectType.SuitablityTest;
                                            loginResponse.RedirectType = (int)RedirectType.SuitablityTest;
                                        }
                                        user = loginUser(dtUserInfo, isKYCRequired, model.KYCOverAllStatusText);
                                        loginResponse.UserModel = user;
                                        loginResponse.IsAuthenticate = false;
                                        loginResponse.Message = _stringLocalizer["LoginSuccess"].Value;
                                        return loginResponse;

                                    }
                                    else
                                    {
                                        DataTable dtAlert = _alert.AlertCheckAlertOnLogin(int.Parse(dtUserInfo.Rows[0]["User_ID"].ToString()));
                                        if (dtAlert.Rows.Count > 0)
                                        {
                                            DataTable DtAlert_Get_in_ToShow = _alert.AlertGetAllShowInLogin();
                                            if (DtAlert_Get_in_ToShow.Rows.Count > 0)
                                            {
                                                if (DtAlert_Get_in_ToShow.Rows[0]["Alert_Show_Type"].ToString() == "1")
                                                {
                                                    redirect = RedirectType.Alert_page;
                                                    loginResponse.RedirectType = (int)RedirectType.Alert_page;
                                                    loginResponse.IsAuthenticate = false;
                                                    user = loginUser(dtUserInfo, isKYCRequired, model.KYCOverAllStatusText);
                                                    loginResponse.UserModel = user;
                                                    loginResponse.Message = _stringLocalizer["LoginSuccess"].Value;
                                                    return loginResponse;

                                                }
                                                else if (DtAlert_Get_in_ToShow.Rows[0]["Alert_Show_Type"].ToString() == "2")
                                                {
                                                    redirect = RedirectType.Alert_PopUp;
                                                    loginResponse.RedirectType = (int)RedirectType.Alert_PopUp;
                                                    loginResponse.IsAuthenticate = false;
                                                    user = loginUser(dtUserInfo, isKYCRequired, model.KYCOverAllStatusText);
                                                    loginResponse.UserModel = user;
                                                    loginResponse.Message = _stringLocalizer["LoginSuccess"].Value;
                                                    return loginResponse;

                                                }
                                            }
                                        }
                                        else
                                        {
                                            RedirectType red;
                                            user = loginUser(dtUserInfo, isKYCRequired, model.KYCOverAllStatusText);
                                            DataTable dtSurvey = _survey.SurveyCheckSurveysOnLogin(int.Parse(user.Id));
                                            if (dtSurvey.Rows.Count > 0)
                                            {
                                                redirect = RedirectType.Survey;
                                                loginResponse.RedirectType = (int)RedirectType.Survey;
                                            }

                                            loginResponse.IsAuthenticate = true;
                                            loginResponse.UserModel = user;
                                            loginResponse.Message = _stringLocalizer["LoginSuccess"].Value;
                                            redirect = RedirectType.UserDashboard;
                                            loginResponse.RedirectType = (int)RedirectType.UserDashboard;
                                            return loginResponse;

                                        }
                                    }
                                }
                            }
                            else if (int.Parse(userStatus) == (int)UserStatus.NotQualified || int.Parse(userStatus) == (int)UserStatus.New)
                            {
                                redirect = RedirectType.Questionnaire; //go to the validation popup to change the user from not verified to new and the taked to final page
                                loginResponse.RedirectType = (int)RedirectType.Questionnaire;
                                string lastTab = UserGetLastTabsByDataTable(dtUserInfo);
                                if (lastTab != null && lastTab == "0")
                                    loginResponse.RedirectType = (int)RedirectType.Questionnaire;
                                else if (lastTab != null && lastTab == "2")
                                {
                                    redirect = RedirectType.SuitablityTest;
                                    loginResponse.RedirectType = (int)RedirectType.SuitablityTest;
                                }
                                user = loginUser(dtUserInfo, isKYCRequired, model.KYCOverAllStatusText);

                                loginResponse.UserModel = user;
                                loginResponse.IsAuthenticate = false;
                                loginResponse.Message = _stringLocalizer["LoginSuccess"].Value;

                                return loginResponse;

                            }
                            else
                            {
                                redirect = RedirectType.InActiveUser;
                                loginResponse.RedirectType = (int)RedirectType.InActiveUser;
                                loginResponse.IsAuthenticate = false;
                                user = loginUser(dtUserInfo, isKYCRequired, model.KYCOverAllStatusText);
                                loginResponse.UserModel = user;
                                loginResponse.Message = _stringLocalizer["LoginSuccess"].Value;
                                return loginResponse;

                            }
                        }
                    }
                }
                redirect = RedirectType.InvalidAuthentication;
                loginResponse.RedirectType = (int)RedirectType.InvalidAuthentication;
                loginResponse.IsAuthenticate = false;
                loginResponse.Message = _stringLocalizer["InvalidUsernameOrPassword"].Value;
                return loginResponse;

            }
            catch (Exception ex)
            {
                LoginResponse loginResponse = new LoginResponse();
                if (dtUserInfo.Rows.Count > 0)
                {
                    _errHandler.WriteError("Failed User Authentication:\n" + ex.Message + "\n" + ex.StackTrace + "\n" + "EUREECA_USER_ID: " + dtUserInfo.Rows[0]["User_ID"].ToString());
                }
                else
                {
                    _errHandler.WriteError("Failed User Authentication:\n" + ex.Message + "\n" + ex.StackTrace);
                }
                redirect = RedirectType.InvalidAuthentication;
                loginResponse.RedirectType = (int)RedirectType.InvalidAuthentication;
                loginResponse.IsAuthenticate = false;
                loginResponse.Message = _stringLocalizer["InvalidUsernameOrPassword"].Value;
                return loginResponse;


            }
        }

        public User loginUser(DataTable dtUserInfo, bool isKYCRequired, string KYCOverAllStatus)
        {
            User user = new User();

            user.Id = dtUserInfo.Rows[0]["User_ID"].ToString();
            user.Username = dtUserInfo.Rows[0]["User_Username"].ToString();
            user.Email = dtUserInfo.Rows[0]["User_Email"].ToString();
            user.FirstName = dtUserInfo.Rows[0]["Profile_FirstName"].ToString();
            user.LastName = dtUserInfo.Rows[0]["Profile_LastName"].ToString();
            user.Phone = dtUserInfo.Rows[0]["User_Phone"].ToString();
            user.Guid = dtUserInfo.Rows[0]["User_guid"].ToString();
            user.CountryId = int.Parse(dtUserInfo.Rows[0]["User_Country"].ToString());
            DataTable dtUserObjects = UserGetUserEnrollments(long.Parse(user.Id), (int)ObjectsGroups.Badges);

            if (dtUserObjects.Rows.Count > 0)
            {
                user.BadgeName = dtUserObjects.Rows[0]["Master_ObjectTitle"].ToString();
            }

            user.LanguageId = int.Parse(dtUserInfo.Rows[0]["User_LanguageID"].ToString());
            user.CurrencyId = int.Parse(dtUserInfo.Rows[0]["User_preferred_currency"].ToString());
            user.IsPartner = bool.Parse(dtUserInfo.Rows[0]["Is_Partner"].ToString());
            user.Type = int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString());
            user.IsKYCRequired = isKYCRequired;
            user.KYCOverAllStatus = KYCOverAllStatus;
            UserUpdateLastLoginDate(long.Parse(user.Id));
            return user;
        }
        /// <summary>
        /// This method is used to update the last login date
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>int value</returns>
        /// <exception cref="Exception"></exception>
        public int UserUpdateLastLoginDate(long userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                return _sqlHelper.ExecuteNonQuery(_connectionString, "User_UpdateLastLoginDate", paramUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message);

            }
        }
        /// <summary>
        /// This function returned the list of objects for the user
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="groupId"></param>
        /// <returns>Datatable of information</returns>
        /// <exception cref="Exception"></exception>
        public DataTable UserGetUserEnrollments(long userId, int groupId)
        {
            try
            {
                SqlParameter paramDetailsUserId = new SqlParameter("@Details_UserID", userId);
                SqlParameter paramMasterGroupID = new SqlParameter("@Master_GroupID", groupId);
                return _sqlHelper.GetDataTable(_connectionString, "ObjectDetails_GetUserEnrollments", paramDetailsUserId, paramMasterGroupID);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message);

            }
        }

        public DataTable UserGetInvestorsList(string listInvestorShowFilter, string filterCountryId, int countryId, int badgeId, string investorName, int langId, int lFirstRec, int lLastRec)
        {
            try
            {
                SqlParameter paramListInvestorShowFilter = new SqlParameter("@Show", listInvestorShowFilter);
                SqlParameter paramFilterCountryId = new SqlParameter("@Sort", filterCountryId);
                SqlParameter paramCountryId = new SqlParameter("@CountryID", countryId);
                SqlParameter paramBadgeId = new SqlParameter("@BadgeID", badgeId);
                SqlParameter paramInvestorName = new SqlParameter();
                if (!string.IsNullOrEmpty(investorName))
                {
                    paramInvestorName = new SqlParameter("@InvestorName", "%" + investorName + "%");
                }
                else
                {
                    paramInvestorName = new SqlParameter("@InvestorName", null);
                }
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramLFirstRec = new SqlParameter("@lFirstRec", lFirstRec);
                SqlParameter paramLLastRec = new SqlParameter("@lLastRec", lLastRec);
                DataTable dtInvestors = _sqlHelper.GetDataTable(_connectionString, "User_GetInvestorList", paramListInvestorShowFilter, paramFilterCountryId, paramCountryId, paramBadgeId, paramInvestorName, paramLangId, paramLFirstRec, paramLLastRec);
                return dtInvestors;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        public DataTable UserGetInvestorsListOffest(string listInvestorShowFilter, string sortFilterId, int countryId, int badgeId, string investorName, int langId, int lFirstRec, int lLastRec, out int recordCount)
        {
            try
            {
                SqlParameter paramListInvestorShowFilter = new SqlParameter("@Show", listInvestorShowFilter);
                SqlParameter paramSortFilterId = new SqlParameter("@Sort", sortFilterId);
                SqlParameter paramCountryId = new SqlParameter("@CountryID", countryId);
                SqlParameter paramBadgeId = new SqlParameter("@BadgeID", badgeId);
                SqlParameter paramInvestorName = new SqlParameter();
                if (!string.IsNullOrEmpty(investorName))
                {
                    paramInvestorName = new SqlParameter("@InvestorName", "%" + investorName + "%");
                }
                else
                {
                    paramInvestorName = new SqlParameter("@InvestorName", null);
                }
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramLFirstRec = new SqlParameter("@PageNo", lFirstRec);
                SqlParameter paramLLastRec = new SqlParameter("@PageSize", lLastRec);
                SqlParameter paramRecordCount = new SqlParameter("@RecordCount", SqlDbType.Int, 4);
                paramRecordCount.Direction = ParameterDirection.Output;

                //DataTable dtInvestors = _sqlHelper.GetDataTable(_connectionString, "User_GetInvestorListOffest", paramListInvestorShowFilter, paramFilterCountryId, paramCountryId, paramBadgeId, paramInvestorName, paramLangId, paramLFirstRec, paramLLastRec);
                DataTable dtInvestors = _sqlHelper.GetDataTable(_connectionString, "User_GetInvestorListOffest", paramListInvestorShowFilter, paramSortFilterId, paramCountryId, paramBadgeId, paramInvestorName, paramLangId, paramLFirstRec, paramLLastRec, paramRecordCount);
                recordCount = int.Parse(paramRecordCount.Value.ToString());
                return dtInvestors;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        public DataTable UserGetEntrepreneursList(string listEntrepreneurShowFilter, int filterCountryId, int langId, int lFirstRec, int lLastRec)
        {
            try
            {
                SqlParameter paramListEntrepreneurShowFilter = new SqlParameter("@Show", listEntrepreneurShowFilter);
                SqlParameter paramFilterCountryId = new SqlParameter("@Sort", filterCountryId);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramLFirstRec = new SqlParameter("@lFirstRec", lFirstRec);
                SqlParameter paramLLastRec = new SqlParameter("@lLastRec", lLastRec);

                DataTable dtEntrepreneurs = _sqlHelper.GetDataTable(_connectionString, "User_GetEntrepreneurList", paramListEntrepreneurShowFilter, paramFilterCountryId, paramLangId, paramLFirstRec, paramLLastRec);
                return dtEntrepreneurs;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public DataTable UserGetEntrepreneursListOffest(string listEntrepreneurShowFilter, string filterCountryId, int langId, int lFirstRec, int lLastRec, out int recordCount)
        {
            try
            {
                SqlParameter paramListEntrepreneurShowFilter = new SqlParameter("@Show", listEntrepreneurShowFilter);
                SqlParameter paramFilterCountryId = new SqlParameter("@Sort", filterCountryId);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramLFirstRec = new SqlParameter("@PageNo", lFirstRec);
                SqlParameter paramLLastRec = new SqlParameter("@PageSize", lLastRec);
                SqlParameter paramRecordCount = new SqlParameter("@RecordCount", SqlDbType.Int, 4);
                paramRecordCount.Direction = ParameterDirection.Output;

                DataTable dtEntrepreneurs = _sqlHelper.GetDataTable(_connectionString, "User_GetEntrepreneurListOffestPaging", paramListEntrepreneurShowFilter, paramFilterCountryId, paramLangId, paramLFirstRec, paramLLastRec, paramRecordCount);
                recordCount = int.Parse(paramRecordCount.Value.ToString());
                return dtEntrepreneurs;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public DataTable UserGetRecentlyInvested(int userId, int langId, int currencyId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_Id", userId);
                SqlParameter paramLangId = new SqlParameter("@Language", langId);
                SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", currencyId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetRecentlyInvestedForUser", paramUserId, paramLangId, paramCurrencyId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        public DataTable UserGetRecentlyFollowed(int userConnectionSourceUserId, int langId)
        {
            try
            {
                SqlParameter paramUserConnectionSourceUserId = new SqlParameter("@UserConnection_SourceUserID", userConnectionSourceUserId);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetRecentlyFollowedForUser", paramUserConnectionSourceUserId, paramLangId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to give request statue
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="pitchId"></param>
        /// <param name="requestType"></param>
        /// <returns>RequestAccessStatus enum value</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public RequestAccessStatus UserGetRequestStatus(int userId, int pitchId, int requestType)
        {

            try
            {
                DataTable dtUserRequst = UserGetRequest(requestType, userId, pitchId);
                return UserGetRequestStatus(dtUserRequst);

            }

            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get user request details by type
        /// </summary>
        /// <param name="requestType"></param>
        /// <param name="userId"></param>
        /// <param name="requestPitchId"></param>
        /// <returns></returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable UserGetRequest(int requestType, int userId, int requestPitchId)
        {
            try
            {
                SqlParameter param_Request_Type = new SqlParameter("@Request_Type", requestType);
                SqlParameter param_User_ID = new SqlParameter("@User_ID", userId);
                SqlParameter param_Request_PitchID = new SqlParameter("@Request_PitchID", requestPitchId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetUserRequest", param_Request_Type, param_User_ID, param_Request_PitchID);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to update user investor classification
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="investorClassification"></param>
        public int UserUpdateInvestorCategory(int userId, int investorClassification)
        {
            SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
            SqlParameter paramInvestorClassification = new SqlParameter("@User_InvestorClassification", investorClassification);
            return _sqlHelper.ExecuteNonQuery(_connectionString, "User_UpdateInvestorCategory", paramUserId, paramInvestorClassification);
        }

        public UploadKYCResponseModel KYCUploadFile(int userId, int countryId, int docType, string docName, IFormFile file)
        {
            int res = -1;
            int overallStatus = (int)KYCUserDocsStatus.NotUploaded;
            UploadKYCResponseModel response = new UploadKYCResponseModel();

            if (file != null)
            {
                if (userId != 0)
                {
                    DataTable dtUserInfo = new DataTable();

                    if (userId != 0)
                    {
                        dtUserInfo = UserSelectById(userId);
                    }

                    if (dtUserInfo.Rows.Count > 0)
                    {
                        userId = int.Parse(dtUserInfo.Rows[0]["User_ID"].ToString());
                        response.User = dtUserInfo.Rows[0];
                        try
                        {
                            string userCountry = dtUserInfo.Rows[0]["User_Country"].ToString();
                            if (string.IsNullOrEmpty(userCountry))
                                userCountry = countryId.ToString();

                            DataTable dtUserCountry = _countryBasedControl.CountryBasedGetCountryDetails(int.Parse(userCountry), (int)Languages.English);
                            if (dtUserCountry.Rows.Count > 0)
                            {
                                int[] array = new int[19];
                                array = _kyc.KYCGetRequiredDocs(int.Parse(dtUserInfo.Rows[0]["User_ID"].ToString()), int.Parse(dtUserCountry.Rows[0]["Country_KYC_Tire"].ToString()));

                                int x = array[5];
                                string extension = Path.GetExtension(file.FileName).ToLower();
                                string FileName = Guid.NewGuid().ToString() + extension;
                                string path = Path.Combine(_configuration.GetValue<string>("AttachmentPath") + "KYC/" + Tools.FilterHTML(FileName));

                                if (extension != ".pdf" && extension != ".doc" && extension != ".docx" && extension != ".xslx" && extension != ".xls" && extension != ".png" && extension != ".jpg" && extension != ".jpeg")
                                    res = (int)ResponseStatus.NotSupportedFileExtension;
                                else
                                {
                                    FileInfo File = new FileInfo(path);
                                    if (!File.Exists)
                                    {
                                        string personalPhoto = "";
                                        string uploadedDoc = "";
                                        int personalPhotoStatus = (int)KYCUserDocsStatus.NotUploaded;
                                        string passport = "";
                                        string passportName = "";
                                        int passportStatus = (int)KYCUserDocsStatus.NotUploaded;
                                        string Passport_Expire = "";
                                        string utility = "";
                                        int utilityStatus = (int)KYCUserDocsStatus.NotUploaded;
                                        string paymentConfirmation = "";
                                        int paymentConfirmationStatus = (int)KYCUserDocsStatus.NotUploaded;
                                        string proofOfAddress = "";
                                        string proofOfAddressAddress = "";
                                        int proofOfAddressStatus = (int)KYCUserDocsStatus.NotUploaded;
                                        string proofOfAddressExpire = "";
                                        string sourceOfWealth = "";
                                        int sourceOfWealthStatus = (int)KYCUserDocsStatus.NotUploaded;
                                        string certefiedCopies = "";
                                        int certefiedCopiesStatus = (int)KYCUserDocsStatus.NotUploaded;
                                        string personalPhotoUploadingDate = "";
                                        string passportUploadingDate = "";
                                        string utilityUploadingDate = "";
                                        string paymentConfirmationUploadingDate = "";
                                        string proofOfAddressUploadingDate = "";
                                        string sourceOfWealthUploadingDate = "";
                                        string certefiedCopiesUploadingDate = "";
                                        string PEPDoc = "";
                                        int PEPStatus = (int)KYCUserDocsStatus.NotUploaded;
                                        string PEPUploadingDate = "";

                                        bool CanUpload = true;


                                        DataTable dtUserDocs = _kyc.KYCGetUserDocs(userId);
                                        if (dtUserDocs.Rows.Count > 0)
                                        {
                                            personalPhotoUploadingDate = dtUserDocs.Rows[0]["Personal_Photo_UploadingDate"].ToString();
                                            passportUploadingDate = dtUserDocs.Rows[0]["Passport_UploadingDate"].ToString();
                                            utilityUploadingDate = dtUserDocs.Rows[0]["Utility_UploadingDate"].ToString();
                                            paymentConfirmationUploadingDate = dtUserDocs.Rows[0]["Payment_Confirmation_UploadingDate"].ToString();
                                            proofOfAddressUploadingDate = dtUserDocs.Rows[0]["Proof_of_address_UploadingDate"].ToString();
                                            sourceOfWealthUploadingDate = dtUserDocs.Rows[0]["Source_of_wealth_UploadingDate"].ToString();
                                            certefiedCopiesUploadingDate = dtUserDocs.Rows[0]["Certefied_copies_UploadingDate"].ToString();
                                            PEPUploadingDate = dtUserDocs.Rows[0]["PEP_UploadingDate"].ToString();
                                        }

                                        if (docType == (int)KYCDocType.PersonalPhote && (array[3] == (int)KYCUserDocsStatus.NotUploaded || array[3] == (int)KYCUserDocsStatus.NotAccepted || array[3] == (int)KYCUserDocsStatus.Expired))
                                        {
                                            personalPhotoUploadingDate = DateTime.Now.ToString();
                                            personalPhotoStatus = (int)KYCUserDocsStatus.PendingApproval;
                                            passportStatus = array[5];
                                            utilityStatus = array[7];
                                            paymentConfirmationStatus = array[9];
                                            proofOfAddressStatus = array[11];
                                            sourceOfWealthStatus = array[13];
                                            certefiedCopiesStatus = array[15];
                                            PEPStatus = array[17];

                                            personalPhoto = FileName;

                                            if (dtUserDocs.Rows.Count > 0)
                                            {

                                                uploadedDoc = dtUserDocs.Rows[0]["Personal_Photo"].ToString();
                                                passport = dtUserDocs.Rows[0]["Passport"].ToString();
                                                passportName = dtUserDocs.Rows[0]["Passport_Name"].ToString();
                                                proofOfAddress = dtUserDocs.Rows[0]["Proof_of_address"].ToString();
                                                proofOfAddressAddress = dtUserDocs.Rows[0]["Proof_of_address_Address"].ToString();
                                                sourceOfWealth = dtUserDocs.Rows[0]["Source_of_wealth"].ToString();
                                                certefiedCopies = dtUserDocs.Rows[0]["Certefied_copies"].ToString();
                                                paymentConfirmation = dtUserDocs.Rows[0]["Payment_Confirmation"].ToString();
                                                utility = dtUserDocs.Rows[0]["Utility"].ToString();
                                                PEPDoc = dtUserDocs.Rows[0]["PEP_Doc"].ToString();
                                            }
                                        }
                                        else if (docType == (int)KYCDocType.Passport && (array[5] == (int)KYCUserDocsStatus.NotUploaded || array[5] == (int)KYCUserDocsStatus.NotAccepted || array[5] == (int)KYCUserDocsStatus.Expired))
                                        {
                                            passportUploadingDate = DateTime.Now.ToString();
                                            personalPhotoStatus = array[3];
                                            passportStatus = (int)KYCUserDocsStatus.PendingApproval;
                                            utilityStatus = array[7];
                                            paymentConfirmationStatus = array[9];
                                            proofOfAddressStatus = array[11];
                                            sourceOfWealthStatus = array[13];
                                            certefiedCopiesStatus = array[15];
                                            PEPStatus = array[17];

                                            passport = FileName;
                                            passportName = docName;
                                            if (string.IsNullOrEmpty(docName))
                                            {
                                                response.ResponseStatus = (int)ResponseStatus.EmptyPassportDocName;
                                                return response;
                                            }

                                            if (dtUserDocs.Rows.Count > 0)
                                            {
                                                personalPhoto = dtUserDocs.Rows[0]["Personal_Photo"].ToString();
                                                uploadedDoc = dtUserDocs.Rows[0]["Passport"].ToString();
                                                proofOfAddress = dtUserDocs.Rows[0]["Proof_of_address"].ToString();
                                                proofOfAddressAddress = dtUserDocs.Rows[0]["Proof_of_address_Address"].ToString();
                                                sourceOfWealth = dtUserDocs.Rows[0]["Source_of_wealth"].ToString();
                                                certefiedCopies = dtUserDocs.Rows[0]["Certefied_copies"].ToString();
                                                paymentConfirmation = dtUserDocs.Rows[0]["Payment_Confirmation"].ToString();
                                                utility = dtUserDocs.Rows[0]["Utility"].ToString();
                                                PEPDoc = dtUserDocs.Rows[0]["PEP_Doc"].ToString();
                                            }
                                        }
                                        else if (docType == (int)KYCDocType.ProofOfAddress && (array[11] == (int)KYCUserDocsStatus.NotUploaded || array[11] == (int)KYCUserDocsStatus.NotAccepted || array[11] == (int)KYCUserDocsStatus.Expired))
                                        {
                                            proofOfAddressUploadingDate = DateTime.Now.ToString();
                                            personalPhotoStatus = array[3];
                                            passportStatus = array[5];
                                            utilityStatus = array[7];
                                            paymentConfirmationStatus = array[9];
                                            proofOfAddressStatus = (int)KYCUserDocsStatus.PendingApproval;
                                            sourceOfWealthStatus = array[13];
                                            certefiedCopiesStatus = array[15];
                                            PEPStatus = array[17];

                                            proofOfAddress = FileName;
                                            proofOfAddressAddress = docName;
                                            if (string.IsNullOrEmpty(docName))
                                            {
                                                response.ResponseStatus = (int)ResponseStatus.EmptyPOADocName;
                                                return response;
                                            }

                                            if (dtUserDocs.Rows.Count > 0)
                                            {
                                                personalPhoto = dtUserDocs.Rows[0]["Personal_Photo"].ToString();
                                                passport = dtUserDocs.Rows[0]["Passport"].ToString();
                                                passportName = dtUserDocs.Rows[0]["Passport_Name"].ToString();
                                                uploadedDoc = dtUserDocs.Rows[0]["Proof_of_address"].ToString();
                                                sourceOfWealth = dtUserDocs.Rows[0]["Source_of_wealth"].ToString();
                                                certefiedCopies = dtUserDocs.Rows[0]["Certefied_copies"].ToString();
                                                paymentConfirmation = dtUserDocs.Rows[0]["Payment_Confirmation"].ToString();
                                                utility = dtUserDocs.Rows[0]["Utility"].ToString();
                                                PEPDoc = dtUserDocs.Rows[0]["PEP_Doc"].ToString();
                                            }
                                        }
                                        else if (docType == (int)KYCDocType.SourceOfWealth && (array[13] == (int)KYCUserDocsStatus.NotUploaded || array[13] == (int)KYCUserDocsStatus.NotAccepted || array[13] == (int)KYCUserDocsStatus.Expired))
                                        {
                                            sourceOfWealthUploadingDate = DateTime.Now.ToString();
                                            personalPhotoStatus = array[3];
                                            passportStatus = array[5];
                                            utilityStatus = array[7];
                                            paymentConfirmationStatus = array[9];
                                            proofOfAddressStatus = array[11];
                                            sourceOfWealthStatus = (int)KYCUserDocsStatus.PendingApproval;
                                            certefiedCopiesStatus = array[15];
                                            PEPStatus = array[17];

                                            sourceOfWealth = FileName;

                                            if (dtUserDocs.Rows.Count > 0)
                                            {
                                                personalPhoto = dtUserDocs.Rows[0]["Personal_Photo"].ToString();
                                                passport = dtUserDocs.Rows[0]["Passport"].ToString();
                                                passportName = dtUserDocs.Rows[0]["Passport_Name"].ToString();
                                                proofOfAddress = dtUserDocs.Rows[0]["Proof_of_address"].ToString();
                                                proofOfAddressAddress = dtUserDocs.Rows[0]["Proof_of_address_Address"].ToString();
                                                uploadedDoc = dtUserDocs.Rows[0]["Source_of_wealth"].ToString();
                                                certefiedCopies = dtUserDocs.Rows[0]["Certefied_copies"].ToString();
                                                paymentConfirmation = dtUserDocs.Rows[0]["Payment_Confirmation"].ToString();
                                                utility = dtUserDocs.Rows[0]["Utility"].ToString();
                                                PEPDoc = dtUserDocs.Rows[0]["PEP_Doc"].ToString();
                                            }
                                        }
                                        else if (docType == (int)KYCDocType.CertificatedCopies && (array[15] == (int)KYCUserDocsStatus.NotUploaded || array[15] == (int)KYCUserDocsStatus.NotAccepted || array[15] == (int)KYCUserDocsStatus.Expired))
                                        {
                                            certefiedCopiesUploadingDate = DateTime.Now.ToString();
                                            personalPhotoStatus = array[3];
                                            passportStatus = array[5];
                                            utilityStatus = array[7];
                                            paymentConfirmationStatus = array[9];
                                            proofOfAddressStatus = array[11];
                                            sourceOfWealthStatus = array[13];
                                            certefiedCopiesStatus = (int)KYCUserDocsStatus.PendingApproval;
                                            PEPStatus = array[17];

                                            certefiedCopies = FileName;

                                            if (dtUserDocs.Rows.Count > 0)
                                            {
                                                personalPhoto = dtUserDocs.Rows[0]["Personal_Photo"].ToString();
                                                passport = dtUserDocs.Rows[0]["Passport"].ToString();
                                                passportName = dtUserDocs.Rows[0]["Passport_Name"].ToString();
                                                proofOfAddress = dtUserDocs.Rows[0]["Proof_of_address"].ToString();
                                                proofOfAddressAddress = dtUserDocs.Rows[0]["Proof_of_address_Address"].ToString();
                                                sourceOfWealth = dtUserDocs.Rows[0]["Source_of_wealth"].ToString();
                                                uploadedDoc = dtUserDocs.Rows[0]["Certefied_copies"].ToString();
                                                paymentConfirmation = dtUserDocs.Rows[0]["Payment_Confirmation"].ToString();
                                                utility = dtUserDocs.Rows[0]["Utility"].ToString();
                                                PEPDoc = dtUserDocs.Rows[0]["PEP_Doc"].ToString();
                                            }
                                        }
                                        else if (docType == (int)KYCDocType.PEPDoc && (array[17] == (int)KYCUserDocsStatus.NotUploaded || array[17] == (int)KYCUserDocsStatus.NotAccepted || array[17] == (int)KYCUserDocsStatus.Expired))
                                        {
                                            PEPUploadingDate = DateTime.Now.ToString();
                                            personalPhotoStatus = array[3];
                                            passportStatus = array[5];
                                            utilityStatus = array[7];
                                            paymentConfirmationStatus = array[9];
                                            proofOfAddressStatus = array[11];
                                            sourceOfWealthStatus = array[13];
                                            certefiedCopiesStatus = array[15];
                                            PEPStatus = (int)KYCUserDocsStatus.PendingApproval;

                                            PEPDoc = FileName;

                                            if (dtUserDocs.Rows.Count > 0)
                                            {
                                                personalPhoto = dtUserDocs.Rows[0]["Personal_Photo"].ToString();
                                                passport = dtUserDocs.Rows[0]["Passport"].ToString();
                                                passportName = dtUserDocs.Rows[0]["Passport_Name"].ToString();
                                                proofOfAddress = dtUserDocs.Rows[0]["Proof_of_address"].ToString();
                                                proofOfAddressAddress = dtUserDocs.Rows[0]["Proof_of_address_Address"].ToString();
                                                sourceOfWealth = dtUserDocs.Rows[0]["Source_of_wealth"].ToString();
                                                certefiedCopies = dtUserDocs.Rows[0]["Certefied_copies"].ToString();
                                                uploadedDoc = dtUserDocs.Rows[0]["PEP_Doc"].ToString();
                                                paymentConfirmation = dtUserDocs.Rows[0]["Payment_Confirmation"].ToString();
                                                utility = dtUserDocs.Rows[0]["Utility"].ToString();
                                            }
                                        }
                                        else if (docType == (int)KYCDocType.Utility && (array[7] == (int)KYCUserDocsStatus.NotUploaded || array[7] == (int)KYCUserDocsStatus.NotAccepted || array[7] == (int)KYCUserDocsStatus.Expired))
                                        {
                                            utilityUploadingDate = DateTime.Now.ToString();
                                            personalPhotoStatus = array[3];
                                            passportStatus = array[5];
                                            utilityStatus = (int)KYCUserDocsStatus.PendingApproval;
                                            paymentConfirmationStatus = array[9];
                                            proofOfAddressStatus = array[11];
                                            sourceOfWealthStatus = array[13];
                                            certefiedCopiesStatus = array[15];
                                            PEPStatus = array[17];

                                            utility = FileName;

                                            if (dtUserDocs.Rows.Count > 0)
                                            {
                                                personalPhoto = dtUserDocs.Rows[0]["Personal_Photo"].ToString();
                                                passport = dtUserDocs.Rows[0]["Passport"].ToString();
                                                passportName = dtUserDocs.Rows[0]["Passport_Name"].ToString();
                                                proofOfAddress = dtUserDocs.Rows[0]["Proof_of_address"].ToString();
                                                proofOfAddressAddress = dtUserDocs.Rows[0]["Proof_of_address_Address"].ToString();
                                                sourceOfWealth = dtUserDocs.Rows[0]["Source_of_wealth"].ToString();
                                                certefiedCopies = dtUserDocs.Rows[0]["Certefied_copies"].ToString();
                                                paymentConfirmation = dtUserDocs.Rows[0]["Payment_Confirmation"].ToString();
                                                uploadedDoc = dtUserDocs.Rows[0]["Utility"].ToString();
                                                PEPDoc = dtUserDocs.Rows[0]["PEP_Doc"].ToString();
                                            }
                                        }
                                        else if (docType == (int)KYCDocType.PaymentConfirmation && (array[9] == (int)KYCUserDocsStatus.NotUploaded || array[9] == (int)KYCUserDocsStatus.NotAccepted || array[9] == (int)KYCUserDocsStatus.Expired))
                                        {
                                            paymentConfirmationUploadingDate = DateTime.Now.ToString();
                                            personalPhotoStatus = array[3];
                                            passportStatus = array[5];
                                            utilityStatus = array[7];
                                            paymentConfirmationStatus = (int)KYCUserDocsStatus.PendingApproval;
                                            proofOfAddressStatus = array[11];
                                            sourceOfWealthStatus = array[13];
                                            certefiedCopiesStatus = array[15];
                                            PEPStatus = array[17];

                                            paymentConfirmation = FileName;

                                            if (dtUserDocs.Rows.Count > 0)
                                            {
                                                personalPhoto = dtUserDocs.Rows[0]["Personal_Photo"].ToString();
                                                passport = dtUserDocs.Rows[0]["Passport"].ToString();
                                                passportName = dtUserDocs.Rows[0]["Passport_Name"].ToString();
                                                proofOfAddress = dtUserDocs.Rows[0]["Proof_of_address"].ToString();
                                                proofOfAddressAddress = dtUserDocs.Rows[0]["Proof_of_address_Address"].ToString();
                                                sourceOfWealth = dtUserDocs.Rows[0]["Source_of_wealth"].ToString();
                                                certefiedCopies = dtUserDocs.Rows[0]["Certefied_copies"].ToString();
                                                uploadedDoc = dtUserDocs.Rows[0]["Payment_Confirmation"].ToString();
                                                utility = dtUserDocs.Rows[0]["Utility"].ToString();
                                                PEPDoc = dtUserDocs.Rows[0]["PEP_Doc"].ToString();
                                            }
                                        }
                                        else
                                            CanUpload = false;

                                        if (CanUpload) //if the file is not accepted or pending approval
                                        {
                                            bool personalPhotoNeeded = Convert.ToBoolean(array[2]);
                                            bool passportNeeded = Convert.ToBoolean(array[4]);
                                            bool utilityNeeded = Convert.ToBoolean(array[6]);
                                            bool paymentConfirmNeeded = Convert.ToBoolean(array[8]);

                                            bool proofOfAddressNeeded = Convert.ToBoolean(array[10]);
                                            bool sourceOfWealthNeeded = Convert.ToBoolean(array[12]);
                                            bool certefiedCopiesNeeded = Convert.ToBoolean(array[14]);


                                            bool personalPhotoAcceptance = true, passportAcceptance = true, utilityAcceptance = true, paymentAcceptance = true,
                                                proofOfAddressAcceptance = true, sourceOfWealthAcceptance = true, certefiedCopiesAcceptance = true,
                                                personalPhotoPendingAcceptance = true, passportPendingAcceptance = true, utilityPendingAcceptance = true, paymentPendingAcceptance = true,
                                                proofOfAddressPendingAcceptance = true, sourceOfWealthPendingAcceptance = true, certefiedCopiesPendingAcceptance = true;

                                            if (personalPhotoNeeded)
                                            {
                                                personalPhotoAcceptance = personalPhotoStatus == (int)KYCUserDocsStatus.Accepted;
                                                personalPhotoPendingAcceptance = personalPhotoStatus == (int)KYCUserDocsStatus.PendingApproval || personalPhotoStatus == (int)KYCUserDocsStatus.Accepted;
                                            }

                                            if (passportNeeded)
                                            {
                                                passportAcceptance = passportStatus == (int)KYCUserDocsStatus.Accepted;
                                                passportPendingAcceptance = passportStatus == (int)KYCUserDocsStatus.PendingApproval || passportStatus == (int)KYCUserDocsStatus.Accepted;
                                            }

                                            if (utilityNeeded)
                                            {
                                                utilityAcceptance = utilityStatus == (int)KYCUserDocsStatus.Accepted;
                                                utilityPendingAcceptance = utilityStatus == (int)KYCUserDocsStatus.PendingApproval || utilityStatus == (int)KYCUserDocsStatus.Accepted;
                                            }

                                            if (paymentConfirmNeeded)
                                            {
                                                paymentAcceptance = paymentConfirmationStatus == (int)KYCUserDocsStatus.Accepted;
                                                paymentPendingAcceptance = paymentConfirmationStatus == (int)KYCUserDocsStatus.PendingApproval || paymentConfirmationStatus == (int)KYCUserDocsStatus.Accepted;
                                            }
                                            //  New kyc
                                            if (proofOfAddressNeeded)
                                            {
                                                proofOfAddressAcceptance = proofOfAddressStatus == (int)KYCUserDocsStatus.Accepted;
                                                proofOfAddressPendingAcceptance = proofOfAddressStatus == (int)KYCUserDocsStatus.PendingApproval || proofOfAddressStatus == (int)KYCUserDocsStatus.Accepted;
                                            }
                                            if (sourceOfWealthNeeded)
                                            {
                                                sourceOfWealthAcceptance = sourceOfWealthStatus == (int)KYCUserDocsStatus.Accepted;
                                                sourceOfWealthPendingAcceptance = sourceOfWealthStatus == (int)KYCUserDocsStatus.PendingApproval || sourceOfWealthStatus == (int)KYCUserDocsStatus.Accepted;
                                            }
                                            if (certefiedCopiesNeeded)
                                            {
                                                certefiedCopiesAcceptance = certefiedCopiesStatus == (int)KYCUserDocsStatus.Accepted;
                                                certefiedCopiesPendingAcceptance = certefiedCopiesStatus == (int)KYCUserDocsStatus.PendingApproval || certefiedCopiesStatus == (int)KYCUserDocsStatus.Accepted;
                                            }

                                            if (proofOfAddressAcceptance && passportAcceptance && sourceOfWealthAcceptance && certefiedCopiesAcceptance)
                                                overallStatus = (int)KYCUserDocsStatus.Accepted;
                                            else if (proofOfAddressPendingAcceptance && passportPendingAcceptance && sourceOfWealthPendingAcceptance && certefiedCopiesPendingAcceptance)
                                                overallStatus = (int)KYCUserDocsStatus.PendingApproval;

                                            if (uploadedDoc != "" && System.IO.File.Exists(Path.Combine(_configuration.GetValue<string>("AttachmentPath") + "KYC/" + uploadedDoc)))
                                                System.IO.File.Delete(Path.Combine(_configuration.GetValue<string>("AttachmentPath") + "KYC/" + uploadedDoc));

                                            _kyc.KYCManageUserAutomation(userId, overallStatus, personalPhoto, personalPhotoUploadingDate, personalPhotoStatus, "", passport, passportUploadingDate, passportName, passportStatus,
                                                Passport_Expire, "", utility, utilityUploadingDate, utilityStatus, paymentConfirmation, paymentConfirmationUploadingDate, paymentConfirmationStatus, proofOfAddress, proofOfAddressUploadingDate, proofOfAddressAddress, proofOfAddressStatus,
                                                proofOfAddressExpire, "", sourceOfWealth, sourceOfWealthUploadingDate, sourceOfWealthStatus, "", certefiedCopies, certefiedCopiesUploadingDate, certefiedCopiesStatus, "", PEPDoc, PEPStatus, "", PEPUploadingDate);


                                            DataTable dtUserObjects = UserGetUserEnrollments(userId, (int)ObjectsGroups.Badges);

                                            if (dtUserObjects.Rows.Count > 0)
                                            {
                                                response.ObjectTitle = dtUserObjects.Rows[0]["Master_ObjectTitle"].ToString();
                                                response.ImageName = dtUserObjects.Rows[0]["Master_ImageUrlBig"].ToString();

                                            }

                                            //_message.sendKYCUploadedEmailToKYCTeam(user.getSystemAdmin(), dtUserInfo.Rows[0], ObjectTitle, ImageName);

                                            if (overallStatus == (int)KYCUserDocsStatus.PendingApproval)
                                            {
                                                response.AllUploadedDocs = passport + "," + proofOfAddress + "," + sourceOfWealth + "," + certefiedCopies;
                                                //_message.sendKYCUploadedEmailToKYCAdmin(_user.getSystemAdmin(), dtUserInfo.Rows[0], ObjectTitle, allUploadedDocs);
                                            }

                                            res = (int)ResponseStatus.Success;
                                        }
                                        else
                                            res = (int)ResponseStatus.FileAlreadyUploaded;
                                    }
                                    else
                                        res = (int)ResponseStatus.FileAlreadyExists;
                                }
                            }
                            else
                                res = (int)ResponseStatus.EmptyDataTable;
                        }
                        catch (Exception ex)
                        {
                            _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n" + "UserID: " + userId);
                            res = (int)ResponseStatus.CatchError;
                        }
                    }
                }
                else
                {
                    res = (int)ResponseStatus.NullUserId;
                }
            }
            else
                res = (int)ResponseStatus.NullKYCFile;

            response.OverallStatus = overallStatus;
            response.ResponseStatus = res;
            return response;

        }

        /// <summary>
        /// This method is used to update user score
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userScoreAdded"></param>
        public void UserUpdateUserScore(int userId, int userScoreAdded)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramUserScoreAdded = new SqlParameter("@User_ScoreAdded", userScoreAdded);
                _sqlHelper.ExecuteNonQuery(_connectionString, "User_UpdateUserScore", paramUserId, paramUserScoreAdded);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public int AddRequest(int userId, int pitchID, string requestDesc, int requestType)
        {
            try
            {
                requestDesc = Tools.FilterHTML(requestDesc);

                SqlParameter param_User_ID = new SqlParameter("@User_ID", userId);
                SqlParameter param_Request_PitchID = new SqlParameter("@Request_PitchID", pitchID);
                SqlParameter param_Request_Desc = new SqlParameter("@Request_Desc", requestDesc);
                SqlParameter param_Request_Type = new SqlParameter("@Request_Type", requestType);
                return _sqlHelper.ExecuteNonQuery(_connectionString, "User_AddRequest", param_User_ID, param_Request_PitchID, param_Request_Desc, param_Request_Type);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception();
            }
        }

        public SuitabilityTestSubmitAnswerResponse SuitabilityTestSubmitAnswers(int userId, int countryId, List<SuitabilityAnswer> answers, int langId)
        {
            SuitabilityTestSubmitAnswerResponse response = new SuitabilityTestSubmitAnswerResponse();
            if (userId != 0)
            {

                DataTable dtUser = UserSelectById(userId);
                int roundNumber = 0;
                if (dtUser.Rows.Count > 0)
                {
                    roundNumber = int.Parse(dtUser.Rows[0]["User_Attempet_Number"].ToString());
                    string countryCode = CountryBasedGetCountryDetails(countryId, langId).Rows[0]["Country_Code"].ToString();
                    DataTable DTForms = _suitabilityTest.SuitabilityTestGetCurrencyCheckQuestion(Convert.ToInt32(CountryBasedControls.Questionnaire), countryCode);
                    int QCount = _suitabilityTest.SuitabilityTestGetCountQuestionsByForm(Convert.ToInt32(DTForms.Rows[0]["Form_ID"].ToString()));
                    if (answers.Count == QCount)
                    {

                        UserActivationLevel NewActivationLevel = UserActivationLevel.FirstFailure;
                        _suitabilityTest.SuitabilityTestReportDeleteUser(userId);
                        string currentActivation = Convert.IsDBNull(dtUser.Rows[0]["User_ActivationLevel"]) ? "First Time" : dtUser.Rows[0]["User_ActivationLevel"].ToString() == "3" ? "Pass" : "Fail";
                        bool checkAns = false;
                        int correctAnswersCount = 0;
                        foreach (SuitabilityAnswer qAnswer in answers)
                        {

                            DataTable DTH = _suitabilityTest.SuitabilityTestGetQuestion(qAnswer.QuestionId);
                            if (qAnswer.AnswerId == Convert.ToInt32(DTH.Rows[0]["Question_Anwers_Right"].ToString()))
                                correctAnswersCount = correctAnswersCount + 1;
                            response.CurrentActivation = currentActivation;
                            string hdnQ = DTH.Rows[0]["Question_ID"].ToString();
                            string hdnGroupID = DTH.Rows[0]["Group_ID"].ToString();
                            _suitabilityTest.SuitabilityTestQuestionsAddAnswersTest(userId, int.Parse(hdnQ), qAnswer.AnswerId, _suitabilityTest.SuitabilityTestQuestionsCheckForStatue(int.Parse(hdnQ), qAnswer.AnswerId), int.Parse(hdnGroupID), langId);

                        }

                        if (correctAnswersCount == answers.Count)
                            checkAns = true;
                        else
                            checkAns = false;

                        if (checkAns)
                        {
                            NewActivationLevel = UserActivationLevel.Success;
                            UserUpdateActivationLevel(userId, NewActivationLevel);
                        }
                        else
                        {
                            UserUpdateUserStatus(userId, UserStatus.NotQualified);
                            UserUpdateAttempetNumber(int.Parse(dtUser.Rows[0]["user_id"].ToString()));
                            if (roundNumber == 4)
                            {
                                if (!string.IsNullOrEmpty(dtUser.Rows[0]["User_ActivationLevel"].ToString()))
                                {
                                    int CurrentActivationLevel = int.Parse(dtUser.Rows[0]["User_ActivationLevel"].ToString());
                                    if (CurrentActivationLevel == (int)UserActivationLevel.New)
                                        NewActivationLevel = UserActivationLevel.FirstFailure;
                                    else if (CurrentActivationLevel == (int)UserActivationLevel.FirstFailure)
                                        NewActivationLevel = UserActivationLevel.SecondFailure;

                                }
                                else NewActivationLevel = UserActivationLevel.FirstFailure;

                                UserUpdateActivationLevel(userId, NewActivationLevel);
                            }

                        }


                        dtUser = UserSelectById(userId);

                        UserupdateLastUpdateDate(userId);

                        if (UserIsSuitabilityTestAllowedForUser(dtUser.Rows[0]) == 2)
                        {
                            return GetQuestionnairStatusDetails(userId, "fail", langId, countryId);
                        }
                        else
                        {

                            if (UserGetLastTabsByDataTable(dtUser) == "3")
                            {
                                return GetQuestionnairStatusDetails(userId, "success", langId, countryId);
                            }
                            else if (UserGetLastTabsByDataTable(dtUser) == "2")
                            {
                                return GetQuestionnairStatusDetails(userId, "fail", langId, countryId);
                            }
                            else
                            {
                                response.ResponseStatus = ResponseStatus.NotAllowedTab;
                                return response;
                            }
                        }

                    }
                    else
                    {
                        response.ResponseStatus = ResponseStatus.SomeQuestionsNotAnswered;
                        return response;//login.aspx
                    }
                }
                else
                {
                    response.ResponseStatus = ResponseStatus.UserDoesNotExist;
                    return response;
                }

            }
            else
            {
                response.ResponseStatus = ResponseStatus.NullUserId;
                return response;
            }

        }

        public void UserUpdateActivationLevel(int userId, UserActivationLevel userActivationLevel)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramUserActivationLevel = new SqlParameter("@User_ActivationLevel", userActivationLevel);
                _sqlHelper.ExecuteNonQuery(_connectionString, "User_UpdateActivationLevel", paramUserId, paramUserActivationLevel);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }
        public SuitabilityTestSubmitAnswerResponse GetQuestionnairStatusDetails(int userId, string Status, int langId, int countryId)
        {
            try
            {
                SuitabilityTestSubmitAnswerResponse answerResponse = new SuitabilityTestSubmitAnswerResponse();
                DataTable dtUser = UserSelectById(userId);
                int roundNmber = 0;
                int[] array = new int[19];
                bool isKYCRequired = false;
                string KYCOverAllStatus = "";

                roundNmber = int.Parse(dtUser.Rows[0]["User_Attempet_Number"].ToString());
                if (Status == "success")
                {
                    if (!string.IsNullOrEmpty(dtUser.Rows[0]["User_Country"].ToString()))
                        UserUpdateBankCountry(int.Parse(dtUser.Rows[0]["User_ID"].ToString()), int.Parse(dtUser.Rows[0]["User_Country"].ToString()));
                    else if (countryId != -1)
                    {
                        UserUpdateCountry(int.Parse(dtUser.Rows[0]["User_ID"].ToString()), countryId);
                        UserUpdateBankCountry(int.Parse(dtUser.Rows[0]["User_ID"].ToString()), countryId);
                    }

                    UserUpdateUserStatus(int.Parse(dtUser.Rows[0]["User_ID"].ToString()), UserStatus.Active);


                    int userCountry = !string.IsNullOrEmpty(dtUser.Rows[0]["User_Country"].ToString()) ? int.Parse(dtUser.Rows[0]["User_Country"].ToString()) : countryId;


                    DataTable dtUserNew = UserSelectById(userId);
                    KYCModel model = KYCGetRequiredFiles(int.Parse(dtUserNew.Rows[0]["User_ID"].ToString()), userCountry);


                    if (model.KYCOverAllStatus != (int)KYCUserDocsStatus.Accepted && (int.Parse(dtUser.Rows[0]["User_UserFormType"].ToString()) == (int)UserType.Investor || int.Parse(dtUser.Rows[0]["User_UserFormType"].ToString()) == (int)UserType.InvestorAndEnreprenuer))
                        isKYCRequired = true;

                    KYCOverAllStatus = model.KYCOverAllStatusText;




                    answerResponse.ResponseStatus = ResponseStatus.Success;
                    answerResponse.Status = "success";
                }
                else
                {

                    string days = _stringLocalizer["Days"].Value;
                    string day = _stringLocalizer["Day"].Value;
                    string ourregulators = _stringLocalizer["OurRegulators"].Value;
                    string youNotAble = _stringLocalizer["YouNotAble"].Value;
                    string beforeRetaking = _stringLocalizer["BeforeRetaking"].Value;
                    string investor_education_guide = _stringLocalizer["InvestorEducationGuide"].Value;
                    string InCaseYou = _stringLocalizer["InCaseYou"].Value;
                    string YouCanContact = _stringLocalizer["YouCanContact"].Value;
                    string Hours = _stringLocalizer["Hours"].Value;
                    string Hour = _stringLocalizer["Hour"].Value;



                    answerResponse.Status = "fail";
                    answerResponse.ResponseStatus = ResponseStatus.FailedSuitability;


                    if (roundNmber >= 5)
                    {
                        int activationLevel = int.Parse(dtUser.Rows[0]["User_ActivationLevel"].ToString());
                        DateTimeFormatInfo dtfi = new DateTimeFormatInfo();
                        dtfi.ShortDatePattern = "MM/dd/yyyy";
                        dtfi.DateSeparator = "/";
                        DateTime currentDate = Convert.ToDateTime(DateTime.Now.ToString(), dtfi);
                        DateTime activationDate = Convert.ToDateTime(dtUser.Rows[0]["User_ActivationDate"].ToString(), dtfi);
                        int daysFromActivation = (currentDate - activationDate).Days;
                        int PreventedDays = 7;
                        double hoursFromActivation = (currentDate - activationDate).TotalHours;
                        ///////////////////////////////////////////////////////////// 
                        int remainDays = Math.Abs(daysFromActivation - PreventedDays);
                        int remainHours = Math.Abs(24 - Convert.ToInt32(hoursFromActivation));


                        string hdnDays = "7 " + days + "";
                        string totatHoursRemain = "" + day + "";
                        if (remainDays > 1)
                            hdnDays = remainDays + " " + days + "";
                        else if (remainDays == 1)
                            hdnDays = remainDays + " " + day + "";
                        if (hoursFromActivation < 2 && hoursFromActivation >= 1)
                            totatHoursRemain = "" + Hour;
                        else
                            totatHoursRemain = "" + Hours;



                        if (activationLevel == (int)UserActivationLevel.FirstFailure)
                        {
                            if (hoursFromActivation < 24)
                            {

                                answerResponse.BtnTry = false;
                                answerResponse.FailTitle = ourregulators;
                                answerResponse.FailDesc1 = youNotAble + " " + remainHours + " " + totatHoursRemain;
                                answerResponse.FailDesc2 = "" + beforeRetaking + " <strong><a style='color:#231f20' href='" + Tools.UrlGet() + "/Downloads/Eureeca.pdf'>" + investor_education_guide + "</a></strong>";
                            }
                            else
                            {

                                answerResponse.BtnTry = true;
                                answerResponse.FailTitle = InCaseYou;
                                answerResponse.FailDesc1 = YouCanContact;
                                answerResponse.FailDesc2 = beforeRetaking + " <strong><a style='color:#231f20' href='" + Tools.UrlGet() + "/Downloads/Eureeca.pdf'>" + investor_education_guide + "</a></strong>";
                            }
                        }
                        else if (activationLevel == (int)UserActivationLevel.SecondFailure)
                        {
                            if (daysFromActivation < 7)
                            {

                                answerResponse.BtnTry = false;
                                answerResponse.FailTitle = ourregulators;
                                answerResponse.FailDesc1 = "" + youNotAble + " " + hdnDays;
                                answerResponse.FailDesc2 = "" + beforeRetaking + " <strong><a style='color:#231f20' href='" + Tools.UrlGet() + "/Downloads/Eureeca.pdf'>" + investor_education_guide + "</a></strong>";
                            }
                            else
                            {
                                answerResponse.BtnTry = true;
                                answerResponse.FailTitle = InCaseYou;
                                answerResponse.FailDesc1 = YouCanContact;
                                answerResponse.FailDesc2 = "" + beforeRetaking + " <strong><a style='color:#231f20' href='" + Tools.UrlGet() + "/Downloads/Eureeca.pdf'>" + investor_education_guide + "</a></strong>";

                            }
                        }

                    }
                    else
                    {
                        answerResponse.BtnTry = true;
                        answerResponse.FailTitle = InCaseYou;
                        answerResponse.FailDesc1 = YouCanContact;
                        answerResponse.FailDesc2 = beforeRetaking + " <strong><a style='color:#231f20' href='" + Tools.UrlGet() + "/Downloads/Eureeca.pdf'>" + investor_education_guide + "</a></strong>";
                    }
                }


                User user = loginUser(dtUser, isKYCRequired, KYCOverAllStatus);
                answerResponse.User = user;
                return answerResponse;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception();
            }
        }


        /// <summary>
        /// This method is used to update user account information<
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userCountry"></param>
        public void UserUpdateCountry(int userId, int userCountry)
        {
            try
            {
                SqlParameter param_User_ID = new SqlParameter("@User_ID", userId);
                SqlParameter param_User_Country = new SqlParameter("@User_Country", userCountry);
                _sqlHelper.ExecuteNonQuery(_connectionString, "User_UpdateUserCountry", param_User_ID, param_User_Country);
                UserupdateLastUpdateDate(userId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to update user bank details
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userBankCountry"></param>
        public int UserUpdateBankCountry(int userId, int userBankCountry)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramUserBankCountry = new SqlParameter("@User_BankCountry", userBankCountry);
                return _sqlHelper.ExecuteNonQuery(_connectionString, "User_UpdateUserBankCountry", paramUserId, paramUserBankCountry);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This method is used check user status
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        /// <exception cref="Exception">Will write the error in the error log fiel</exception>
        public int UserCheckUserStatus(string userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                return _sqlHelper.ExecuteScalar(_connectionString, "User_CheckUserStatus", paramUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// Get Avaliable payment money for users
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable UserGetBalanceForCurrency(int userId)
        {
            try
            {
                SqlParameter param_User_ID = new SqlParameter("@User_ID", userId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetUser_BalanceForCurrency", param_User_ID);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the proposals that the user follow ordered by either closing date or heat indicator and the data wil return using pagination (method moved from old class)
        /// </summary>
        /// <param name="userId">this is the user ID that we need to get his followed proposals</param>
        /// <param name="userId"></param>
        /// <param name="languageId">this is the language of the proposa title to be returned with</param>
        /// <param name="sortBy">this is order field whic is 1 for closing date and 2 for heat indicator</param>
        /// <param name="pageNo">this is first page number in pagination</param>
        /// <param name="pageSize">this is page size in pagination</param>
        /// <param name="recordCount">this is total records number in pagination</param>
        /// <returns>Data table of the proposals data</returns>
        /// <exception cref="Exception"></exception>
        public DataTable UserGetFollowedPitches(int userId, int languageId, int sortBy, int pageNo, int pageSize, out int recordCount)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@USER_ID", userId);
                SqlParameter paramLanguageId = new SqlParameter("@Pitch_LanguageID", languageId);
                SqlParameter paramSortBy = new SqlParameter("@SortBy", sortBy);
                SqlParameter param_PageNo = new SqlParameter("@PageNo", pageNo);
                SqlParameter param_PageSize = new SqlParameter("@PageSize", pageSize);
                SqlParameter param_RecordCount = new SqlParameter("@RecordCount", SqlDbType.Int, 4);
                param_RecordCount.Direction = ParameterDirection.Output;

                return _sqlHelper.GetDataTable(_connectionString, "User_GetFollowedPitchesPaging", out recordCount, paramUserId, paramLanguageId, paramSortBy, param_PageNo, param_PageSize, param_RecordCount);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get how many minutes between the current time and the proposal's closing time (method moved from old class)
        /// </summary>
        /// <param name="pitchId">this is the pitch ID that we need to get its remaining time</param>
        /// <returns>Data table of the proposals data</returns>
        /// <exception cref="Exception"></exception>
        public DataTable UserGetPitchRemindMints(int pitchId)
        {
            try
            {
                SqlParameter paramPitchId = new SqlParameter("@Pitch_ID", pitchId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetFollowedPitchesRemindMints", paramPitchId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public PendingOffers APIGetSumPendingOffersForUserByCurrency(int offerBuyerId, int offerCurrencyId)
        {
            try
            {
                var postData = "Offer_BuyerID=" + Uri.EscapeDataString(offerBuyerId.ToString());
                postData += "&Offer_CurrencyID=" + Uri.EscapeDataString(offerCurrencyId.ToString());
                var json = JsonConvert.DeserializeObject<PendingOffers>(Tools.CallingAPI(_config, "API_GetSumPendingOffersForUserByCurrency", postData));
                if (json.ResponseCode == "100")
                {
                    return json;
                }
                else
                {
                    _errHandler.WriteError("API Failed : API_GetSumPendingOffersForUserByCurrency " + "\n" + "Response_Code: " + /*json.Response_Code +*/  "\n" + "Response_Msg: " + /*json.Response_Msg +*/ "\n" + "Offer_BuyerID: " + offerBuyerId.ToString() + "\n" + "Offer_CurrencyID: " + offerCurrencyId.ToString());
                    return null;
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError("API Failed : API_GetSumPendingOffersForUserByCurrency" + "\n" + "ex.Message: " + ex.Message + "\n" + "ex.StackTrace: " + ex.StackTrace + "\n" + "Offer_BuyerID: " + offerBuyerId.ToString() + "\n" + "Offer_CurrencyID: " + offerCurrencyId.ToString());
                return null;
            }
        }

        /// <summary>
        /// This method is used to check if the currency allowed to user to invest in
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="currencyId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable UserIsAllowedInvestmentCurrency(int userId, int currencyId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramCurrencyId = new SqlParameter("@Currency_ID", currencyId);
                return _sqlHelper.GetDataTable(_connectionString, "User_isAllowedInvestmentCurrency", paramUserId, paramCurrencyId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summsary>
        /// This method is used to get the user investment currency
        /// </summary>
        /// <param name="langId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public DataTable UserGetAllInvestmentCurrency(int langId, int userId)
        {
            try
            {
                SqlParameter param_LangID = new SqlParameter("@LangID", langId);
                SqlParameter param_User_ID = new SqlParameter("@User_ID", userId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetAllUserInvestmentCurrency", param_LangID, param_User_ID);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the user's investment order by closing date and the data will return using pagination (method moved from old class)
        /// </summary>
        /// <param name="userId">this is the user ID that we need to get his inevstments</param>
        /// <param name="languageId">this is the language of the proposal title to be returned with</param>
        /// <param name="mode">this is either to order by closing date (1) or popularity (0)</param>
        /// <param name="pageNo">this is first page number in pagination</param>
        /// <param name="pageSize">this is page size in pagination</param>
        /// <param name="recordCount">this is total records number in pagination</param>
        /// <returns>Data table of the inevstments data</returns>
        /// <exception cref="Exception"></exception>
        public DataTable UserGetNotRefundedInvestments(int userId, int languageId, int mode, int pageNo, int pageSize, out int recordCount)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@UserID", userId);
                SqlParameter paramPitchLanguageId = new SqlParameter("@Pitch_LanguageID", languageId);
                SqlParameter paramMode = new SqlParameter("@Mode", mode);
                SqlParameter param_PageNo = new SqlParameter("@PageNo", pageNo);
                SqlParameter param_PageSize = new SqlParameter("@PageSize", pageSize);
                SqlParameter param_RecordCount = new SqlParameter("@RecordCount", SqlDbType.Int, 4);
                param_RecordCount.Direction = ParameterDirection.Output;

                return _sqlHelper.GetDataTable(_connectionString, "User_GetNotRefundedInvestmentsPaging", out recordCount, paramUserId, paramPitchLanguageId, paramMode, param_PageNo, param_PageSize, param_RecordCount);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the user request by the request id
        /// </summary>
        /// <param name="requestId"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception">Will log the error in the error log file</exception>
        public DataTable UserGetRequestById(int requestId)
        {
            try
            {
                SqlParameter paramRequestId = new SqlParameter("@requestID", requestId);
                return _sqlHelper.GetDataTable(_connectionString, "GetRequestByID", paramRequestId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to return the request status
        /// </summary>
        /// <param name="requestId"></param>
        /// <returns>the request status</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public RequestAccessStatus UserGetRequestStatusByRequestId(int requestId)
        {
            try
            {
                DataTable dtUserRequst = UserGetRequestById(requestId);
                return UserGetRequestStatus(dtUserRequst);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the request status
        /// </summary>
        /// <param name="dtUserRequst"></param>
        /// <returns>RequestAccessStatus </returns>
        public RequestAccessStatus UserGetRequestStatus(DataTable dtUserRequst)
        {
            if (dtUserRequst.Rows.Count > 0)
            {
                bool flag = bool.Parse(dtUserRequst.Rows[0]["flag"].ToString());
                bool rejectFlag = bool.Parse(dtUserRequst.Rows[0]["Reject_Flag"].ToString());

                if (!flag && !rejectFlag)
                    return RequestAccessStatus.Pending;
                else if (rejectFlag)
                    return RequestAccessStatus.Rejected;
                else if (flag)
                    return RequestAccessStatus.Accepted;
            }
            return RequestAccessStatus.NotRequested;

        }

        /// <summary>
        /// This method is used to update reject flag in user request table to true , when the admin reject user request.
        /// </summary>
        /// <param name="requestId"></param>
        public void UserUpdateRequestRejectFlag(int requestId)
        {
            try
            {
                SqlParameter paramRequestId = new SqlParameter("@RequestID", requestId);
                SqlParameter paramRequestAdminReplyDate = new SqlParameter("@Request_AdminReplyDate", DateTime.Now);
                _sqlHelper.ExecuteNonQuery(_connectionString, "UpdateUserRequestRejectFlag", paramRequestId, paramRequestAdminReplyDate);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to accept the user request - updating the flag column
        /// </summary>
        /// <param name="requestId"></param>
        public void UserUpdateUserRequestFlag(int requestId)
        {
            try
            {
                SqlParameter paramRequestId = new SqlParameter("@requestID", requestId);
                _sqlHelper.ExecuteNonQuery(_connectionString, "UpdateUserRequestFlag", paramRequestId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to the the user proposal request
        /// </summary>
        /// <param name="pitchId"></param>
        /// <param name="langId"></param>
        /// <param name="requestType"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public DataTable UserGetProposalRequests(int pitchId, int langId, int requestType)
        {
            try
            {
                SqlParameter paramPitchId = new SqlParameter("@PitchID", pitchId);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramRequestType = new SqlParameter("@Request_Type", DBNull.Value);
                if (requestType > 0)
                    paramRequestType.Value = requestType;

                return _sqlHelper.GetDataTable(_connectionString, "GetProposalRequests", paramPitchId, paramLangId, paramRequestType);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the user's total followers count (method moved from old class)
        /// </summary>
        /// <param name="userId">this is the user ID that we need to get his contacts count</param>
        /// <returns>Data table of the inevstments data</returns>
        /// <exception cref="Exception"></exception>
        public int UserGetTotalFollowersCount(int userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@UID", userId);
                return _sqlHelper.ExecuteScalar(_connectionString, "User_GetTotalFollowers", paramUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the user's followers using pagination (method moved from old class)
        /// </summary>
        /// <param name="userId">this is the user ID that we need to get his followers</param>
        /// <param name="languageId">this is the language of the returned data</param>
        /// <param name="pageNo">this is the page number for pagination</param>
        /// <param name="pageSize">this is the page size for pagination</param>
        /// <returns>Data table of the user followers data</returns>
        /// <exception cref="Exception"></exception>
        public DataTable UserGetAllFollowersByPage(int userId, int languageId, int pageNo, int pageSize)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@UserConnection_DestinationUserID", userId);
                SqlParameter paramLanguageId = new SqlParameter("@Profile_LanguageID", languageId);
                SqlParameter paramPageNo = new SqlParameter("@PageNo", pageNo);
                SqlParameter paramPageSize = new SqlParameter("@PageSize", pageSize);

                return _sqlHelper.GetDataTable(_connectionString, "User_GetAllFollowersByPage", paramUserId, paramLanguageId, paramPageNo, paramPageSize);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the users that this user follow using pagination (method moved from old class)
        /// </summary>
        /// <param name="userId">this is the user ID that we need to get his follows</param>
        /// <param name="languageId">this is the language of the returned data</param>
        /// <param name="pageNo">this is the page number for pagination</param>
        /// <param name="pageSize">this is the page size for pagination</param>
        /// <param name="recordCount">this is all the records counts</param>
        /// <returns>Data table of the user follows data</returns>
        /// <exception cref="Exception"></exception>
        public DataTable UserGetAllUserFollowingByPage(int userId, int languageId, int pageNo, int pageSize, out int recordCount)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@UserConnection_SourceUserID", userId);
                SqlParameter paramLanguageId = new SqlParameter("@Profile_LanguageID", languageId);
                SqlParameter paramPageNo = new SqlParameter("@PageNo", pageNo);
                SqlParameter paramPageSize = new SqlParameter("@PageSize", pageSize);
                SqlParameter paramRecordCount = new SqlParameter("@RecordCount", SqlDbType.Int, 4);
                paramRecordCount.Direction = ParameterDirection.Output;

                return _sqlHelper.GetDataTable(_connectionString, "User_GetUsersAmFollowingByPage", out recordCount, paramUserId, paramLanguageId, paramPageNo, paramPageSize, paramRecordCount);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the user's contacts using pagination (method moved from old class)
        /// </summary>
        /// <param name="userId">this is the user ID that we need to get his contacts</param>
        /// <param name="languageId">this is the language of the returned data</param>
        /// <param name="pageNo">this is the page number for pagination</param>
        /// <param name="pageSize">this is the page size for pagination</param>
        /// <returns>Data table of the user contacts data</returns>
        /// <exception cref="Exception"></exception>
        public DataTable UserGetAllContactsByPage(int userId, int languageId, int pageNo, int pageSize)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@Contact_SrcUserID", userId);
                SqlParameter paramLanguageId = new SqlParameter("@Profile_LanguageID", languageId);
                SqlParameter paramPageNo = new SqlParameter("@PageNo", pageNo);
                SqlParameter paramPageSize = new SqlParameter("@PageSize", pageSize);

                return _sqlHelper.GetDataTable(_connectionString, "User_GetContactsByPage", paramUserId, paramLanguageId, paramPageNo, paramPageSize);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method used to delete user followers
        /// </summary>
        /// <param name="userConnectionId"></param>
        public void UserUnfollowUserFollower(string userConnectionId)
        {
            try
            {
                SqlParameter paramUserConnectionId = new SqlParameter("@UserConnection_ID", userConnectionId);
                _sqlHelper.ExecuteNonQuery(_connectionString, "UnfollowUserFollower", paramUserConnectionId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get Users by page and by User name.
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="startRow"></param>
        /// <param name="endRow"></param>
        /// <param name="langId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable SearchUsersByPageAndUserNameLang(string userName, int startRow, int endRow, int langId)
        {
            try
            {
                SqlParameter paramUserName = new SqlParameter("@UserName", userName);
                SqlParameter paramStartRow = new SqlParameter("@StartRow", startRow);
                SqlParameter paramEndRow = new SqlParameter("@EndRow", endRow);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                return _sqlHelper.GetDataTable(_connectionString, "User_SearchUsersByPageAndUserNameLang", paramUserName, paramStartRow, paramEndRow, paramLangId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get a random users to build community using pagination (method moved from old class)
        /// </summary>
        /// <param name="userId">this is the user ID that we need to get community for him</param>
        /// <param name="languageId">this is the language of the returned data</param>
        /// <param name="pageNo">this is the page number for pagination</param>
        /// <param name="pageSize">this is the page size for pagination</param>
        /// <returns>Data table of the users data</returns>
        /// <exception cref="Exception"></exception>
        public DataTable UserGetMembersToFollow(int userId, int languageId, int pageNo, int pageSize)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@UserConnection_SourceUserID", userId);
                SqlParameter paramLanguageId = new SqlParameter("@Profile_LanguageID", languageId);
                SqlParameter paramPageNo = new SqlParameter("@PageNo", pageNo);
                SqlParameter paramPageSize = new SqlParameter("@PageSize", pageSize);

                return _sqlHelper.GetDataTable(_connectionString, "User_GetRandomFollowersByPage", paramUserId, paramLanguageId, paramPageNo, paramPageSize);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get a user details and his connection with current user (method moved from old class)
        /// </summary>
        /// <param name="currentUserID">this is the logged in user ID (0 to pass NULL)</param>
        /// <param name="destinationUserID">this is the user ID that we need to get his details</param>
        /// <param name="languageID">this is the language of the returned data</param>
        /// <returns>Data table of the user data</returns>
        /// <exception cref="Exception"></exception>
        public DataTable UserCommunityGetUserDataByID(int currentUserId, int destinationUserId, int languageId)
        {
            try
            {
                SqlParameter paramCurrentUserId = new SqlParameter("@CurrentUser_ID", null);
                if (currentUserId != 0)
                    paramCurrentUserId.Value = currentUserId;
                SqlParameter paramUserId = new SqlParameter("@User_ID", destinationUserId);
                SqlParameter paramLanguageId = new SqlParameter("@Profile_LanguageID", languageId);

                return _sqlHelper.GetDataTable(_connectionString, "User_GetUserDataById", paramCurrentUserId, paramUserId, paramLanguageId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get user type name (method moved from old class)
        /// </summary>
        /// <param name="userType">this is the logged in user ID (0 to pass NULL)</param>
        /// <param name="investorType">this is the user ID that we need to get his details</param>
        /// <param name="languageId">this is the language of the returned data</param>
        /// <returns>string of the type name</returns>
        public string UserGetUserTypeName(int userType, int investorType, int languageId)
        {
            string type = "";
            string typeOfInvestor = "";

            switch (investorType)
            {
                case 0:
                    if (languageId == (int)Languages.English || languageId == (int)Languages.Spanish)
                        typeOfInvestor = "Crowdfunding";
                    else
                        typeOfInvestor = "جماعي";
                    break;

                case 1:
                    if (languageId == (int)Languages.English || languageId == (int)Languages.Spanish)
                        typeOfInvestor = "Private";
                    else
                        typeOfInvestor = "مخفي";
                    break;

                case 2:
                    if (languageId == (int)Languages.English || languageId == (int)Languages.Spanish)
                        typeOfInvestor = "Pre-Raised Capital";
                    else
                        typeOfInvestor = "مسبق الدفع";
                    break;

                case 3:
                    if (languageId == (int)Languages.English || languageId == (int)Languages.Spanish)
                        typeOfInvestor = "Institutional";
                    else
                        typeOfInvestor = "مؤسساتي";
                    break;
            }

            switch (userType)
            {
                case 0:
                    type = "Admin";
                    break;
                case 1:
                    type = "System Admin";
                    break;
                case 2:
                    if (languageId == (int)Languages.English || languageId == (int)Languages.Spanish)
                        type = typeOfInvestor + " Investor";
                    else
                        type = "مستثمر " + typeOfInvestor;
                    break;
                case 3:
                    if (languageId == (int)Languages.English || languageId == (int)Languages.Spanish)
                        type = "Entrepreneur";
                    else
                        type = "رائد أعمال";
                    break;
                case 4:
                    if (languageId == (int)Languages.English || languageId == (int)Languages.Spanish)
                        type = typeOfInvestor + " Investor And Entrepreneur";
                    else
                        type = "مستثمر " + typeOfInvestor + " و رائد أعمال ";
                    break;
                case 5:
                    type = "BI Admin";
                    break;
            }
            return type;
        }

        /// <summary>
        /// This method is used to check if a user followed on anther user
        /// </summary>
        /// <param name="follower"></param>
        /// <param name="followedBy"></param>
        /// <returns>0 or 1 </returns>
        public int UserCheckUserFollow(int follower, int followedBy)
        {
            try
            {
                SqlParameter paramFollower = new SqlParameter("@Follower", follower);
                SqlParameter paramFollowedBy = new SqlParameter("@FollowedBy", followedBy);
                return _sqlHelper.ExecuteScalar(_connectionString, "CheckUserFollow", paramFollower, paramFollowedBy);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return 0;
            }
        }

        /// <summary>
        /// This method is used to add user follower
        /// </summary>
        /// <param name="userConnectionSourceUserId"></param>
        /// <param name="userConnectionDestinationUserId"></param>
        /// <returns>int</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public int UserAddFollower(int userConnectionSourceUserId, int userConnectionDestinationUserId)
        {
            try
            {
                SqlParameter paramUserConnectionSourceUserId = new SqlParameter("@UserConnection_SourceUserID", userConnectionSourceUserId);
                SqlParameter paramUserConnectionDestinationUserId = new SqlParameter("@UserConnection_DestinationUserID", userConnectionDestinationUserId);
                return _sqlHelper.ExecuteScalar(_connectionString, "AddUserFollower", paramUserConnectionSourceUserId, paramUserConnectionDestinationUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to update if the investor accept to be contacted by proposal SME or not
        /// </summary>
        /// <param name="email">this is the investor email</param>
        /// <param name="pitchId">This is the proposal ID that the investor take action</param>
        /// <param name="investorContactableBySME">This is to clarify if the investor accept to be contacted by proposal SME or not</param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public int UserSMEContactAdd(string email, int pitchId, bool investorContactableBySME)
        {
            try
            {
                SqlParameter paramEmail = new SqlParameter("@Email", email);
                SqlParameter paramPitchId = new SqlParameter("@Pitch_ID", pitchId);
                SqlParameter paramInvestorContactableBySME = new SqlParameter("@InvestorContactableBySME", investorContactableBySME);

                return _sqlHelper.ExecuteNonQuery(_connectionString, "User_SME_Contact_Add", paramEmail, paramPitchId, paramInvestorContactableBySME);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This method is used to get Availabe currencies for the user
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="langId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable UserGetAvaliableCurrency(int userId, int langId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramCurrencyLangId = new SqlParameter("@Currency_LangID", langId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetAvaliableCurrency", paramUserId, paramCurrencyLangId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }


        public bool UserCheckProfileVisible(long profileUserId, int profileLanguageId)
        {
            try
            {
                SqlParameter paramProfileUserId = new SqlParameter("@Profile_UserID", profileUserId);
                SqlParameter paramProfileLanguageId = new SqlParameter("@Profile_LanguageID", profileLanguageId);
                SqlParameter paramReturnValue = new SqlParameter("ReturnValue", SqlDbType.Int, 4);
                paramReturnValue.Direction = ParameterDirection.ReturnValue;
                _sqlHelper.ExecuteNonQuery(_connectionString, "User_CheckProfileVisible", paramProfileUserId, paramProfileLanguageId, paramReturnValue);
                return (int)paramReturnValue.Value != 0 && (int)paramReturnValue.Value != 2;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }

        /// <summary>
        /// This method is used to add two users as contacts<
        /// </summary>
        /// <param name="contactSrcUserId"></param>
        /// <param name="contactTargUserId"></param>
        public void UserAddContact(int contactSrcUserId, int contactTargUserId)
        {
            try
            {
                SqlParameter paramContactSrcUserId = new SqlParameter("@Contact_SrcUserID", contactSrcUserId);
                SqlParameter paramContactTargUserId = new SqlParameter("@Contact_TargUserID", contactTargUserId);
                _sqlHelper.ExecuteNonQuery(_connectionString, "User_AddContact", paramContactSrcUserId, paramContactTargUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to check if two users are contacts
        /// </summary>
        /// <param name="contactSrcUserId"></param>
        /// <param name="contactTargUserId"></param>
        /// <returns>Boolean</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public bool UserCheckUsersContact(int contactSrcUserId, int contactTargUserId)
        {
            try
            {
                SqlParameter paramContactSrcUserId = new SqlParameter("@Contact_SrcUserID", contactSrcUserId);
                SqlParameter paramContactTargUserId = new SqlParameter("@Contact_TargUserID", contactTargUserId);
                return _sqlHelper.GetDataTable(_connectionString, "User_CheckUsersContact", paramContactSrcUserId, paramContactTargUserId).Rows.Count > 0;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is use to change the preffered currency for user
        /// </summary>
        /// <param name="currencyCode"></param>
        /// <param name="userId"></param>
        public void UserChangePreferredCurrency(string currencyCode, int userId)
        {
            try
            {
                SqlParameter param_User_ID = new SqlParameter("@User_ID", userId);
                SqlParameter param_Prefered_Currency_Code = new SqlParameter("@Prefered_Currency_Code", currencyCode);
                _sqlHelper.ExecuteNonQuery(_connectionString, "User_ChangePreferredCurrency", param_User_ID, param_Prefered_Currency_Code);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// Get last and max user investments
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="languageId"></param>
        /// <param name="currencyId"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception"></exception>
        public DataTable UserGetInvestmentsForProfile(int userId, int languageId, int currencyId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@UserID", userId);
                SqlParameter paramPitchLanguageId = new SqlParameter("@Pitch_LanguageID", languageId);
                SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", currencyId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetInvestmentsForProfile", paramUserId, paramPitchLanguageId, paramCurrencyId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n UserID: " + userId + "\n Pitch_LanguageID: " + languageId + "\n CurrencyID: " + currencyId + "\n sql_helper is NULL: " + (_sqlHelper == null));
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }


    }
}