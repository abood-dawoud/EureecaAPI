﻿using Eureeca_API.General;
using Eureeca_API.Interface.UserInterface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.UserRepos
{
    public class LeadRepository : ILead
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;
        public LeadRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }
        public void LeadUserCheckIfEureecaUpdateEureecaId(string leadEmail)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Lead_user_CheckIfEureeca_UpdateEureecaID", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@Lead_email", leadEmail));

                        sql.Open();
                        cmd.ExecuteNonQuery();

                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }


        }

        public int LeadUsersAddNewLead(int leadId, int leadType, string leadEmail, string leadFirstName, string leadLastName, int leadSource, string[] proposals, string leadNotes, string leadOwer, int leadCountry, string leadPhone, string leadAddress1, string leadAddress2, string leadAnticipatedCommitment, int eureecaUserId, bool leadComingSoonAccessRequest)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Lead_Users_Add_New_Lead", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        SqlParameter paramLeadId = new SqlParameter("@Lead_ID", DBNull.Value);
                        if (leadId > 0)
                            paramLeadId.Value = leadId;
                        cmd.Parameters.Add(paramLeadId);
                        cmd.Parameters.Add(new SqlParameter("@Lead_Type", leadType));
                        cmd.Parameters.Add(new SqlParameter("@Lead_Email", leadEmail));

                        SqlParameter paramLeadFirstName = new SqlParameter("@Lead_FirstName", DBNull.Value);
                        if (!string.IsNullOrWhiteSpace(leadFirstName))
                            paramLeadFirstName.Value = leadFirstName;
                        cmd.Parameters.Add(paramLeadFirstName);
                        SqlParameter paramLeadLastName = new SqlParameter("@Lead_LastName", DBNull.Value);
                        if (!string.IsNullOrWhiteSpace(leadLastName))
                            paramLeadLastName.Value = leadLastName;
                        cmd.Parameters.Add(paramLeadLastName);

                        SqlParameter paramLeadSource = new SqlParameter("@Lead_source", DBNull.Value);
                        if (leadSource > 0)
                            paramLeadSource.Value = leadSource;
                        cmd.Parameters.Add(paramLeadSource);

                        DataTable dtProposals = new DataTable();
                        dtProposals.Columns.Add("Pitch_ID", typeof(string));
                        DataRow workRow;
                        foreach (string Pitch_ID in proposals)
                        {
                            workRow = dtProposals.NewRow();
                            workRow["Pitch_ID"] = Pitch_ID.Trim();
                            dtProposals.Rows.Add(workRow);
                        }
                        cmd.Parameters.Add(new SqlParameter("@Proposals", dtProposals));
                        SqlParameter paramLeadNotes = new SqlParameter("@Lead_Notes", DBNull.Value);
                        if (!string.IsNullOrWhiteSpace(leadNotes))
                            paramLeadNotes.Value = leadNotes;
                        cmd.Parameters.Add(paramLeadNotes);

                        SqlParameter paramLeadPhone = new SqlParameter("@Lead_Phone", DBNull.Value);
                        if (!string.IsNullOrWhiteSpace(leadPhone))
                            paramLeadPhone.Value = leadPhone;
                        cmd.Parameters.Add(paramLeadPhone);

                        SqlParameter paramLeadCountry = new SqlParameter("@Lead_Country", DBNull.Value);
                        if (leadCountry > 0)
                            paramLeadCountry.Value = leadCountry;
                        cmd.Parameters.Add(paramLeadCountry);

                        cmd.Parameters.Add(new SqlParameter("@Lead_Ower", leadOwer));

                        SqlParameter paramLeadAnticipatedCommitment = new SqlParameter("@Lead_Anticipated_Commitment", DBNull.Value);
                        if (!string.IsNullOrWhiteSpace(leadAnticipatedCommitment))
                            paramLeadAnticipatedCommitment.Value = leadAnticipatedCommitment;
                        cmd.Parameters.Add(paramLeadAnticipatedCommitment);
                        SqlParameter paramEureecaUserId = new SqlParameter("@Eureeca_User_ID", DBNull.Value);
                        if (eureecaUserId > 0)
                            paramEureecaUserId.Value = eureecaUserId;
                        cmd.Parameters.Add(paramEureecaUserId);

                        SqlParameter paramLeadAddress1 = new SqlParameter("@Lead_Address_1", DBNull.Value);
                        if (!string.IsNullOrWhiteSpace(leadAddress1))
                            paramLeadAddress1.Value = leadAddress1;
                        cmd.Parameters.Add(paramLeadAddress1);

                        SqlParameter paramLeadAddress2 = new SqlParameter("@Lead_Address_2", DBNull.Value);
                        if (!string.IsNullOrWhiteSpace(leadAddress2))
                            paramLeadAddress2.Value = leadAddress2;
                        cmd.Parameters.Add(paramLeadAddress2);


                        cmd.Parameters.Add(new SqlParameter("@Lead_Coming_Soon_Access_Request", leadComingSoonAccessRequest));
                        sql.Open();

                        return Convert.ToInt32(cmd.ExecuteScalar());
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        public DataTable LeadUsersGetLeadByEmail(string leadEmail)
        {
            try
            {
                SqlParameter paramLeadEmail = new SqlParameter("@Lead_Email", leadEmail);
                return _sqlHelper.GetDataTable(_connectionString, "Lead_users_get_Lead_By_Email", paramLeadEmail);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }


    }
}
