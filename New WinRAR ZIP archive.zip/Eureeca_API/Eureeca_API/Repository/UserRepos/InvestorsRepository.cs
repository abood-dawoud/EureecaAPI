﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Models.UserModels.ViewModesl;
using System.Data;

namespace Eureeca_API.Repository.UserRepos
{
    public class InvestorsRepository : IInvestors
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        public static IWebHostEnvironment _environment;
        private readonly IUser _user;
        private readonly IPitch _pitch;
        private readonly IConfiguration _config;
        public InvestorsRepository(IConfiguration config, IWebHostEnvironment environment, IUser user, IPitch pitch)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _environment = environment;
            _user = user;
            _pitch = pitch;
            _config = config;
        }
        public InvestorsResponse InvestorsGetInvestorsList(string listInvestorShowFilter, string sortFilterId, int countryId, int badgeId, string investorName, int langId, int pageNo, int pageSize, string userId, int currencyId)
        {
            try
            {
                bool hasMore = false;
                int recordCount = 0;
                DataTable dtInvestors = _user.UserGetInvestorsListOffest(listInvestorShowFilter, sortFilterId, countryId, badgeId, investorName, langId, pageNo, pageSize, out recordCount);
                if (dtInvestors.Rows.Count > 0)
                {
                    List<Investors> investors = new List<Investors>();
                    foreach (DataRow dr in dtInvestors.Rows)
                    {
                        Investors investor = new Investors();
                        investor.UserId = dr["User_ID"].ToString();
                        if (string.IsNullOrEmpty(dr["User_Picture"].ToString()) || !File.Exists(Path.Combine(_config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dr["User_Picture"].ToString())))
                            investor.UserPicture = _config.GetValue<string>("EnvironmentURL") + "/Images/v2/Default.jpg";
                        else
                            investor.UserPicture = _config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dr["User_Picture"].ToString();

                        if (!string.IsNullOrEmpty(dr["User_IsFeaturedInvestor"].ToString()) && bool.Parse(dr["User_IsFeaturedInvestor"].ToString()))
                            investor.UserIsFeaturedInvestor = true;
                        else
                            investor.UserIsFeaturedInvestor = false;
                        investor.UserName = dr["User_Username"].ToString();
                        investor.ProfileFirstName = dr["Profile_FirstName"].ToString();
                        investor.ProfileLastName = dr["Profile_LastName"].ToString();
                        investor.MaxInvestmentAmount = dr["Max_Investment_Amount"].ToString();
                        investor.LastInvestmentDate = dr["Latest_Investment_Date"].ToString();
                        investor.FollowingNumber = dr["Following"].ToString();
                        investor.FollowersNumber = dr["Followers"].ToString();
                        investor.FeaturedImage = _config.GetValue<string>("AssetsEnvironmentURL") + "images/white-star.png";

                        if (userId != null)
                        {
                            int userConnectionId = _user.UserGetUserConnectionId(userId, dr["User_ID"].ToString());
                            if (userConnectionId != 0)
                            {
                                investor.CanFollow = false;
                            }
                            else
                            {
                                investor.CanFollow = true;
                            }

                            DataTable dtRecentlyInvested = _user.UserGetRecentlyInvested(int.Parse(dr["User_ID"].ToString()), langId, currencyId);
                            if (dtRecentlyInvested.Rows.Count > 0)
                            {
                                investor.LastInvestmentPitchId = dtRecentlyInvested.Rows[0]["Investment_PitchID"].ToString();
                                investor.LastInvestmentAmount = Convert.ToInt32(dtRecentlyInvested.Rows[0]["Investment_Amount"]).ToString("#0,00");
                                investor.LastInvestmentPitchTitle = dtRecentlyInvested.Rows[0]["Pitch_Tilte"].ToString();
                            }
                            investor.InvestmentList = new List<RecentInvestments>();
                            foreach (DataRow drIn in dtRecentlyInvested.Rows)
                            {
                                RecentInvestments recentInvestment = new RecentInvestments();
                                recentInvestment.InvestmentId = drIn["Investment_ID"].ToString();
                                recentInvestment.InvestmentPitchId = drIn["Investment_PitchID"].ToString();
                                recentInvestment.InvestmentAmount = drIn["Investment_Amount"].ToString();
                                recentInvestment.PitchTilte = drIn["Pitch_Tilte"].ToString();
                                recentInvestment.TotalInvetments = drIn["Total_Invetments"].ToString();
                                if (drIn["Pitch_Status"].ToString() != "published" && drIn["Pitch_Status"].ToString() != "Overfunding")
                                {
                                    recentInvestment.PitchStatus = false;
                                }
                                else
                                {
                                    recentInvestment.PitchStatus = true;
                                }
                                investor.InvestmentList.Add(recentInvestment);
                            }
                            DataTable dtRecentlyFollowed = _user.UserGetRecentlyFollowed(int.Parse(dr["User_ID"].ToString()), langId);
                            investor.RecentFollowed = new List<RecentlyFollowed>();
                            foreach (DataRow drRf in dtRecentlyFollowed.Rows)
                            {
                                RecentlyFollowed recentlyFollowed = new RecentlyFollowed();
                                recentlyFollowed.UserId = drRf["USER_ID"].ToString();
                                recentlyFollowed.UserUserName = drRf["User_Username"].ToString();
                                recentlyFollowed.ProfileFirstName = drRf["Profile_FirstName"].ToString();
                                recentlyFollowed.ProfileLastName = drRf["Profile_LastName"].ToString();
                                investor.RecentFollowed.Add(recentlyFollowed);
                            }
                        }


                        #region Badge object
                        investor.ExpertImage = _config.GetValue<string>("AssetsEnvironmentURL") + "images/circle-arrowsup.png";
                        investor.IsExpert = _user.UserIsExpert(int.Parse(dr["User_ID"].ToString()));
                        DataTable DtObject = _user.UserGetUserEnrollmentsByLang(int.Parse(dr["User_ID"].ToString()), langId, (int)ObjectsGroups.Badges);
                        if (DtObject.Rows.Count > 0)
                        {
                            investor.HasBadge = true;
                            investor.ProfileObjectTitle = DtObject.Rows[0]["Profile_ObjectTitle"].ToString();
                            investor.MasterImageUrlBig = _config.GetValue<string>("EnvironmentURL") +DtObject.Rows[0]["Master_ImageUrlBig"].ToString();
                            investor.MasterImageUrl = _config.GetValue<string>("EnvironmentURL") + DtObject.Rows[0]["Master_ImageUrl"].ToString();
                        }
                        else
                        {
                            investor.HasBadge = false;
                            investor.MasterImageUrlBig = _config.GetValue<string>("AssetsEnvironmentURL") + "images/badge_Regular.png";
                            investor.MasterImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/badge_Regular.png";
                        }
                        #endregion
                        investors.Add(investor);
                    }
                    hasMore = recordCount > ((pageNo + 1) * pageSize);
                    InvestorsResponse response = new InvestorsResponse(200, true, recordCount, hasMore, pageNo, investors);
                    return response;
                }
                else // no data
                {
                    List<Investors> investor = new List<Investors>();
                    InvestorsResponse response = new InvestorsResponse(200, true, 0, false, pageNo, investor);
                    return response;
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                List<Investors> investor = new List<Investors>();
                InvestorsResponse response = new InvestorsResponse(200, true, 0, false, pageNo, investor);
                return response;
            }
        }
    }
}
