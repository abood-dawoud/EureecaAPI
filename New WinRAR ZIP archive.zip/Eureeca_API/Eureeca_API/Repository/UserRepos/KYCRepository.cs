﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface.UserInterface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.UserRepos
{
    public class KYCRepository : IKYC
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;

        public KYCRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();

        }

        public int[] KYCGetRequiredDocs(int userId, int countryKYCTire)
        {
            try
            {
                int[] array = new int[19] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
                //index 0: #Needed Docs for this tier
                //index 1: #Accepted Or Pending Docs From Needed
                //index 2: flag for the Personal Photo Need (0,1)
                //index 3: Personal Photo Status
                //index 4: flag for the Passport Need (0,1)
                //index 5: Passport Status
                //index 6: flag for the Utility Need (0,1)
                //index 7: Utility Status
                //index 8: flag for the Payment Confirm Need (0,1)
                //index 9: Payment Confirm Status
                //index 10: flag for the Proof Of Address Need (0,1)
                //index 11: Proof Of Address Status
                //index 12: flag for the Source Of Wealth Need (0,1)
                //index 13: Source Of Wealth Status
                //index 14: flag for the Certefied Copies Need (0,1)
                //index 15: Certefied Copies Status
                //index 16: flag for the PEP Doc Needed Need (0,1)
                //index 17: PEP Doc Status
                //index 18: #Accepted Docs From Needed

                DataTable dtTierDocs = KYCGetTierNeededDocs(countryKYCTire, userId);
                if (dtTierDocs.Rows.Count > 0) //there is a record for this tier in the needed docs table (KYC Required)
                {
                    DataRow drTierDocs = dtTierDocs.Rows[0];

                    int personalPhotoNeeded = array[2] = Convert.ToInt32(bool.Parse(drTierDocs["Personal_Photo_Needed"].ToString()));
                    int passportNeeded = array[4] = Convert.ToInt32(bool.Parse(drTierDocs["Passport_Needed"].ToString()));
                    int utilityNeeded = array[6] = Convert.ToInt32(bool.Parse(drTierDocs["Utility_Needed"].ToString()));
                    int paymentConfirmNeeded = array[8] = Convert.ToInt32(bool.Parse(drTierDocs["Payment_Confirm_Needed"].ToString()));
                    int proofOfAddressNeeded = array[10] = Convert.ToInt32(bool.Parse(drTierDocs["Proof_of_address_Needed"].ToString()));
                    int sourceOfWealthNeeded = array[12] = Convert.ToInt32(bool.Parse(drTierDocs["Source_of_wealth_Needed"].ToString()));
                    int certefiedCopiesNeeded = array[14] = Convert.ToInt32(bool.Parse(drTierDocs["Certefied_copies_Needed"].ToString()));
                    int PEPDocNeeded = array[16] = Convert.ToInt32(bool.Parse(drTierDocs["PEP_Doc_Needed"].ToString()));

                    int NeededDocs = 0;
                    if (personalPhotoNeeded == 1)
                        NeededDocs++;
                    if (passportNeeded == 1)
                        NeededDocs++;
                    if (proofOfAddressNeeded == 1)
                        NeededDocs++;
                    if (sourceOfWealthNeeded == 1)
                        NeededDocs++;
                    if (certefiedCopiesNeeded == 1)
                        NeededDocs++;
                    if (utilityNeeded == 1)
                        NeededDocs++;
                    if (paymentConfirmNeeded == 1)
                        NeededDocs++;
                    if (PEPDocNeeded == 1)
                        NeededDocs++;

                    array[0] = NeededDocs;

                    if (NeededDocs > 0)
                    {
                        DataTable dtUserDocs = KYCGetUserDocs(userId);

                        if (dtUserDocs.Rows.Count > 0) //the user uploaded some/all needed docs before
                        {
                            DataRow drUserDocs = dtUserDocs.Rows[0];

                            int acceptedDocsFromNeeded = 0;
                            int acceptedOrPendingDocsFromNeeded = 0;
                            int overAllStatus = int.Parse(drUserDocs["Overall_Status"].ToString());

                            int personalPhotoStatus = drUserDocs["Personal_Photo_Status"] != DBNull.Value ? int.Parse(drUserDocs["Personal_Photo_Status"].ToString()) : (int)KYCUserDocsStatus.NotUploaded;
                            int passportStatus = drUserDocs["Passport_Status"] != DBNull.Value ? int.Parse(drUserDocs["Passport_Status"].ToString()) : (int)KYCUserDocsStatus.NotUploaded;
                            int utilityStatus = drUserDocs["Utility_Status"] != DBNull.Value ? int.Parse(drUserDocs["Utility_Status"].ToString()) : (int)KYCUserDocsStatus.NotUploaded;
                            int paymentConfirmationStatus = drUserDocs["Payment_Confirmation_Status"] != DBNull.Value ? int.Parse(drUserDocs["Payment_Confirmation_Status"].ToString()) : (int)KYCUserDocsStatus.NotUploaded;
                            int proofOfAddressStatus = drUserDocs["Proof_of_address_Status"] != DBNull.Value ? int.Parse(drUserDocs["Proof_of_address_Status"].ToString()) : (int)KYCUserDocsStatus.NotUploaded;
                            int sourceOfWealthStatus = drUserDocs["Source_of_wealth_Status"] != DBNull.Value ? int.Parse(drUserDocs["Source_of_wealth_Status"].ToString()) : (int)KYCUserDocsStatus.NotUploaded;
                            int certefiedCopiesStatus = drUserDocs["Certefied_copies_Status"] != DBNull.Value ? int.Parse(drUserDocs["Certefied_copies_Status"].ToString()) : (int)KYCUserDocsStatus.NotUploaded;
                            int PEPStatus = drUserDocs["PEP_Status"] != DBNull.Value ? int.Parse(drUserDocs["PEP_Status"].ToString()) : (int)KYCUserDocsStatus.NotUploaded;

                            #region PersonalPhoto
                            if (personalPhotoNeeded == 1)
                                if (personalPhotoStatus == (int)KYCUserDocsStatus.NotUploaded)
                                    overAllStatus = (int)KYCUserDocsStatus.NotUploaded;
                                else if (personalPhotoStatus == (int)KYCUserDocsStatus.NotAccepted)
                                    overAllStatus = (int)KYCUserDocsStatus.NotAccepted;
                                else if (personalPhotoStatus == (int)KYCUserDocsStatus.PendingApproval)
                                    acceptedOrPendingDocsFromNeeded++;
                                else if (personalPhotoStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    acceptedDocsFromNeeded++;
                                    acceptedOrPendingDocsFromNeeded++;
                                }
                            #endregion
                            #region Passport
                            if (passportNeeded == 1)
                            {
                                if (passportStatus == (int)KYCUserDocsStatus.NotUploaded)
                                    overAllStatus = (int)KYCUserDocsStatus.NotUploaded;
                                else if (passportStatus == (int)KYCUserDocsStatus.NotAccepted)
                                    overAllStatus = (int)KYCUserDocsStatus.NotAccepted;

                                if (passportStatus == (int)KYCUserDocsStatus.Accepted || passportStatus == (int)KYCUserDocsStatus.PendingApproval)
                                    if (drUserDocs["Passport_Expire"] != DBNull.Value && Tools.CompareDates(drUserDocs["Passport_Expire"].ToString(), DateTime.Now.ToShortDateString()) == -1)
                                        overAllStatus = passportStatus = (int)KYCUserDocsStatus.Expired;
                                    else
                                    {
                                        acceptedOrPendingDocsFromNeeded++;
                                        if (passportStatus == (int)KYCUserDocsStatus.Accepted)
                                            acceptedDocsFromNeeded++;
                                    }
                            }
                            #endregion
                            #region ProofOfAddress
                            if (proofOfAddressNeeded == 1)
                            {
                                if (proofOfAddressStatus == (int)KYCUserDocsStatus.NotUploaded)
                                    overAllStatus = (int)KYCUserDocsStatus.NotUploaded;
                                else if (proofOfAddressStatus == (int)KYCUserDocsStatus.NotAccepted)
                                    overAllStatus = (int)KYCUserDocsStatus.NotAccepted;

                                if (proofOfAddressStatus == (int)KYCUserDocsStatus.Accepted || proofOfAddressStatus == (int)KYCUserDocsStatus.PendingApproval)
                                    if (drUserDocs["Proof_of_address_Expire"] != DBNull.Value && Tools.CompareDates(drUserDocs["Proof_of_address_Expire"].ToString(), DateTime.Now.ToShortDateString()) == -1)
                                        overAllStatus = proofOfAddressStatus = (int)KYCUserDocsStatus.Expired;
                                    else
                                    {
                                        acceptedOrPendingDocsFromNeeded++;
                                        if (proofOfAddressStatus == (int)KYCUserDocsStatus.Accepted)
                                            acceptedDocsFromNeeded++;
                                    }
                            }
                            #endregion
                            #region CertefiedCopies
                            if (certefiedCopiesNeeded == 1)
                                if (certefiedCopiesStatus == (int)KYCUserDocsStatus.NotUploaded)
                                    overAllStatus = (int)KYCUserDocsStatus.NotUploaded;
                                else if (certefiedCopiesStatus == (int)KYCUserDocsStatus.NotAccepted)
                                    overAllStatus = (int)KYCUserDocsStatus.NotAccepted;
                                else if (certefiedCopiesStatus == (int)KYCUserDocsStatus.PendingApproval)
                                    acceptedOrPendingDocsFromNeeded++;
                                else if (certefiedCopiesStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    acceptedDocsFromNeeded++;
                                    acceptedOrPendingDocsFromNeeded++;
                                }
                            #endregion
                            #region SourceOfWealth
                            if (sourceOfWealthNeeded == 1)
                                if (sourceOfWealthStatus == (int)KYCUserDocsStatus.NotUploaded)
                                    overAllStatus = (int)KYCUserDocsStatus.NotUploaded;
                                else if (sourceOfWealthStatus == (int)KYCUserDocsStatus.NotAccepted)
                                    overAllStatus = (int)KYCUserDocsStatus.NotAccepted;
                                else if (sourceOfWealthStatus == (int)KYCUserDocsStatus.PendingApproval)
                                    acceptedOrPendingDocsFromNeeded++;
                                else if (sourceOfWealthStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    acceptedDocsFromNeeded++;
                                    acceptedOrPendingDocsFromNeeded++;
                                }
                            #endregion
                            #region Utility
                            if (utilityNeeded == 1)
                                if (utilityStatus == (int)KYCUserDocsStatus.NotUploaded)
                                    overAllStatus = (int)KYCUserDocsStatus.NotUploaded;
                                else if (utilityStatus == (int)KYCUserDocsStatus.NotAccepted)
                                    overAllStatus = (int)KYCUserDocsStatus.NotAccepted;
                                else if (utilityStatus == (int)KYCUserDocsStatus.PendingApproval)
                                    acceptedOrPendingDocsFromNeeded++;
                                else if (utilityStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    acceptedDocsFromNeeded++;
                                    acceptedOrPendingDocsFromNeeded++;
                                }
                            #endregion
                            #region  PaymentConfirmation
                            if (paymentConfirmNeeded == 1)
                                if (paymentConfirmationStatus == (int)KYCUserDocsStatus.NotUploaded)
                                    overAllStatus = (int)KYCUserDocsStatus.NotUploaded;
                                else if (paymentConfirmationStatus == (int)KYCUserDocsStatus.NotAccepted)
                                    overAllStatus = (int)KYCUserDocsStatus.NotAccepted;
                                else if (paymentConfirmationStatus == (int)KYCUserDocsStatus.PendingApproval)
                                    acceptedOrPendingDocsFromNeeded++;
                                else if (paymentConfirmationStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    acceptedDocsFromNeeded++;
                                    acceptedOrPendingDocsFromNeeded++;
                                }
                            #endregion
                            #region PEPDoc
                            if (PEPDocNeeded == 1)
                                if (PEPStatus == (int)KYCUserDocsStatus.NotUploaded)
                                    overAllStatus = (int)KYCUserDocsStatus.NotUploaded;
                                else if (PEPStatus == (int)KYCUserDocsStatus.NotAccepted)
                                    overAllStatus = (int)KYCUserDocsStatus.NotAccepted;
                                else if (PEPStatus == (int)KYCUserDocsStatus.PendingApproval)
                                    acceptedOrPendingDocsFromNeeded++;
                                else if (PEPStatus == (int)KYCUserDocsStatus.Accepted)
                                {
                                    acceptedDocsFromNeeded++;
                                    acceptedOrPendingDocsFromNeeded++;
                                }
                            #endregion

                            if (int.Parse(drUserDocs["Overall_Status"].ToString()) != (int)KYCUserDocsStatus.Accepted && acceptedDocsFromNeeded == NeededDocs)
                                overAllStatus = (int)KYCUserDocsStatus.Accepted;
                            else if (int.Parse(drUserDocs["Overall_Status"].ToString()) != (int)KYCUserDocsStatus.PendingApproval && acceptedOrPendingDocsFromNeeded == NeededDocs && acceptedDocsFromNeeded != NeededDocs)
                                overAllStatus = (int)KYCUserDocsStatus.PendingApproval;

                            if (overAllStatus != int.Parse(drUserDocs["Overall_Status"].ToString()))
                            {
                                KYCManageUserAutomation(userId, overAllStatus,
                                    drUserDocs["Personal_Photo"].ToString(), drUserDocs["Personal_Photo_UploadingDate"].ToString(), personalPhotoStatus, drUserDocs["Personal_Photo_Notes"].ToString(),
                                    drUserDocs["Passport"].ToString(), drUserDocs["Passport_UploadingDate"].ToString(), drUserDocs["Passport_Name"].ToString(), passportStatus,
                                    drUserDocs["Passport_Expire"].ToString(), drUserDocs["Passport_Notes"].ToString(),
                                    drUserDocs["Utility"].ToString(), drUserDocs["Utility_UploadingDate"].ToString(), utilityStatus,
                                    drUserDocs["Payment_Confirmation"].ToString(), drUserDocs["Payment_Confirmation_UploadingDate"].ToString(), paymentConfirmationStatus,
                                    drUserDocs["Proof_of_address"].ToString(), drUserDocs["Proof_of_address_UploadingDate"].ToString(), drUserDocs["Proof_of_address_Address"].ToString(), proofOfAddressStatus,
                                    drUserDocs["Proof_of_address_Expire"].ToString(), drUserDocs["Proof_of_address_Notes"].ToString(),
                                    drUserDocs["Source_of_wealth"].ToString(), drUserDocs["Source_of_wealth_UploadingDate"].ToString(), sourceOfWealthStatus, drUserDocs["Source_of_wealth_Notes"].ToString(),
                                    drUserDocs["Certefied_copies"].ToString(), drUserDocs["Certefied_copies_UploadingDate"].ToString(), certefiedCopiesStatus, drUserDocs["Certefied_copies_Notes"].ToString(),
                                    drUserDocs["PEP_Doc"].ToString(), PEPStatus, drUserDocs["PEP_Notes"].ToString(), drUserDocs["PEP_UploadingDate"].ToString());

                                if (int.Parse(drUserDocs["Overall_Status"].ToString()) != (int)KYCUserDocsStatus.Expired && overAllStatus == (int)KYCUserDocsStatus.Expired)
                                {

                                    //if (Passport_Status == (int)KYC_UserDocsStatus.Expired)

                                    // _message.sendKYCExpiredEmailToInvestor(user.getSystemAdmin(), user.SelectUserById(User_ID).Rows[0], "Passport");
                                    //if (Proof_of_address_Status == (int)KYC_UserDocsStatus.Expired)
                                    //message.sendKYCExpiredEmailToInvestor(user.getSystemAdmin(), user.SelectUserById(User_ID).Rows[0], "Proof of address");
                                }
                            }

                            array[1] = acceptedOrPendingDocsFromNeeded;
                            array[3] = personalPhotoStatus;
                            array[5] = passportStatus;
                            array[7] = utilityStatus;
                            array[9] = paymentConfirmationStatus;
                            array[11] = proofOfAddressStatus;
                            array[13] = sourceOfWealthStatus;
                            array[15] = certefiedCopiesStatus;
                            array[17] = PEPStatus;
                            array[18] = acceptedDocsFromNeeded;
                        }
                        else //there is no uploaded docs from the needed before for this user
                        {
                            array[3] = array[5] = array[7] = array[9] = array[11] = array[13] = array[15] = array[17] = (int)KYCUserDocsStatus.NotUploaded;
                        }
                    }
                    else //KYC required but no needed docs for this tier
                    { }
                }
                else //there is no record for this tier in the needed docs table (KYC Not Required)
                {
                }

                return array;

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        public DataTable KYCGetTierNeededDocs(int countryKYCTire, int userId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("KYC_GetTierNeededDocs", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;
                        SqlParameter countryKYCTireParam = new SqlParameter("@Country_KYC_Tire", SqlDbType.Int);
                        SqlParameter userIdParam = new SqlParameter("@User_ID", SqlDbType.Int);

                        countryKYCTireParam.Value = countryKYCTire;
                        if (userId > 0)
                            userIdParam.Value = userId;
                        else
                            userIdParam.Value = DBNull.Value;

                        comm.Parameters.AddRange(new SqlParameter[] { countryKYCTireParam, userIdParam });

                        SqlDataAdapter DA = new SqlDataAdapter(comm);
                        DataTable DT = new DataTable();
                        DA.Fill(DT);
                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }


        }
        public DataTable KYCGetUserDocs(float userId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("KYC_GetUserDocs", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;
                        SqlParameter userIdParam = new SqlParameter("@User_ID", SqlDbType.Int);

                        userIdParam.Value = userId;

                        comm.Parameters.AddRange(new SqlParameter[] { userIdParam });
                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(comm);
                        DataTable DT = new DataTable();
                        DA.Fill(DT);
                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }


        }
        public int KYCManageUserAutomation(int userId, int overAllStatus, string personalPhoto, string personalPhotoUploadingDate, int personalPhotoStatus, string personalPhotoNotes, string passport, string passportUploadingDate, string passportName, int passportStatus, string passportExpire, string passportNotes, string utility, string utilityUploadingDate, int utilityStatus, string paymentConfirmation, string paymentConfirmationUploadingDate, int paymentConfirmationStatus,
       string proofOfAddress, string proofOfAddressUploadingDate, string proofOfAddressAddress, int proofOfAddressStatus, string proofOfAddressExpire, string proofOfAddressNotes, string sourceOfWealth, string sourceOfWealthUploadingDate, int sourceOfWealthStatus, string sourceOfWealthNotes, string certefiedCopies, string certefiedCopiesUploadingDate, int certefiedCopiesStatus, string certefiedCopiesNotes,
       string PEPDoc, int PEPStatus, string PEPNotes, string PEPUploadingDate)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("KYC_ManageUserAutomation", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;
                        SqlParameter userIdParam = new SqlParameter("@User_ID", SqlDbType.Int);
                        SqlParameter overAllStatusParam = new SqlParameter("@Overall_Status", SqlDbType.Int);
                        SqlParameter personalPhotoParam = new SqlParameter("@Personal_Photo", SqlDbType.VarChar);
                        SqlParameter personalPhotoUploadingDateParam = new SqlParameter("@Personal_Photo_UploadingDate", SqlDbType.VarChar);
                        SqlParameter personalPhotoStatusParam = new SqlParameter("@Personal_Photo_Status", SqlDbType.Int);
                        SqlParameter personalPhotoNotesParam = new SqlParameter("@Personal_Photo_Notes", SqlDbType.VarChar);

                        SqlParameter passportParam = new SqlParameter("@Passport", SqlDbType.VarChar);
                        SqlParameter passportUploadingDateParam = new SqlParameter("@Passport_UploadingDate", SqlDbType.VarChar);
                        SqlParameter passportNameParam = new SqlParameter("@Passport_Name", SqlDbType.VarChar);
                        SqlParameter passportStatusParam = new SqlParameter("@Passport_Status", SqlDbType.Int);
                        SqlParameter passportExpireParam = new SqlParameter("@Passport_Expire", SqlDbType.VarChar);
                        SqlParameter passportNotesParam = new SqlParameter("@Passport_Notes", SqlDbType.VarChar);

                        SqlParameter utilityParam = new SqlParameter("@Utility", SqlDbType.VarChar);
                        SqlParameter utilityUploadingDateParam = new SqlParameter("@Utility_UploadingDate", SqlDbType.VarChar);
                        SqlParameter utilityStatusParam = new SqlParameter("@Utility_Status", SqlDbType.Int);

                        SqlParameter paymentConfirmationParam = new SqlParameter("@Payment_Confirmation", SqlDbType.VarChar);
                        SqlParameter paymentConfirmationUploadingDateParam = new SqlParameter("@Payment_Confirmation_UploadingDate", SqlDbType.VarChar);
                        SqlParameter paymentConfirmationStatusParam = new SqlParameter("@Payment_Confirmation_Status", SqlDbType.Int);

                        SqlParameter proofOfAddressParam = new SqlParameter("@Proof_of_address", SqlDbType.VarChar);
                        SqlParameter proofOfAddressUploadingDateParam = new SqlParameter("@Proof_of_address_UploadingDate", SqlDbType.VarChar);
                        SqlParameter proofOfAddressAddressParam = new SqlParameter("@Proof_of_address_Address", SqlDbType.VarChar);
                        SqlParameter proofOfAddressStatusParam = new SqlParameter("@Proof_of_address_Status", SqlDbType.Int);
                        SqlParameter proofOfAddressExpireParam = new SqlParameter("@Proof_of_address_Expire", SqlDbType.VarChar);
                        SqlParameter proofOfAddressNotesParam = new SqlParameter("@Proof_of_address_Notes", SqlDbType.VarChar);

                        SqlParameter sourceOfWealthParam = new SqlParameter("@Source_of_wealth", SqlDbType.VarChar);
                        SqlParameter sourceOfWealthUploadingDateParam = new SqlParameter("@Source_of_wealth_UploadingDate", SqlDbType.VarChar);
                        SqlParameter sourceOfWealthStatusParam = new SqlParameter("@Source_of_wealth_Status", SqlDbType.Int);
                        SqlParameter sourceOfWealthNotesParam = new SqlParameter("@Source_of_wealth_Notes", SqlDbType.VarChar);

                        SqlParameter certefiedCopiesParam = new SqlParameter("@Certefied_copies", SqlDbType.VarChar);
                        SqlParameter certefiedCopiesUploadingDateParam = new SqlParameter("@Certefied_copies_UploadingDate", SqlDbType.VarChar);
                        SqlParameter certefiedCopiesStatusParam = new SqlParameter("@Certefied_copies_Status", SqlDbType.Int);
                        SqlParameter certefiedCopiesNotesParam = new SqlParameter("@Certefied_copies_Notes", SqlDbType.VarChar);

                        SqlParameter PEPDocParam = new SqlParameter("@PEP_Doc", SqlDbType.VarChar);
                        SqlParameter PEPStatusParam = new SqlParameter("@PEP_Status", SqlDbType.Int);
                        SqlParameter PEPNotesParam = new SqlParameter("@PEP_Notes", SqlDbType.VarChar);
                        SqlParameter PEPUploadingDateParam = new SqlParameter("@PEP_UploadingDate", SqlDbType.VarChar);

                        SqlParameter parameterReturnValue = new SqlParameter("ReturnValue", SqlDbType.Int, 4);
                        parameterReturnValue.Direction = ParameterDirection.ReturnValue;

                        userIdParam.Value = userId;
                        overAllStatusParam.Value = overAllStatus;

                        if (personalPhoto != "")
                            personalPhotoParam.Value = personalPhoto;
                        else
                            personalPhotoParam.Value = DBNull.Value;

                        if (personalPhotoUploadingDate != "")
                            personalPhotoUploadingDateParam.Value = personalPhotoUploadingDate;
                        else
                            personalPhotoUploadingDateParam.Value = DBNull.Value;

                        personalPhotoStatusParam.Value = personalPhotoStatus;

                        if (!string.IsNullOrWhiteSpace(personalPhotoNotes))
                            personalPhotoNotesParam.Value = personalPhotoNotes;
                        else
                            personalPhotoNotesParam.Value = DBNull.Value;

                        if (passport != "")
                            passportParam.Value = passport;
                        else
                            passportParam.Value = DBNull.Value;

                        if (passportUploadingDate != "")
                            passportUploadingDateParam.Value = passportUploadingDate;
                        else
                            passportUploadingDateParam.Value = DBNull.Value;

                        passportNameParam.Value = passportName;
                        passportStatusParam.Value = passportStatus;

                        if (passportExpire != "")
                            passportExpireParam.Value = passportExpire;
                        else
                            passportExpireParam.Value = DBNull.Value;

                        if (!string.IsNullOrWhiteSpace(passportNotes))
                            passportNotesParam.Value = passportNotes;
                        else
                            passportNotesParam.Value = DBNull.Value;

                        if (utility != "")
                            utilityParam.Value = utility;
                        else
                            utilityParam.Value = DBNull.Value;

                        if (utilityUploadingDate != "")
                            utilityUploadingDateParam.Value = utilityUploadingDate;
                        else
                            utilityUploadingDateParam.Value = DBNull.Value;

                        utilityStatusParam.Value = utilityStatus;

                        if (paymentConfirmation != "")
                            paymentConfirmationParam.Value = paymentConfirmation;
                        else
                            paymentConfirmationParam.Value = DBNull.Value;

                        if (paymentConfirmationUploadingDate != "")
                            paymentConfirmationUploadingDateParam.Value = paymentConfirmationUploadingDate;
                        else
                            paymentConfirmationUploadingDateParam.Value = DBNull.Value;

                        paymentConfirmationStatusParam.Value = paymentConfirmationStatus;

                        if (proofOfAddress != "")
                            proofOfAddressParam.Value = proofOfAddress;
                        else
                            proofOfAddressParam.Value = DBNull.Value;

                        if (proofOfAddressUploadingDate != "")
                            proofOfAddressUploadingDateParam.Value = proofOfAddressUploadingDate;
                        else
                            proofOfAddressUploadingDateParam.Value = DBNull.Value;

                        proofOfAddressAddressParam.Value = proofOfAddressAddress;
                        proofOfAddressStatusParam.Value = proofOfAddressStatus;

                        if (proofOfAddressExpire != "")
                            proofOfAddressExpireParam.Value = proofOfAddressExpire;
                        else
                            proofOfAddressExpireParam.Value = DBNull.Value;

                        if (!string.IsNullOrWhiteSpace(proofOfAddressNotes))
                            proofOfAddressNotesParam.Value = proofOfAddressNotes;
                        else
                            proofOfAddressNotesParam.Value = DBNull.Value;

                        if (sourceOfWealth != "")
                            sourceOfWealthParam.Value = sourceOfWealth;
                        else
                            sourceOfWealthParam.Value = DBNull.Value;

                        if (sourceOfWealthUploadingDate != "")
                            sourceOfWealthUploadingDateParam.Value = sourceOfWealthUploadingDate;
                        else
                            sourceOfWealthUploadingDateParam.Value = DBNull.Value;

                        sourceOfWealthStatusParam.Value = sourceOfWealthStatus;

                        if (!string.IsNullOrWhiteSpace(sourceOfWealthNotes))
                            sourceOfWealthNotesParam.Value = sourceOfWealthNotes;
                        else
                            sourceOfWealthNotesParam.Value = DBNull.Value;

                        if (certefiedCopies != "")
                            certefiedCopiesParam.Value = certefiedCopies;
                        else
                            certefiedCopiesParam.Value = DBNull.Value;

                        if (certefiedCopiesUploadingDate != "")
                            certefiedCopiesUploadingDateParam.Value = certefiedCopiesUploadingDate;
                        else
                            certefiedCopiesUploadingDateParam.Value = DBNull.Value;

                        certefiedCopiesStatusParam.Value = certefiedCopiesStatus;

                        if (!string.IsNullOrWhiteSpace(certefiedCopiesNotes))
                            certefiedCopiesNotesParam.Value = certefiedCopiesNotes;
                        else
                            certefiedCopiesNotesParam.Value = DBNull.Value;

                        if (PEPDoc != "")
                            PEPDocParam.Value = PEPDoc;
                        else
                            PEPDocParam.Value = DBNull.Value;

                        PEPStatusParam.Value = PEPStatus;

                        if (!string.IsNullOrWhiteSpace(PEPNotes))
                            PEPNotesParam.Value = PEPNotes;
                        else
                            PEPNotesParam.Value = DBNull.Value;

                        if (PEPUploadingDate != "")
                            PEPUploadingDateParam.Value = PEPUploadingDate;
                        else
                            PEPUploadingDateParam.Value = DBNull.Value;


                        comm.Parameters.AddRange(new SqlParameter[] { userIdParam, overAllStatusParam, personalPhotoParam, personalPhotoUploadingDateParam, personalPhotoStatusParam, personalPhotoNotesParam, passportParam, passportUploadingDateParam, passportNameParam, passportStatusParam, passportExpireParam, passportNotesParam, utilityParam, utilityUploadingDateParam, utilityStatusParam
                    , paymentConfirmationParam, paymentConfirmationUploadingDateParam, paymentConfirmationStatusParam, parameterReturnValue
                ,proofOfAddressParam, proofOfAddressUploadingDateParam, proofOfAddressAddressParam, proofOfAddressStatusParam,proofOfAddressExpireParam,proofOfAddressNotesParam, sourceOfWealthParam, sourceOfWealthUploadingDateParam, sourceOfWealthStatusParam,sourceOfWealthNotesParam, certefiedCopiesParam, certefiedCopiesUploadingDateParam, certefiedCopiesStatusParam, certefiedCopiesNotesParam
                , PEPDocParam, PEPStatusParam, PEPNotesParam, PEPUploadingDateParam
                });

                        sql.Open();
                        SqlDataReader dr = comm.ExecuteReader();

                        int ReturnValue = (int)parameterReturnValue.Value;

                        return ReturnValue;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
    }
}
