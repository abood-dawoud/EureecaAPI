﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Models.UserModels.ViewModesl;
using Microsoft.Extensions.Localization;
using System.Data;
using System.Globalization;
using Tools = Eureeca_API.General.Tools;

namespace Eureeca_API.Repository.UserRepos
{
    public class EntrepreneursRepository : IEntrepreneurs
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        public static IWebHostEnvironment _environment;
        private readonly IUser _user;
        private readonly IPitch _pitch;
        private readonly IGeneral _general;
        private readonly IConfiguration _config;
        private readonly IStringLocalizer<Resources.EntrepreneurRepository> _stringLocalizer;
        public EntrepreneursRepository(IConfiguration config, IWebHostEnvironment environment, IUser user, IPitch pitch, IStringLocalizer<Resources.EntrepreneurRepository> stringLocalizer, IGeneral general)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _environment = environment;
            _user = user;
            _pitch = pitch;
            _config = config;
            _stringLocalizer = stringLocalizer;
            _general = general;
        }


        public EntrepreneursResponse EntrepreneursGetEntrepreneurs(string listEntrepreneurShowFilter, string filterCountryId, int lFirstRec, int lLastRec, string userId, int langId, int currencyId)
        {
            bool hasMore = false;
            int recordCount = 0;
            DataTable dtEntrepreneurs = _user.UserGetEntrepreneursListOffest(listEntrepreneurShowFilter, filterCountryId, langId, lFirstRec, lLastRec, out recordCount);
            if (dtEntrepreneurs.Rows.Count > 0)
            {
                List<Entrepreneurs> entrepreneurs = new List<Entrepreneurs>();
                foreach (DataRow dr in dtEntrepreneurs.Rows)
                {
                    Entrepreneurs entrepreneur = new Entrepreneurs();
                    entrepreneur.UserId = int.Parse(dr["User_ID"].ToString());
                    if (string.IsNullOrEmpty(dr["User_Picture"].ToString()) || !File.Exists(Path.Combine(_config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dr["User_Picture"].ToString())))
                        entrepreneur.UserPicture = _config.GetValue<string>("EnvironmentURL") + "/Images/v2/Default.jpg";
                    else
                        entrepreneur.UserPicture = _config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dr["User_Picture"].ToString();

                    if (!string.IsNullOrEmpty(dr["User_IsFeaturedInvestor"].ToString()) && bool.Parse(dr["User_IsFeaturedInvestor"].ToString()))
                        entrepreneur.UserIsFeaturedInvestor = true;
                    else
                        entrepreneur.UserIsFeaturedInvestor = false;

                    entrepreneur.FeaturedImage = _config.GetValue<string>("AssetsEnvironmentURL") + "images/white-star.png";
                    DateTime dClosingDate = DateTime.ParseExact(dr["Pitch_ClosingDate"].ToString(), "MM/dd/yyyy", CultureInfo.InvariantCulture);
                    int daysLeft = (dClosingDate - DateTime.Now).Days;
                    entrepreneur.PitchDaysLeft = daysLeft < 0 ? 0 : daysLeft;
                    if (entrepreneur.PitchDaysLeft <= 0)
                    {
                        entrepreneur.ProposalStatus = _stringLocalizer["Closed"].Value;
                    }
                    else
                    {
                        entrepreneur.ProposalStatus = _stringLocalizer["DaysLeft"].Value + " " + entrepreneur.PitchDaysLeft.ToString();
                    }
                    entrepreneur.FollowersNumber = dr["Followers"].ToString();
                    entrepreneur.FollowingNumbers = dr["Following"].ToString();
                    entrepreneur.FirstName = dr["Profile_FirstName"].ToString();
                    entrepreneur.LastName = dr["Profile_LastName"].ToString();
                    entrepreneur.PitchId = dr["Pitch_ID"].ToString();
                    entrepreneur.PitchTitle = dr["Profile_PitchTitle"].ToString();
                    entrepreneur.PitchShortSummary = dr["Profile_pitchshortsummary"].ToString();

                    if (userId != null)
                    {
                        int userConnectionId = _user.UserGetUserConnectionId(userId, dr["User_ID"].ToString());
                        if (userConnectionId != 0)
                        {
                            entrepreneur.CanFollow = false;
                        }
                        else
                        {
                            entrepreneur.CanFollow = true;
                        }

                        DataTable dtMostRecentInvestments = _pitch.PitchGetTopThreeInvestment(int.Parse(dr["Pitch_ID"].ToString()), langId, currencyId);

                        entrepreneur.TopThreeInvestment = new List<ProposalInvestor>();
                        if (dtMostRecentInvestments.Rows.Count > 0)
                        {
                            for (int i = 0; i < dtMostRecentInvestments.Rows.Count; i++)
                            {
                                ProposalInvestor proposalInvestor = new ProposalInvestor();
                                proposalInvestor.Investment_Amount = Convert.ToDouble(dtMostRecentInvestments.Rows[i]["Investment_Amount"]);
                                DataTable dtCurreny = _general.CurrencyGetCurrencyByID(currencyId);
                                string currencySymbol = dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$";

                                proposalInvestor.InvestmentAmountFormatted = Tools.FormatNumberWithCurrency(langId, currencySymbol, double.Parse(dtMostRecentInvestments.Rows[i]["Investment_Amount"].ToString()).ToString("#,##0"));

                                proposalInvestor.UserID = Convert.ToInt64(dtMostRecentInvestments.Rows[i]["Investment_UserID"]);
                                proposalInvestor.ProfileFirstName = dtMostRecentInvestments.Rows[i]["user_FirstName"].ToString();
                                proposalInvestor.ProfileLastName = dtMostRecentInvestments.Rows[i]["user_LastName"].ToString();
                                DataTable dtEnrollmentObject = _user.UserGetUserEnrollmentsByLang(int.Parse(proposalInvestor.UserID.ToString()), langId, (int)ObjectsGroups.Badges);
                                if (dtEnrollmentObject.Rows.Count > 0)
                                {
                                    proposalInvestor.ProfileObject = dtEnrollmentObject.Rows[0]["Profile_ObjectTitle"] == null ? "" : dtEnrollmentObject.Rows[0]["Profile_ObjectTitle"].ToString();
                                }
                                else
                                {
                                    entrepreneur.ProfileObjectTitle = _stringLocalizer["RegularUser"].Value;
                                }
                                if (string.IsNullOrEmpty(dtMostRecentInvestments.Rows[i]["user_Pic"].ToString()) || !File.Exists(Path.Combine(_config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dtMostRecentInvestments.Rows[i]["user_Pic"].ToString())))
                                    proposalInvestor.UserImage = _config.GetValue<string>("EnvironmentURL") + "/Images/v2/Default.jpg";
                                else
                                    proposalInvestor.UserImage = _config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dtMostRecentInvestments.Rows[i]["user_Pic"].ToString();
                                proposalInvestor.PitchName = dtMostRecentInvestments.Rows[i]["pitch_Name"].ToString();

                                entrepreneur.TopThreeInvestment.Add(proposalInvestor);
                            }
                        }

                    }

                    #region Badge object
                    entrepreneur.ExpertImage = _config.GetValue<string>("AssetsEnvironmentURL") + "images/circle-arrowsup.png";
                    entrepreneur.IsExpert = _user.UserIsExpert(int.Parse(dr["User_ID"].ToString()));

                    DataTable DtObject = _user.UserGetUserEnrollmentsByLang(int.Parse(dr["User_ID"].ToString()), langId, (int)ObjectsGroups.Badges);
                    if (DtObject.Rows.Count > 0)
                    {
                        entrepreneur.HasBadge = true;
                        entrepreneur.ProfileObjectTitle = DtObject.Rows[0]["Profile_ObjectTitle"] == null ? "" : DtObject.Rows[0]["Profile_ObjectTitle"].ToString();
                        entrepreneur.MasterImageUrlBig = _config.GetValue<string>("EnvironmentURL") + DtObject.Rows[0]["Master_ImageUrlBig"].ToString();
                        entrepreneur.MasterImageUrl = _config.GetValue<string>("EnvironmentURL") + DtObject.Rows[0]["Master_ImageUrl"].ToString();
                    }
                    else
                    {
                        entrepreneur.ProfileObjectTitle = _stringLocalizer["RegularUser"].Value;
                        entrepreneur.HasBadge = false;
                        entrepreneur.MasterImageUrlBig = _config.GetValue<string>("AssetsEnvironmentURL") + "images/badge_Regular.png";
                        entrepreneur.MasterImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/badge_Regular.png";
                    }
                    #endregion

                    entrepreneurs.Add(entrepreneur);

                }
                hasMore = recordCount > ((lFirstRec + 1) * lLastRec);

                EntrepreneursResponse response = new EntrepreneursResponse(200, true, recordCount, hasMore, lFirstRec, entrepreneurs);
                return response;
            }
            // No data.
            else
            {
                List<Entrepreneurs> entrepreneurs = new List<Entrepreneurs>();
                EntrepreneursResponse response = new EntrepreneursResponse(200, true, 0, false, lFirstRec, entrepreneurs);
                return response;
            }
        }
    }
}
