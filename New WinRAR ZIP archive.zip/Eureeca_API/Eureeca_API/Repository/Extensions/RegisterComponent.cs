﻿using Eureeca_API.Interface;
using Eureeca_API.Interface.AccountInterface;
using Eureeca_API.Interface.CountryBasedInterface;
using Eureeca_API.Interface.InboxInterface;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Repository.AccountRepos;
using Eureeca_API.Repository.CountryBasedRepos;
using Eureeca_API.Repository.GeneralRepos;
using Eureeca_API.Repository.InvestmentRepos;
using Eureeca_API.Repository.MessageRepos;
using Eureeca_API.Repository.PitchRepos;
using Eureeca_API.Repository.UserRepos;

namespace Eureeca_API.Repository.Extensions
{
    public static class RegisterComponent
    {
        public static void RegisterComponents(this IServiceCollection serviceDescriptors)
        {
            serviceDescriptors.AddScoped<IGeneral, GeneralRepository>();
            serviceDescriptors.AddScoped<IPitch, PitchRepository>();
            serviceDescriptors.AddScoped<ICountryBasedControl, CountryBasedControlRepository>();
            serviceDescriptors.AddScoped<INews, NewsRepository>();
            serviceDescriptors.AddScoped<IUser, UserRepository>();
            serviceDescriptors.AddScoped<IPitchAttachements, PitchAttachementsRepository>();
            serviceDescriptors.AddScoped<IPitchLikeFollower, PitchLikeFollowerRepository>();
            serviceDescriptors.AddScoped<IMessage, MessageRepository>();
            serviceDescriptors.AddScoped<IInternalMessage, InternalMessageRepository>();
            serviceDescriptors.AddScoped<IConfig, ConfigRepository>();
            serviceDescriptors.AddScoped<ITopic, TopicRepository>();
            serviceDescriptors.AddScoped<IAgreement, AgreementRepository>();
            serviceDescriptors.AddScoped<IGeoIP, GeoIPRepository>();
            serviceDescriptors.AddScoped<ICustomForumUser, CustomForumUserRepository>();
            serviceDescriptors.AddScoped<ILead, LeadRepository>();
            serviceDescriptors.AddScoped<IAccount, AccountRepository>();
            serviceDescriptors.AddScoped<IAlert, AlertRepository>();
            serviceDescriptors.AddScoped<ISuitabilityTest, SuitabilityTestRepository>();
            serviceDescriptors.AddScoped<IKYC, KYCRepository>();
            serviceDescriptors.AddScoped<IEntrepreneurs, EntrepreneursRepository>();
			serviceDescriptors.AddScoped<IInvestors, InvestorsRepository>();
			serviceDescriptors.AddScoped<ISurvey, SurveyRepository>();
			serviceDescriptors.AddScoped<IMainImages, MainImagesRepository>();
			serviceDescriptors.AddScoped<IPitchScore, PitchScoreRepository>();
			serviceDescriptors.AddScoped<IInvestment, InvestmentRepository>();
			serviceDescriptors.AddScoped<IPaymentUserProposalRelation, PaymentUserProposalRelationRepository>();
            serviceDescriptors.AddScoped<IPaymentSelector, PaymentSelectorRepository>();
            serviceDescriptors.AddScoped<IUserObjects, UserObjectsRepository>();
            serviceDescriptors.AddScoped<ICountryBasedBankDetails, CountryBasedBankDetailsRepository>();
            serviceDescriptors.AddScoped<IPayment, PaymentRepository>();
        }
    }
}
