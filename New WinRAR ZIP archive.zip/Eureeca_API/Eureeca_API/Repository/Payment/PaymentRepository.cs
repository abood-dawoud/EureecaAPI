﻿using Eureeca_API.General;
using Eureeca_API.Interface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository
{
    public class PaymentRepository : IPayment
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;

        public PaymentRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();  
        }

        /// <summary>
        /// This method is used to Get the user amount in the USD for the accepted payments for one year before today
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public DataTable PaymentGetUserAnnualPayments(int userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                return _sqlHelper.GetDataTable(_connectionString, "Payment_GetUserAnnualPayments", paramUserId);                   
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

    }
}
