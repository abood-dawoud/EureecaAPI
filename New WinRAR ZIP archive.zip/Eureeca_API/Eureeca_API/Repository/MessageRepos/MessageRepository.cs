﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Interface.InboxInterface;
using Eureeca_API.Interface.UserInterface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.MessageRepos
{
    public class MessageRepository : IMessage
    {
        private string _subject = "", _body = "", _alias = "Eureeca";

        private readonly string _connectionString;
        private readonly string _connectionString2;
        private readonly IUser _user;
        private readonly IInternalMessage _internalMessage;
        private readonly IConfig _config;
        private readonly IConfiguration _configuration;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;

        public MessageRepository(IConfiguration configuration, IUser user, IInternalMessage internalMessage, IConfig config)
        {
            _connectionString = configuration.GetConnectionString("mailConnection");
            _connectionString2 = configuration.GetConnectionString("dbConnection");
            _configuration = configuration;
            _user = user;
            _internalMessage = internalMessage;
            _config = config;
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }
        public void MessageSendMessageForUserFollowers(DataRow sender, DataTable dtFollowers, DataRow user, string actionPitchTitle, int actionProposalId, string actionUserName, int actionUserId, UserAction action)
        {
            try
            {
                foreach (DataRow drFollower in dtFollowers.Rows)
                {
                    if (action == UserAction.InvestmentInviteFriends)
                    {
                        _subject = "I just invested in " + actionPitchTitle + "on Eureeca – check it out";
                        _body = "Hi " + drFollower["Profile_FirstName"].ToString() +
                                "<br /><br />I thought of sharing with you that I have just invested in <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + actionProposalId + "'>" + actionPitchTitle + "</a> on Eureeca.com. Perhaps you would be interested in this great opportunity as well." +
                                "<br /><br />If you have not had the opportunity to check out the proposal yet, I would recommend you do so." +
                                "<br /><br />Take a look, and if you like what you see credit your account by credit card or bank transfer and join me a shareholder <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + actionProposalId + "'>" + actionPitchTitle + "</a>." +
                                "<br /><br />Thanks" +
                                "<br /><br />" + user["User_Username"].ToString();
                    }
                    else if (action == UserAction.PitchInvestment)
                    {
                        _subject = user["User_Username"] + " invested in " + actionPitchTitle;
                        _body = "Hi " + drFollower["Profile_FirstName"].ToString() +
                                "<br /><br />The user you are following <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + user["User_ID"] + "'>" + user["User_Username"] + "</a> has invested in " + "<a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + actionProposalId + "'>" + actionPitchTitle + "</a>" +
                                "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                                "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drFollower["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                                "<br /><br />The team at Eureeca";
                    }
                    else if (action == UserAction.AddCommentToUser)
                    {
                        _subject = user["User_Username"] + " added a new comment";
                        _body = "Hi " + drFollower["Profile_FirstName"].ToString() +
                                "<br /><br />The user you are following <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + user["User_ID"] + "'>" + user["User_Username"] + "</a> has added " + "<a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + actionUserId + "'>a new comment.</a>" +
                                "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                                "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drFollower["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                                "<br /><br />The team at Eureeca";
                    }
                    else if (action == UserAction.AddCommentToProposal)
                    {
                        _subject = user["User_Username"] + " added a new comment";
                        _body = "Hi " + drFollower["Profile_FirstName"].ToString() +
                                "<br /><br />The user you are following <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + user["User_ID"] + "'>" + user["User_Username"] + "</a> has added " + "<a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + actionProposalId + "&tabID=4'>a new comment.</a>" +
                                "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                                "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drFollower["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                                "<br /><br />The team at Eureeca";
                    }
                    else if (action == UserAction.AddQuestionToUser)
                    {
                        _subject = user["User_Username"] + " added a new question";
                        _body = "Hi " + drFollower["Profile_FirstName"].ToString() +
                                "<br /><br />The user you are following <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + user["User_ID"] + "'>" + user["User_Username"] + "</a> has added " + "<a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + actionUserId + "&tabID=2'>a new question.</a>" +
                                "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                                "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drFollower["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                                "<br /><br />The team at Eureeca";
                    }
                    else if (action == UserAction.AddQuestionToProposal)
                    {
                        _subject = user["User_Username"] + " added a new question";
                        _body = "Hi " + drFollower["Profile_FirstName"].ToString() +
                                "<br /><br />The user you are following <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + user["User_ID"] + "'>" + user["User_Username"] + "</a> has added " + "<a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + actionProposalId + "&tabID=3'>a new question.</a>" +
                                "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                                "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drFollower["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                                "<br /><br />The team at Eureeca";
                    }
                    else if (action == UserAction.AddAnswerToUser)
                    {
                        _subject = user["User_Username"] + " answered on a new question";
                        _body = "Hi " + drFollower["Profile_FirstName"].ToString() +
                                "<br /><br />The user you are following <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + user["User_ID"] + "'>" + user["User_Username"] + "</a> has answered " + "<a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + actionUserId + "&tabID=2'>a question.</a>" +
                                "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                                "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drFollower["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                                "<br /><br />The team at Eureeca";
                    }
                    else if (action == UserAction.AddAnswerToProposal)
                    {
                        _subject = user["User_Username"] + " answered on a new question";
                        _body = "Hi " + drFollower["Profile_FirstName"].ToString() +
                                "<br /><br />The user you are following <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + user["User_ID"] + "'>" + user["User_Username"] + "</a> has answered " + "<a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + actionProposalId + "&tabID=3'>a question.</a>" +
                                "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                                "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drFollower["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                                "<br /><br />The team at Eureeca";
                    }
                    else if (action == UserAction.FollowUser)
                    {
                        _subject = user["User_Username"] + " followed " + actionUserName;
                        _body = "Hi " + drFollower["Profile_FirstName"].ToString() +
                                "<br /><br />The user you are following <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + user["User_ID"] + "'>" + user["User_Username"] + "</a> is now following " + "<a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + actionUserId + "'>" + actionUserName + "</a>" +
                                "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                                "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drFollower["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                                "<br /><br />The team at Eureeca";
                    }
                    else if (action == UserAction.FollowProposal)
                    {
                        _subject = user["User_Username"] + " followed " + actionPitchTitle;
                        _body = "Hi " + drFollower["Profile_FirstName"].ToString() +
                                "<br /><br />The user you are following <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + user["User_ID"] + "'>" + user["User_Username"] + "</a> is now following " + "<a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + actionProposalId + "'>" + actionPitchTitle + "</a>" +
                                "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                                "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drFollower["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                                "<br /><br />The team at Eureeca";
                    }

                    MessageSendMessage(sender, _subject, _body, drFollower, sender["User_Email"].ToString());
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);

            }
        }

        public void MessageSendProposalActionsEmail(DataRow sender, DataTable admins, DataRow proposal, DataRow owner, string customBody, PitchAction action)
        {
            try
            {
                string firstName = owner["Profile_FirstName"].ToString();
                string User_guid = owner["User_guid"].ToString();

                if (action == PitchAction.PublishedExpireSoon)
                {
                    _subject = "Your proposal " + proposal["Profile_PitchTitle"].ToString() + " will expire soon";
                    _body = "Hi " + firstName +
                            "<br /><br />Your proposal is going to expire shortly. You have 15 days left. It’s time for the final push toward reaching your target. Once that target has been reached you will very soon gain access to the development capital you need to move your business on." +
                            "<br /><br />Remember, if your proposal does expire without hitting its minimum target, all current investment commitments will be reversed and refunded to the crowd." +
                            "<br /><br />Why don’t you get in contact with your Entrepreneur Manager to discuss how you can obtain the final funds that need to be raised?" +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options. " +
                            "<br /><br />Regards," +
                            "<br /><br />Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());

                    _body = "This message was sent to the proposal owner <br /><br />========================================<br /><br />" +
                            "<br /><br />Hi " + firstName +
                            "<br /><br />Your proposal is going to expire shortly. You have 15 days left. It’s time for the final push toward reaching your target. Once that target has been reached you will very soon gain access to the development capital you need to move your business on." +
                            "<br /><br />Remember, if your proposal does expire without hitting its minimum target, all current investment commitments will be reversed and refunded to the crowd." +
                            "<br /><br />Why don’t you get in contact with your Entrepreneur Manager to discuss how you can obtain the final funds that need to be raised?" +
                            "<br /><br />Regards," +
                            "<br /><br />Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, admins);
                }
                else if (action == PitchAction.OvefundingExpireSoon)
                {
                    _subject = "Your proposal " + proposal["Profile_PitchTitle"].ToString() + " will expire soon";
                    _body = "Hi " + firstName +
                            "<br /><br />Your proposal is going to expire shortly. You have 15 days left. Your proposal is in Overfunding mode." +
                            "<br /><br />Why don’t you get in contact with your Entrepreneur Manager to discuss the next steps." +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options. " +
                            "<br /><br />Regards," +
                            "<br /><br />Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());

                    _body = "This message was sent to the proposal owner <br /><br />========================================<br /><br />" +
                            "<br /><br />Hi " + firstName +
                            "<br /><br />Your proposal is going to expire shortly. You have 15 days left. Your proposal is in Overfunding mode." +
                            "<br /><br />Why don’t you get in contact with your Entrepreneur Manager to discuss the next steps." +
                            "<br /><br />Regards," +
                            "<br /><br />Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, admins);
                }
                else if (action == PitchAction.ExtendedForOwner)
                {
                    _subject = "Proposal has been extended";
                    _body = "Hi " + firstName +
                            "<br /><br /> Your proposal named " + proposal["Profile_PitchTitle"].ToString() + " has been extended to " + proposal["Pitch_ClosingDate"].ToString() +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options. " +
                            "<br /><br />Thanks!<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                    _body = "This message was sent to the proposal owner <br />========================================<br /><br />" + _body;
                    MessageSendMessage(sender, _subject, _body, admins);
                }
                else if (action == PitchAction.ErrorInRefunding)
                {
                    _subject = "Error in refunding " + proposal["Profile_PitchTitle"].ToString();
                    _body = "There is an error in refunding proposal " + proposal["Profile_PitchTitle"].ToString();
                    MessageSendMessage(sender, _subject, _body, admins);
                }
                else if (action == PitchAction.ApproveUpdate)
                {
                    _subject = "Your update was approved";
                    _body = "Update was approved" +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options." +
                            "<br /><br />Regards," +
                            "<br /><br />Eureeca Team";

                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                }
                else if (action == PitchAction.RejectUpdate)
                {
                    _subject = "Your update was not approved";
                    _body = customBody +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options." +
                            "<br /><br />Regards," +
                            "<br /><br />Eureeca Team";

                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                }
                else if (action == PitchAction.rejectProposal)
                {
                    _subject = "Proposal was not approved";
                    _body = customBody +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options." +
                            "<br /><br />Regards," +
                            "<br /><br />Eureeca Team";

                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public void MessageSendPithStatusChangesEmail(DataRow sender, DataTable admins, DataRow owner, DataRow proposal, PitchStatus currentStatus, PitchStatus newStatus)
        {
            try
            {
                string pitchTitle = proposal["Profile_PitchTitle"].ToString();
                string firstName = owner["Profile_FirstName"].ToString();
                string User_guid = owner["User_guid"].ToString();

                if (currentStatus == PitchStatus.NotReady && newStatus == PitchStatus.SubmittedForApproval)
                {
                    _subject = "Confirmation of proposal submission";
                    _body = "Hi " + firstName
                        + "<br /><br /> Your proposal named " + pitchTitle
                        + " was submitted for approval."
                        + "<br /><br />Our Investment Committee will review this and will get in touch with you very shortly."
                        + "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options."
                        + "<br /><br />Thanks!"
                        + "<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                    _body = "This message was sent to the proposal owner <br />========================================<br /><br />" +
                        "Hi " + firstName +
                        "<br /><br /> Your proposal named " + pitchTitle +
                        " was submitted for approval.<br /><br />" +
                        "Our Investment Committee will review this and will get in touch with you very shortly." +
                        "<br /><br />Thanks!<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, admins);
                }
                else if (currentStatus == PitchStatus.NotReady && newStatus == PitchStatus.ComingSoon)
                {
                    _subject = "Confirmation of proposal submission";
                    _body = "Hi " + firstName +
                        "<br /><br /> Your proposal named " + pitchTitle +
                        " was submitted for approval with \"coming soon\" status.<br /><br />" +
                        "Our Investment Committee will review this and will get in touch with you very shortly." +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options. " +
                        "<br /><br />Thanks!<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                    _body = "This message was sent to the proposal owner <br />========================================<br /><br />" +
                        "Hi " + firstName +
                        "<br /><br /> Your proposal named " + pitchTitle +
                        " was submitted for approval with \"coming soon\" status.<br /><br />" +
                        "Our Investment Committee will review this and will get in touch with you very shortly." +
                        "<br /><br />Thanks!<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, admins);
                }
                else if ((currentStatus == PitchStatus.SubmittedForApproval || currentStatus == PitchStatus.ComingSoon) && newStatus == PitchStatus.EarlyAccess)
                {
                    _subject = "Your proposal " + pitchTitle + " is now live with \"Early Access\" status";
                    _body = "Hi " + firstName +
                        "<br /><br />Your proposal named " + pitchTitle + " has been approved with \"Early Access\" status." +
                        "<br /><br />Your Entrepreneur Manager will be in touch to guide you through anything you need." +
                        "<br /><br />Looking forward to seeing you on eureeca.com." +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options." +
                        "<br /><br />Thanks!" +
                        "<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                }
                else if (currentStatus == PitchStatus.EarlyAccess && newStatus == PitchStatus.SubmittedForApproval)
                {
                    _subject = "Confirmation of proposal submission";
                    _body = "Hi " + firstName +
                        "<br /><br /> Your proposal named " + pitchTitle +
                        " was submitted for approval.<br /><br />" +
                        "Our Investment Committee will review this and will get in touch with you very shortly." +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options. " +
                        "<br /><br />Thanks!" +
                        "<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                    _body = "This message was sent to the proposal owner <br />========================================<br /><br />" +
                        "Hi " + firstName +
                        "<br /><br /> Your proposal named " + pitchTitle +
                        " was submitted for approval.<br /><br />" +
                        "Our Investment Committee will review this and will get in touch with you very shortly." +
                        "<br /><br />Thanks!" +
                        "<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, admins);
                }
                else if (currentStatus == PitchStatus.SubmittedForApproval && newStatus == PitchStatus.Published)
                {
                    _subject = "Your proposal " + pitchTitle + " is now live";
                    _body = "Hi " + firstName +
                        "<br /><br />Your proposal named " + pitchTitle + " has been approved! " +
                        "<br /><br />Your Entrepreneur Manager will be in touch to guide you through anything you need." +
                        "<br /><br />Looking forward to seeing you on eureeca.com." +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options." +
                        "<br /><br />Thanks!" +
                        "<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                }
                else if (currentStatus == PitchStatus.EarlyAccess && newStatus == PitchStatus.Published)
                {
                    _subject = "Your proposal " + pitchTitle + " is now live";
                    _body = "Hi " + firstName +
                        "<br /><br />Your proposal named " + pitchTitle + " has been approved! " +
                        "<br /><br />Your Entrepreneur Manager will be in touch to guide you through anything you need." +
                        "<br /><br />Looking forward to seeing you on eureeca.com." +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options." +
                        "<br /><br />Thanks!" +
                        "<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                }
                else if (currentStatus == PitchStatus.Published && newStatus == PitchStatus.Expired)
                {
                    _subject = "Your proposal didn’t hit its target";
                    _body = "Hi " + firstName +
                        "<br /><br />Unfortunately your Proposal, " + pitchTitle + " has expired without reaching your funding target." +
                        "<br /><br />All pending investment transactions will be reversed & refunded shortly." +
                        "<br /><br />You can relist your proposal. Your Entrepreneur Manager will be in contact to discuss what went wrong and how we can improve the chances of getting funded next time." +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options." +
                        "<br /><br />Regards,<br /><br />Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                    _body = "This message was sent to the proposal owner <br />========================================<br /><br />" +
                            "Hi " + firstName +
                            "<br /><br />Unfortunately your Proposal, " + pitchTitle + " has expired without reaching your funding target." +
                            "<br /><br />All pending investment transactions will be reversed & refunded shortly." +
                            "<br /><br />You can relist your proposal. Your Entreprneur Manager will be in contact to discuss what went wrong and how we can improve the chances of getting funded next time." +
                            "<br /><br />Regards,<br /><br />Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, admins);
                }
                else if (currentStatus == PitchStatus.Published && newStatus == PitchStatus.MinimumFunded)
                {
                    _subject = "Minimum-Funded";
                    _body = "Hi " + firstName +
                        "<br /><br />Great news! This email is to confirm that your funding proposal named " + pitchTitle + " reached its minimum funding target." +
                        "<br /><br />You will receive an email from us shortly with information on the next steps. Alternatively you can get straight in contact with your Entrepreneur Manager to discuss further. " +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options." +
                        "<br /><br />Regards,<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                    _body = "This message was sent to the proposal owner <br />========================================<br /><br />" +
                        "Hi " + firstName +
                        "<br /><br />Great news! This email is to confirm that your funding proposal named " + pitchTitle + " reached its minimum funding target." +
                        "<br /><br />You will receive an email from us shortly with information on the next steps. Alternatively you can get straight in contact with your Entrepreneur Manager to discuss further. " +
                        "<br /><br />Regards,<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, admins);
                }
                else if (currentStatus == PitchStatus.Published && newStatus == PitchStatus.Completed)
                {
                    _subject = "Funding target reached!";
                    _body = "Hi " + firstName +
                        "<br /><br />Great news! This email is to confirm that your funding proposal named " + pitchTitle + " was completed and the requested investment target was hit." +
                        "<br /><br />You will receive an email from us shortly with information on the next steps. Alternatively you can get straight in contact with your Entrepreneur Manager to discuss further. " +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options. " +
                        "<br /><br />Regards," +
                        "<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                    _body = "This message was sent to the proposal owner <br />========================================<br /><br />" +
                        "Hi " + firstName +
                        "<br /><br />Great news! This email is to confirm that your funding proposal named " + pitchTitle + " was completed and the requested investment target was hit." +
                        "<br /><br />You will receive an email from us shortly with information on the next steps. Alternatively you can get straight in contact with your Entrepreneur Manager to discuss further. " +
                        "<br /><br />Regards," +
                        "<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, admins);
                }
                else if (currentStatus == PitchStatus.Published && newStatus == PitchStatus.OverFunding)
                {
                    _subject = "Your proposal is now in Overfunding mode";
                    _body = "Hi " + firstName +
                        "<br /><br />Great News! This email is to confirm that your funding  proposal named " + pitchTitle + " reached its target and is in overfunding mode." +
                        "<br /><br />Your Entrepreneur Manager will be in touch to guide you through anything you need." +
                        "<br /><br />Looking forward to seeing you on eureeca.com." +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options." +
                        "<br /><br />Thanks!" +
                        "<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                    _body = "This message was sent to the proposal owner <br />========================================<br /><br />" +
                        "Hi " + firstName +
                        "<br /><br />Great News! This email is to confirm that your funding  proposal named " + pitchTitle + " reached its target and is in overfunding mode." +
                        "<br /><br />Your Entrepreneur Manager will be in touch to guide you through anything you need." +
                        "<br /><br />Looking forward to seeing you on eureeca.com." +
                        "<br /><br />Thanks!" +
                        "<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, admins);
                }
                else if (currentStatus == PitchStatus.Published && newStatus == PitchStatus.Cancelled)
                {
                    _subject = "Your proposal " + pitchTitle + " was cancelled";
                    _body = "Hi " + firstName +
                        "<br /><br />This email is to confirm that your funding  proposal named " + pitchTitle + " was cancelled." +
                        "<br /><br />All pending investment transactions will be reversed & refunded shortly." +
                        "<br /><br />Your Entrepreneur Manager will be in touch to guide you through anything you need." +
                        "<br /><br />Looking forward to seeing you on eureeca.com." +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options." +
                        "<br /><br />Thanks!" +
                        "<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                    _body = "This message was sent to the proposal owner <br />========================================<br /><br />" +
                        "Hi " + firstName +
                        "<br /><br />This email is to confirm that your funding  proposal named " + pitchTitle + " was cancelled." +
                        "<br /><br />All pending investment transactions will be reversed & refunded shortly." +
                        "<br /><br />Your Entrepreneur Manager will be in touch to guide you through anything you need." +
                        "<br /><br />Looking forward to seeing you on eureeca.com." +
                        "<br /><br />Thanks!" +
                        "<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, admins);
                }
                else if (currentStatus == PitchStatus.Cancelled && newStatus == PitchStatus.CancelledAndClosed)
                {
                    _subject = "Your proposal " + pitchTitle + " was cancelled";
                    _body = "Hi " + firstName +
                        "<br /><br />This email is to confirm that your funding  proposal named " + pitchTitle + " was cancelled." +
                        "<br /><br />All pending investment transactions were reversed and refunded." +
                        "<br /><br />Your Entrepreneur Manager will be in touch to guide you through anything you need." +
                        "<br /><br />Looking forward to seeing you on eureeca.com." +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options." +
                        "<br /><br />Thanks!" +
                        "<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                    _body = "This message was sent to the proposal owner <br />========================================<br /><br />" +
                        "Hi " + firstName +
                        "<br /><br />This email is to confirm that your funding  proposal named " + pitchTitle + " was cancelled." +
                        "<br /><br />All pending investment transactions were reversed and refunded." +
                        "<br /><br />Your Entrepreneur Manager will be in touch to guide you through anything you need." +
                        "<br /><br />Looking forward to seeing you on eureeca.com." +
                        "<br /><br />Thanks!" +
                        "<br /><br />The Eureeca Team";
                    MessageSendMessage(sender, _subject, _body, admins);
                }
                else if (currentStatus == PitchStatus.OverFunding && newStatus == PitchStatus.OverFunded)
                {
                    _subject = "Overfunding target reached!";
                    _body = "Hi " + firstName +
                        "<br /><br />Great news! This email is to confirm that your funding proposal named " + pitchTitle + " was completed and the requested Overfunding investment target was hit." +
                        "<br /><br />You will receive an email from us shortly with information on the next steps. Alternatively you can get straight in contact with your Entrepreneur Manager to discuss further. " +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options. " +
                        "<br /><br />Regards," +
                        "<br /><br />The team at Eureeca";
                    MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                    _body = "This message was sent to the proposal owner <br />========================================<br /><br />" +
                        "Hi " + firstName +
                        "<br /><br />Great news! This email is to confirm that your funding proposal named " + pitchTitle + " was completed and the requested Overfunding investment target was hit." +
                        "<br /><br />You will receive an email from us shortly with information on the next steps. Alternatively you can get straight in contact with your Entrepreneur Manager to discuss further. " +
                        "<br /><br />Regards," +
                        "<br /><br />The team at Eureeca";
                    MessageSendMessage(sender, _subject, _body, admins);
                }
                else if (currentStatus == PitchStatus.OverFunding && newStatus == PitchStatus.Completed)
                {
                    float Pitch_Balance = float.Parse(proposal["Pitch_Balance"].ToString()),
                       Pitch_InvestmentRequired = float.Parse(proposal["Pitch_InvestmentRequired"].ToString());
                    _subject = "Funding target reached!";
                    if (Pitch_Balance > Pitch_InvestmentRequired)
                    {
                        _body = "Hi " + firstName +
                           "<br /><br />Great news! This email is to confirm that your funding proposal named " + pitchTitle + " was completed with overfunding." +
                           "<br /><br />You will receive an email from us shortly with information on the next steps. Alternatively you can get straight in contact with your Entrepreneur Manager to discuss further. " +
                           "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options. " +
                           "<br /><br />Regards," +
                           "<br /><br />The team at Eureeca";
                        MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                        _body = "This message was sent to the proposal owner <br />========================================<br /><br />" +
                           "Hi " + firstName +
                           "<br /><br />Great news! This email is to confirm that your funding proposal named " + pitchTitle + " was completed with overfunding." +
                           "<br /><br />You will receive an email from us shortly with information on the next steps. Alternatively you can get straight in contact with your Entrepreneur Manager to discuss further. " +
                           "<br /><br />Regards," +
                           "<br /><br />The team at Eureeca";
                        MessageSendMessage(sender, _subject, _body, admins);
                    }
                    else
                    {
                        _body = "Hi " + firstName +
                            "<br /><br />Great news! This email is to confirm that your funding proposal named " + pitchTitle + " was completed and the requested investment target was hit.  No more investments will be accepted." +
                            "<br /><br />You will receive an email from us shortly with information on the next steps. Alternatively you can get straight in contact with your Entrepreneur Manager to discuss further. " +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User_guid + "'>here</a> to change your notifications options. " +
                            "<br /><br />Regards," +
                            "<br /><br />The team at Eureeca";
                        MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
                        _body = "This message was sent to the proposal owner <br />========================================<br /><br />" +
                            "Hi " + firstName +
                            "<br /><br />Great news! This email is to confirm that your funding proposal named " + pitchTitle + " was completed and the requested investment target was hit.  No more investments will be accepted." +
                            "<br /><br />You will receive an email from us shortly with information on the next steps. Alternatively you can get straight in contact with your Entrepreneur Manager to discuss further. " +
                            "<br /><br />Regards," +
                            "<br /><br />The team at Eureeca";
                        MessageSendMessage(sender, _subject, _body, admins);
                    }
                }

                ///////////////////////By Mahmoued Abu Abdo///////////////////////////////////////////////
                ///////////////////Send Notification To All Pitch Followers ///////////////////////////
                string Pitch_ID = proposal["Pitch_ID"].ToString();
                string Pitch_UserID = proposal["Pitch_UserID"].ToString();
                DataTable DTFollowrs = _user.UserGetAllPitchFollower(Pitch_ID);

                if (DTFollowrs.Rows.Count > 0)
                {
                    string ScurrentStatus = PitchGetStatus(currentStatus);
                    string SnewStatus = PitchGetStatus(newStatus);

                    foreach (DataRow r in DTFollowrs.Rows)
                        _user.UserAddNotification(Pitch_UserID, r["User_ID"].ToString(), ScurrentStatus + "_" + SnewStatus, NotificationType.ProposalStatusChange);
                }
                ///////////////////////////////////////////////////////////////
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        public void MessageSendMessageForPitchUsers(DataRow sender, DataTable dtUsers, string pitchTitle, string proposalId, string ownerFirstName, PitchAction action)
        {
            try
            {
                foreach (DataRow drUser in dtUsers.Rows)
                {

                    if (action == PitchAction.PublishedForFollowers)
                    {
                        _subject = "Proposal is now live";
                        _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                            "<br /><br />We have great news! " + pitchTitle + ", the proposal you are following on eureeca.com is now live and is accepting investments" +
                            "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a>" +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />Congratulations again!" +
                            "<br /><br />The Eureeca Team";
                    }
                    else if (action == PitchAction.MinimumFundedForFollowers)
                    {
                        _subject = "Minimum funding target reached!";
                        _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                            "<br /><br />We have great news! " + pitchTitle + ", the proposal you are following on eureeca.com has just reached its minimum funding target!" +
                            "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />Congratulations again!" +
                            "<br /><br />The Eureeca Team";
                    }
                    else if (action == PitchAction.MinimumFundedForInvestors)
                    {
                        _subject = "Minimum funding target reached!";
                        _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                            "<br /><br />We have great news! " + pitchTitle + ", the proposal you invested in, on eureeca.com has just reached its minimum funding target! Congratulations!" +
                            "<br /><br />What’s next? " +
                            "<br /><br />Our legal team will be working through the technicalities to finalize the share swap – you can expect to hear from us within the next few weeks with an update." +
                            "<br /><br />You can expect to hear from " + ownerFirstName + ", the entrepreneur behind " + pitchTitle + ", very soon. " +
                            "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />Congratulations again!" +
                            "<br /><br />The team at Eureeca";
                    }
                    else if (action == PitchAction.ExpiredForFollowers)
                    {
                        _subject = "A proposal you followed has expired";
                        _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                            ", <br /><br />Unfortunately " + pitchTitle + ", a proposal you are following on eureeca.com has not succeeded in reaching its funding goal." +
                            "<br /><br />There are still plenty of great businesses on eureeca.com so please take a look to see if there is anything else you are interested in. If not, stay tuned as new proposals are being uploaded all the time." +
                            "<br /><br />If you have any questions, we are here to help! Please get in touch with us at <a href='mailto:investors@eureeca.com'>investors@eureeca.com</a>" +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />See you on eureeca.com very soon!" +
                            "<br /><br />The Eureeca Team";
                    }
                    else if (action == PitchAction.ExpiredForInvestors)
                    {
                        _subject = "A proposal you invested in has expired";
                        _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                            ", <br /><br />Unfortunately, " + pitchTitle + ", a proposal you made an investment commitment for on eureeca.com, has failed to reach its funding goal. The funds you committed to this proposal will be returned to your Eureeca account." +
                            "<br /><br />There are plenty of great businesses on eureeca.com so take a look and see if there is anything else you are interested in investing in. If not, new proposals are being uploaded all the time." +
                            "<br /><br />If you have any questions we are here to help! Please get in touch with us at <a href='mailto:investors@eureeca.com'>investors@eureeca.com</a>" +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />See you back on eureeca.com very soon!" +
                            "<br /><br />The team at Eureeca";
                    }
                    else if (action == PitchAction.CompletedForFollowers)
                    {
                        _subject = "Funding target reached!";
                        _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                            "<br /><br />We have great news! " + pitchTitle + ", the proposal you are following on eureeca.com has just reached 100% of its funding goal!" +
                            "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />Congratulations again!" +
                            "<br /><br />The Eureeca Team";
                    }
                    else if (action == PitchAction.ExtraCompletedForFollowers)
                    {
                        _subject = "Funding target reached!";
                        _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                            "<br /><br />We have great news! " + pitchTitle + ",  the proposal you are following on eureeca.com has been overfunded and closed." +
                            "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />Congratulations again!" +
                            "<br /><br />The Eureeca Team";
                    }
                    else if (action == PitchAction.ExtraCompletedForInvestors)
                    {
                        _subject = "Funding target reached!";
                        _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                            "<br /><br />We have great news! " + pitchTitle + ", the proposal you invested in, on eureeca.com has just reached 100% of its funding goal! and was Overfunded, Congratulations!" +
                            "<br /><br />What’s next? " +
                            "<br /><br />Our legal team will be working through the technicalities to finalize the share swap – you can expect to hear from us within the next few weeks with an update." +
                            "<br /><br />You can expect to hear from " + ownerFirstName + ", the entrepreneur behind " + pitchTitle + ", very soon. " +
                            "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />Congratulations again!" +
                            "<br /><br />The team at Eureeca";
                    }
                    else if (action == PitchAction.OverfundingForFollowers)
                    {
                        _subject = "Funding target reached! and the proposal is now open for Overfunding";
                        _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                            "<br /><br />We have great news! " + pitchTitle + ", the proposal you are following on eureeca.com has just reached 100% and the proposal is now open for overfunding." +
                            "<br /><br />If you have any questions or issues please don’t hesitate to contact us at " +
                            "<br /> <a href='mailto:support@eureeca.com'>support@eureeca.com</a>" +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />Congratulations again!" +
                            "<br /><br />The Eureeca Team";
                    }
                    else if (action == PitchAction.OverfundingForInvestors)
                    {
                        _subject = "Funding target reached! and the proposal is now open for Overfunding";
                        _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                            "<br /><br />We have great news! " + pitchTitle + ", the proposal you invested in, on eureeca.com has just reached 100% and the proposal is now open for Overfunding" +
                            "<br /><br />If you have any questions or issues please don’t hesitate to contact us at " +
                            "<br /> <a href='mailto:support@eureeca.com'>support@eureeca.com</a>" +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />Congratulations again!" +
                            "<br /><br />The team at Eureeca";
                    }
                    else if (action == PitchAction.CompletedForInvestors || action == PitchAction.OverfundedForInvestors)
                    {
                        if (action == PitchAction.CompletedForInvestors)
                            _subject = "Funding target reached!";
                        else if (action == PitchAction.OverfundedForInvestors)
                            _subject = "Overfunding target reached!";

                        _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                            "<br /><br />We have great news! " + pitchTitle + ", the proposal you invested in, on eureeca.com has just reached 100% of its funding goal! Congratulations!" +
                            "<br /><br />What’s next? " +
                            "<br /><br />Our legal team will be working through the technicalities to finalize the share swap – you can expect to hear from us within the next few weeks with an update." +
                            "<br /><br />You can expect to hear from " + ownerFirstName + ", the entrepreneur behind " + pitchTitle + ", very soon. " +
                            "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />Congratulations again!" +
                            "<br /><br />The team at Eureeca";
                    }
                    else if (action == PitchAction.OverfundedForFollowers)
                    {
                        _subject = "Overfunding target reached!";
                        _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                            "<br /><br />We have great news! " + pitchTitle + ", the proposal you are following on eureeca.com has reached its overfunding target." +
                            "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />Congratulations again!" +
                            "<br /><br />The Eureeca Team";
                    }
                    else if (action == PitchAction.CompletedWithoutOverfundingBalanceForFollowers)
                    {
                        _subject = "Funding target reached!";
                        _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                            "<br /><br />We have great news! " + pitchTitle + ",  the proposal you are following on eureeca.com has been funded and closed." +
                            "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />Congratulations again!" +
                            "<br /><br />The Eureeca Team";
                    }
                    else if (action == PitchAction.ExtendedForUsers)
                    {
                        _subject = "Proposal has been extended";
                        _body = "Hi " + drUser["Profile_FirstName"] +
                            "<br /><br />Good news! a proposal you are following or invested in, has been extended. Check it out here: <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + proposalId + "'>" + pitchTitle + "</a>" +
                            "<br /><br />Remember that the crowd works best when you are all interacting. Let others know what you think of the proposal by leaving comments or questions." +
                            "<br /><br />See you soon on eureeca.com!" +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"] + "'>here</a> to change your notifications options. " +
                            "<br /><br />Thanks!" +
                            "<br /><br />The Eureeca Team";
                    }
                    else if (action == PitchAction.UpdateForUsers)
                    {
                        _subject = "Proposal update";
                        _body = "Hi " + drUser["Profile_FirstName"]
                        + "<br /><br />Good news! There has been an update to a proposal you are following or invested in. Check it out here: <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?pid=" + proposalId + "&DO=updates'>" + pitchTitle + "</a>"
                        + "<br /><br />Remember that the crowd works best when you are all interacting. Let others know what you think of the proposal by leaving comments or questions."
                        + "<br /><br />See you soon on eureeca.com!"
                        + "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"] + "'>here</a> to change your notifications options. "
                        + "<br /><br />Thanks!"
                        + "<br /><br />The Eureeca Team";
                    }
                    else if (action == PitchAction.CancelledForUsers)
                    {
                        _subject = "The proposal " + pitchTitle + " was cancelled";
                        _body = "Hi " + drUser["Profile_FirstName"]
                        + "<br /><br />This email is to confirm that the funding proposal named " + pitchTitle + " was cancelled."
                        + "<br /><br />All pending investment transactions will be reversed & refunded Shortly."
                        + "<br /><br />See you soon on eureeca.com!"
                        + "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"] + "'>here</a> to change your notifications options. "
                        + "<br /><br />Thanks!"
                        + "<br /><br />The Eureeca Team";
                    }
                    else if (action == PitchAction.CancelledAndClosedForUsers)
                    {
                        _subject = "The proposal " + pitchTitle + " was cancelled";
                        _body = "Hi " + drUser["Profile_FirstName"]
                        + "<br /><br />This email is to confirm that the funding proposal named " + pitchTitle + " was cancelled."
                        + "<br /><br />All pending investment transactions were reversed and refunded."
                        + "<br /><br />See you soon on eureeca.com!"
                        + "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"] + "'>here</a> to change your notifications options. "
                        + "<br /><br />Thanks!"
                        + "<br /><br />The Eureeca Team";
                    }
                    MessageSendMessage(sender, _subject, _body, drUser, sender["User_Email"].ToString());
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);

            }
        }

        public void MessageSendKYCUploadedEmailToInvestor(DataRow sender, DataRow User)
        {
            _subject = "Thank you for uploading the documents";
            _body = "Hi " + User["Profile_FirstName"].ToString()
                    + "<br /><br />Thank you for uploading your KYC documents."
                    + "<br /><br />These will now be reviewed by the Eureeca compliance team who will get back in touch with you within 24 hours."
                    + "<br /><br />In the meantime, if you have any questions, please contact us on <a href='mailto:kyc@eureeca.com'>kyc@eureeca.com</a>"
                    + "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + User["User_guid"].ToString() + "'>here</a> to change your notifications options."
                    + "<br /><br />The Eureeca Team";
            MessageSendMessage(sender, _subject, _body, User, sender["User_Email"].ToString());
        }

        public void MessageSendKYCUploadedEmailToKYCTeam(DataRow sender, DataRow user, string objectTitle, string imageName)
        {
            _subject = user["User_Username"].ToString() + " has just uploaded the documents.";
            _body = "Dear KYC team,"
                    + "<br /><br />" + user["User_Username"].ToString() + " has just uploaded the documents.";

            if (!string.IsNullOrWhiteSpace(objectTitle))
                _body += "<br /><br />\"" + objectTitle + "\""
                    + "<br /><br /><img alt='" + objectTitle + "' src='http://" + Tools.GetRoot() + imageName + "' />";

            _body += "<br /><br />Please check documents for verification."
                    + "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a>"
                    + "<br /><br />The Eureeca Team";
            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("contactusEmail"), _subject, _body);
            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("KYCTeamEmail"), _subject, _body);
            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("CreditCardNotificationEmail"), _subject, _body);
        }

        public void MessageSendKYCUploadedEmailToKYCAdmin(DataRow sender, DataRow user, string objectTitle, string uploadedDocs)
        {
            _subject = user["User_Username"].ToString() + " has just uploaded the documents.";
            _body = "Dear KYC Admin,"
                    + "<br /><br />" + user["User_Username"].ToString() + " has just uploaded the documents.";

            string[] docs = uploadedDocs.Split(',');
            _body += "<br /><br /><a href='http://" + Tools.GetRoot() + "/Attachments/KYC/" + docs[0] + "'>Passport ID</a>";
            _body += "<br /><br /><a href='http://" + Tools.GetRoot() + "/Attachments/KYC/" + docs[1] + "'>Proof of address</a>";
            _body += "<br /><br /><a href='http://" + Tools.GetRoot() + "/Attachments/KYC/" + docs[2] + "'>Source of wealth</a>";
            _body += "<br /><br /><a href='http://" + Tools.GetRoot() + "/Attachments/KYC/" + docs[3] + "'>Certified copies</a>";
            _body += "<br /><br /><a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/Admin/KYCAutomation.aspx?User_ID=" + user["user_id"].ToString() + "'>Please click here to visit the Main Admin Panel</a><br /><br />";
            _body += "<br /><br />Username : " + user["User_Username"].ToString();
            _body += "<br /><br />Kyc Date  : " + DateTime.Now.ToString();
            /*  _configuration.GetValue<string>("KYCTeamEmail"].ToString() -- This should be changed to kycadmin which is WAFIC */
            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("KYCTeamEmail"), _subject, _body);
        }


        public string MessageSendMessage(DataRow sender, string subject, string body, DataTable receivers)
        {
            string msg = "";
            try
            {
                string receiversList = "";
                int count = 0;

                foreach (DataRow r in receivers.Rows)
                {
                    if (bool.Parse(r["User_ReceiveEmails"].ToString()))
                    {
                        if (count > 0)
                            receiversList += ",";

                        receiversList += r["User_Email"].ToString();
                        int Inbox_ID = 0;
                        int Sent_ID = 0;
                        _internalMessage.InternalMessageAddMessage(int.Parse(sender["User_ID"].ToString()), int.Parse(r["User_ID"].ToString()), subject, body, 0, out Inbox_ID, out Sent_ID);
                        MessageSendExternalMessage(sender["User_Email"].ToString(), r["User_Email"].ToString(), subject, body);
                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                msg = ex.Message + "<br>" + ex.StackTrace;
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
            return msg;
        }

        public void MessageSendMessage(DataRow sender, string subject, string Body, DataRow receiver, string replyTo)
        {
            try
            {
                if (bool.Parse(receiver["User_ReceiveEmails"].ToString()))
                {
                    int Inbox_ID = 0;
                    int Sent_ID = 0;
                    _internalMessage.InternalMessageAddMessage(int.Parse(sender["User_ID"].ToString()), int.Parse(receiver["User_ID"].ToString()), subject, Body, 0, out Inbox_ID, out Sent_ID);
                    MessageSendExternalMessage(replyTo, receiver["User_Email"].ToString(), subject, Body);
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);

            }

        }
        public void MessageSendExternalMessage(string replyTo, string to, string subject, string body)
        {
            try
            {
                MessageAddOutgoingEmail(to, subject, body, replyTo);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);

            }
        }

        public string PitchGetStatus(PitchStatus convertedStatus)
        {
            string status = "";
            if (convertedStatus == PitchStatus.NotReady)
                status = "Not Ready";
            if (convertedStatus == PitchStatus.CancelledAndClosed)
                status = "Cancelled And Closed";
            if (convertedStatus == PitchStatus.EarlyAccess)
                status = "Early Access";
            if (convertedStatus == PitchStatus.CompletedAndClosed)
                status = "Completed And Closed";
            if (convertedStatus == PitchStatus.ExpiredAndClosed)
                status = "Expired And Closed";
            if (convertedStatus == PitchStatus.MinimumFunded)
                status = "Minimum Funded";
            if (convertedStatus == PitchStatus.SubmittedForApproval)
                status = "Submitted For Approval";
            if (convertedStatus == PitchStatus.Published)
                status = "Published";
            if (convertedStatus == PitchStatus.Cancelled)
                status = "Cancelled";
            if (convertedStatus == PitchStatus.Expired)
                status = "Expired";
            if (convertedStatus == PitchStatus.Completed)
                status = "Completed";
            if (convertedStatus == PitchStatus.ComingSoon)
                status = "Coming Soon";
            if (convertedStatus == PitchStatus.OverFunding)
                status = "OverFunding";
            if (convertedStatus == PitchStatus.OverFunded)
                status = "OverFunded";

            return status;
        }

        public void MessageAddOutgoingEmail(string outGouingTo, string outGouingSubject, string outGouingBody, string outGouingReplyTo)
        {
            try
            {
                SqlParameter paramOutGouingTo = new SqlParameter("@OutGouing_To", outGouingTo);
                SqlParameter paramOutGouingSubject = new SqlParameter("@OutGouing_Subject", outGouingSubject);
                string body = outGouingBody;
                if (bool.Parse(_config.ConfigsGetConfigValue(ConfigurationsEnum.UseEmailsFooterText).Rows[0]["Config_Value"].ToString()))
                    body += "<br /><br />" + _config.ConfigsGetConfigValue(ConfigurationsEnum.EmailsFooterText).Rows[0]["Config_Value"].ToString();

                SqlParameter paramBody = new SqlParameter("@OutGouing_Body", body);
                SqlParameter paramOutGouingReplyTo = new SqlParameter("@OutGouing_ReplyTo", outGouingReplyTo);

                _sqlHelper.ExecuteNonQuery(_connectionString, "addOutgoingEmail", paramOutGouingTo, paramOutGouingSubject, paramBody, paramOutGouingReplyTo);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public void MessageSendAccountVerificationEmail(string from, string to, string firstName, string guid)
        {
            try
            {
                _subject = "Eureeca account verification";
                _body = "Hi " + firstName + ""
                   + "<br /><br />Thank you for registering your account with us at Eureeca."
                   + "<br /><br />Please click on the link below to verify your email address."
                   + "<br /><br /><a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Register/ValidateEmail.aspx?guid=" + guid + "'>Click here to verify your email address</a>"
                   + "<br /><br />We look forward to seeing you on the site!"
                   + "<br /><br />Regards"
                   + "<br /><br />Eureeca Team.";

                MessageSendExternalMessage(from, to, _subject, _body);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);

            }
        }

        public void MessageSendContactsEmail(DataRow sender, DataTable admins, string subject, string name, string email, string phone, string details, UserAction action)
        {
            try
            {
                _subject = subject;
                if (action == UserAction.ContactUs || action == UserAction.BecomePartner)
                {
                    _body = string.Format(@"Thank you for using Eureeca, The following information has been sent to our team."
                                        + "<br /><br /><< {0} >>"
                                        + "<br /><br />We will respond to your question shortly."
                                        + "<br /><br />Eureeca Team.", details);
                }

                MessageSendExternalMessage(sender["User_Email"].ToString(), email, _subject, _body);
                _body = string.Format("From: {0}<br />Email: {1}<br />Phone: {2}<br /><br />{3}", name, email, phone, details);
                MessageSendMessage(sender, _subject, _body, admins);
                MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("SpreadSheetRange"), _subject, _body);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }

        }
        public void MessageSendMessageWhenUserRequestToContactProposalOwner(DataRow sender, DataTable admins, DataRow receiver, DataRow owner, string pitchTitle, RequestType requestType)
        {
            try
            {
                if (bool.Parse(owner["User_ReceiveEmails"].ToString()))
                {
                    int inboxId = 0;
                    int sentId = 0;
                    _internalMessage.InternalMessageAddMessage(int.Parse(receiver["User_ID"].ToString()), int.Parse(owner["User_ID"].ToString()), "", "", 0, out inboxId, out sentId);

                    if (requestType == RequestType.RequestMeetingWithEnt)
                    {
                        _subject = receiver["User_Username"].ToString() + " has requested to meet with you";
                        _body = "Hi " + owner["Profile_FirstName"].ToString() +
                           "<br /><br />The user <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + receiver["User_ID"] + "'>" + receiver["User_Username"].ToString() + "</a> has requested to meet with you." +
                           "<br /><br />You can reply back by clicking on the <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/MailSystem/crowd-user-inbox.aspx?Inbox_ID=" + inboxId + "'>reply</a> link." +
                           "<br /><br />Regards," +
                           "<br /><br />The Eureeca Team";
                    }
                    else if (requestType == RequestType.RequestCallWithEnt)
                    {
                        _subject = receiver["User_Username"].ToString() + " has requested a call with you";
                        _body = "Hi " + owner["Profile_FirstName"].ToString() +
                           "<br /><br />The user <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + receiver["User_ID"] + "'>" + receiver["User_Username"].ToString() + "</a> has requested a call with you." +
                           "<br /><br />You can reply back by clicking on the <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/MailSystem/crowd-user-inbox.aspx?Inbox_ID=" + inboxId + "'>reply</a> link." +
                           "<br /><br />Regards," +
                           "<br /><br />The Eureeca Team";
                    }
                    else if (requestType == RequestType.RequestBusinessPlan)
                    {
                        _subject = receiver["User_Username"].ToString() + " has requested the business plan for your proposal " + pitchTitle;
                        _body = "Hi " + owner["Profile_FirstName"].ToString() +
                           "<br /><br />The user <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + receiver["User_ID"] + "'>" + receiver["User_Username"].ToString() + "</a> has requested the business plan for your proposal " + pitchTitle + "." +
                           "<br /><br />You can reply back by clicking on the <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/MailSystem/crowd-user-inbox.aspx?Inbox_ID=" + inboxId + "'>reply</a> link." +
                           "<br /><br />Regards," +
                           "<br /><br />The Eureeca Team";
                    }

                    _internalMessage.InternalMessageUpdateInternalMessage(inboxId, sentId, _body, _subject);
                    MessageSendExternalMessage(sender["User_Email"].ToString(), owner["User_Email"].ToString(), _subject, _body);

                    string adminbody = "This message has been sent to the entrepreneur" +
                            "<br /><br />========================================<br /><br />" +
                            _body;
                    MessageSendMessage(sender, _subject, adminbody, admins);
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public void MessageSendCustomForumEmailsToOwner(DataRow sender, DataRow receiver, string firstName, string pitchId, string pitchTitle, string userId, string comment, string GUID, UserAction action)
        {
            if (action == UserAction.AddCommentToUser)
            {
                _subject = "New comment on your profile";
                _body = "Hi " + firstName +
                       "<br /><br />New comments have been posted to your profile. You can click through from <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + userId + "'>here</a>" +
                       "<br /><br />Remember, the more you engage with the crowd, the easier it will be to achieve your funding target." +
                       "<br /><br />See you soon on eureeca.com!" +
                       "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + GUID + "'>here</a> to change your notifications options." +
                       "<br /><br />Thanks!<br /><br />The Eureeca Team";
            }
            else if (action == UserAction.AddCommentToProposal)
            {
                _subject = "New comment on your proposal";
                _body = "Hi " + firstName +
                       "<br /><br />New comments have been posted to your proposal page. You can click through from here: <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?pid=" + pitchId + "&tabID=4'>" + pitchTitle + "</a>" +
                       "<br /><br />Remember, the more you engage with the crowd, the easier it will be to achieve your funding target." +
                       "<br /><br />See you soon on eureeca.com!" +
                       "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + GUID + "'>here</a> to change your notifications options." +
                       "<br /><br />Thanks!<br /><br />The Eureeca Team";
                if (pitchId == "10390")
                {
                    MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("ChrisNotificationEmail"), _subject, _body);
                    MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("OmarNotificationEmail"), _subject, _body);
                }
            }
            else if (action == UserAction.AddQuestionToUser)
            {
                _subject = "New question on your profile";
                _body = "Hi " + firstName +
                       "<br /><br />A member of the crowd has added a new question on your profile page." +
                       "<br /><br />The Question is :" +
                       "<br /><a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + userId + "&tabID=2'>" + comment + "</a>" +
                       "<br /><br />Remember, the more you engage with the crowd, the easier it will be to achieve your funding target.  Click on the above question to answer it." +
                       "<br /><br />If you need any help with any of these questions, we are here to help!  You can get directly in touch with your entrepreneur manager for support." +
                       "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + GUID + "'>here</a> to change your notifications options." +
                       "<br /><br />Thanks!<br /><br />The Eureeca Team";
            }
            else if (action == UserAction.AddQuestionToProposal)
            {
                _subject = "New question on your proposal";
                _body = "Hi " + firstName +
                       "<br /><br />A member of the crowd has asked a new question about your proposal." +
                       "<br /><br /><a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?pid=" + pitchId + "&tabID=3'>" + comment + "</a>" +
                       "<br /><br />Remember, the more you engage with the crowd, the easier it will be to achieve your funding target.  Click on the above question to answer it." +
                       "<br /><br />If you need any help with any of these questions, we are here to help!  You can get directly in touch with your entrepreneur manager for support." +
                       "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + GUID + "'>here</a> to change your notifications options." +
                       "<br /><br />Thanks!<br /><br />The Eureeca Team";
                if (pitchId == "10390")
                {
                    MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("ChrisNotificationEmail"), _subject, _body);
                    MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("OmarNotificationEmail"), _subject, _body);
                }
                string adminbody = "This message has been sent to the entrepreneur" +
                         "<br /><br />========================================<br /><br />" +
                         _body;
                MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("CreditCardNotificationEmail"), _subject, adminbody);
            }
            else if (action == UserAction.AddAnswerToUser)
            {
                _subject = "Answer has been added to your profile";
                _body = "Hi " + firstName +
                       "<br /><br />An answer has been added to <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + userId + "&tabID=2'>your profile page</a>" +
                       "<br /><br />The answer is : " + comment +
                       "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + GUID + "'>here</a> to change your notifications options." +
                       "<br /><br />Thanks!<br /><br />The Eureeca Team";
            }
            else if (action == UserAction.AddAnswerToProposal)
            {
                _subject = "Answer has been added to your proposal";
                _body = "Hi " + firstName +
                       "<br /><br />An answer has been added to the proposal <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?pid=" + pitchId + "&tabID=3'>" + pitchTitle + "</a>" +
                       "<br /><br />The answer is : " + comment +
                       "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + GUID + "'>here</a> to change your notifications options." +
                       "<br /><br />Thanks!<br /><br />The Eureeca Team";

                if (pitchId == "10390")
                {
                    MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("ChrisNotificationEmail"), _subject, _body);
                    MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("OmarNotificationEmail"), _subject, _body);
                }
                string adminbody = "This message has been sent to the entrepreneur" +
                     "<br /><br />========================================<br /><br />" +
                     _body;
                MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("CreditCardNotificationEmail"), _subject, adminbody);
            }

            MessageSendMessage(sender, _subject, _body, receiver, sender["User_Email"].ToString());
        }

        public void MessageSendMessageWhenUserRequest(DataRow sender, DataTable admins, DataRow receiver, DataRow owner, string pitchTitle, RequestType requestType)
        {
            try
            {
                if (requestType == RequestType.ViewingOpaqueProposal)
                {
                    _subject = receiver["User_Username"].ToString() + " has requested to view your proposal " + pitchTitle;
                    _body = "Hi " + owner["Profile_FirstName"].ToString() +
                       "<br /><br />The following user " + receiver["User_Username"].ToString() + " has requested to view your proposal " + pitchTitle + "." +
                       "<br /><br /> Please Login to your account and go to your dashboard under \"MY FUNDING PROPOSAL->USER REQUESTS\" to accept or reject this user request. " +
                       "<br /><br />If you have any questions please get in touch at <br /><a href='mailto:support@eureeca.com'>support@eureeca.com</a>" +
                       "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + owner["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                       "<br /><br />Regards," +
                       "<br /><br />The Eureeca Team";
                }
                else if (requestType == RequestType.ViewingProposalPrivateDocument)
                {
                    _subject = receiver["User_Username"].ToString() + " has requested to view the private documents for your proposal " + pitchTitle;
                    _body = "Hi " + owner["Profile_FirstName"].ToString() +
                       "<br /><br />The following user " + receiver["User_Username"].ToString() + " has requested to view the private documents for your proposal " + pitchTitle + "." +
                       "<br /><br /> Please Login to your account and go to your dashboard under \"MY FUNDING PROPOSAL->USER REQUESTS\" to accept or reject this user request. " +
                       "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + owner["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                       "<br /><br />Regards," +
                       "<br /><br />The Eureeca Team";
                }
                else if (requestType == RequestType.RequestAccessCode)
                {
                    _subject = "Access requested for proposal " + pitchTitle;
                    _body = "Hi " + owner["Profile_FirstName"] +
                       "<br /><br />The user <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + receiver["User_ID"] + "'>" + receiver["User_Username"].ToString() + "</a> with email address: " + receiver["user_email"] + " is requesting to access the proposal " + pitchTitle +
                       "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + owner["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                       "<br /><br />Regards," +
                       "<br /><br />The Eureeca Team";
                }

                string adminbody = "This message has been sent to the entrepreneur" +
                        "<br /><br />========================================<br /><br />" +
                        _body;
                MessageSendMessage(sender, _subject, adminbody, admins);
                MessageSendMessage(sender, _subject, _body, owner, sender["User_Email"].ToString());
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public void MessageSendSignupNotification(string sender, string receiver, string username, string userPhone, string email, string previous)
        {
            try
            {
                _subject = "The user " + username + " has not passed the knowledge assessment.";
                _body = "The suitability test: "
                            + "<br />========================"
                            + "The user " + username + " with email " + email
                            + " and phone number " + userPhone + " did not pass the suitability test." +
                            "The test result is: " + previous + ";";
                MessageSendExternalMessage(sender, receiver, _subject, _body);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }
        public void MessageSendAddProposalUpdateEmail(DataRow sender, DataTable admins, DataRow proposal)
        {
            _subject = string.Format("A new proposal update has been added to the proposal {0}.", proposal["Profile_PitchTitle"].ToString());
            _body = string.Format("A new proposal update has been added to the proposal {0}<br /><br /> you can return to your control panel to approve or reject it.<br /><br />Thanks!<br /><br />Regards,<br /><br />Eureeca Team", proposal["Profile_PitchTitle"].ToString());
            MessageSendMessage(sender, _subject, _body, admins);
            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("AcookeNotificationEmail"), _subject, _body);
            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("PthomasNotificationEmail"), _subject, _body);
            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("MkiseNotificationEmail"), _subject, _body);
        }

        public void MessageSendInvestmentEmail(DataRow sender, DataTable admins, DataRow receiver, DataRow drInvestor, string pitchTitle, int pitchId, double investmentAmount, PitchAction action, string currencySymbol)
        {
            try
            {
                if (action == PitchAction.OverfundingForOwner)
                {
                    _subject = drInvestor["User_Username"].ToString() + " has invested " + currencySymbol + investmentAmount.ToString() + " in you!";
                    _body = "Hi " + receiver["Profile_FirstName"].ToString() +
                                "<br /><br />Great news! " +
                                "<br /><br />You have received " + currencySymbol + investmentAmount.ToString() + " Overfunding investment commitment in your proposal by <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + drInvestor["User_ID"].ToString() + "'> " + drInvestor["User_Username"].ToString() + "</a>!" +
                                "<br /><br />You may like to contact the investor directly via the chat or email function on the site. They may have some feedback or know some other contacts that would also be interested in investing in you!" +
                                "<br /><br/>Good luck with the rest of the fund raise!" +
                                "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + receiver["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                                "<br /><br />Regards," +
                                "<br /><br />The team at Eureeca";
                }
                else if (action == PitchAction.OverfundingForInvestor)
                {
                    _subject = "Your funds have been committed";
                    _body = "Hi " + receiver["Profile_FirstName"].ToString() +
                            "<br /><br />Thanks for investing in " + pitchTitle + ". We can confirm that your commitment of " + currencySymbol + investmentAmount.ToString() + " has been recorded. The Proposal owner reserves the right to accept or reject your commitment since it is above the needed amount and is considered an Overfunding." +
                            "<br /><br />You can view the proposal <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + pitchId + "'>here</a>" +
                            "<br /><br />If you have any questions please get in touch at <br /><a href='mailto:support@eureeca.com'>support@eureeca.com</a>" +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + receiver["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />Regards," +
                            "<br /><br />The team at Eureeca";
                }
                else if (action == PitchAction.PublishedForOwner)
                {
                    _subject = drInvestor["User_Username"].ToString() + " has invested " + currencySymbol + investmentAmount.ToString() + " in you!";
                    _body = "Hi " + receiver["Profile_FirstName"].ToString() +
                            "<br /><br />Great news! " +
                            "<br /><br />You have received " + currencySymbol + investmentAmount.ToString() + " investment commitment in your proposal by <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + drInvestor["User_ID"].ToString() + "'> " + drInvestor["User_Username"].ToString() + "</a>! Every investment brings you a step closer to your target. " +
                            "<br /><br />You may like to contact the investor directly via the chat or email function on the site. They may have some feedback or know some other contacts that would also be interested in investing in you!" +
                            "<br /><br/>Good luck with the rest of the fund raise!" +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + receiver["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                            "<br /><br />Regards," +
                            "<br /><br />The team at Eureeca";
                }
                else if (action == PitchAction.PublishedForInvestor)
                {
                    _subject = "Your funds have been committed";
                    _body = "Hi " + receiver["Profile_FirstName"].ToString() +
                            "<br /><br />Thanks for investing in " + pitchTitle + ". We can confirm that your commitment of " + currencySymbol + investmentAmount.ToString() + " has been recorded. You can view the proposal <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + pitchId + "'>here</a>" +
                            "<br /><br />If you have any questions please get in touch at <br /><a href='mailto:support@eureeca.com'>support@eureeca.com</a>" +
                            "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + receiver["User_guid"].ToString() + "'>here</a> to change your notifications options." +
                            "<br /><br />Regards" +
                            "<br /><br />Eureeca Team";
                }
                else if (action == PitchAction.InvestmentRejection)
                {
                    _subject = "Your investment has been rejected";
                    _body = "Hi " + drInvestor["Profile_FirstName"].ToString() +
                       "<br /><br />Thank you for investing in " + pitchTitle + "." +
                       "<br /><br /> Unfortunately your investment in the amount of " + currencySymbol + investmentAmount.ToString() + " has been rejected, your funds have been returned back to your eureeca account." +
                       "<br /><br />If you have any questions please get in touch at <br /><a href='mailto:support@eureeca.com'>support@eureeca.com</a>" +
                       "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drInvestor["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                       "<br /><br />Regards," +
                       "<br /><br />The team at Eureeca";

                    string adminbody = "This message has been sent to the investor" +
                            "<br /><br />========================================<br /><br />" +
                            _body;
                    MessageSendMessage(sender, _subject, adminbody, admins);
                }
                else if (action == PitchAction.UnableToInvest)
                {
                    _subject = "Unable to invest in proposal " + pitchTitle;
                    _body = "Unable to invest in proposal " + pitchTitle +
                            "<br />Investment amount after discount is " + currencySymbol + investmentAmount.ToString() +
                            "<br />time is " + DateTime.Now.ToString();
                    MessageSendMessage(sender, _subject, _body, admins);
                    return;
                }

                MessageSendMessage(sender, _subject, _body, receiver, sender["User_Email"].ToString());
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public void MessageSendInvestmentNotificationForAdmins(DataRow sender, DataRow User, string proposalName, string investmentAmount, string currencySymbol)
        {

            _subject = "A new investment has been placed‏";
            _body = string.Format("The user: {0} ({1}) has made a new investment ({3}) to the proposal: {2}. <br/><br/><br/>Eureeca.com system.", User["User_Username"].ToString(), User["User_Email"].ToString(), proposalName, currencySymbol + investmentAmount);

            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("CreditCardNotificationEmail"), _subject, _body);
            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("pthomasNotificationEmail"), _subject, _body);
            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("OmarNotificationEmail"), _subject, _body);
            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("sdalamalNotificationEmail"), _subject, _body);
        }

        public void MessageSendPreCommitmentNotificationForAdmins(DataRow sender, DataRow user, string proposalName, string preCommitAmount, string currencySymbol)
        {

            _subject = "A new pre-commitment has been placed‏";
            _body = string.Format("The user: {0} ({1}) has made a new pre-commitment ({3}) to the proposal: {2}. <br/><br/><br/>Eureeca.com system.", user["User_Username"].ToString(), user["User_Email"].ToString(), proposalName, currencySymbol + preCommitAmount);

            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("PrecommitmentNotificationEmail"), _subject, _body);
            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("pthomasNotificationEmail"), _subject, _body);
            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("OmarNotificationEmail"), _subject, _body);
            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("sdalamalNotificationEmail"), _subject, _body);
        }

        public void MessageSendMessageForPitchUsers(DataRow sender, DataTable dtUsers, string pitchTitle, string pitchId, decimal soFar, string pitchBalance, string investmentAmount, double discount, PitchAction action, string currencyId, PitchStatus pitchStatus)
        {
            try
            {
                foreach (DataRow drUser in dtUsers.Rows)
                {
                    if (action == PitchAction.InvestmentForUsers)
                    {
                        _subject = pitchTitle + " has received a new investment - " + soFar + "% funded";
                        if (pitchStatus == PitchStatus.Published)
                        {
                            _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                                "<br /><br /><a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?pid=" + pitchId + "'>" + pitchTitle + "</a> are edging closer to their funding target, having received a new investment of $" + investmentAmount + ". Bringing their total to $" + pitchBalance + " they are now " + soFar + "% funded." +
                                "<br /><br />Please click on the link above to find out more.";

                            if (discount > 0)
                                _body += "<br /><br />Should you be interested in joining " + pitchTitle + "'s crowd, you can still benefit from the " + discount + "% early adoption discount, but be quick as we are unsure how long this will last.";

                            _body += "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                                "<br /><br />Thanks!" +
                                "<br /><br />The Eureeca Team";
                        }
                        else if (pitchStatus == PitchStatus.OverFunding)
                        {
                            _body = "Hi " + drUser["Profile_FirstName"].ToString() +
                                "<br /><br />Surging past their funding target, <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?pid=" + pitchId + "'>" + pitchTitle + "</a> continues to gain momentum and receives a new investment of $" + investmentAmount + ". Bringing their total to $" + pitchBalance + " they are now " + soFar + "% funded." +
                                "<br /><br />With <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?pid=" + pitchId + "'>" + pitchTitle + "</a> remaining open for investment for a limited time only please click on the link above to find out more whilst you still can.";
                            _body += "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + drUser["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                                "<br /><br />Thanks!" +
                                "<br /><br />The Eureeca Team";
                        }

                        MessageSendMessage(sender, _subject, _body, drUser, sender["User_Email"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public void MessageSendRequestRejectionEmail(DataRow sender, DataTable admins, DataRow investor, DataRow pitch, RequestType type)
        {
            string investorName = investor["Profile_FirstName"].ToString();
            string pitchTitle = pitch["Profile_PitchTitle"].ToString();
            string pitchId = pitch["Profile_PitchID"].ToString();

            if (type == RequestType.ViewingProposalPrivateDocument)
            {
                _subject = "Access to view private documents for " + pitchTitle + " by the user " + investorName + " was rejected";
                _body = "The request to access and view the private documents for the proposal <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + pitchId + "'>" + pitchTitle + "</a> was rejected." +
                       "<br /><br />Regards," +
                       "<br /><br />Eureeca Team";
            }

            MessageSendExternalMessage(sender["User_Email"].ToString(), _configuration.GetValue<string>("contactusEmail"), _subject, _body);
            MessageSendMessage(sender, _subject, _body, admins);
        }

        public void MessageSendUserRequestWhenAcceptance(DataRow sender, DataTable admins, DataRow Investor, DataRow pitch, int type)
        {
            string userGuid = Investor["User_guid"].ToString();
            string username = Investor["Profile_FirstName"].ToString();
            string pitchTitle = pitch["Profile_PitchTitle"].ToString();
            string pitchId = pitch["Profile_PitchID"].ToString();

            if (type == (int)RequestType.ViewingOpaqueProposal)
            {
                _subject = "Access to view the proposal " + pitchTitle;
                _body = "Hi " + username +
                       "<br /><br />Your access to view the proposal <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + pitchId + "'>" + pitchTitle + "</a> is now granted" +
                       "<br /><br />Please click on the link above to view the requested proposal." +
                       "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + userGuid + "'>here</a> to change your notifications options." +
                       "<br /><br />Regards," +
                       "<br /><br />Eureeca Team";
            }
            else if (type == (int)RequestType.ViewProposalPrevention)
            {
                _subject = "Access to view the proposal " + pitchTitle;
                _body = "Hi " + username +
                        "<br /><br />Your access to view the proposal <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + pitchId + "'>" + pitchTitle + "</a> is now granted" +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + userGuid + "'>here</a> to change your notifications options." +
                        "<br /><br />Regards," +
                        "<br /><br />Eureeca Team";
            }
            else if (type == (int)RequestType.InvestmentPrevention)
            {
                _subject = "Access to invest in the proposal " + pitchTitle;
                _body = "Hi " + username +
                        "<br /><br />Your access to invest in the proposal <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + pitchId + "'>" + pitchTitle + "</a> is now granted" +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + userGuid + "'>here</a> to change your notifications options." +
                        "<br /><br />Regards," +
                        "<br /><br />Eureeca Team";
            }
            else if (type == (int)RequestType.ViewingProposalPrivateDocument)
            {
                _subject = "Access to view private documents for " + pitchTitle + " was granted";
                _body = "Hi " + username +
                        "<br /><br />The request to access and view the private documents for the proposal <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + pitchId + "'>" + pitchTitle + "</a> was approved and the access is now granted." +
                        "<br /><br />Please login into your Eureeca account and visit the proposal <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + pitchId + "'>" + pitchTitle + "</a> to download these documents." +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + userGuid + "'>here</a> to change your notifications options." +
                        "<br /><br />Regards," +
                        "<br /><br />Eureeca Team";
            }
            else if (type == (int)RequestType.RequestAccessCode)
            {
                _subject = pitchTitle + " access code!";
                _body = "Hi " + username +
                        "<br /><br />Your access request to the <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Pitch/crowd-investment-pitch.aspx?PID=" + pitchId + "'>" + pitchTitle + "</a> campaign, has been approved." +
                        "<br /><br />The access code is: " + pitch["Pitch_AccessCode"].ToString() +
                        "<br /><br />Please visit the proposal from the link above and enter the access code to view the campaign details." +
                        "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + userGuid + "'>here</a> to change your notifications options." +
                        "<br /><br />Regards," +
                        "<br /><br />Eureeca Team";
            }

            MessageSendMessage(sender, _subject, _body, Investor, sender["User_Email"].ToString());
        }
        /// <summary>
        /// This method is used to get inbox message.
        /// </summary>
        /// <param name="messageId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable MessageGetMessageInboxById(int messageId)
        {
            try
            {
                SqlParameter paramMessageId = new SqlParameter("@MessageID", messageId);
                return _sqlHelper.GetDataTable(_connectionString2, "GetMessageInboxByID", paramMessageId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to Delete inbox message.
        /// </summary>
        /// <param name="messageId"></param>
        /// <exception cref="Exception"></exception>
        public void MessageDeleteMessageInbox(int messageId)
        {
            try
            {
                SqlParameter paramMessageId = new SqlParameter("@MessageID", messageId);
                _sqlHelper.ExecuteReader(_connectionString2, "DeleteMessageInbox", paramMessageId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to get sent message.
        /// </summary>
        /// <param name="messageId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable MessageGetSentItemById(int messageId)
        {
            try
            {
                SqlParameter paramMessageId = new SqlParameter("@MessageID", messageId);
                return _sqlHelper.GetDataTable(_connectionString2, "GetSentItemByID", paramMessageId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to delete sent message.
        /// </summary>
        /// <param name="messageId"></param>
        /// <exception cref="Exception"></exception>
        public void MessageDeleteMessageSentItem(int messageId)
        {
            try
            {
                SqlParameter paramMessageId = new SqlParameter("@MessageID", messageId);
                _sqlHelper.ExecuteReader(_connectionString2, "DeleteMessageSentItem", paramMessageId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to update flag of Inbox message to read.
        /// </summary>
        /// <param name="messageId"></param>
        /// <exception cref="NotImplementedException"></exception>
        public void MessageUpdateMessageInboxFlag(int messageId)
        {
            try
            {
                SqlParameter paramMessageId = new SqlParameter("@MessageID", messageId);
                _sqlHelper.ExecuteReader(_connectionString2, "UpdateMessageInboxFlag", paramMessageId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to update sent message flag to read. 
        /// </summary>
        /// <param name="messageId"></param>
        /// <exception cref="Exception"></exception>
        public void MessageUpdateSentReadFlag(int messageId)
        {
            try
            {
                SqlParameter paramMessageId = new SqlParameter("@MessageID", messageId);
                _sqlHelper.ExecuteReader(_connectionString2, "UpdateSentReadFlag", paramMessageId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }
        public void MessageSendMessageForUserFollowedBy(DataRow sender, DataRow drFollower, DataRow receiver)
        {
            try
            {
                /*subject = drFollower["User_Username"] + " is now following you.";
                body = "Hi " + receiver["Profile_FirstName"] +
                   ", <br /><br /><a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + drFollower["User_ID"] + "'>" + drFollower["User_Username"] + "</a>  is now following you." +
                   "<br /><br />If you have any questions or issues please don’t hesitate to contact us at <a href='mailto:support@eureeca.com'>support@eureeca.com</a> " +
                   "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + receiver["User_guid"].ToString() + "'>here</a> to change your notifications options. " +
                   "<br /><br />The team at Eureeca";

                SendMessage(sender, subject, body, receiver);*/
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }
    }
}
