﻿using Eureeca_API.General;
using Eureeca_API.Interface.InboxInterface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.MessageRepos
{
    public class InternalMessageRepository : IInternalMessage
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;


        public InternalMessageRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }
        /// <summary>
        /// This method is used to add messages.
        /// </summary>
        /// <param name="senderId"></param>
        /// <param name="receiverId"></param>
        /// <param name="subject"></param>
        /// <param name="message"></param>
        /// <param name="flag"></param>
        /// <param name="inboxId"></param>
        /// <param name="sentId"></param>
        /// <exception cref="Exception"></exception>
        public void InternalMessageAddMessage(int senderId, int receiverId, string subject, string message, int flag, out int inboxId, out int sentId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("AddMessage", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@SenderID", senderId);
                        cmd.Parameters.AddWithValue("@ReceiverID", receiverId);
                        cmd.Parameters.AddWithValue("@Subject", subject);
                        cmd.Parameters.AddWithValue("@Message", message);
                        cmd.Parameters.AddWithValue("@Flag", flag);
                        cmd.Parameters.Add("@Inbox_ID", SqlDbType.BigInt);
                        cmd.Parameters["@Inbox_ID"].Direction = ParameterDirection.Output;
                        cmd.Parameters.Add("@Sent_ID", SqlDbType.BigInt);
                        cmd.Parameters["@Sent_ID"].Direction = ParameterDirection.Output;

                        sql.Open();

                        SqlDataReader data = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                        inboxId = int.Parse(cmd.Parameters["@Inbox_ID"].Value.ToString());
                        sentId = int.Parse(cmd.Parameters["@Sent_ID"].Value.ToString());
                    }


                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to update internal messages.
        /// </summary>
        /// <param name="inboxId"></param>
        /// <param name="sentId"></param>
        /// <param name="inboxMessage"></param>
        /// <param name="inboxSubject"></param>
        public void InternalMessageUpdateInternalMessage(int inboxId, int sentId, string inboxMessage, string inboxSubject)
        {
            try
            {
                SqlParameter paramInboxId = new SqlParameter("@Inbox_ID", inboxId);
                SqlParameter paramSentId = new SqlParameter("@Sent_ID", sentId);
                SqlParameter paramInboxMessage = new SqlParameter("@Inbox_Message", inboxMessage);
                SqlParameter paramInboxSubject = new SqlParameter("@Inbox_Subject", inboxSubject);
                _sqlHelper.ExecuteReader(_connectionString, "Inbox_UpdateInternalMessage", paramInboxId, paramSentId, paramInboxMessage, paramInboxSubject);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
            }

        }
        /// <summary>
        /// This method is used to retrieve send messages.
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sentSubject"></param>
        /// <param name="langId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable InternalMessageGetSentForUserN(int userId, int pageIndex, int pageSize, string sentSubject, int langId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@UserID", userId);
                SqlParameter paramPageIndex = new SqlParameter("@PageNo", pageIndex);
                SqlParameter paramPageSize = new SqlParameter("@PageSize", pageSize);
                SqlParameter paramSentSubject = new SqlParameter("@Sent_Subject", sentSubject);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                return _sqlHelper.GetDataTable(_connectionString, "GetSentForUser_N", paramUserId, paramPageIndex, paramPageSize, paramSentSubject, paramLangId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to retrieve Inbox messages.
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="inboxSubject"></param>
        /// <param name="langId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable InternalMessageGetInboxForUserN(int userId, int pageIndex, int pageSize, string inboxSubject, int langId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@UserID", userId);
                SqlParameter paramPageIndex = new SqlParameter("@PageNo", pageIndex);
                SqlParameter paramPageSize = new SqlParameter("@PageSize", pageSize);
                SqlParameter paramInboxSubject = new SqlParameter("@Inbox_Subject", inboxSubject);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                return _sqlHelper.GetDataTable(_connectionString, "GetInboxForUser_N", paramUserId, paramPageIndex, paramPageSize, paramInboxSubject, paramLangId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }
    }
}
