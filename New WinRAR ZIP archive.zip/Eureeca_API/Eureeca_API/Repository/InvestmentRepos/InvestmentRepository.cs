﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Interface.CountryBasedInterface;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.InvestmentModels.ViewModels;
using Eureeca_API.Models.UserModels.ViewModesl;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Localization;
using System.Data;

namespace Eureeca_API.Repository.InvestmentRepos
{
    public class InvestmentRepository : IInvestment
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;
        private readonly IUser _user;
        private readonly IPitch _pitch;
        private readonly IAgreement _agreement;
        private readonly IGeneral _general;
        private readonly ICountryBasedControl _countryBasedControl;
        private readonly IStringLocalizer<Resources.InvestmentRepsitory> _stringLocalizer;

        public InvestmentRepository(IConfiguration config, IUser user, IPitch pitch, IGeneral general, IAgreement agreement, ICountryBasedControl countryBasedControl, IStringLocalizer<Resources.InvestmentRepsitory> stringLocalizer)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
            _user = user;
            _pitch = pitch;
            _general = general;
            _agreement = agreement;
            _countryBasedControl = countryBasedControl;
            _stringLocalizer = stringLocalizer;

        }

        public InvestmentInfoResponseModel InvestmentGetData(int pitchId, int userId, int currencyId, int langId)
        {
            try
            {
                InvestmentInfoResponseModel investmentInfoModel = new InvestmentInfoResponseModel();
                List<InvestmentInfo> investmentInfoList = new List<InvestmentInfo>();
                InvestmentCurrencyModel investmentCurrency = new InvestmentCurrencyModel();
                if (userId != 0)
                {
                    DataTable dtUser = _user.UserSelectById(userId);
                    if (dtUser.Rows.Count > 0)
                    {
                        int userStatus = _user.UserCheckUserStatus(userId.ToString());
                        if (userStatus == (int)UserStatus.InActive || userStatus == (int)UserStatus.Canceled)
                        {
                            investmentInfoModel.ResponseStatus = (int)ResponseStatus.InActiveOrCanceledUser;
                            return investmentInfoModel;
                        }
                        else
                        {
                            KYCModel kyc = _user.KYCGetRequiredFiles(userId, int.Parse(dtUser.Rows[0]["User_Country"].ToString()));
                            if (kyc != null && !kyc.UserCanPay )
                            {
                                investmentInfoModel.ResponseStatus = (int)ResponseStatus.KYCIssue;
                                return investmentInfoModel;
                            }
      
                            List<InvestmentCurrencyModel> investmentCurrencyList = new List<InvestmentCurrencyModel>();
                            string UserBalance = dtUser.Rows[0]["User_Balance"].ToString();
                            int currencyCounter = 0;
                            int SumPendingPreInvestmentsAfterDiscount = 0;
                            int Pitch_Balance = 0;

                            DataTable DTCurrencyForUser = _user.UserGetBalanceForCurrency(userId);
                            if (DTCurrencyForUser.Rows.Count > 0)
                            {
                                for (int i = 0; i < DTCurrencyForUser.Rows.Count; i++)
                                {

                                    if (Convert.ToInt32(DTCurrencyForUser.Rows[i]["User_Blanace"].ToString()) <= 0)
                                    {
                                        currencyCounter++;
                                    }
                                }
                            }
                            if (Convert.ToInt32(UserBalance) <= 0 && currencyCounter == DTCurrencyForUser.Rows.Count)
                            {

                                investmentInfoModel.UserHasBalance = false;
                                return investmentInfoModel;
                            }
                            else
                            {
                                DataTable dtPitchDetails = _pitch.PitchDetailsForQuickInvest(pitchId, langId, currencyId);

                                if (dtPitchDetails.Rows.Count > 0)
                                {

                                    investmentInfoModel.PitchId = pitchId;
                                    investmentInfoModel.PitchTitle = dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString();
                                    string preventionMessage = "";
                                    if (InvestmentPrevention(pitchId, dtUser.Rows[0]["User_Country"].ToString(), userId, out preventionMessage))
                                    {
                                        investmentInfoModel.IsInvestmentPrevented = true;
                                        investmentInfoModel.PreventionReason = preventionMessage;
                                        investmentInfoModel.ResponseStatus = (int)ResponseStatus.InvestmentPrevention;
                                        return investmentInfoModel;
                                    }
                                    else if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() != "published" && dtPitchDetails.Rows[0]["Pitch_Status"].ToString() != "Overfunding" && dtPitchDetails.Rows[0]["Pitch_Status"].ToString() != "Early Access")
                                    {
                                        investmentInfoModel.IsInvestmentPrevented = true;
                                        investmentInfoModel.PreventionReason = _stringLocalizer["InvestmentPreventionCompletedProposal"];
                                        investmentInfoModel.ResponseStatus = (int)ResponseStatus.InvestmentPrevention;
                                        return investmentInfoModel;

                                    }



                                    if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "Early Access")
                                        investmentInfoModel.SumPendingPreInvestmentsAfterDiscount = _pitch.PitchGetSumPendingPreInvestmentsAfterDiscount(pitchId);

                                    if (!string.IsNullOrEmpty(dtPitchDetails.Rows[0]["OverSubStatus"].ToString()) && int.Parse(dtPitchDetails.Rows[0]["OverSubStatus"].ToString()) == 2)
                                        investmentInfoModel.PitchInvestmentRequired = int.Parse(dtPitchDetails.Rows[0]["OverSubAmount"].ToString());
                                    else
                                    {
                                        if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "completed") //this only for the status if pitch was in overfunding mode then the user stopped overfunding and changed it's status to completed
                                            investmentInfoModel.PitchInvestmentRequired = double.Parse(dtPitchDetails.Rows[0]["Pitch_Balance"].ToString());
                                        else
                                            investmentInfoModel.PitchInvestmentRequired = float.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentRequired"].ToString());
                                    }
                                    Pitch_Balance = Convert.ToInt32(double.Parse(dtPitchDetails.Rows[0]["Pitch_Balance"].ToString()) + SumPendingPreInvestmentsAfterDiscount);
                                    double remainAllowedInv = Convert.ToDouble(investmentInfoModel.PitchInvestmentRequired) - Pitch_Balance;



                                    investmentInfoModel.Raised = Convert.ToDouble(dtPitchDetails.Rows[0]["Pitch_balance_Converted"]).ToString("#,##0");//this is only to show the current raised
                                    investmentInfoModel.Raising = Convert.ToDouble(dtPitchDetails.Rows[0]["Pitch_InvestmentRequired_Converted"]).ToString("#,##0");//this is only to show the vurrent needed
                                    if (!string.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_MinInvestmentRequired"] + ""))
                                    {
                                        investmentInfoModel.MinimumInvestmentRequired = Convert.ToDouble(dtPitchDetails.Rows[0]["Pitch_MinInvestmentRequired_Converted"]).ToString("#,##0");//this is only to show the vurrent needed
                                    }

                                    DataTable dtUserCurrecy = _user.UserGetAllInvestmentCurrency(langId, userId);
                                    if (dtUserCurrecy.Rows.Count > 0)
                                    {
                                        foreach (DataRow dr in dtUserCurrecy.Rows)
                                        {

                                            InvestmentCurrencyModel investmentCurrencyModel = new InvestmentCurrencyModel();
                                            investmentCurrencyModel.CurrencyName = dr["Currency"].ToString();
                                            investmentCurrencyModel.CurrencyId = int.Parse(dr["Currency_ID"].ToString());
                                            investmentCurrencyModel.UserBalance = int.Parse(dr["User_Blanace"].ToString()).ToString("#,##0");
                                            investmentCurrencyModel.CurrencySymbol = dr["Currency_Symbol"].ToString();
                                            investmentCurrencyModel.IsInvestEnabled = int.Parse(dr["User_Blanace"].ToString()) > 0;
                                            investmentCurrencyModel.PitchExchangeRate = _pitch.PitchGetPitchRateAsDouble(pitchId, investmentCurrencyModel.CurrencyId);
                                            InvestmentInfo investmentInfo = SetInvestmentInfo(dtPitchDetails, investmentCurrencyModel.CurrencyId, remainAllowedInv, int.Parse(dr["User_Blanace"].ToString()), Pitch_Balance);

                                            investmentInfo.Currency = investmentCurrencyModel;
                                            investmentInfoList.Add(investmentInfo);
                                        }
                                    }

                                    investmentInfoModel.InvestmentInfoList = investmentInfoList;


                                    #region Investment Agreement 
                                    List<Agreement> agreements = new List<Agreement>();

                                    if (bool.Parse(dtPitchDetails.Rows[0]["Pitch_HasMinInvestmentRequired"].ToString()) && dtPitchDetails.Rows[0]["Pitch_Status"].ToString() != "Early Access")
                                    {
                                        Agreement minimumInvestmentAgreement = new Agreement();
                                        minimumInvestmentAgreement.MessageTypeLbl = _stringLocalizer["MinInvestmentAgreement"].Value;
                                        minimumInvestmentAgreement.IsAgreement = true;
                                        agreements.Add(minimumInvestmentAgreement);
                                    }

                                    Agreement investorTermsOfBusinessAgreement = _agreement.AgreementGetEureecaTermsOfUse(int.Parse(dtUser.Rows[0]["User_Country"].ToString()), langId);
                                    if (investorTermsOfBusinessAgreement != null)
                                    {
                                        investorTermsOfBusinessAgreement.MessageTypeLbl = _stringLocalizer["InvestorTermsOfBusinessAgreement"].Value;
                                        investorTermsOfBusinessAgreement.IsAgreement = true;
                                        agreements.Add(investorTermsOfBusinessAgreement);
                                    }

                                    Agreement riskDisclosureAgreement = _agreement.AgreementGetRiskAgreement(int.Parse(dtUser.Rows[0]["User_Country"].ToString()), langId);
                                    if (riskDisclosureAgreement != null)
                                    {
                                        riskDisclosureAgreement.MessageTypeLbl = _stringLocalizer["RiskAgreement"].Value;
                                        riskDisclosureAgreement.IsAgreement = true;
                                        agreements.Add(riskDisclosureAgreement);
                                    }

                                    investmentInfoModel.Agreements = agreements;

                                    if (dtUser.Rows[0]["User_Country"].ToString() == "159" && dtPitchDetails.Rows[0]["Pitch_Country"] != "159")
                                    {
                                        investmentInfoModel.ShowMalaysianWarning = true;
                                        investmentInfoModel.MalaysianWarning = _stringLocalizer["MalWarning"].Value;
                                    }
                                    //investmentInfo.CurrentDiscount = dtPitchDetails.Rows[0]["Current_Discount"].ToString();
                                    //investmentInfo.CurrentRemainingSharesCurrency = dtPitchDetails.Rows[0]["Current_Discount_Size"].ToString();
                                    #endregion

                                    investmentInfoModel.ResponseStatus = (int)ResponseStatus.Success;
                                    return investmentInfoModel;

                                }
                                else // no data
                                {
                                    investmentInfoModel.ResponseStatus = (int)ResponseStatus.EmptyDataTable;
                                    return investmentInfoModel;
                                }
                            }
                        }


                    }
                    else
                    {
                        investmentInfoModel.ResponseStatus = (int)ResponseStatus.UserDoesNotExist;
                        return investmentInfoModel;
                    }

                }
                else
                {
                    investmentInfoModel.ResponseStatus = (int)ResponseStatus.NullUserId;
                    return investmentInfoModel;
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);

            }
        }

        public bool InvestmentPrevention(int pitchId, string userCountry, int userId, out string preventionReason)
        {
            #region Investment Prevention
            /***************** Investment Prevention ******************/
            bool isPrevented = true;
            preventionReason = "";
            DataTable dtPitchDetails = _pitch.PitchGetDedicatedPitchDetailsByLang(pitchId, (int)Languages.English);

            if (!string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_Prevent_Exeption"].ToString()) && !Convert.ToBoolean(dtPitchDetails.Rows[0]["Pitch_Prevent_Exeption"].ToString()))
            {
                int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Invest_Prevent, int.Parse(userCountry), int.Parse(dtPitchDetails.Rows[0]["Pitch_Country"].ToString()));
                if (groupId > 0)
                {
                    DataTable dtUserRequst = _user.UserGetUserRequest((int)RequestType.InvestmentPrevention, userId, int.Parse(dtPitchDetails.Rows[0]["Pitch_ID"].ToString()));
                    if (dtUserRequst.Rows.Count > 0)
                    {
                        bool flag = bool.Parse(dtUserRequst.Rows[0]["flag"].ToString());
                        bool rejectFlag = bool.Parse(dtUserRequst.Rows[0]["Reject_Flag"].ToString());

                        if (!flag && !rejectFlag)
                        {
                            preventionReason = _stringLocalizer["InvestmentPreventionPendingRequest"].Value;
                        }
                        else if (rejectFlag)
                        {
                            preventionReason = _stringLocalizer["InvestmentPreventionNeedRequest"].Value;
                        }
                        else
                        {
                            isPrevented = false;
                        }
                    }
                    else
                    {
                        preventionReason = _stringLocalizer["InvestmentPreventionNeedRequest"].Value;
                    }
                }
                else
                {
                    isPrevented = false;
                }
            }
            else
            {
                isPrevented = false;
            }
            /**********************************************************************/
            #endregion
            return isPrevented;
        }

        private InvestmentInfo SetInvestmentInfo(DataTable dtPitchDetails, int currencyId, double remainAllowedInv, int qInvestAmount4, int Pitch_Balance)
        {
            int pitchId = int.Parse(dtPitchDetails.Rows[0]["Pitch_ID"].ToString());
            InvestmentInfo investmentInfo = new InvestmentInfo();
            int qInvestAmount1 = 500;
            int qInvestAmount2 = 1000;
            int qInvestAmount3 = 1500;
            //int qInvestAmount4 = 0;
            List<int> quickInvestList = new List<int>();

            #region investment amount & equity
            if (Convert.ToInt32(dtPitchDetails.Rows[0]["Pitch_InvestmentWay"]) == 1) // multiple of amounts
            {
                qInvestAmount1 = Convert.ToInt32(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"]) * 1;
                qInvestAmount2 = Convert.ToInt32(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"]) * 2;
                qInvestAmount3 = Convert.ToInt32(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"]) * 3;

            }
            else
            {
                if (Convert.ToInt32(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"]) > 500)
                {
                    qInvestAmount1 = Convert.ToInt32(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"]);
                    qInvestAmount2 = Convert.ToInt32(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"]) + 500;
                    qInvestAmount3 = Convert.ToInt32(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"]) + 1000;
                }

                if (remainAllowedInv < qInvestAmount4)
                {
                    qInvestAmount4 = 0;
                }
            }

            if (remainAllowedInv < qInvestAmount3)
            {
                qInvestAmount3 = 0;

                if (remainAllowedInv < qInvestAmount2)
                {
                    qInvestAmount2 = 0;

                    if (remainAllowedInv < qInvestAmount1)
                    {
                        qInvestAmount1 = Convert.ToInt32(Math.Ceiling(remainAllowedInv));
                    }
                }
            }

            qInvestAmount1 = (int)_pitch.PitchGetExactAmountAfterExchange(qInvestAmount1, currencyId, "1", pitchId);
            qInvestAmount2 = (int)_pitch.PitchGetExactAmountAfterExchange(qInvestAmount2, currencyId, "1", pitchId);
            qInvestAmount3 = (int)_pitch.PitchGetExactAmountAfterExchange(qInvestAmount3, currencyId, "1", pitchId);
            //qInvestAmount4 = (int) _pitch.PitchGetExactAmountAfterExchange(qInvestAmount4, currencyId, "2", pitchId);

            List<float> EquityList = new List<float>();


            if (qInvestAmount1 != 0)
            {
                quickInvestList.Add(qInvestAmount1);
                EquityList.Add(Tools.Round2DP(_pitch.PitchCalcSharesOfDollars(qInvestAmount1, float.Parse(dtPitchDetails.Rows[0]["Pitch_Share_Price"].ToString()), Pitch_Balance, bool.Parse(dtPitchDetails.Rows[0]["Pitch_HasDiscount"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize1"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize1"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize2"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize2"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize3"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize3"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize4"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize4"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString())) * double.Parse(dtPitchDetails.Rows[0]["Pitch_Share_Price"].ToString()) / double.Parse(dtPitchDetails.Rows[0]["Pitch_Post_Money_Val"].ToString()) * 100));//.ToString("f2");

            }
            if (qInvestAmount2 != 2)
            {
                quickInvestList.Add(qInvestAmount2);
                EquityList.Add(Tools.Round2DP(_pitch.PitchCalcSharesOfDollars(qInvestAmount2, float.Parse(dtPitchDetails.Rows[0]["Pitch_Share_Price"].ToString()), Pitch_Balance, bool.Parse(dtPitchDetails.Rows[0]["Pitch_HasDiscount"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize1"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize1"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize2"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize2"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize3"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize3"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize4"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize4"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString())) * double.Parse(dtPitchDetails.Rows[0]["Pitch_Share_Price"].ToString()) / double.Parse(dtPitchDetails.Rows[0]["Pitch_Post_Money_Val"].ToString()) * 100));

            }
            if (qInvestAmount3 != 0)
            {
                quickInvestList.Add(qInvestAmount3);
                EquityList.Add(Tools.Round2DP(_pitch.PitchCalcSharesOfDollars(qInvestAmount3, float.Parse(dtPitchDetails.Rows[0]["Pitch_Share_Price"].ToString()), Pitch_Balance, bool.Parse(dtPitchDetails.Rows[0]["Pitch_HasDiscount"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize1"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize1"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize2"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize2"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize3"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize3"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize4"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize4"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString())) * double.Parse(dtPitchDetails.Rows[0]["Pitch_Share_Price"].ToString()) / double.Parse(dtPitchDetails.Rows[0]["Pitch_Post_Money_Val"].ToString()) * 100));

            }
            if (qInvestAmount4 != 0)
            {
                quickInvestList.Add(qInvestAmount4);
                EquityList.Add(Tools.Round2DP(_pitch.PitchCalcSharesOfDollars(qInvestAmount3, float.Parse(dtPitchDetails.Rows[0]["Pitch_Share_Price"].ToString()), Pitch_Balance, bool.Parse(dtPitchDetails.Rows[0]["Pitch_HasDiscount"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize1"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize1"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize2"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize2"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize3"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize3"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize4"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize4"].ToString()), string.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString())) * double.Parse(dtPitchDetails.Rows[0]["Pitch_Share_Price"].ToString()) / double.Parse(dtPitchDetails.Rows[0]["Pitch_Post_Money_Val"].ToString()) * 100));

            }

            investmentInfo.EquityList = EquityList;
            investmentInfo.QuickInvestList = quickInvestList;
            #endregion

            #region Discount 
            double CurrentRemainingTrancheSize = 0, CurrentRemainingSharesCurrency = 0, TranchDiscount = 0;

            if (Convert.ToBoolean(dtPitchDetails.Rows[0]["Pitch_HasDiscount"].ToString()))//Session["User_Currency"] //Currency_App
                _pitch.PitchGetCurrentTrancheDiscAndRemSizeByBalanceAfterDiscount(dtPitchDetails.Rows[0], float.Parse(Pitch_Balance.ToString()), out TranchDiscount, out CurrentRemainingTrancheSize);


            CurrentRemainingSharesCurrency = _pitch.PitchGetExactAmountAfterExchange(CurrentRemainingTrancheSize, currencyId, "1", pitchId);
            string CurrentRemainingSharesRegex = CurrentRemainingSharesCurrency % 1 == 0 ? "{0:n0}" : "{0:n}";
            DataTable dtCurreny = _general.CurrencyGetCurrencyByID(currencyId);
            string currencySymbol = dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$";
            investmentInfo.CurrentDiscountSizeCurrency = currencySymbol + string.Format(CurrentRemainingSharesRegex, CurrentRemainingSharesCurrency);
            investmentInfo.CurrentDiscount = TranchDiscount;
            #endregion

            return investmentInfo;

        }

        /// <summary>
        /// Get the user amount of completed and pending investments and pending precommitments for one year before from today by currency
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="currencyId"></param>
        /// <returns>Datatable of information</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public DataTable InvestmentGetUserAnnualInvAndPreInv(int userId, int currencyId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", currencyId);
                return _sqlHelper.GetDataTable(_connectionString, "Investment_GetUserAnnualInvAndPreInv", paramUserId, paramCurrencyId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);

                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This method used to get sum user investment amounts on pitch by a given currency
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="pitchId"></param>
        /// <param name="currencyId"></param>
        /// <returns>user investment amount in the pitch</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public int InvestmentGetUserInvestmentAmountOnPitch(int userId, int pitchId, int currencyId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramPitchId = new SqlParameter("@Pitch_ID", pitchId);
                SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", currencyId);
                return _sqlHelper.ExecuteScalar(_connectionString, "Investment_GetTotalUserInvesments", paramUserId, paramPitchId, paramCurrencyId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// When the user enter his investments, it decreases the investment which
        /// he typed in from his balance and add the investment to the pitch invested in the pitch table
        /// and during this operation it saved this transaction which occurred in the pitch investment table and in Balance transaction table 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="pitchId"></param>
        /// <param name="investAmountAfterDiscount"></param>
        /// <param name="sharesSoldBD"></param>
        /// <param name="sharesSoldAD"></param>
        /// <param name="equitySold"></param>
        /// <param name="investmentType"></param>
        /// <param name="Investment_SpecialNotes"></param>
        /// <param name="transactionCurrencyId"></param>
        /// <param name="investmentBackEnd"></param>
        /// <param name="pitchRate"></param>
        /// <param name="investAmountAfterDiscountAfterExchange"></param>
        /// <param name="investmentLoggedInUserId"></param>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public void InvestmentUpdate(string userId, string pitchId, string investAmountAfterDiscount, double sharesSoldBD, double sharesSoldAD, double equitySold, int investmentType,
        string Investment_SpecialNotes, int transactionCurrencyId, bool investmentBackEnd, string pitchRate, int investAmountAfterDiscountAfterExchange, int investmentLoggedInUserId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramPitchId = new SqlParameter("@Pitch_ID", pitchId);
                SqlParameter paramInvestAmountAfterDiscount = new SqlParameter("@investAmountAfterDiscount", investAmountAfterDiscount);
                SqlParameter paramInvestmentSpecialNotes = new SqlParameter("@Investment_SpecialNotes", Investment_SpecialNotes);
                SqlParameter paramCurrencyId = new SqlParameter("@Transaction_CurrencyID", transactionCurrencyId);
                SqlParameter paramInvestmentBackEnd = new SqlParameter("@Investment_BackEnd", investmentBackEnd);
                SqlParameter paramPitchRate = new SqlParameter("@Pitch_Rate", pitchRate);
                SqlParameter paramInvestAmountAfterDiscountAfterExchange = new SqlParameter("@investAmountAfterDiscountAfterExchange", investAmountAfterDiscountAfterExchange);
                SqlParameter paramInvestmentLoggedInUserID = new SqlParameter("@Investment_LoggedInUserID", investmentLoggedInUserId);
                SqlParameter paramEquitySold = new SqlParameter("@Equity_Sold", equitySold);
                SqlParameter paramSharesSoldAD = new SqlParameter("@Shares_Sold_AD", sharesSoldAD);
                SqlParameter paramSharesSoldBD = new SqlParameter("@Shares_Sold_BD", sharesSoldBD);
                SqlParameter paramInvestmentType = new SqlParameter("@InvestmentType", investmentType);
                _sqlHelper.ExecuteReader(_connectionString, "Investment_UpdateInvestment", paramUserId, paramPitchId, paramInvestAmountAfterDiscount, paramInvestmentSpecialNotes, paramCurrencyId, paramInvestmentBackEnd, paramPitchRate, paramInvestAmountAfterDiscountAfterExchange, paramInvestmentLoggedInUserID, paramEquitySold, paramSharesSoldAD, paramSharesSoldBD, paramInvestmentType);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }

        }

        public string GetMoneyAfterExchange(int userId, int pitchId, int currencyId, string amount, string type)
        {
            DataTable DTRate = _pitch.PitchGetPitchRate(pitchId, currencyId);
            if (userId != 0)
            {
                if (DTRate.Rows.Count > 0)
                {
                    if (type == "1")
                        return Convert.ToString(Math.Ceiling(double.Parse(DTRate.Rows[0]["Pitch_rate"].ToString()) * double.Parse(amount)));
                    else if (type == "2")
                        return Convert.ToString(Math.Floor(double.Parse(amount) / double.Parse(DTRate.Rows[0]["Pitch_rate"].ToString())));
                    else return "-2";
                }
                else
                    return "-3";

            }
            else
                return "-1";

        }

        /// <summary>
        /// This method is used to get sum/total of all the user's investment amounts by the currency (method moved from old class)
        /// </summary>
        /// <param name="userId">this is the user ID that we need to get his</param>
        /// <param name="currencyId">this is the user ID that we need to get its remaining time</param>
        /// <returns>int total investmetns amount</returns>
        /// <exception cref="Exception"></exception>
        public int InvestmentGetAllTotalUserInvesments(int userId, int currencyId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", currencyId);

                return _sqlHelper.ExecuteScalar(_connectionString, "Investment_GetAllTotalUserInvesments", paramUserId, paramCurrencyId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get Pending Investments Percentage (method moved from old class)
        /// </summary>
        /// <param name="userId">this is the user ID that we need to get his</param>
        /// <param name="pitchLanguageId">this is the pitch ID that we need to get the investor's pending investment</param>
        /// <param name="pageNo">this is first page number in pagination</param>
        /// <param name="pageSize">this is page size in pagination</param>
        /// <param name="recordCount">this is total records number in pagination</param>
        /// <returns>DataTable of all the data</returns>
        /// <exception cref="Exception"></exception>
        public DataTable InvestmentGetPendingInvestmentsPercentage(int userId, int pitchLanguageId, int pageNo, int pageSize, out int recordCount)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@UserID", userId);
                SqlParameter paramPitchLanguageId = new SqlParameter("@Pitch_LanguageID", pitchLanguageId);
                SqlParameter param_PageNo = new SqlParameter("@PageNo", pageNo);
                SqlParameter param_PageSize = new SqlParameter("@PageSize", pageSize);
                SqlParameter param_RecordCount = new SqlParameter("@RecordCount", SqlDbType.Int, 4);
                param_RecordCount.Direction = ParameterDirection.Output;

                return _sqlHelper.GetDataTable(_connectionString, "User_GetPendingInvestmentsPercentagePaging", out recordCount, paramUserId, paramPitchLanguageId, param_PageNo, param_PageSize, param_RecordCount);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the user's precommitments (method moved from old class)
        /// </summary>
        /// <param name="userId">this is the user ID that we need to get his precommitments</param>
        /// <param name="preComInvestmentStatus">this is the status of returned precommitments or -1 to get all</param>
        /// <param name="languageId">this is the language of the proposal title to be returned with</param>
        /// <param name="currencyId">this is the currency of return precommitments amounts</param>
        /// <returns>Data table of the precommitments data</returns>
        /// <exception cref="Exception"></exception>
        public DataTable InvestmentGetAllUserPreCommitments(int userId, int preComInvestmentStatus, int languageId, int currencyId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramPreComInvestmentStatus = new SqlParameter("@PreComInvestment_Status", DBNull.Value);

                if (preComInvestmentStatus != -1)
                    paramPreComInvestmentStatus = new SqlParameter("@PreComInvestment_Status", preComInvestmentStatus);

                SqlParameter paramProfileLanguageId = new SqlParameter("@Profile_LanguageID", languageId);
                SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", currencyId);

                return _sqlHelper.GetDataTable(_connectionString, "Pitch_GetAllUserPreCommitments", paramUserId, paramPreComInvestmentStatus, paramProfileLanguageId, paramCurrencyId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the user's investments percentage from each category (method moved from old class)
        /// </summary>
        /// <param name="userId">this is the user ID that we need to get his investments percentage</param>
        /// <param name="languageId">this is the language of the returned data</param>
        /// <returns>Data table of the investments data</returns>
        /// <exception cref="Exception"></exception>
        public DataTable InvestmentGetInvestmentsSectors(int userId, int languageId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@UserID", userId);
                SqlParameter paramLanguageId = new SqlParameter("@LanguageID", languageId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetInvestmentsSectors", paramUserId, paramLanguageId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the user's investments percentage from each invested proposal by currency (method moved from old class)
        /// </summary>
        /// <param name="userId">this is the user ID that we need to get his investments percentage</param>
        /// <param name="languageId">this is the language of the returned data</param>
        /// <param name="currencyId">this is the currency of the returned data</param>
        /// <returns>Data table of the investments data</returns>
        /// <exception cref="Exception"></exception>
        public DataTable InvestmentGetInvestmentsBreakdown(int userId, int languageId, int currencyId)
        {
            try
            {
                SqlParameter paramUserID = new SqlParameter("@UserID", userId);
                SqlParameter paramLanguageId = new SqlParameter("@LanguageID", languageId);
                SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", currencyId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetInvestmentsBreakdown", paramUserID, paramLanguageId, paramCurrencyId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the user's investments percentage from each investment status (method moved from old class)
        /// </summary>
        /// <param name="userId">this is the user ID that we need to get his investments percentage</param>
        /// <returns>Data table of the investments data</returns>
        /// <exception cref="Exception"></exception>
        public DataTable InvestmentGetInvestmentActiveClosed(int userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@UserID", userId);
                return _sqlHelper.GetDataTable(_connectionString, "User_GetInvestmentActiveClosed", paramUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
    }
}