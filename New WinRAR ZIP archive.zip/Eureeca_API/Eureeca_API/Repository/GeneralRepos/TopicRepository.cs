﻿using Eureeca_API.General;
using Eureeca_API.Interface;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Localization;
using System.Data;
using System.Data.Common;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Eureeca_API.Repository.GeneralRepos
{
    public class TopicRepository : ITopic
    {
        private readonly string _connectionString;
        private readonly IStringLocalizer<Resources.TopicRepository> _stringLocalizer;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;

        public TopicRepository(IConfiguration config, IStringLocalizer<Resources.TopicRepository> stringLocalizer)
        {
            _connectionString = config.GetConnectionString("ForumCQAConnection");
            _stringLocalizer = stringLocalizer;
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();

        }

        public DataTable TopicGetAcceptedQuestionsOfTopic(int questionTopicId, int questionLanguageId)
        {
            try
            {
                SqlParameter paramQuestionTopicId = new SqlParameter("@QUESTION_TOPIC_ID", questionTopicId);
                SqlParameter paramQuestionLanguageId = new SqlParameter("@QUESTION_LANGUAGEID", questionLanguageId);
                if (questionLanguageId == -1)
                    paramQuestionLanguageId.Value = DBNull.Value;

                return _sqlHelper.GetDataTable(_connectionString, "QUESTION_getAcceptedQuestionsOfTopic", paramQuestionTopicId, paramQuestionLanguageId);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        public DataTable TopicGetAcceptedAnswersOfQuestion(int questionId)
        {
            try
            {
                SqlParameter paramQuestionId = new SqlParameter("@ANSWER_QUESTION_ID", questionId);
                return _sqlHelper.GetDataTable(_connectionString, "ANSWER_getAcceptedAnswersOfQuestion", paramQuestionId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        public List<string> TopicGetQuestionsAffiliationDisclosure(int langId)
        {
            List<string> questionsAffiliation = new List<string>();
            questionsAffiliation.Add(_stringLocalizer["AFFD_NoRelationship"]);
            questionsAffiliation.Add(_stringLocalizer["AFFD_Customer"]);
            questionsAffiliation.Add(_stringLocalizer["AFFD_Employee"]);
            questionsAffiliation.Add(_stringLocalizer["AFFD_Director"]);
            questionsAffiliation.Add(_stringLocalizer["AFFD_ExistingPreviousInvestor"]);
            questionsAffiliation.Add(_stringLocalizer["AFFD_CloseRelative"]);
            questionsAffiliation.Add(_stringLocalizer["AFFD_ReferralParty"]);
            questionsAffiliation.Add(_stringLocalizer["AFFD_Other"]);

            return questionsAffiliation;
        }

        public int TopicAddTopic(int topicTypeId, string topicName, int topicUserId, string topicCreationDate)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("TOPIC_addTopic", sql))
                    {
                        topicName = Tools.FilterHTML(topicName);
                        int topicId = 0;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@TOPIC_TOPICTYPE_ID", topicTypeId);
                        cmd.Parameters.AddWithValue("@TOPIC_NAME", topicName);
                        cmd.Parameters.AddWithValue("@TOPIC_USERID", topicUserId);
                        cmd.Parameters.AddWithValue("@TOPIC_CREATION_DATE", topicCreationDate);
                        sql.Open();
                        SqlDataReader data = cmd.ExecuteReader();
                        if (data.Read())
                            topicId = Int32.Parse(data[0].ToString());
                        return topicId;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public DataTable TopicGetTopicTypeDetailsByName(string topicTypeName)
        {
            try
            {
                SqlParameter paramTopicTypeName = new SqlParameter("TOPIC_TYPE_NAME", topicTypeName);
                return _sqlHelper.GetDataTable(_connectionString, "TOPIC_TYPE_getTopicTypeDetailsByName", paramTopicTypeName);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get all details of dedicated topic type
        /// </summary>
        /// <param name="topicTypeId"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception">Will write the error in the errorlog file</exception>
        public DataTable TopicGetTopicTypeDetails(int topicTypeId)
        {
            try
            {
                SqlParameter paramTopicTypeId = new SqlParameter("@TOPIC_TYPE_ID", topicTypeId);
                return _sqlHelper.GetDataTable(_connectionString, "TOPIC_TYPE_getTypeDetails", paramTopicTypeId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get topic details
        /// </summary>
        /// <param name="topicId"></param>
        /// <returns>DatatableOf information</returns>
        public DataTable TopicGetTopicDetails(int topicId)
        {
            try
            {
                SqlParameter paramTopicId = new SqlParameter("@TOPIC_ID", topicId);
                return _sqlHelper.GetDataTable(_connectionString, "TOPIC_getTopicDetails", paramTopicId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        public int TopicAddQuestion(string questionText, string date, int questionerId, int topicId, string acceptance, int langId, int relationshipToSME, string relationshipToSMEWhenOther)
        {
            try
            {
                SqlParameter paramQuestionText = new SqlParameter("@QUESTION_TEXT", questionText);
                SqlParameter paramQuestionDate = new SqlParameter("@QUESTION_DATE", date);
                SqlParameter paramQuestionerId = new SqlParameter("@QUESTION_QUESTIONER_ID", questionerId);
                SqlParameter paramTopicId = new SqlParameter("@QUESTION_TOPIC_ID", topicId);
                SqlParameter paramAcceptance = new SqlParameter("@QUESTION_ACCEPTANCE", acceptance);
                SqlParameter paramLangId = new SqlParameter("@QUESTION_LANGUAGEID", langId);
                SqlParameter paramRelationshipToSME = new SqlParameter("@QUESTION_RelationshipToSME", relationshipToSME);
                SqlParameter paramRelationshipToSMEWhenOther = new SqlParameter("@QUESTION_RelationshipToSMEWhenOther", DBNull.Value);
                if (relationshipToSMEWhenOther != null)
                    paramRelationshipToSMEWhenOther.Value = relationshipToSMEWhenOther;

                return _sqlHelper.ExecuteScalar(_connectionString, "QUESTION_addQuestion", paramQuestionText, paramQuestionDate, paramQuestionerId, paramTopicId, paramAcceptance, paramLangId, paramRelationshipToSME, paramRelationshipToSMEWhenOther);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }

        }

        public void TopicAddAnswer(int topicId, string answertext, string answerDate, int userId, int questionId, string answerAcceptance)
        {
            try
            {
                SqlParameter paramTopicId = new SqlParameter("@TOPIC_ID", topicId);
                SqlParameter paramAnswerText = new SqlParameter("@ANSWER_TEXT", answertext);
                SqlParameter paramAnswerDate = new SqlParameter("@ANSWER_DATE", answerDate);
                SqlParameter paramAnswererId = new SqlParameter("@ANSWER_ANSWERER_ID", userId);
                SqlParameter paramQuestionId = new SqlParameter("@ANSWER_QUESTION_ID", questionId);
                SqlParameter paramAnswerAcceptance = new SqlParameter("@ANSWER_ACCEPTANCE", answerAcceptance);
                _sqlHelper.ExecuteNonQuery(_connectionString, "ANSWER_addAnswer", paramTopicId, paramAnswerText, paramAnswerDate, paramQuestionId, paramAnswererId, paramAnswerAcceptance);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }
    }
}
