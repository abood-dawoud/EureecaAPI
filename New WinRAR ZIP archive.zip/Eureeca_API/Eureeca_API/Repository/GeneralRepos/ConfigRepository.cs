﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.GeneralRepos
{
    public class ConfigRepository : IConfig
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;
        public ConfigRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }
        /// <summary>
        /// This method is used to get configuration value
        /// </summary>
        /// <param name="configVariable"></param>
        /// <returns>Data table of all information.</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable ConfigsGetConfigValue(ConfigurationsEnum configVariable)
        {
            try
            {
                SqlParameter paramConfigVariable = new SqlParameter("@Config_Variable", (int)configVariable);
                return _sqlHelper.GetDataTable(_connectionString, "Configs_GetConfigValue", paramConfigVariable);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
    }
}
