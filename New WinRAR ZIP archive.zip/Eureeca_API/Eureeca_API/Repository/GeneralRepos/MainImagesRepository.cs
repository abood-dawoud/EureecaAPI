﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Interface.CountryBasedInterface;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.PitchModels.ViewModels;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.GeneralRepos
{
    public class MainImagesRepository : IMainImages
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;
        private readonly IConfiguration _config;
        private readonly IUser _user;
        private readonly IPitch _pitch;
        private readonly ICountryBasedControl _countryBasedControl;
        private readonly IKYC _kyc;
        private readonly IPitchAttachements _pitchAttachements;


        public MainImagesRepository(IConfiguration config, IUser user, IPitch pitch, ICountryBasedControl countryBasedControl, IKYC kyc, IPitchAttachements pitchAttachements)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
            _config = config;
            _user = user;
            _pitch = pitch;
            _countryBasedControl = countryBasedControl;
            _kyc = kyc;
            _pitchAttachements = pitchAttachements;

        }


        public List<PitchBanner> MainImagesGetBannerProposal(int userId, int langId, int countryId, int currencyId)
        {
            List<PitchBanner> pitchBanners = new List<PitchBanner>();
            DataTable dtSlider = new DataTable();
            int KYCNeededDocs = 0;
            if (userId != 0)
            {
                DataTable dtUserInfo = _user.UserSelectById(userId);

                int NeededDocs = 0;
                int AcceptedDocsFromNeeded = 0;

                if (dtUserInfo.Rows.Count > 0)
                {
                    if (int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.Enreprenuer && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.Admin && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.BIAdmin && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.SystemAdmin)
                    {
                        int[] array = new int[19];
                        DataTable dtUserCountry = _countryBasedControl.CountryBasedGetCountryDetails(countryId, (int)Languages.English);
                        if (dtUserCountry.Rows.Count > 0)
                            array = _kyc.KYCGetRequiredDocs(userId, int.Parse(dtUserCountry.Rows[0]["Country_KYC_Tire"].ToString()));

                        NeededDocs = array[0];
                        AcceptedDocsFromNeeded = array[18];
                    }
                }

                KYCNeededDocs = NeededDocs - AcceptedDocsFromNeeded;
            }
            if (langId != 0 && countryId != 0)
            {
                int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.MainBannerImages, countryId);
                if (groupId > 0)
                    dtSlider = _pitch.PitchGetSortPitchHomePageSlider(langId, currencyId);
            }

            foreach (DataRow dr in dtSlider.Rows)
            {
                PitchBanner pitch = new PitchBanner();
                pitch.PitchStatus = dr["Pitch_Status"].ToString();
                List<Investor> investors = new List<Investor>();
                if (userId != 0)
                {
                    DataTable dtLoggedInUserInfo = _user.UserSelectById(userId);
                    if (pitch.PitchStatus != "published" && pitch.PitchStatus != "Overfunding" || dtLoggedInUserInfo.Rows[0]["User_UserType"].ToString() != "2" && dtLoggedInUserInfo.Rows[0]["User_UserType"].ToString() != "4" || Convert.ToInt32(dtLoggedInUserInfo.Rows[0]["User_UserFormType"]) == (int)UserType.Enreprenuer ||
                        KYCNeededDocs > 0 && (countryId == 2 || countryId == 260) && (pitch.PitchStatus == "Early Access" || pitch.PitchStatus == "published" || pitch.PitchStatus == "Overfunding")
                    )
                    {
                        pitch.IsInvestEnabled = false;
                    }

                    if (Convert.ToInt32(dtLoggedInUserInfo.Rows[0]["User_UserFormType"]) == (int)UserType.Enreprenuer)
                    {
                        pitch.IsInvestEnabled = false;
                    }
                }

                DataTable DTCounter = _pitch.PitchGetCounter(int.Parse(dr["Pitch_ID"].ToString()));
                int CounterPitchInvestors = int.Parse(DTCounter.Rows[0]["Counter_PitchInvestors"].ToString());
                string CounterPitchInvestorsOver = CounterPitchInvestors > 0 ? (CounterPitchInvestors - 1).ToString() : "0";
                string ProfilePitchTitle = dr["Profile_PitchTitle"].ToString();
                string PitchInvestedSoFar = Math.Floor(float.Parse(dr["Pitch_InvestedSoFar"].ToString())).ToString();
                string PitchBalance = string.Format("{0:n0}", double.Parse(dr["Pitch_Balance"].ToString()));
                pitch.PitchId = int.Parse(dr["Pitch_ID"].ToString());
                pitch.PitchBannerTitle = dr["PitchBannerOption_Title1"].ToString().Replace("[Profile_PitchTitle]", ProfilePitchTitle).Replace("[Pitch_InvestedSoFar]", PitchInvestedSoFar).Replace("[Pitch_Balance]", PitchBalance).Replace("$", "");
                pitch.PitchBannerBody = dr["PitchBannerOption_Title2"].ToString().Replace("[Profile_PitchTitle]", ProfilePitchTitle).Replace("[Pitch_InvestedSoFar]", PitchInvestedSoFar).Replace("[Pitch_Balance]", PitchBalance).Replace("[Counter_PitchInvestorsOver]", CounterPitchInvestorsOver).Replace("[Counter_PitchInvestors]", CounterPitchInvestors.ToString()).Replace("$", "");
                if (string.IsNullOrEmpty(dr["Profile_PitchBannerID"].ToString().Trim()))
                    pitch.ImageURL = _config.GetValue<string>("AssetsEnvironmentURL") + "Images/default.jpg";
                else
                {
                    DataTable dtPitchAttachInf = _pitchAttachements.PitchAttachmentGetDetails(int.Parse(dr["Profile_PitchBannerID"].ToString()));

                    if (dtPitchAttachInf.Rows.Count > 0)
                    {
                        string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                        if (!File.Exists(Path.Combine(_config.GetValue<string>("AttachementsEnvironmentURL") + "pitch/" + img)))
                            pitch.ImageURL = _config.GetValue<string>("AssetsEnvironmentURL") + "Images/default.jpg";
                        else
                            pitch.ImageURL = _config.GetValue<string>("AttachementsEnvironmentURL") + "pitch/" + img;

                    }
                    else
                        pitch.ImageURL = _config.GetValue<string>("AssetsEnvironmentURL") + "Images/default.jpg";
                }

                DataTable dtInvestors = _pitch.PitchGetTop6InvestorsForSlider(pitch.PitchId);
                if (dtInvestors.Rows.Count != 0)
                {
                    foreach (DataRow drInvestor in dtInvestors.Rows)
                    {
                        Investor investor = new Investor();
                        investor.username = drInvestor["User_Username"].ToString();
                        investor.Id = int.Parse(drInvestor["User_ID"].ToString());
                        if (string.IsNullOrEmpty(drInvestor["User_Picture"].ToString()) || !File.Exists(_config.GetValue<string>("AttachementsEnvironmentURL") + "User/thumbs/thumb_" + drInvestor["User_Picture"].ToString()))
                            investor.UserImage = _config.GetValue<string>("EnvironmentURL") + "/images/v2/Default.jpg";
                        else
                            investor.UserImage = _config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + drInvestor["User_Picture"].ToString();
                        investors.Add(investor);

                    }

                }
                pitch.Investors = investors;
                pitch.RemainInvestorCount = CounterPitchInvestors - pitch.Investors.Count;

                if (_pitch.PitchIsProposalViewPrevented(dr, countryId, userId.ToString()))
                    dr.Delete();
                else
                    pitchBanners.Add(pitch);


            }
            dtSlider.AcceptChanges();

            return pitchBanners;

        }


        /// <summary>
        /// This method is used to return the MainBanner images
        /// </summary>
        /// <param name="langId"></param>
        /// <param name="countryId"></param>
        /// <returns>List of MainBanner images</returns>
        public List<MainImage> MainImagesBindImagesWithButton(int langId, int countryId)
        {
            DataTable DTSliderBtn = new DataTable();
            List<MainImage> images = new List<MainImage>();
            if (langId != 0 && countryId != 0)
            {
                int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.MainBannerImages, countryId);
                if (groupId > 0)
                    DTSliderBtn = MainImagesGetActiveImages(groupId, langId);
                if (DTSliderBtn.Rows.Count > 0)
                {
                    foreach (DataRow dr in DTSliderBtn.Rows)
                    {
                        MainImage mainImage = new MainImage();
                        mainImage.Id = int.Parse(dr["Image_ID"].ToString());
                        mainImage.Title = dr["Image_Title"].ToString();
                        mainImage.Body = dr["Image_Body"].ToString();
                        mainImage.CustomButtonTitle = dr["Image_ButtonText"].ToString();
                        mainImage.ShowButtons = bool.Parse(dr["Image_ShowButtons"].ToString());
                        mainImage.CustomButtonURL = dr["Image_URL"].ToString();
                        mainImage.ImageURL = _config.GetValue<string>("AttachementsEnvironmentURL") + "/Attachments/Slider/" + dr["Image_Guid"].ToString() + dr["Image_Path"].ToString(); ;

                        images.Add(mainImage);
                    }

                }
            }
            return images;
        }


        /// <summary>
        /// this function is used to get the country based group images of dedicated language
        /// </summary>
        /// <param name="groupId"></param>
        /// <param name="langId"></param>
        /// <returns>DataTable of Information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable MainImagesGetActiveImages(int groupId, int langId)
        {
            try
            {
                SqlParameter paramGroupId = new SqlParameter("@Image_Group_ID", groupId);
                SqlParameter paramLangId = new SqlParameter("@Image_LanguageID", langId);
                return _sqlHelper.GetDataTable(_connectionString, "MainImages_GetActiveImages", paramGroupId, paramLangId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message);
            }
        }


    }
}
