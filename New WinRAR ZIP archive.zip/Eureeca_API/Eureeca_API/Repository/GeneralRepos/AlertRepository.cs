﻿using Eureeca_API.General;
using Eureeca_API.Interface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.GeneralRepos
{
    public class AlertRepository : IAlert
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;

        public AlertRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }
        /// <summary>
        /// This method is used to Update the show in login
        /// </summary>
        /// <returns>Data table of all information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable AlertGetAllShowInLogin()
        {
            try
            {
                return _sqlHelper.GetDataTable(_connectionString, "Alert_Get_All_Show_In_Login", null);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to Add Update Alert
        /// </summary>
        /// <param name="alertId"></param>
        /// <param name="userId"></param>
        /// <param name="accept"></param>
        /// <exception cref="Exception"></exception>
        public void AlertUserAddAcceptUser(int alertId, int userId, bool accept)
        {
            try
            {
                SqlParameter paramAlertId = new SqlParameter("@Alert_ID", alertId);
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                SqlParameter paramAccept = new SqlParameter("@Accept", accept);

                _sqlHelper.ExecuteNonQuery(_connectionString, "Alert_User_Add_Accept_User", paramAlertId, paramUserId, paramAccept);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to check alert last one to show in login
        /// </summary>
        /// <param name="userId">This is the user id will check the alert </param>
        /// <returns>Data table of all information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable AlertCheckAlertOnLogin(int userId)
        {
            try
            {
                SqlParameter paramUserId = new SqlParameter("@User_ID", userId);
                return _sqlHelper.GetDataTable(_connectionString, "Alert_CheckAlertOnLogin", paramUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }


    }
}
