﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using MaxMind.GeoIP2;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using System.Data;
using System.Net;
using System.Text;

namespace Eureeca_API.Repository.GeneralRepos
{
    public class GeoIPRepository : IGeoIP
    {
        private readonly IConfiguration _config;
        private readonly string _connectionString;
        private readonly DatabaseReader _lookup;
        private readonly ErrHandler _errHandler;



        public GeoIPRepository(IConfiguration config)
        {
            _config = config;
            _connectionString = config.GetConnectionString("dbConnection");
            _lookup = new DatabaseReader(Path.Combine("AppData/GeoIP.mmdb"));
            _errHandler = new ErrHandler();
        }

        public int GeoGetCountryId(string userIP)
        {
            try
            {
                int countryId = 0;
                if (userIP != null)
                {
                    string countryCode = GetUserCountryCode(userIP);
                    if (countryCode != null)
                        return GetEureecaCountryID(countryCode);
                }
                return countryId;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }


        }

        public string GetUserCountryCode(string userIP)
        {
            try
            {

                // this is switch between maxmind geo ip, web service or local db file
                if (_config.GetValue<string>("ActivateMaxmindWebService") == "1")
                {
                    return GetMaxmindCountry(userIP);
                }
                else
                {
                    try
                    {

                        var country = _lookup.Country(userIP);
                        if (!string.IsNullOrWhiteSpace(country.Country.ToString()))
                        {
                            return country.Country.IsoCode;
                        }
                        else if (!string.IsNullOrWhiteSpace(country.RegisteredCountry.ToString()))
                        {
                            return country.RegisteredCountry.IsoCode;
                        }
                        else if (!string.IsNullOrWhiteSpace(country.RepresentedCountry.ToString()))
                        {
                            return country.RepresentedCountry.IsoCode;
                        }
                        else return "-1";
                    }
                    catch (MaxMind.GeoIP2.Exceptions.AddressNotFoundException ex)
                    {
                        return "-1";
                    }
                    catch (MaxMind.GeoIP2.Exceptions.GeoIP2Exception ex)
                    {
                        return "-1";
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError("GeoIP Service Error:\n" + ex.Message + "\n" + ex.StackTrace);
                return string.Empty;
            }
        }

        public int GetEureecaCountryID(string CountryCode)
        {
            try
            {
                DataTable dt = GetCountryDetailsByCode(CountryCode, (int)Languages.English);

                if (dt.Rows.Count > 0)
                    return int.Parse(dt.Rows[0]["Country_ID"].ToString());

                return 0;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        private DataTable GetCountryDetailsByCode(string CountryCode, int Profile_LanguageID)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand comm = new SqlCommand("GetCountryDetailsByCode", sql))
                    {
                        comm.CommandType = CommandType.StoredProcedure;

                        comm.Parameters.AddWithValue("@Country_Code", CountryCode);
                        comm.Parameters.AddWithValue("@Profile_LanguageID", Profile_LanguageID);

                        sql.Open();
                        SqlDataAdapter da = new SqlDataAdapter(comm);

                        DataTable DT = new DataTable();

                        da.Fill(DT);

                        return DT;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }


        }

        public string GetMaxmindCountry(string ip)
        {
            try
            {
                string Maxmind_URL = _config.GetValue<string>("MaxmindURL");
                string Maxmind_UserID = _config.GetValue<string>("MaxmindUserID");
                string Maxmind_License_Key = _config.GetValue<string>("MaxmindLicenseKey");

                string requestURL = string.Format("{0}{1}", Maxmind_URL, ip);

                string svcCredentials = Convert.ToBase64String(Encoding.ASCII.GetBytes(Maxmind_UserID + ":" + Maxmind_License_Key));

                HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(requestURL);
                httpWebRequest.ProtocolVersion = HttpVersion.Version11;
                httpWebRequest.Method = "GET";
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Headers.Add("Authorization", "Basic " + svcCredentials);
                httpWebRequest.ContentLength = 0;

                using (WebResponse response6 = httpWebRequest.GetResponse())
                {
                    using (Stream stream5 = response6.GetResponseStream())
                    {
                        HttpWebResponse response = (HttpWebResponse)httpWebRequest.GetResponse();

                        if ((int)response.StatusCode == 200) //OK -  
                        {
                            StreamReader reader = new StreamReader(response6.GetResponseStream(), Encoding.Default);

                            string jsonresponse = "";
                            string temp = null;
                            while ((temp = reader.ReadLine()) != null)
                            {
                                jsonresponse += temp;
                            }
                            JsonConvert.DeserializeObject(jsonresponse);

                            var jObject = Newtonsoft.Json.Linq.JObject.Parse(jsonresponse);
                            var countryObj = Newtonsoft.Json.Linq.JObject.Parse(jObject["country"].ToString());

                            return (string)countryObj["iso_code"];
                        }
                        else
                            return "-1";
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
    }
}
