﻿using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.GeneralRepos
{
    public class NewsRepository : INews
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly IConfiguration _config;

        public NewsRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _config = config;
        }
        public List<News> NewsGetHomeNews(int langId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("News_GetHomeNews", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@Profile_LanguageID", langId));
                        sql.Open();
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                List<News> newses = new List<News>();
                                newses = Tools.DataReaderMapToList<News>(reader);
                                foreach (News news in newses)
                                {
                                    news.News_Profile_Image = _config.GetValue<string>("AttachementsEnvironmentURL") + "News/Thumbs/Thumb_" + news.News_Profile_Image;
                                }
                                return newses;
                            }
                            return null;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public List<News> NewsGetNews(int newsProfileLanguageId, string newsId)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlDataAdapter adpt = new SqlDataAdapter("News_GetNews", sql))
                    {
                        adpt.SelectCommand.CommandType = CommandType.StoredProcedure;
                        adpt.SelectCommand.Parameters.AddWithValue("@News_Profile_LanguageID", newsProfileLanguageId);
                        if (newsId != "")
                            adpt.SelectCommand.Parameters.AddWithValue("@News_ID", newsId);
                        DataTable DT = new DataTable();
                        adpt.Fill(DT);

                        List<News> newses = new List<News>();
                        newses = Tools.ConvertDataTable<News>(DT);
                        foreach (News news in newses)
                        {

                            news.News_Profile_Image = _config.GetValue<string>("AttachementsEnvironmentURL") + "News/Thumbs/Thumb_" + news.News_Profile_Image;
                        }

                        return newses;
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
    }
}
