﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Interface.CountryBasedInterface;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.UserModels.ViewModesl;
using Google.Apis.Sheets.v4.Data;
using MaxMind.Db;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Localization;
using System.Data;

namespace Eureeca_API.Repository.GeneralRepos
{
    public class GeneralRepository : IGeneral
    {
        private readonly string _connectionString;
        private int _currencyId;
        private readonly ICountryBasedControl _countryBasedControlRepository;
        private readonly INews _news;
        private readonly IPitch _pitch;
        private readonly ILead _lead;
        private readonly IConfiguration _config;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;
        public GeneralRepository(ICountryBasedControl countryBasedControlRepository, INews news, IPitch pitch, IConfiguration config, ILead lead)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _countryBasedControlRepository = countryBasedControlRepository;
            _news = news;
            _pitch = pitch;
            _lead = lead;
            _config = config;
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }

        public Statistics StatsGetAll(string statsID, int currencyId)
        {
            try
            {
                Statistics statistics = new Statistics();
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Stats_GetAll", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        SqlParameter paramStatsId = new SqlParameter("@Stats_ID", null);
                        if (statsID != "")
                            paramStatsId.Value = statsID;

                        cmd.Parameters.Add(paramStatsId);
                        sql.Open();
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                this._currencyId = currencyId;
                                statistics = MapStatsToValue(reader);
                            }
                            return statistics;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public float CurrencyGetGlobalRate(int currencyId)
        {
            try
            {
                float value = 0;

                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Currency_GetGlobalExchangeRateByID", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@CurrencyID", currencyId));
                        sql.Open();

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                //value = reader["Currency_GlobalExchangeRate"] == DBNull.Value ? 1f :(float)reader["Currency_GlobalExchangeRate"];
                                value = float.Parse(reader["Currency_GlobalExchangeRate"].ToString());
                                this._currencyId = currencyId;
                            }
                        }

                    }
                }

                return value;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        public List<CurrencyModel> CONSTGetCurrencies(int langId)
        {
            try
            {
                SqlParameter paramLangId = new SqlParameter("@Currency_LangID", langId);
                DataTable dt = _sqlHelper.GetDataTable(_connectionString, "User_GetAllPaymentCurrency", paramLangId);
                return Tools.ConvertDataTable<CurrencyModel>(dt);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        private Statistics MapStatsToValue(SqlDataReader reader)
        {
            return new Statistics()
            {
                Countries = reader["Stats_Countries"].ToString(),
                ProposalsOverfunded = reader["Stats_Proposals_overfunded"].ToString(),
                ActiveUsers = reader["ActiveUsers"].ToString(),
                AverageInvestment = string.Format("{0:##,##}", int.Parse(reader["Stats_Average_Investment"].ToString()) * CurrencyGetGlobalRate(_currencyId)),
                EureecaOverviewVideo = "odeo117gco"

            };
        }

        public List<Country> CONSTGetCountries(int langId, string countryName)
        {
            try
            {
                SqlParameter paramLangId = new SqlParameter("@LanguageID", langId);
                SqlParameter paramCountryName = new SqlParameter("@Country_Name", DBNull.Value);
                if (countryName != null && !string.IsNullOrWhiteSpace(countryName.Trim()))
                    paramCountryName.Value = countryName;
                SqlParameter paramKYCTier = new SqlParameter("@KYC_Tier", DBNull.Value);
                SqlParameter paramPageNo = new SqlParameter("@PageNo", 1);

                SqlParameter paramRecordCount = new SqlParameter("@RecordCount", SqlDbType.Int, 4);
                paramRecordCount.Direction = ParameterDirection.Output;

                SqlParameter paramPageSize = new SqlParameter("@PageSize", 100000);
                DataTable DT = _sqlHelper.GetDataTable(_connectionString, "GetCountryList", paramLangId, paramCountryName, paramKYCTier, paramPageNo, paramPageSize, paramRecordCount);

                foreach (DataRow dr in DT.Rows)
                {
                    dr["Country_Flag_URL"] = _config.GetValue<string>("AssetsEnvironmentURL") + "circle_flags/" + dr["Country_Flag_URL"];
                }
                return Tools.ConvertDataTable<Country>(DT);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        public List<Language> CONSTGetLanguages(int? langId = 0)
        {
            try
            {
                using (SqlConnection sql = new SqlConnection(_connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("Languages_GetLanguageData", sql))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        SqlParameter paramLanguageId = new SqlParameter("@Language_ID", SqlDbType.Int);
                        if (langId > 0)
                            paramLanguageId.Value = langId;

                        cmd.Parameters.Add(paramLanguageId);

                        sql.Open();
                        SqlDataAdapter DA = new SqlDataAdapter(cmd);

                        DataTable DT = new DataTable();

                        DA.Fill(DT);
                        foreach (DataRow dr in DT.Rows)
                        {
                            dr["Language_FlagPath"] = _config.GetValue<string>("EnvironmentURL")  + dr["Language_FlagPath"];
                        }
                        return Tools.ConvertDataTable<Language>(DT);
                    }
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        public List<KeyInvestor> HomeGetTop10Investor(int? langId, int currencyId, int countryId, string userId)
        {
            try
            {

                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                SqlParameter paramCurrencyId = new SqlParameter("@CurrencyID", currencyId);

                DataTable dt = _sqlHelper.GetDataTable(_connectionString, "User_GetTop10InvestorForPitch", paramLangId, paramCurrencyId);
                foreach (DataRow dr in dt.Rows)
                {
                    if (_pitch.PitchIsProposalViewPrevented(dr, countryId, userId))
                        dr.Delete();
                }
                List<KeyInvestor> keyInvestors = Tools.ConvertDataTable<KeyInvestor>(dt);
                return keyInvestors;


            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        public List<Testimonials> HomeGetTestimonials(int langId, int countryId)
        {
            try
            {
                int groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Testimonials, countryId);
                if (groupId > 0)
                {
                    DataTable testimonialsDT = _countryBasedControlRepository.CountryBasedGetGroupDataProfile(groupId, langId);

                    List<Testimonials> testimonials = new List<Testimonials>();
                    testimonials = Tools.ConvertDataTable<Testimonials>(testimonialsDT);
                    foreach (Testimonials testimonial in testimonials)
                    {

                        testimonial.Img_Name = _config.GetValue<string>("AttachementsEnvironmentURL") + "Testimonials/" + testimonial.Img_Name;
                    }

                    return testimonials;

                }
                return null;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        public DefaultPageCustomModel HomeGetNewsTestimonialsKeyInvestor(int langId, int countryId, int currencyId, string userId)
        {
            try
            {
                DefaultPageCustomModel result = new DefaultPageCustomModel();
                result.KeyInvestors = HomeGetTop10Investor(langId, currencyId, countryId, userId);
                result.News = _news.NewsGetHomeNews(langId);
                result.Testimonials = HomeGetTestimonials(langId, countryId);
                return result;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public int SubscribeByEmail(string email, int countryId)
        {
            try
            {
                if (email != null)
                {
                    if (string.IsNullOrEmpty(email.ToString().Trim()))
                    {
                        return 4;
                    }
                    else if (!string.IsNullOrEmpty(email.ToString().Trim()) && !System.Text.RegularExpressions.Regex.IsMatch(email.ToString().Trim(), @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"))
                    {
                        return 3;
                    }
                    else
                    {
                        if (countryId != 0)
                        {
                            _lead.LeadUsersAddNewLead(0, (int)UserType.Investor, Tools.FilterHTML(email.ToString()), "", "", (int)LeadSource.MailChimp, new string[] { }, "", "News Letter Home Page", countryId, "", "", "", "", 0, false);
                            return 1;
                        }
                        else return 2;

                    }
                }
                else return 2;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the cureency Details depends on Id
        /// </summary>
        /// <param name="Currency_ID"></param>
        /// <returns>Data table of information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable CurrencyGetCurrencyByID(int currencyId)
        {
            try
            {

                SqlParameter paramCurrencyId = new SqlParameter("@Currency_ID", currencyId);
                return _sqlHelper.GetDataTable(_connectionString, "Currency_GetCurrencyByID", paramCurrencyId);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        public string CurrencyGetCurrencySymbol(Currencies currency)
        {
            DataTable dtCurreny = CurrencyGetCurrencyByID((int)currency);
            return dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$";

        }


    }
}
