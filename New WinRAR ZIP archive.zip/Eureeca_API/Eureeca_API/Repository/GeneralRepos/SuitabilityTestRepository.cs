﻿using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Models;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.GeneralRepos
{
    public class SuitabilityTestRepository : ISuitabilityTest
    {
        private readonly string _connectionString;
        private readonly SqlHelper _sqlHelper;
        private readonly ErrHandler _errHandler;

        public SuitabilityTestRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }

        public DataTable SuitabilityTestGetQuestionsByForm(int formId)
        {
            try
            {
                SqlParameter paramFormId = new SqlParameter("@Form_ID", formId);
                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_GetQuestionsByForm", paramFormId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        public DataTable SuitabilityTestGetUserAnswers(int formId, int questionnaireRepUserId)
        {
            try
            {
                SqlParameter paramFormId = new SqlParameter("@Form_ID", formId);
                SqlParameter paramUserId = new SqlParameter("@Questionnaire_Rep_UserID", questionnaireRepUserId);

                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_Questionnaire_Report_GetUserAnswers", paramFormId, paramUserId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        public DataTable SuitabilityTestGetAnswers(int questionId)
        {
            try
            {
                SqlParameter paramQuestionId = new SqlParameter("@Qestion_ID", questionId);
                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_GetAnswers", paramQuestionId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        public DataTable SuitabilityTestGetCurrencyCheckQuestion(int controlId, string countryCode)
        {
            try
            {
                SqlParameter paramControlId = new SqlParameter("@Control_ID", controlId);
                SqlParameter paramCountryCode = new SqlParameter("@Country_Code", countryCode);
                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_Get_Currency_Check_Question", paramControlId, paramCountryCode);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        public int SuitabilityTestGetCountQuestionsByForm(int formId)
        {
            try
            {
                SqlParameter paramFormId = new SqlParameter("@Form_ID", formId);
                return _sqlHelper.ExecuteScalar(_connectionString, "Country_Based_Control_GetCountQuestionsByForm", paramFormId);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        public void SuitabilityTestReportDeleteUser(int repUserId)
        {
            try
            {
                SqlParameter paramRepUserId = new SqlParameter("@Questionnaire_Rep_UserID", repUserId);
                _sqlHelper.ExecuteReader(_connectionString, "Country_Based_Control_Questionnaire_Report_Delete_User", paramRepUserId);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }

        }

        public DataTable SuitabilityTestGetQuestion(int questionId)
        {
            try
            {
                SqlParameter paramQuestionId = new SqlParameter("@Qestion_ID", questionId);
                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_GetQuestion", paramQuestionId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        public void SuitabilityTestQuestionsAddAnswersTest(int repUserId, int repQuestionId, int repAnswerId, bool repStatue, int groupId, int repLanguage)
        {
            try
            {
                SqlParameter paramRepUserId = new SqlParameter("@Questionnaire_Rep_UserID", repUserId);
                SqlParameter paramRepQuestionId = new SqlParameter("@Questionnaire_Rep_QuestionID", repQuestionId);
                SqlParameter paramRepAnswerId = new SqlParameter("@Questionnaire_Rep_AnswerID", repAnswerId);
                SqlParameter paramRepStatus = new SqlParameter("@Questionnaire_Rep_Statue", repStatue);
                SqlParameter paramGroupId = new SqlParameter("@Group_ID", groupId);
                SqlParameter paramLangId = new SqlParameter("@Questionnaire_Rep_Language", repLanguage);
                _sqlHelper.ExecuteReader(_connectionString, "Country_Based_Control_Questions_AddAnswers_Test", paramRepUserId, paramRepQuestionId, paramRepAnswerId, paramRepStatus, paramGroupId, paramLangId);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }

        }

        public bool SuitabilityTestQuestionsCheckForStatue(int questionId, int answerRight)
        {
            try
            {
                SqlParameter paramQuestionId = new SqlParameter("@QuestionID", questionId);
                SqlParameter paramAnswerRightId = new SqlParameter("@Answer_Right", answerRight);
                DataTable dt = _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_Questions_checkForStatue", paramQuestionId, paramAnswerRightId);
                return dt.Rows.Count > 0;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

    }
}
