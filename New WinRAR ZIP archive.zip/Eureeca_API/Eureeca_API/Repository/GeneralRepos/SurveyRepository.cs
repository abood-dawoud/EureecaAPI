﻿using Eureeca_API.General;
using Eureeca_API.Interface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.GeneralRepos
{
    public class SurveyRepository : ISurvey
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;

        public SurveyRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }

        /// <summary>
        /// This method is used to check for new survey on user login
        /// </summary>
        /// <param name="userId"></param>
        /// <returns>Data table of information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable SurveyCheckSurveysOnLogin(int userId)
        {
            try
            {
                SqlParameter param_User_ID = new SqlParameter("@User_ID", userId);
                return _sqlHelper.GetDataTable(_connectionString, "Survey_CheckSurveysOnLogin", param_User_ID);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }


    }
}
