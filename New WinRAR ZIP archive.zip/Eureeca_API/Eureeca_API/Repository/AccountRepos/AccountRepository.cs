﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface.AccountInterface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.AccountRepos
{
    public class AccountRepository : IAccount
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;


        public AccountRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();

        }
        /// <summary>
        /// This method will create a user account
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="firstName"></param>
        /// <param name="lastName"></param>
        /// <param name="userId"></param>
        public void AccountCreateUserAccount(string userName, string firstName, string lastName, int userId)
        {
            try
            {
                AccountingChartOfAccountsAddEdit(null, ((int)AccountType.User).ToString(), "U_" + userId.ToString(), firstName + " " + lastName + " (" + userName + ")", null, userId.ToString());
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to Add/Edit Chart Of Accounts 
        /// </summary>
        /// <param name="accountId"></param>
        /// <param name="accountType"></param>
        /// <param name="accountNumber"></param>
        /// <param name="accountName"></param>
        /// <param name="accountNotes"></param>
        /// <param name="accountEurrecaId"></param>
        /// <returns>The account id</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public int AccountingChartOfAccountsAddEdit(string accountId, string accountType, string accountNumber, string accountName, string accountNotes, string accountEurrecaId)
        {
            try
            {
                SqlParameter paramAccountId = new SqlParameter("@Account_ID", null);
                if (!string.IsNullOrWhiteSpace(accountId))
                    paramAccountId.Value = Tools.FilterHTML(accountId);

                SqlParameter paramAccountNumber = new SqlParameter("@Account_Number", null);
                if (!string.IsNullOrWhiteSpace(accountNumber))
                    paramAccountNumber.Value = Tools.FilterHTML(accountNumber);

                SqlParameter paramAccountType = new SqlParameter("@Account_Type", Tools.FilterHTML(accountType));
                SqlParameter paramAccountName = new SqlParameter("@Account_Name", Tools.FilterHTML(accountName));

                SqlParameter paramAccountNotes = new SqlParameter("@Account_Notes", null);
                if (!string.IsNullOrWhiteSpace(accountNotes))
                    paramAccountNotes.Value = Tools.FilterHTML(accountNotes);

                SqlParameter paramAccountEurrecaId = new SqlParameter("@Account_Eurreca_ID", Tools.FilterHTML(accountEurrecaId));

                return _sqlHelper.ExecuteScalar(_connectionString, "Accounting_Chart_Of_Accounts_Add_Edit", paramAccountId, paramAccountType, paramAccountNumber, paramAccountName, paramAccountNotes, paramAccountEurrecaId);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        public void AccountAddInvestment(DataTable dtUserDetails, int transactionCurrencyId, string pitchRate, int proposalId, string IAADAfterExchange, string profilePitchTitle)
        {
            try
            {
                //DataTable dtUserDetails = _user.UserSelectById(int.Parse(Investor_ID));

                int JournalID = AccountingJournalEntryAdd_Edit(null, DateTime.Now.ToString(), transactionCurrencyId.ToString(), pitchRate, "Investment / Username: " + dtUserDetails.Rows[0]["User_Username"] + " / Proposal: " + profilePitchTitle, null, null, ((int)JournalEntryType.Investment).ToString());
                if (JournalID > 0)
                {
                    AccountingJournalEntryDetailsAdd(JournalID.ToString(), null, GetSubAccountID(AccountingGetEntityAccountID(Convert.ToInt32(dtUserDetails.Rows[0]["User_ID"]), (int)AccountType.User), transactionCurrencyId), 0, Convert.ToDecimal(IAADAfterExchange));
                    AccountingJournalEntryDetailsAdd(JournalID.ToString(), null, GetSubAccountID(AccountingGetEntityAccountID(proposalId, (int)AccountType.Proposal), transactionCurrencyId), Convert.ToDecimal(IAADAfterExchange), 0);
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public int AccountingJournalEntryAdd_Edit(string journalId, string journalDate, string journalCurrencyId, string journalExchangeRate, string journalStatement, string journalDocumentReference, string journalDocumentReferenceDate, string journalTypeId)
        {
            try
            {
                SqlParameter paramJournalId = new SqlParameter("@Journal_ID", null);
                if (!string.IsNullOrWhiteSpace(journalId))
                    paramJournalId.Value = Tools.FilterHTML(journalId);

                SqlParameter paramJournalDate = new SqlParameter("@Journal_Date", null);
                if (!string.IsNullOrWhiteSpace(journalDate))
                    paramJournalDate.Value = Convert.ToDateTime(Tools.FilterHTML(journalDate));

                SqlParameter paramJournalCurrencyId = new SqlParameter("@Journal_Currency_ID", Tools.FilterHTML(journalCurrencyId));
                SqlParameter paramJournalExchangeRate = new SqlParameter("@Journal_Exchange_Rate", Tools.FilterHTML(journalExchangeRate));

                SqlParameter paramJournalStatement = new SqlParameter("@Journal_Statement", null);
                if (!string.IsNullOrWhiteSpace(journalStatement))
                    paramJournalStatement.Value = Tools.FilterHTML(journalStatement);

                SqlParameter paramJournalDocumentReference = new SqlParameter("@Journal_Document_Reference", null);
                if (!string.IsNullOrWhiteSpace(journalDocumentReference))
                    paramJournalDocumentReference.Value = Tools.FilterHTML(journalDocumentReference);

                SqlParameter paramJournalDocumentReferenceDate = new SqlParameter("@Journal_Document_Reference_Date", null);
                if (!string.IsNullOrWhiteSpace(journalDocumentReferenceDate))
                    paramJournalDocumentReferenceDate.Value = Convert.ToDateTime(Tools.FilterHTML(journalDocumentReferenceDate));

                SqlParameter paramJournalTypeId = new SqlParameter("@Journal_Type_ID", Tools.FilterHTML(journalTypeId));

                return _sqlHelper.ExecuteScalar(_connectionString, "Accounting_Journal_Entry_Add_Edit", paramJournalId, paramJournalDate, paramJournalCurrencyId, paramJournalExchangeRate, paramJournalStatement, paramJournalDocumentReference, paramJournalDocumentReferenceDate, paramJournalTypeId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public int AccountingJournalEntryDetailsAdd(string journalId, string journalDetailStatement, int journalDetailSubAccountId, decimal journalDetailAmountCredit, decimal journalDetailAmountDebit)
        {
            try
            {
                SqlParameter paramJournalId = new SqlParameter("@Journal_ID", Tools.FilterHTML(journalId));
                SqlParameter paramJournalDetailStatement = new SqlParameter("@Journal_Detail_Statement", null);
                if (!string.IsNullOrWhiteSpace(Tools.FilterHTML(journalDetailStatement)))
                    paramJournalDetailStatement.Value = Tools.FilterHTML(journalDetailStatement);

                SqlParameter paramJournalDetailSubAccountId = new SqlParameter("@Journal_Detail_SubAccount_ID", journalDetailSubAccountId);
                SqlParameter paramJournalDetailAmountCredit = new SqlParameter("@Journal_Detail_Amount_Credit", journalDetailAmountCredit);
                SqlParameter paramJournalDetailAmountDebit = new SqlParameter("@Journal_Detail_Amount_Debit", journalDetailAmountDebit);

                return _sqlHelper.ExecuteScalar(_connectionString, "Accounting_Journal_Entry_Details_Add", paramJournalId, paramJournalDetailStatement, paramJournalDetailSubAccountId, paramJournalDetailAmountCredit, paramJournalDetailAmountDebit);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public int GetSubAccountID(int journalDetailSubAccountAccountId, int journalCurrencyId)
        {
            try
            {
                SqlParameter param_Journal_Detail_SubAccount_Account_ID = new SqlParameter("@Journal_Detail_SubAccount_Account_ID", journalDetailSubAccountAccountId);
                SqlParameter param_Journal_Currency_ID = new SqlParameter("@Journal_Currency_ID", journalCurrencyId);

                DataTable dt = _sqlHelper.GetDataTable(_connectionString, "Accounting_GetSubAccountID", param_Journal_Detail_SubAccount_Account_ID, param_Journal_Currency_ID);
                if (dt.Rows.Count > 0)
                {
                    return Convert.ToInt32(dt.Rows[0]["SubAccount_ID"]);
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public int AccountingGetEntityAccountID(int Account_Eurreca_ID, int Account_Type)
        {
            try
            {
                SqlParameter param_Account_Eurreca_ID = new SqlParameter("@Account_Eurreca_ID", Account_Eurreca_ID);
                SqlParameter param_Account_Type = new SqlParameter("@Account_Type", Account_Type);

                DataTable dt = _sqlHelper.GetDataTable(_connectionString, "Accounting_Get_Entity_AccountID", param_Account_Eurreca_ID, param_Account_Type);
                if (dt.Rows.Count > 0)
                {
                    return Convert.ToInt32(dt.Rows[0]["Account_ID"]);
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        public void AccountEditUserAccount(string userName, string firstName, string lastName, int userId)
        {
            try
            {
                AccountingChartOfAccountsAddEdit(AccountingGetEntityAccountID(userId, (int)AccountType.User).ToString(), ((int)AccountType.User).ToString(), "U_" + userId.ToString(), firstName + " " + lastName + " (" + userName + ")", null, userId.ToString());
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }
        }


    }
}
