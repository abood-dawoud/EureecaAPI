﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface.CountryBasedInterface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.CountryBasedRepos
{
    public class CountryBasedControlRepository : ICountryBasedControl
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;
        public CountryBasedControlRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }

        public int CountryBasedCheckCountryRestrictedForControl(CountryBasedControls controlId, int countryId)
        {
            try
            {
                SqlParameter paramControlId = new SqlParameter("@Control_ID", (int)controlId);
                SqlParameter paramCountryId = new SqlParameter("@Country_ID", countryId);
                return _sqlHelper.ExecuteReader(_connectionString, "Country_Based_Control_CheckCountryRestrictedForControl", paramControlId, paramCountryId);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        public int CountryBasedCheckCountryRestrictedForControl(CountryBasedControls controlId, int userCountryId, int proposalCountryId)
        {
            try
            {
                SqlParameter paramControlId = new SqlParameter("@Control_ID", (int)controlId);
                SqlParameter paramUserCountryId = new SqlParameter("@UserCountry_ID", userCountryId);
                SqlParameter paramProposalCountryId = new SqlParameter("@ProposalCountry_ID", proposalCountryId);
                
                return _sqlHelper.ExecuteReader(_connectionString, "Country_Based_Control_CheckCountryRestrictedForPreventionControl", paramControlId, paramUserCountryId, paramProposalCountryId);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        public int CountryBasedCheckCountryRestrictedForControlbyPage(CountryBasedControls controlId, int pitchId, int proposalCountryId)
        {
            try
            {
                SqlParameter paramPitchId = new SqlParameter("@Pitch_ID", pitchId);
                SqlParameter paramProposalCountryId = new SqlParameter("@ProposalCountry_ID", proposalCountryId);
                SqlParameter paramControlId = new SqlParameter("@Control_ID", controlId);
                
                return _sqlHelper.ExecuteReader(_connectionString, "Country_Based_Control_CheckCountryRestrictedForPreventionControlByPage", paramPitchId, paramProposalCountryId, paramControlId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        public DataTable CountryBasedGetGroupDataProfile(int groupId, int languageId)
        {
            try
            {
                SqlParameter paramGroupId = new SqlParameter("@Group_ID", groupId);
                SqlParameter paramLangId = new SqlParameter("@Language_ID", languageId);
                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_GetGroupData_Profile", paramGroupId, paramLangId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }

        public DataTable CountryBasedGetGroupData(int groupId)
        {
            try
            {
                SqlParameter paramGroupId = new SqlParameter("@Group_ID", groupId);
                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_GetGroupData", paramGroupId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        public int CountryBasedGetCountryDetailsByID(string countryId)
        {
            try
            {
                SqlParameter paramCountryId = new SqlParameter("@Country_ID", countryId);
                return _sqlHelper.ExecuteScalar(_connectionString, "GetCountryDetailsByID", paramCountryId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        public DataTable CountryBasedGetQuestionnaireCategoryGroupDetails(int groupId)
        {
            try
            {
                SqlParameter paramGroupId = new SqlParameter("@Group_ID", groupId);
                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_GetQuestionnaireCategoryGroupDetails", paramGroupId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        public DataTable CountryBasedGetCurrencyCheckQuestion(int controlId, string countryCode)
        {
            try
            {
                SqlParameter paramControlId = new SqlParameter("@Control_ID", controlId);
                SqlParameter paramCountryCode = new SqlParameter("@Country_Code", countryCode);

                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_Get_Currency_Check_Question", paramControlId, paramCountryCode);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        /// <summary>
        /// This method is used to get country details
        /// </summary>
        /// <param name="countryId"></param>
        /// <param name="langId"></param>
        /// <returns>Datatable of information</returns>
        /// <exception cref="Exception">Will write the exception in the error log file.</exception>
        public DataTable CountryBasedGetCountryDetails(int countryId, int langId)
        {
            try
            {
                SqlParameter paramCountryId = new SqlParameter("@Country_ID", countryId);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", langId);
                return _sqlHelper.GetDataTable(_connectionString, "GetCountryDetails", paramCountryId, paramLangId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n Country_ID: " + countryId + "\n Profile_LanguageID: " + langId + "\n sql_helper is NULL: " + (_sqlHelper == null));
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        /// <summary>
        /// This method is used to get the group data
        /// </summary>
        /// <param name="groupId"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable CountryBasedGetGroupDataMinimumAgeAllowed(int groupId)
        {
            try
            {
                SqlParameter paramGroupId = new SqlParameter("@Group_ID", groupId);
                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_GetGroupDataMinimumAgeAllowed", paramGroupId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

    }
}
