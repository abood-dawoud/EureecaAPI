﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface.CountryBasedInterface;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Localization;
using System.Data;

namespace Eureeca_API.Repository.CountryBasedRepos
{
    public class AgreementRepository : IAgreement
    {
        private readonly string _connectionString;
        private readonly ICountryBasedControl _countryBasedControlRepository;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;
        private readonly IStringLocalizer<Resources.AgreementRepository> _stringLocalizer;


        public AgreementRepository(IConfiguration config, ICountryBasedControl countryBasedControl, IStringLocalizer<Resources.AgreementRepository> stringLocalizer)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _countryBasedControlRepository = countryBasedControl;
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
            _stringLocalizer = stringLocalizer;
        }
        public Agreement AgreementGetRiskAgreement(int countryId, int langId)
        {
            try
            {
                Agreement agreement = new Agreement();
                int groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Footer_Risk, countryId);
                if (groupId > 0)
                {
                    DataTable dtGroupData = _countryBasedControlRepository.CountryBasedGetGroupData(groupId);
                    if (dtGroupData.Rows.Count > 0)
                    {
                        DataTable dTDetailsCmsPage = CMSGetPageByLang(int.Parse(dtGroupData.Rows[0]["CMS_PageID"].ToString()), langId);
                        if (dTDetailsCmsPage.Rows.Count > 0)
                        {
                            if (!string.IsNullOrEmpty(dTDetailsCmsPage.Rows[0]["Profile_Name"].ToString()))
                                agreement.Title = dTDetailsCmsPage.Rows[0]["Profile_Name"].ToString();
                            if (!string.IsNullOrEmpty(dTDetailsCmsPage.Rows[0]["Profile_Details"].ToString()))
                                agreement.Details = dTDetailsCmsPage.Rows[0]["Profile_Details"].ToString();

                            agreement.HasIcon = false;
                            agreement.CanClose = true;
                            agreement.MessageType = (int)MessageType.Agreement;
                            agreement.MessageTypeLbl = "Agreement";

                        }

                    }
                }
                return agreement;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        public Agreement AgreementGetEureecaPrivacyPolicy(int countryId, int langId)
        {
            try
            {
                Agreement agreement = new Agreement();
                int groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.PrivacyPolicy, countryId);
                if (groupId > 0)
                {
                    DataTable dtGroupData = _countryBasedControlRepository.CountryBasedGetGroupData(groupId);
                    if (dtGroupData.Rows.Count > 0)
                    {
                        DataTable dTDetailsCmsPage = CMSGetPageByLang(int.Parse(dtGroupData.Rows[0]["CMS_PageID"].ToString()), langId);
                        if (dTDetailsCmsPage.Rows.Count > 0)
                        {
                            if (!string.IsNullOrEmpty(dTDetailsCmsPage.Rows[0]["Profile_Name"].ToString()))
                                agreement.Title = dTDetailsCmsPage.Rows[0]["Profile_Name"].ToString();
                            if (!string.IsNullOrEmpty(dTDetailsCmsPage.Rows[0]["Profile_Details"].ToString()))
                                agreement.Details = dTDetailsCmsPage.Rows[0]["Profile_Details"].ToString();
                            agreement.HasIcon = false;
                            agreement.CanClose = true;
                            agreement.MessageType = (int)MessageType.Agreement;
                            agreement.MessageTypeLbl = "Agreement";

                        }

                    }
                }
                return agreement;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        public Agreement AgreementGetEureecaTermsOfUse(int countryId, int langId)
        {
            try
            {
                Agreement agreement = new Agreement();
                int groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.TermsOfUse, countryId);
                if (groupId > 0)
                {
                    DataTable dtGroupData = _countryBasedControlRepository.CountryBasedGetGroupData(groupId);
                    if (dtGroupData.Rows.Count > 0)
                    {
                        DataTable dTDetailsCmsPage = CMSGetPageByLang(int.Parse(dtGroupData.Rows[0]["CMS_PageID"].ToString()), langId);
                        if (dTDetailsCmsPage.Rows.Count > 0)
                        {
                            if (!string.IsNullOrEmpty(dTDetailsCmsPage.Rows[0]["Profile_Name"].ToString()))
                                agreement.Title = dTDetailsCmsPage.Rows[0]["Profile_Name"].ToString();
                            if (!string.IsNullOrEmpty(dTDetailsCmsPage.Rows[0]["Profile_Details"].ToString()))
                                agreement.Details = dTDetailsCmsPage.Rows[0]["Profile_Details"].ToString();
                            agreement.HasIcon = false;
                            agreement.CanClose = true;
                            agreement.MessageType = (int)MessageType.Agreement;
                            agreement.MessageTypeLbl = "Agreement";
                        }
                    }
                }
                return agreement;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        public Agreement AgreementGetEureecaTermsOfBusiness(int countryId, int langId)
        {
            try
            {
                Agreement agreement = new Agreement();
                int groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.TermsOfBusiness, countryId);
                if (groupId > 0)
                {
                    DataTable dtGroupData = _countryBasedControlRepository.CountryBasedGetGroupData(groupId);
                    if (dtGroupData.Rows.Count > 0)
                    {
                        DataTable dTDetailsCmsPage = CMSGetPageByLang(int.Parse(dtGroupData.Rows[0]["CMS_PageID"].ToString()), langId);
                        if (dTDetailsCmsPage.Rows.Count > 0)
                        {
                            if (!string.IsNullOrEmpty(dTDetailsCmsPage.Rows[0]["Profile_Name"].ToString()))
                                agreement.Title = dTDetailsCmsPage.Rows[0]["Profile_Name"].ToString();
                            if (!string.IsNullOrEmpty(dTDetailsCmsPage.Rows[0]["Profile_Details"].ToString()))
                                agreement.Details = dTDetailsCmsPage.Rows[0]["Profile_Details"].ToString();
                            agreement.HasIcon = false;
                            agreement.CanClose = true;
                            agreement.MessageType = (int)MessageType.Agreement;
                            agreement.MessageTypeLbl = "Agreement";
                        }
                    }
                }
                return agreement;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        public Agreement AgreementGetEureecaUSTerms(int langId)
        {
            try
            {
                Agreement agreement = new Agreement();
                DataTable dTDetailsCmsPage = CMSGetPageByLang(13, langId);
                if (dTDetailsCmsPage.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dTDetailsCmsPage.Rows[0]["Profile_Name"].ToString()))
                        agreement.Title = dTDetailsCmsPage.Rows[0]["Profile_Name"].ToString();
                    if (!string.IsNullOrEmpty(dTDetailsCmsPage.Rows[0]["Profile_Details"].ToString()))
                        agreement.Details = dTDetailsCmsPage.Rows[0]["Profile_Details"].ToString();
                    agreement.HasIcon = false;
                    agreement.CanClose = true;
                    agreement.MessageType = (int)MessageType.Agreement;
                    agreement.MessageTypeLbl = "Agreement";
                }
                return agreement;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }
        public Agreement AgreementGetExposedPerson(int langId)
        {
            try
            {
                Agreement agreement = new Agreement();
                DataTable dTDetailsCmsPage = CMSGetPageByLang(159, langId);
                if (dTDetailsCmsPage.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dTDetailsCmsPage.Rows[0]["Profile_Name"].ToString()))
                        agreement.Title = dTDetailsCmsPage.Rows[0]["Profile_Name"].ToString();
                    if (!string.IsNullOrEmpty(dTDetailsCmsPage.Rows[0]["Profile_Details"].ToString()))
                        agreement.Details = dTDetailsCmsPage.Rows[0]["Profile_Details"].ToString();
                    agreement.HasIcon = false;
                    agreement.CanClose = true;
                    agreement.MessageType = (int)MessageType.Agreement;
                    agreement.MessageTypeLbl = "Agreement";
                }
                return agreement;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        /// <summary>
        /// This method is used to get CMS page by labg id
        /// </summary>
        /// <param name="menuId"></param>
        /// <param name="lang"></param>
        /// <returns></returns>
        /// <exception cref="Exception"></exception>
        public DataTable CMSGetPageByLang(int menuId, int lang)
        {
            try
            {
                SqlParameter paramMenuId = new SqlParameter("@menu_id", menuId);
                SqlParameter paramLangId = new SqlParameter("@Profile_LanguageID", lang);
                return _sqlHelper.GetDataTable(_connectionString, "GetPage", paramMenuId, paramLangId);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        public Agreement AgreementGetRegistrationPrevention(int countryId, int langId)
        {
            try
            {
                Agreement registrationPrevent = new Agreement();
                int groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Regist_Prevent, countryId);
                if (groupId > 0)
                {
                    DataTable dtGroupData = _countryBasedControlRepository.CountryBasedGetGroupData(groupId);
                    if (dtGroupData.Rows.Count > 0)
                    {
                        DataTable dtPage = CMSGetPageByLang(int.Parse(dtGroupData.Rows[0]["CMS_PageID"].ToString()), langId);

                        if (dtPage.Rows.Count > 0)
                        {
                            if (!string.IsNullOrEmpty(dtPage.Rows[0]["Profile_Name"].ToString()))
                                registrationPrevent.Title = dtPage.Rows[0]["Profile_Name"].ToString();
                            if (!string.IsNullOrEmpty(dtPage.Rows[0]["Profile_Details"].ToString()))
                                registrationPrevent.Details = dtPage.Rows[0]["Profile_Details"].ToString();
                            registrationPrevent.HasIcon = false;
                            registrationPrevent.CanClose = true;
                            registrationPrevent.MessageType = (int)MessageType.info;
                            registrationPrevent.MessageTypeLbl = "info";
                            return registrationPrevent;
                        }
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }

        }
        public Agreement AgreementGetRegistrationWarning(int countryId, int langId)
        {
            try
            {
                Agreement registrationWarning = new Agreement();
                int groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Regist_Warn, countryId);
                if (groupId > 0)
                {
                    DataTable dtGroupData = _countryBasedControlRepository.CountryBasedGetGroupData(groupId);
                    if (dtGroupData.Rows.Count > 0)
                    {
                        DataTable dtPage = CMSGetPageByLang(int.Parse(dtGroupData.Rows[0]["CMS_PageID"].ToString()), langId);

                        if (dtPage.Rows.Count > 0)
                        {
                            if (!string.IsNullOrEmpty(dtPage.Rows[0]["Profile_Name"].ToString()))
                                registrationWarning.Title = dtPage.Rows[0]["Profile_Name"].ToString();
                            if (!string.IsNullOrEmpty(dtPage.Rows[0]["Profile_Details"].ToString()))
                                registrationWarning.Details = dtPage.Rows[0]["Profile_Details"].ToString();

                            registrationWarning.HasIcon = true;
                            registrationWarning.CanClose = true;
                            registrationWarning.MessageType = (int)MessageType.warning;
                            registrationWarning.MessageTypeLbl = "warning";
                            return registrationWarning;


                        }
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }


        }
        public Agreement AgreementGetRegistrationRegulatorsAgreement(int countryId, int langId)
        {
            try
            {
                Agreement regulatorsAgreement = new Agreement();
                int groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Regulators_Agreements, countryId);
                if (groupId > 0)
                {
                    DataTable dtGroupData = _countryBasedControlRepository.CountryBasedGetGroupData(groupId);
                    if (dtGroupData.Rows.Count > 0)
                    {
                        DataTable dtPage = CMSGetPageByLang(int.Parse(dtGroupData.Rows[0]["CMS_PageID"].ToString()), langId);

                        if (dtPage.Rows.Count > 0)
                        {
                            if (!string.IsNullOrEmpty(dtPage.Rows[0]["Profile_Name"].ToString()))
                                regulatorsAgreement.Title = dtPage.Rows[0]["Profile_Name"].ToString();
                            if (!string.IsNullOrEmpty(dtPage.Rows[0]["Profile_Details"].ToString()))
                                regulatorsAgreement.Details = dtPage.Rows[0]["Profile_Details"].ToString();
                            regulatorsAgreement.HasIcon = false;
                            regulatorsAgreement.CanClose = false;
                            regulatorsAgreement.MessageType = (int)MessageType.info;
                            regulatorsAgreement.MessageTypeLbl = "info";
                            return regulatorsAgreement;

                        }
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }


        }
        public int GetMinimunAge(int countryId)
        {
            int minimumAge = 18; //the default value minimumAge
            try
            {
                int groupId = _countryBasedControlRepository.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.RegistrationMinAge, countryId);
                DataTable dtMinimumAge = _countryBasedControlRepository.CountryBasedGetGroupDataMinimumAgeAllowed(groupId);
                if (dtMinimumAge.Rows.Count > 0)
                {
                    minimumAge = int.Parse(dtMinimumAge.Rows[0]["MinimumAgeAllowed"].ToString());
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }

            return minimumAge;
        }
    }
}
