﻿using Eureeca_API.General;
using Eureeca_API.Interface.CountryBasedInterface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.CountryBasedRepos
{
    public class CountryBasedBankDetailsRepository : ICountryBasedBankDetails
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;
        public CountryBasedBankDetailsRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();
        }

        public DataTable CountryBasedControlGetGroupDataBankDetailst(int groupId, int currencyLangId)
        {
            try
            {
                SqlParameter paramGroupId = new SqlParameter("@Group_ID", groupId);
                SqlParameter paramLangId = new SqlParameter("@Currency_LangID", currencyLangId);
                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_GetGroupDataBankDetailst", paramGroupId, paramLangId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }
        /// <summary>
        /// This method is used to get the bank countries.
        /// </summary>
        /// <param name="currencyId"></param>
        /// <param name="langId"></param>
        /// <param name="groupId"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception">Will write the error in the error log file.</exception>
        public DataTable CountryBasedControlGetAllBankInfoByCurrencyLang(int currencyId, int langId, int groupId)
        {
            try
            {
                SqlParameter paramCurrencyId = new SqlParameter("@Currency_ID", currencyId);
                SqlParameter paramLangId = new SqlParameter("@Language_ID", langId);
                SqlParameter paramGroupId = new SqlParameter("@Group_ID", groupId);
                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_GetAllBankInfoByCurrencyLang", paramCurrencyId, paramLangId, paramGroupId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }



    }
}
