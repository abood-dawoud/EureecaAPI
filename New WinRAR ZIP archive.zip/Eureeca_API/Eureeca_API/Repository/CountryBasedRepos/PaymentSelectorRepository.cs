﻿using Eureeca_API.General;
using Eureeca_API.Interface.CountryBasedInterface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.CountryBasedRepos
{
    public class PaymentSelectorRepository : IPaymentSelector
    {
        private readonly string _connectionString;
        private readonly SqlHelper _sqlHelper;
        private readonly ErrHandler _errHandler;


        public PaymentSelectorRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _sqlHelper = new SqlHelper();
            _errHandler = new ErrHandler();

        }


        /// <summary>
        /// This method is used to get the payment note and the if is the country rejected or not
        /// </summary>
        /// <param name="controlId"></param>
        /// <param name="countryCode"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public DataTable PaymentSelectorGetTextDetailsDataPayment(int controlId, string countryCode)
        {
            try
            {
                SqlParameter paramControlId = new SqlParameter("@Control_ID", controlId);
                SqlParameter paramCountryCode = new SqlParameter("@Country_Code", countryCode);
                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_GetTextPayment", paramControlId, paramCountryCode);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// This method is used to Check Country Payment
        /// </summary>
        /// <param name="controlId"></param>
        /// <param name="countryCode"></param>
        /// <returns>Status of the country if is rejected or not</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public int PaymentSelectorCheckCountryPayment(int controlId, string countryCode)
        {
            try
            {
                SqlParameter paramControlId = new SqlParameter("@Control_ID", controlId);
                SqlParameter paramCountryCode = new SqlParameter("@Country_Code", countryCode);

                return Convert.ToInt32(_sqlHelper.ExecuteScalar(_connectionString, "Country_Based_Control_CheckCountryPayment", paramControlId, paramCountryCode));

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }

        }
        /// <summary>
        /// This method is used to get the payment methods allowed to the country
        /// </summary>
        /// <param name="controlId"></param>
        /// <param name="countryCode"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception"></exception>
        public DataTable PaymentSelectorGetCridetTransfae(int controlId, string countryCode)
        {
            try
            {
                SqlParameter paramControlId = new SqlParameter("@Control_ID", controlId);
                SqlParameter paramCountryCode = new SqlParameter("@Country_Code", countryCode);
                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_Get_Cridet_Transfae", paramControlId, paramCountryCode);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }




    }
}
