﻿using Eureeca_API.General;
using Eureeca_API.Interface.CountryBasedInterface;
using Microsoft.Data.SqlClient;
using System.Data;

namespace Eureeca_API.Repository.CountryBasedRepos
{
    public class PaymentUserProposalRelationRepository : IPaymentUserProposalRelation
    {
        private readonly string _connectionString;
        private readonly ErrHandler _errHandler;
        private readonly SqlHelper _sqlHelper;

        public PaymentUserProposalRelationRepository(IConfiguration config)
        {
            _connectionString = config.GetConnectionString("dbConnection");
            _errHandler = new ErrHandler();
            _sqlHelper = new SqlHelper();

        }

        /// <summary>
        /// This method is used to get the group users and proposals countries
        /// </summary>
        /// <param name="groupId"></param>
        /// <returns>Datatable of all information</returns>
        /// <exception cref="Exception">Will write the error in the error log file</exception>
        public DataTable PaymentUserProposalRelationGetGroupData(int groupId)
        {
            try
            {
                SqlParameter paramGroupId = new SqlParameter("@Group_ID", groupId);
                return _sqlHelper.GetDataTable(_connectionString, "Country_Based_Control_GetGroupData_User_Proposal_Payment_Relation", paramGroupId);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }


    }
}
