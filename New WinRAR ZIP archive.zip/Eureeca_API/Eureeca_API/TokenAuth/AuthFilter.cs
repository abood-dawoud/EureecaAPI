﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Text;

namespace Eureeca_API.TokenAuth
{
    [AttributeUsage(AttributeTargets.Class)]
    public class AuthFilter : Attribute, IAuthorizationFilter
    {
        public static string UserId = string.Empty;
        /// <summary>  
        /// This will Authorize User  
        /// </summary>  
        /// <returns></returns>  
        public void OnAuthorization(AuthorizationFilterContext filterContext)
        {

            if (filterContext != null)
            {
                if (filterContext.ActionDescriptor.EndpointMetadata.Any(x => x.GetType() == typeof(AllowAnonymousAttribute)))
                {
                    return;
                }
                Microsoft.Extensions.Primitives.StringValues authTokens;
                filterContext.HttpContext.Request.Headers.TryGetValue("Authorization", out authTokens);

                var _token = authTokens.FirstOrDefault();

                if (_token != null)
                {
                    string authToken = _token;
                    if (authToken != null)
                    {
                        if (IsValidToken(GetJwtToken(authToken)))
                        {
                            filterContext.HttpContext.Response.Headers.Add("Authorization", authToken);
                            filterContext.HttpContext.Response.Headers.Add("AuthStatus", "Authorized");
                            return;
                        }
                        else
                        {
                            filterContext.HttpContext.Response.Headers.Add("Authorization", authToken);
                            filterContext.HttpContext.Response.Headers.Add("AuthStatus", "NotAuthorized");
                            filterContext.HttpContext.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                            filterContext.Result = new JsonResult("NotAuthorized")
                            {
                                Value = new
                                {
                                    Status = "Error",
                                    Message = "Not Authorized"
                                },
                            };
                        }

                    }

                }
                else
                {
                    filterContext.HttpContext.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                    filterContext.Result = new JsonResult("Please Provide authToken")
                    {
                        Value = new
                        {
                            Status = "Error",
                            Message = "Not Authorized"
                        },
                    };
                }
            }
        }

        public bool IsValidToken(string authToken)
        {
            try
            {
                var validationParameters = new TokenValidationParameters()
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidAudience = "JWTServicePostmanClient",// get data from app settings
                    ValidIssuer = "JWTAuthenticationServer",// get data from app settings
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("Yh2k7QSu4l8CZg5p6X3Pna9L0Miy4D3Bvt0JVr87UcOj69Kqw5R2Nmf4FWs03Hdx")) // get key from app settings
                };
                var principal = new JwtSecurityTokenHandler().ValidateToken(authToken, validationParameters, out var validatedToken);
                 UserId = principal?.FindFirstValue("User_ID");
                if (string.IsNullOrEmpty(UserId))
                    return false;
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public string GetJwtToken(string token)
        {
            if (!string.IsNullOrEmpty(token))
            {
                if (token.StartsWith("Bearer "))
                    return token.Substring(7).Trim();
                else
                    return token;
            }
            return string.Empty;
        }


    }
}
