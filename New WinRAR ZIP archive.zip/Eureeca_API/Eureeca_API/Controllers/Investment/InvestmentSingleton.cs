﻿using Microsoft.Extensions.Caching.Memory;

namespace Eureeca_API.Controllers.Investment
{
    public sealed class InvestmentSingleton
    {
        private static InvestmentSingleton instance;
        private static object lockObj = new Object();
        private InvestmentSingleton() {}
        public static InvestmentSingleton Instance
        {
            get
            {
                lock (lockObj)
                {
                    if (instance == null)
                        instance = new InvestmentSingleton();
                }
                return instance;
            }
        }

        
        public bool AddProposalToMemory(int pid, IMemoryCache memoryCache)
        {
            lock (lockObj)
            {
                if (!memoryCache.TryGetValue(pid, out int value))
                {
                    memoryCache.Set(pid, DateTime.Now);
                    return true;
                }
                    return false;
            }
        }

        public void RemoveProposalFromMemory(int pid, IMemoryCache memoryCache)
        {
            lock (lockObj)
            {
                if (!memoryCache.TryGetValue(pid, out int value))
                    memoryCache.Remove(pid);

            }
        }

    }
}
