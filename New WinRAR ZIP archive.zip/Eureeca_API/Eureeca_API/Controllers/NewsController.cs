﻿using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Models.GeneralModels.Dto;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace Eureeca_API.Controllers
{

    [Route("api/news/[action]")]
    [ApiController]

    public class NewsController : ControllerBase
    {
        private readonly INews _news;
        private readonly ErrHandler _errHandler;

        public NewsController(INews news)
        {
            _news = news;
            _errHandler = new ErrHandler();

        }

        [HttpGet]
        public async Task<ActionResult<List<News>>> NewsGetNews([FromQuery]GetNews getNews)
        {
            try
            {
                var response = await Task.FromResult(_news.NewsGetNews((int)getNews.LangId, getNews.NewsID));
                return Ok(new { code = 200, success = true, News = response });
            }
            catch(Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

    }
}
    