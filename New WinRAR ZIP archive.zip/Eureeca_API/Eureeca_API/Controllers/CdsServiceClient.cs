﻿namespace Eureeca_API.Controllers
{
    internal class CdsServiceClient
    {
    }
}