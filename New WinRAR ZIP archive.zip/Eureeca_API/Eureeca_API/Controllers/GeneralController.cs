﻿using Microsoft.AspNetCore.Mvc;
using Eureeca_API.Interface;
using System.ComponentModel.DataAnnotations;
using Microsoft.Extensions.Localization;
using Eureeca_API.General;
using Eureeca_API.Enums;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Interface.InboxInterface;
using Eureeca_API.Models.GeneralModels.Dto;
using Microsoft.AspNetCore.Authorization;

namespace Eureeca_API.Controllers
{
    [Route("Api/[controller]/[action]")]
    [ApiController]
    public class GeneralController : ControllerBase
    {
        private readonly IGeneral _general;
        private readonly IMessage _message;
        private readonly IUser _user;
        private readonly IConfiguration _config;
        private readonly IStringLocalizer<Resources.GeneralController> _stringLocalizer;
        private readonly ErrHandler _errHandler;


        public GeneralController(IGeneral general, IStringLocalizer<Resources.GeneralController> stringLocalizer, IMessage message, IUser user, IConfiguration config)
        {
            _general = general;
            _stringLocalizer = stringLocalizer;
            _errHandler = new ErrHandler();
            _message = message;
            _user = user;
            _config = config;
        }

        [HttpGet]
        public async Task<ActionResult> StatsGetAll([FromQuery] Stats stats)
        {
            try
            {
                var response = await Task.FromResult(_general.StatsGetAll(stats.StatsId, stats.CurrencyId));
                return Ok(new { code = 200, success = true,  data = response });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpGet]
        public async Task<ActionResult> CONSTGetCurrencies([Required] int langId)
        {
            try
            {
                var response = await Task.FromResult(_general.CONSTGetCurrencies(langId));
                if (response == null) { return NotFound(); }
                return Ok(new { code = 200, success = true, currencies = response });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpGet]
        public async Task<ActionResult> CONSTGetCountries([Required] int langId, string? countryName)
        {
            try { 
                var response = await Task.FromResult(_general.CONSTGetCountries(langId, countryName));
                if (response == null) { return NotFound(); }
                return Ok(new { code = 200, success = true, Countries = response }); ;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet]
        public async Task<ActionResult> CONSTGetLanguages(int? langId)
        {
            try
            {
                var response = await Task.FromResult(_general.CONSTGetLanguages(langId));
                foreach (Language language in response.ToList())
                {
                    if (((language.Language_ID == (int)Languages.Arabic && _config.GetValue<string>("ActivateArabic") == "0") || (language.Language_ID == (int)Languages.Spanish && _config.GetValue<string>("ActivateEspanol") == "0")))
                        response.Remove(language);
                }
                if (response == null) { return NotFound(); }
                return Ok(new { code = 200, success = true, Languages = response }); 
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet]
        public async Task<ActionResult<DefaultPageCustomModel>> HomeGetNewsTestimonialsKeyInvestor([Required] int langId, [Required] int countryId, [Required] int currencyId, string? userId)
        {
            try
            {
                var response = await Task.FromResult(_general.HomeGetNewsTestimonialsKeyInvestor(langId, countryId, currencyId, userId));
                if (response == null) { return NotFound(); }
                return Ok(new { code = 200, success = true,  response.Testimonials , response.News, response.KeyInvestors });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        public async Task<ActionResult> SubscriptionAddEmail(SubscribeEmail subscribeEmail)
        {
            try
            {
                Tools.SetThreadCulture((int)subscribeEmail.LangId);

                var response = await Task.FromResult(_general.SubscribeByEmail(subscribeEmail.Email, subscribeEmail.CountryId));
                if (response == 1)
                  return Ok(new GeneralResponseMessage(200, true, _stringLocalizer["Eureeca_newsletter"].Value, _stringLocalizer["Subscription_successful"].Value));
                else if (response == 3)
                    return Ok(new GeneralResponseMessage(200, false, _stringLocalizer["Eureeca_newsletter"].Value, _stringLocalizer["The_email_is_invalid"].Value));
                else if(response == 4)
                    return Ok(new GeneralResponseMessage(200, false, _stringLocalizer["Eureeca_newsletter"].Value, _stringLocalizer["The_email_is_required"].Value));
                else
                    return Ok(new GeneralResponseMessage(200, false, _stringLocalizer["Error_occuered"].Value, _stringLocalizer["The_email_is_required"].Value));
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }
        [HttpPost]
        public bool MessageContactUs(ContactUs contactUs)
        {
            try
            {
                if ((contactUs.Phone != "") && (contactUs.EmailContact.Trim() != "") && (Tools.IsValidEmail(contactUs.EmailContact)) && (contactUs.Name != "") && (contactUs.Details.Trim() != ""))
                {
                    _message.MessageSendContactsEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), contactUs.ContactId, Tools.FilterHTML(contactUs.Name), Tools.FilterHTML(contactUs.EmailContact), Tools.FilterHTML(contactUs.Phone), Tools.FilterHTML(contactUs.Details), UserAction.ContactUs);
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }
        [AllowAnonymous]
        [HttpGet]
        public IActionResult GeneralContactRegardingFilter([Required] int langId)
        {
            try
            {
                Tools.SetThreadCulture(langId);
                List<object> contactRegardingFilter = new List<object>();
                contactRegardingFilter.Add(new { id = 0, value = _stringLocalizer["lblItem1"].Value });
                contactRegardingFilter.Add(new { id = 1, value = _stringLocalizer["lblItem2"].Value });
                contactRegardingFilter.Add(new { id = 2, value = _stringLocalizer["lblItem3"].Value });
                contactRegardingFilter.Add(new { id = 3, value = _stringLocalizer["lblItem4"].Value });
                contactRegardingFilter.Add(new { id = 4, value = _stringLocalizer["lblItem5"].Value });
                contactRegardingFilter.Add(new { id = 5, value = _stringLocalizer["lblItem6"].Value });
                return Ok(new { code = 200, success = true, contactRegardingFilter });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }
    }



}
