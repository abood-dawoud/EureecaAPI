﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Interface.CountryBasedInterface;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Models;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.Payment;
using Eureeca_API.Models.Payment.dto;
using Eureeca_API.Models.Payment.ViewModels;
using Eureeca_API.Models.UserModels.Dto;
using Eureeca_API.Models.UserModels.ViewModesl;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace Eureeca_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class PaymentController : BaseController
    {
        private readonly ErrHandler _errHandler;
        private readonly IConfiguration _config;
        private readonly IPitch _pitch;
        private readonly ICountryBasedControl _countryBasedControl;
        private readonly IUser _user;
        private readonly IInvestment _investment;
        private readonly IGeneral _general;
        private readonly IPaymentUserProposalRelation _paymentUserProposalRelation;
        private readonly IPaymentSelector _paymentSelector;
        private readonly ICountryBasedBankDetails _countryBasedBankDetails;
        private readonly IPayment _payment;
        private readonly IStringLocalizer<Resources.PaymentController> _stringLocalizer;
        public PaymentController(IHttpContextAccessor httpContextAccessor, IConfiguration config, IPitch pitch, ICountryBasedControl countryBasedControl, IUser user, IInvestment investment, IGeneral general, IPaymentUserProposalRelation paymentUserProposalRelation, IPaymentSelector paymentSelector, IStringLocalizer<Resources.PaymentController> stringLocalizer, ICountryBasedBankDetails countryBasedBankDetails, IPayment payment) : base(httpContextAccessor)
        {
            _errHandler = new ErrHandler();
            _config = config;
            _pitch = pitch;
            _countryBasedControl = countryBasedControl;
            _user = user;
            _investment = investment;
            _stringLocalizer = stringLocalizer;
            _general = general;
            _paymentUserProposalRelation = paymentUserProposalRelation;
            _paymentSelector = paymentSelector;
            _countryBasedBankDetails = countryBasedBankDetails;
            _payment = payment;
        }


        [HttpGet("PaymentGetProposalList")]
        public async Task<ActionResult> PaymentGetProposalList([FromQuery] PaymentProposalListRequestModel request)
        {
            try
            {
                request.UserId = int.Parse(_userId);
                Tools.SetThreadCulture(request.LangId);
                if (request.UserId == 0)
                    return await Task.FromResult(BadRequest());

                List<PaymentProposalList> proposals = new List<PaymentProposalList>();
                DataTable dtUser = _user.UserSelectById(request.UserId);
                if (dtUser.Rows.Count == 0)
                    return BadRequest();

                if (!string.IsNullOrEmpty(dtUser.Rows[0]["User_Country"].ToString()))
                    request.CountryId = int.Parse(dtUser.Rows[0]["User_Country"].ToString());

                DataTable dtActiveProposals = await Task.FromResult(_pitch.PitchGetActivePitchesForPayment(request.LangId));
                if (dtActiveProposals.Rows.Count == 0)
                {
                    DataTable dtUserDetails = _user.UserSelectById(request.UserId);
                    if (dtUserDetails.Rows.Count > 0)
                        _errHandler.WriteError("The proposals list retrieve no values: \r\n" +
                             "username:" + dtUserDetails.Rows[0]["User_username"].ToString() + "," +
                             //"user country:" + Geo.GetUserCountryCode() + "," +
                             //"user ip:" + tools.GetUserIP() + "," +
                             "user bank country:" + dtUserDetails.Rows[0]["User_BankCountry"].ToString() + "," +
                             "user languageID:" + dtUserDetails.Rows[0]["User_LanguageID"].ToString() + "," +
                             "user Preferred currency ID:" + dtUserDetails.Rows[0]["User_Preferred_Currency"].ToString() + ","
                             //"user Browser:" + HttpContext.Current.Request.Browser.Type + ","
                             );
                    return await Task.FromResult(BadRequest());
                }


                int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.UserProposalPaymentRelation, request.CountryId, 0);

                if (groupId == 0 || _paymentUserProposalRelation.PaymentUserProposalRelationGetGroupData(groupId).Rows.Count == 0)
                {
                    PaymentProposalList dontKnowItem = new PaymentProposalList();
                    PaymentProposalList wouldRatherNotToSayItem = new PaymentProposalList();
                    PaymentProposalList manyItem = new PaymentProposalList();

                    //set the items 

                    dontKnowItem.ProposalId = 0;
                    dontKnowItem.ProposalCountry = -1;
                    dontKnowItem.ProposalStatus = "-1";
                    dontKnowItem.OwnerId = -1;
                    dontKnowItem.ProposalPreventExeption = false;
                    dontKnowItem.ProposalTitle = _stringLocalizer["DontKnow"].Value;
                    proposals.Add(dontKnowItem);


                    wouldRatherNotToSayItem.ProposalId = 1;
                    wouldRatherNotToSayItem.ProposalCountry = -1;
                    wouldRatherNotToSayItem.ProposalStatus = "-1";
                    wouldRatherNotToSayItem.OwnerId = -1;
                    wouldRatherNotToSayItem.ProposalPreventExeption = false;
                    wouldRatherNotToSayItem.ProposalTitle = _stringLocalizer["WouldRatherNotSay"].Value;
                    proposals.Add(wouldRatherNotToSayItem);

                    manyItem.ProposalId = 2;
                    manyItem.ProposalCountry = -1;
                    manyItem.ProposalStatus = "-1";
                    manyItem.OwnerId = -1;
                    manyItem.ProposalPreventExeption = false;
                    manyItem.ProposalTitle = _stringLocalizer["Many"].Value;
                    proposals.Add(manyItem);
                }

                DataTable dtCurreny = _general.CurrencyGetCurrencyByID(request.CurrencyId);
                string currencySymbol = dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$";

                foreach (DataRow row in dtActiveProposals.Rows)
                {
                    if (_pitch.PitchIsProposalViewPrevented(row, request.CountryId, request.UserId.ToString()))
                        continue;
                    PaymentProposalList proposal = new PaymentProposalList();
                    proposal.ProposalId = int.Parse(row["Pitch_ID"].ToString());
                    proposal.ProposalCountry = int.Parse(row["Pitch_Country"].ToString());
                    proposal.ProposalStatus = row["Pitch_Status"].ToString();
                    proposal.ProposalTitle = row["Profile_PitchTitle"].ToString();
                    proposal.OwnerId = int.Parse(row["Pitch_UserID"].ToString());
                    proposal.ProposalPreventExeption = bool.Parse(row["Pitch_Prevent_Exeption"].ToString());

                    DataTable dtPitchDetails = _pitch.PitchDetailsForQuickInvest(proposal.ProposalId, request.LangId, request.CurrencyId);
                    if (dtPitchDetails.Rows.Count > 0)
                    {
                        if (!string.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString()))
                        {
                            if (int.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString()) > 0)
                            {
                                proposal.MinimumInvestmentAmount = int.Parse(_investment.GetMoneyAfterExchange(request.UserId, proposal.ProposalId, request.CurrencyId, dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString(), "1"));
                                proposal.MinimumInvestmentNote = _stringLocalizer["TheProposal"].Value + " " + proposal.ProposalTitle + " " + _stringLocalizer["MinimumInvestment"].Value + Tools.FormatNumberWithCurrency(request.LangId, currencySymbol, proposal.MinimumInvestmentAmount.ToString("#,##0")) + ".";

                            }

                        }

                    }
                    proposals.Add(proposal);
                }

                return Ok(new { code = 200, success = true, proposals });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message);
                throw new Exception(ex.Message);
            }
        }


        [HttpGet("PaymentGetUserData")]
        public async Task<ActionResult<PaymentUserModel>> PaymentGetUserData([Required] int langId)
        {
            try
            {
                int userId = int.Parse(_userId);
                langId = Enum.IsDefined(typeof(Languages), langId) ? langId : (int)Languages.English;

                Tools.SetThreadCulture(langId);
                if (userId == 0)
                    return await Task.FromResult(BadRequest());
                PaymentUserModel paymentUserData = new PaymentUserModel();
                DataTable dtUserDetails = _user.UserGetDetails(userId, (int)Languages.English);

                if (dtUserDetails.Rows.Count == 0)
                    dtUserDetails = _user.UserGetDetails(userId, (int)Languages.Spanish);
                if (dtUserDetails.Rows.Count == 0)
                    dtUserDetails = _user.UserGetDetails(userId, (int)Languages.Arabic);

                paymentUserData.UserId = userId;
                paymentUserData.Phone = dtUserDetails.Rows[0]["User_Phone"].ToString();

                List<Country> countries = new List<Country>();
                DataTable dtCountry;
                int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.UserProposalPaymentRelation, int.Parse(dtUserDetails.Rows[0]["User_Country"].ToString()), 0);

                if (groupId > 0 && _paymentUserProposalRelation.PaymentUserProposalRelationGetGroupData(groupId).Rows.Count > 0)
                {
                    dtCountry = await Task.FromResult(_countryBasedControl.CountryBasedGetCountryDetails(int.Parse(dtUserDetails.Rows[0]["User_Country"].ToString()), langId));
                    if (dtCountry.Rows.Count > 0)
                    {
                        foreach (Country country in countries)
                        {
                            country.Country_Flag_URL = _config.GetValue<string>("AssetsEnvironmentURL") + "circle_flags/" + country.Country_Flag_URL;

                        }
                    }
                    countries = Tools.ConvertDataTable<Country>(dtCountry);
                    paymentUserData.BankCountry = countries[0];
                    paymentUserData.IsAllowToChangeHisBankCountry = false;
                }

                dtCountry = await Task.FromResult(_countryBasedControl.CountryBasedGetCountryDetails(int.Parse(dtUserDetails.Rows[0]["User_BankCountry"].ToString()), langId));
                if (dtCountry.Rows.Count > 0)
                {
                    foreach (Country country in countries)
                    {
                        country.Country_Flag_URL = _config.GetValue<string>("AssetsEnvironmentURL") + "circle_flags/" + country.Country_Flag_URL;

                    }
                }
                countries = Tools.ConvertDataTable<Country>(dtCountry);

                paymentUserData.BankCountry = countries[0];

                paymentUserData.PaymentCountryProperties = PaymentGetCountryProperties(paymentUserData.BankCountry.Country_Code, langId);

                //Check the KYC
                KYCModel model = _user.KYCGetRequiredFiles(userId, int.Parse(dtUserDetails.Rows[0]["User_Country"].ToString()));

                if (model.KYCOverAllStatus != (int)KYCUserDocsStatus.Accepted && (int.Parse(dtUserDetails.Rows[0]["User_UserFormType"].ToString()) == (int)UserType.Investor || int.Parse(dtUserDetails.Rows[0]["User_UserFormType"].ToString()) == (int)UserType.InvestorAndEnreprenuer))
                    paymentUserData.IsKYCRequired = true;

                paymentUserData.KYCOverAllStatus = model.KYCOverAllStatusText;



                return await Task.FromResult(Ok(new { code = 200, success = true, paymentUserData }));


            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }


        [HttpGet("PaymentGetBankCountryProperties")]
        public async Task<ActionResult<PaymentCountry>> PaymentGetBankCountryProperties([Required] string countryCode, [Required] int langId)
        {
            try
            {
                langId = Enum.IsDefined(typeof(Languages), langId) ? langId : (int)Languages.English;
                PaymentCountry paymentCountry = await Task.FromResult(PaymentGetCountryProperties(countryCode, langId));
                return await Task.FromResult(Ok(new { code = 200, success = true, paymentCountry }));

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        private PaymentCountry PaymentGetCountryProperties(string countryCode, int langId)
        {
            try
            {
                PaymentCountry paymentCountry = new PaymentCountry();
                DataTable dtText = _paymentSelector.PaymentSelectorGetTextDetailsDataPayment(Convert.ToInt32(CountryBasedControls.Payment_Country), countryCode);

                if (dtText.Rows.Count != 0)
                {
                    string lang = "En";
                    if (langId == (int)Languages.Arabic)
                        lang = "Ar";
                    else if (langId == (int)Languages.Spanish)
                        lang = "Sp";

                    paymentCountry.Text = dtText.Rows[0][lang + "_Text"].ToString();
                    paymentCountry.Details = dtText.Rows[0][lang + "_Details"].ToString();
                    paymentCountry.ReadMoreDetails = dtText.Rows[0][lang + "_More"].ToString();
                    if (dtText.Rows[0]["Group_Name"].ToString().ToLower() != "reject")
                    {
                        paymentCountry.IsAllowedToPay = true;
                    }

                }

                return paymentCountry;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message);
            }

        }

        [HttpPost("PaymentUpdateUserBankCountry")]
        public async Task<ActionResult<GeneralResponseMessage>> PaymentUpdateUserBankCountry(UpdateBankCountryRequest requestModel)
        {
            try
            {
                requestModel.UserId = int.Parse(_userId);
                requestModel.LangId = Enum.IsDefined(typeof(Languages), requestModel.LangId) ? requestModel.LangId : (int)Languages.English;
                if (requestModel.UserId == 0)
                    return await Task.FromResult(BadRequest());

                int status = _paymentSelector.PaymentSelectorCheckCountryPayment(Convert.ToInt32(CountryBasedControls.Payment_Country), requestModel.CountryCode);

                if (status == 0)
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["RejectedCountry"].Value)));

                int countryId = GetCountryId(requestModel.LangId, requestModel.CountryCode);
                if (countryId == 0)
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["InvalidCountryCode"].Value)));

                int result = _user.UserUpdateBankCountry(requestModel.UserId, countryId);

                if (result == 0)
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["TryAgain"].Value)));

                return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, "", _stringLocalizer["BankCountryUpdated"].Value)));



            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        private int GetCountryId(int langId, string countryCode)
        {
            List<Country> countries = _general.CONSTGetCountries(langId, "");
            foreach (Country country in countries)
            {
                if (country.Country_Code == countryCode)
                    return country.Country_ID;
            }

            return 0;

        }

        [HttpGet("PaymentGetAvailableCurrencies")]
        public async Task<ActionResult<PaymentCurrency>> PaymentGetAvailableCurrencies([FromQuery] GetCurrencies request)
        {
            try
            {
                List<PaymentCurrency> currencies = new List<PaymentCurrency>();
                int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Payment_Bank_Currency, request.BankCountryId);
                if (groupId > 0)
                {

                    DataTable dtCurrencies = _countryBasedBankDetails.CountryBasedControlGetGroupDataBankDetailst(groupId, (int)request.LangId);
                    if (dtCurrencies.Rows.Count > 0)
                    {
                        currencies = Tools.ConvertDataTable<PaymentCurrency>(dtCurrencies);
                    }

                }

                return Ok(new { code = 200, success = true, currencies });

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");//0
            }

        }

        [HttpGet("PaymentGetUserBalances")]
        public async Task<ActionResult> PaymentGetUserBalances(Languages langId)
        {
            int userId = int.Parse(_userId);
            DataTable dtUserBalance = _user.UserGetAvaliableCurrency(userId, (int)langId);
            List<UserBalance> userBalances = new List<UserBalance>();
            if (dtUserBalance.Rows.Count > 0)
            {
                foreach (DataRow row in dtUserBalance.Rows)
                {
                    UserBalance userBalance = new UserBalance();
                    userBalance.UserId = int.Parse(row["User_ID"].ToString());
                    userBalance.Balance = double.Parse(row["User_Blanace"].ToString()).ToString("#,##0");
                    userBalance.CurrencyName = row["Currency_App"].ToString();
                    userBalance.CurrencyId = int.Parse(row["Currency_ID"].ToString());
                    userBalance.CurrencySymbol = row["Currency_Symbol"].ToString();
                    userBalance.Balance = Tools.FormatNumberWithCurrency((int)langId, double.Parse(row["User_Blanace"].ToString()).ToString("#,##0"), userBalance.CurrencySymbol);

                    userBalances.Add(userBalance);
                }

                return await Task.FromResult(Ok(new { code = 200, success = true, userBalances}));

            }

            return await Task.FromResult(Ok(new { code = 200, success = true, userBalances }));



        }

        [HttpPost("PaymentCheckMethod")]
        public async Task<ActionResult> PaymentCheckPayMethod(PaymentCheckMethod checkMethod)
        {
            try
            {
                Tools.SetThreadCulture((int)checkMethod.LangId);
                int userId = int.Parse(_userId);


                PaymentMethods paymentMethods = new PaymentMethods();
                paymentMethods.EureecaFee = 0.03;

                DataTable dtCountry = _countryBasedControl.CountryBasedGetCountryDetails(checkMethod.CountryId, (int)checkMethod.LangId);
                string countryCode = string.Empty;
                if (dtCountry.Rows.Count > 0)
                    countryCode = dtCountry.Rows[0]["Country_Code"].ToString();

                int status = _paymentSelector.PaymentSelectorCheckCountryPayment(Convert.ToInt32(CountryBasedControls.Payment_Country), countryCode);

                if (status == 0) //-2 Reject country 
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["RejectedCountry"].Value)));



                DataTable dtCountryCreditBanck = _paymentSelector.PaymentSelectorGetCridetTransfae(Convert.ToInt32(CountryBasedControls.Payment_Method), countryCode);
                if (dtCountryCreditBanck.Rows.Count == 0)
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["RejectedCountry"].Value)));


                string currencyApp = Tools.GetEnumDescription(checkMethod.CurrencyId).ToUpper();

                string cardPaymentAmount = "", stripeCardPaymentAmount = "";

                MaxPayResult result = CheckMaxPayAmountExceeded(userId, checkMethod.CountryId, checkMethod.PaymentAmount);
                if (result.IsExceededMaxPay)
                {
                    DataTable dtCurreny = _general.CurrencyGetCurrencyByID((int)checkMethod.CurrencyId);
                    string currencySymbol = dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$";
                    string maxAnnualUserPaymentAmount = currencySymbol + Math.Ceiling(_general.CurrencyGetGlobalRate((int)checkMethod.CurrencyId) * int.Parse(result.MaxPaymentAmount)).ToString("#,##0") + " ";
                    string message = _stringLocalizer["MaxAnnualUserPaymentAmount"].Value + " " + maxAnnualUserPaymentAmount + _stringLocalizer["AllowedDatePaymentAnnual"].Value + result.AvailablePaymentDate + ". " + _stringLocalizer["PleaseContactUs"].Value;

                    return Ok(new GeneralResponseMessage(200, false, "", message));
                }
                else
                {
                    if (checkMethod.PaymentAmount == 9999999) // for live credit card testing only
                    {
                        checkMethod.PaymentAmount = 1; cardPaymentAmount = "1";
                        //to set the minimum amounts that stripe accept for each currency
                        if (currencyApp == "USD")
                            stripeCardPaymentAmount = "1";
                        else if (currencyApp == "EUR")
                            stripeCardPaymentAmount = "1";
                        else if (currencyApp == "GBP")
                            stripeCardPaymentAmount = "1";
                        else if (currencyApp == "MYR")
                            stripeCardPaymentAmount = "5";
                        else if (currencyApp == "AED")
                            stripeCardPaymentAmount = "2";
                    }
                    else
                        stripeCardPaymentAmount = cardPaymentAmount = AddEureecaTransferFees(checkMethod.PaymentAmount, paymentMethods.EureecaFee);


                    bool userProposalPaymentRelationShowBank = true;
                    bool userProposalPaymentRelationShowCheckout = true;
                    bool userProposalPaymentRelationShowStripe = true;

                    DataTable dTPtchDetails = _pitch.PitchGetPitchNotLocalizedDetails(checkMethod.ProposalId);
                    if (dTPtchDetails.Rows.Count > 0)
                    {
                        int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.UserProposalPaymentRelation, checkMethod.CountryId, int.Parse(dTPtchDetails.Rows[0]["Pitch_Country"].ToString()));

                        if (groupId > 0)
                        {
                            DataTable dtGroupData = _paymentUserProposalRelation.PaymentUserProposalRelationGetGroupData(groupId);
                            if (dtGroupData.Rows.Count > 0)
                            {
                                userProposalPaymentRelationShowBank = bool.Parse(dtGroupData.Rows[0]["Show_Bank"].ToString());
                                userProposalPaymentRelationShowCheckout = bool.Parse(dtGroupData.Rows[0]["Show_Checkout"].ToString());
                                userProposalPaymentRelationShowStripe = bool.Parse(dtGroupData.Rows[0]["Show_Stripe"].ToString());
                            }
                        }
                    }

                    if (Convert.ToBoolean(dtCountryCreditBanck.Rows[0]["Show_Cridet"]) && !userProposalPaymentRelationShowCheckout)
                        paymentMethods.ShowCheckout = false;
                        dtCountryCreditBanck.Rows[0]["Show_Cridet"] = "false";

                    if (Convert.ToBoolean(dtCountryCreditBanck.Rows[0]["Show_Stripe_Credit"]) && !userProposalPaymentRelationShowStripe)
                        dtCountryCreditBanck.Rows[0]["Show_Stripe_Credit"] = "false";

                    if (Convert.ToBoolean(dtCountryCreditBanck.Rows[0]["Show_Bank_Transfare"]) && !userProposalPaymentRelationShowBank)
                        dtCountryCreditBanck.Rows[0]["Show_Bank_Transfare"] = "false";


                    

                    if (Convert.ToBoolean(dtCountryCreditBanck.Rows[0]["Show_Cridet"]) || Convert.ToBoolean(dtCountryCreditBanck.Rows[0]["Show_Stripe_Credit"]))
                    {
                        if (Convert.ToBoolean(dtCountryCreditBanck.Rows[0]["Allow_Credit"]) || Convert.ToBoolean(dtCountryCreditBanck.Rows[0]["Allow_Debit"]))
                        {
                            DataColumn dcolColumnFormatingTransferFees = new DataColumn("FormatingEureecaTransferFees", typeof(string));
                            dtCountryCreditBanck.Columns.Add(dcolColumnFormatingTransferFees);
                            dtCountryCreditBanck.Rows[0]["FormatingEureecaTransferFees"] = string.Format("{0:0,0.00}", double.Parse(cardPaymentAmount));

                            DataColumn dcolColumnFormatingStripeEureecaTransferFees = new DataColumn("FormatingStripeEureecaTransferFees", typeof(string));
                            dtCountryCreditBanck.Columns.Add(dcolColumnFormatingStripeEureecaTransferFees);
                            dtCountryCreditBanck.Rows[0]["FormatingStripeEureecaTransferFees"] = string.Format("{0:0,0.00}", double.Parse(stripeCardPaymentAmount));
                        }
                        else
                            dtCountryCreditBanck.Rows[0]["Show_Cridet"] = dtCountryCreditBanck.Rows[0]["Show_Stripe_Credit"] = "false";
                    }

                    paymentMethods.ShowCheckout = bool.Parse(dtCountryCreditBanck.Rows[0]["Show_Cridet"].ToString());
                    paymentMethods.ShowStripe = bool.Parse(dtCountryCreditBanck.Rows[0]["Show_Stripe_Credit"].ToString());
                    paymentMethods.ShowBank = bool.Parse(dtCountryCreditBanck.Rows[0]["Show_Bank_Transfare"].ToString());
                    paymentMethods.AllowCredit = Convert.ToBoolean(dtCountryCreditBanck.Rows[0]["Allow_Credit"]);
                    paymentMethods.AllowDebit = Convert.ToBoolean(dtCountryCreditBanck.Rows[0]["Allow_Debit"]);


                    
                    if (!paymentMethods.ShowCheckout && !paymentMethods.ShowBank && !paymentMethods.ShowStripe)
                        return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["RejectedCountry"].Value)));

                    if (dtCountryCreditBanck.Rows[0]["Show_Payment_Note"].ToString() == "1")
                    {
                        paymentMethods.ShowPaymentNote = true;
                        if (checkMethod.LangId == Languages.Arabic)
                            paymentMethods.PaymentNote = dtCountryCreditBanck.Rows[0]["Payment_Note_Ar"].ToString();
                        else if(checkMethod.LangId == Languages.Spanish)
                            paymentMethods.PaymentNote = dtCountryCreditBanck.Rows[0]["Payment_Note_Sp"].ToString();
                        else
                            paymentMethods.PaymentNote = dtCountryCreditBanck.Rows[0]["Payment_Note_En"].ToString();


                    }


                    return Ok(new { code = 200, success = true, paymentMethods });

                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        private string AddEureecaTransferFees(int Payment_Amount, double EureecaTransferFees)
        {
            double NetAmount = 0;

            try
            {
                NetAmount = Payment_Amount + Math.Round(Payment_Amount * EureecaTransferFees);
                return NetAmount.ToString();
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return NetAmount.ToString();
            }
        }

        private MaxPayResult CheckMaxPayAmountExceeded(int userId, int countryId, int amount)
        {
            try
            {
                MaxPayResult result = new MaxPayResult();
                result.IsExceededMaxPay = false;
                DataTable dtUserInfo = _user.UserSelectById(userId);
                int userCountry;

                if (dtUserInfo.Rows[0]["User_Country"] != null)
                    userCountry = int.Parse(dtUserInfo.Rows[0]["User_Country"].ToString());
                else
                    userCountry = countryId;


                int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.PaymentInvestmentAmountsLimitations, userCountry);
                DataTable dtGroupData = _countryBasedControl.CountryBasedGetGroupData(groupId);

                if (dtGroupData.Rows.Count > 0 && bool.Parse(dtGroupData.Rows[0]["Is_Enabled"].ToString()))
                {
                    if (!String.IsNullOrEmpty(dtGroupData.Rows[0]["USDMaxAnnualPayment"].ToString()))
                    {
                        int MaxAnnualUserPaymentAmount = int.Parse(dtGroupData.Rows[0]["USDMaxAnnualPayment"].ToString());
                        double ConvertAmountToUSD = Math.Floor((double)amount / 1)/*curreny.GetGeneralRate(currencyId))*/;
                        DataTable dtUserAnnualPaymentAmount = _payment.PaymentGetUserAnnualPayments(userId);

                        if ((ConvertAmountToUSD + double.Parse(dtUserAnnualPaymentAmount.Rows[0]["Total_USD_Amount"].ToString())) > double.Parse(MaxAnnualUserPaymentAmount.ToString()))
                        {
                            result.MaxPaymentAmount = dtGroupData.Rows[0]["USDMaxAnnualPayment"].ToString();
                            result.AvailablePaymentDate = dtUserAnnualPaymentAmount.Rows[0]["Available_Payment_Date"].ToString();
                            result.IsExceededMaxPay = true;
                        }
                    }
                    
                }

                return result;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\r\n" + ex.StackTrace);
                MaxPayResult result = new MaxPayResult();
                result.IsExceededMaxPay = true;
                return result;
            }
        }

        [HttpPost("PaymentGetEureecaBankDetails")]
        public async Task<ActionResult> PaymentGetEureecaBankDetails(PaymentGetBankDetails getBankDetails)
        {
            try
            {
                BankDetails bankDetails = new BankDetails();
                Tools.SetThreadCulture((int)getBankDetails.LangId);
                int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Payment_Bank_Currency, getBankDetails.BankCountryId);
                if (groupId > 0)
                {

                    DataTable dtBankDetails = _countryBasedBankDetails.CountryBasedControlGetAllBankInfoByCurrencyLang((int)getBankDetails.CurrencyId, (int)getBankDetails.LangId, groupId);

                    if (dtBankDetails.Rows.Count > 0)
                    {
                        bankDetails.AccountId = int.Parse(dtBankDetails.Rows[0]["Account_ID"].ToString());
                        bankDetails.AccountBankId = int.Parse(dtBankDetails.Rows[0]["Account_Bank_ID"].ToString());
                        bankDetails.BankId = int.Parse(dtBankDetails.Rows[0]["Bank_ID"].ToString());
                        bankDetails.AccountCurrencyId = int.Parse(dtBankDetails.Rows[0]["Account_currency_ID"].ToString());
                        bankDetails.AccountNumber = dtBankDetails.Rows[0]["Account_Number"].ToString();
                        bankDetails.AccountArchived = dtBankDetails.Rows[0]["Account_Archived"].ToString();
                        bankDetails.AccountSortCode = dtBankDetails.Rows[0]["Account_Sort_Code"].ToString();
                        bankDetails.AccountSwift = dtBankDetails.Rows[0]["Account_Swift"].ToString();
                        bankDetails.AccountIban = dtBankDetails.Rows[0]["Account_Iban"].ToString();
                        bankDetails.AccountInstitution = dtBankDetails.Rows[0]["Account_Institution"].ToString();
                        bankDetails.BankName = dtBankDetails.Rows[0]["Bank_Name"].ToString();
                        bankDetails.AccountName = dtBankDetails.Rows[0]["Account_Name"].ToString();
                        bankDetails.AccountAddress = dtBankDetails.Rows[0]["Account_Address"].ToString();
                        bankDetails.BankAddress = dtBankDetails.Rows[0]["Bank_Address"].ToString();
                        return Ok(new { code = 200, success = true, bankDetails});
                    }
                    else // no data
                    {
                        return Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["NoData"].Value));//"0";
                    }

                }
                else
                {
                    return Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["NoData"].Value));//"0";
                }


            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }
    }
}
