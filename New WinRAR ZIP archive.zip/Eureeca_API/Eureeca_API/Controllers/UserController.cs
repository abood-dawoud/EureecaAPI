﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Interface.AccountInterface;
using Eureeca_API.Interface.CountryBasedInterface;
using Eureeca_API.Interface.InboxInterface;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.PitchModels.Dto;
using Eureeca_API.Models.PitchModels.ViewModels;
using Eureeca_API.Models.SuitabilityModels.Dto;
using Eureeca_API.Models.SuitabilityModels.ViewModels;
using Eureeca_API.Models.UserModels.Dto;
using Eureeca_API.Models.UserModels.ViewModesl;
using Google.Apis.Sheets.v4.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Microsoft.IdentityModel.Tokens;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;

namespace Eureeca_API.Controllers
{
    [Route("Api/User/[action]")]
    [ApiController]

    public class UserController : BaseController
    {
        private readonly IUser _user;
        private readonly ICountryBasedControl _countryBasedControl;
        private readonly ErrHandler _errHandler;
        private readonly IConfiguration _configuration;
        private readonly IStringLocalizer<Resources.UserController> _stringLocalizer;
        private readonly IEntrepreneurs _entrepreneurs;
        private readonly IInvestors _investor;
        private readonly IMessage _message;
        private readonly IPitch _pitch;
        private readonly IPitchLikeFollower _pitchLikeFollower;
        private readonly IGeneral _general;
        private readonly IInvestment _investment;
        private readonly IUserObjects _userObjects;
        private readonly IAccount _account;
        private readonly ICustomForumUser _customForumUser;


        public UserController(IHttpContextAccessor httpContextAccessor, IUser user, ICountryBasedControl countryBasedControl, IConfiguration configuration, IStringLocalizer<Resources.UserController> stringLocalizer, IEntrepreneurs entrepreneurs, IInvestors investor, IMessage message, IPitch pitch, IPitchLikeFollower pitchLikeFollower, IGeneral general, IInvestment investment, IUserObjects userObjects, IAccount account, ICustomForumUser customForumUser) : base(httpContextAccessor)
        {
            _user = user;
            _countryBasedControl = countryBasedControl;
            _errHandler = new ErrHandler();
            _configuration = configuration;
            _stringLocalizer = stringLocalizer;
            _entrepreneurs = entrepreneurs;
            _investor = investor;
            _message = message;
            _pitch = pitch;
            _pitchLikeFollower = pitchLikeFollower;
            _general = general;
            _investment = investment;
            _userObjects = userObjects;
            _account = account;
            _customForumUser = customForumUser;
        }

        [HttpGet]
        public async Task<ActionResult> UserGetInvestorClassification([FromQuery] UserGeneral userGeneral)
        {
            try
            {
                userGeneral.UserId = int.Parse(_userId);
                Tools.SetThreadCulture((int)userGeneral.LangId);
                DataTable dtUser = await Task.FromResult(_user.UserSelectById(userGeneral.UserId));
                List<InvestorClassification> investorClassificationList = new List<InvestorClassification>();
                if (await Task.FromResult(_user.UserIsCategorizationAllowedForUser(dtUser.Rows[0]))) //Allowed Investor_Type ?
                {
                    DataTable dtGroupData = await Task.FromResult(_countryBasedControl.CountryBasedGetQuestionnaireCategoryGroupDetails(_countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Questionnaire_Categorization, int.Parse(dtUser.Rows[0]["User_Country"].ToString()))));
                    if (dtGroupData != null && dtGroupData.Rows.Count > 0)
                    {
                        foreach (DataRow dr in dtGroupData.Rows)
                        {
                            if (!String.IsNullOrEmpty(dr["is_Enabled"].ToString()) && bool.Parse(dr["is_Enabled"].ToString()))
                            {
                                InvestorClassification investorClassification = new InvestorClassification();
                                if (userGeneral.LangId == Languages.English)
                                {
                                    investorClassification.ClassificationTitle = dr["Category_En_Title"].ToString();
                                    investorClassification.ClassificationDescription = dr["Category_En_Details"].ToString();
                                }
                                else if (userGeneral.LangId == Languages.Arabic)
                                {
                                    investorClassification.ClassificationTitle = dr["Category_Ar_Title"].ToString();
                                    investorClassification.ClassificationDescription = dr["Category_Ar_Details"].ToString(); ;

                                }
                                investorClassification.ClassificationId = int.Parse(dr["CategoryType_ID"].ToString());

                                investorClassificationList.Add(investorClassification);
                            }
                        }

                        return Ok(new { code = 200, success = true, investorClassificationList });

                    }
                    else
                    {
                        return Ok(new { code = 200, success = false, message = _stringLocalizer["NotAllowedTab"].Value });
                    }

                }
                else
                {
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["NotAllowedTab"].Value });

                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }


        }
        [HttpGet]
        public async Task<ActionResult> GetSuitabilityTest([FromQuery] UserGeneral userGeneral)
        {
            userGeneral.UserId = int.Parse(_userId);
            Tools.SetThreadCulture((int)userGeneral.LangId);

            string failureMessage = _stringLocalizer["FailureMessage"].Value;

            DataTable dtUser = await Task.FromResult(_user.UserSelectById(userGeneral.UserId));
            int isAllowed = await Task.FromResult(_user.UserIsSuitabilityTestAllowedForUser(dtUser.Rows[0]));
            if ((!await Task.FromResult(_user.UserIsCategorizationAllowedForUser(dtUser.Rows[0])) && (isAllowed == 1 || isAllowed == 3)))
            {
                string description = _stringLocalizer["BeforeComplete"].Value + "<br/>" + _stringLocalizer["UKFinancialAuthority"].Value + "<br/>" + _stringLocalizer["ForThePurpose"].Value + "<br/>" + _stringLocalizer["YouFail"].Value + "<br/>" + _stringLocalizer["YouUnsure"].Value + "<br/> <a href = '" + _configuration.GetValue<string>("EnvironmentURL") + "Downloads/Eureeca.pdf'>" + _stringLocalizer["EducationDoc"].Value + "</a>";
                List<SuitabilityTest> suitabilities = await Task.FromResult(_user.SuitabilityTestGetSuitabilityTest((int)userGeneral.LangId, dtUser.Rows[0]["User_Country"].ToString(), int.Parse(dtUser.Rows[0]["User_ID"].ToString())));
                if (suitabilities != null && suitabilities.Count > 0)
                {
                    return Ok(new { code = 200, success = true, description, suitabilities });
                }
                else
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["NotAllowedTab"].Value, hasFailedBefore = false });
            }
            else if (isAllowed == 2)
            {
                failureMessage += " " + _stringLocalizer["TwentyFourHours"].Value;
                return Ok(new { code = 200, success = false, suitabilityMessage = failureMessage, hasFailedBefore = true });
            }
            else if (isAllowed == 4)
            {
                failureMessage += " " + _stringLocalizer["SevenDays"].Value;
                return Ok(new { code = 200, success = false, suitabilityMessage = failureMessage, hasFailedBefore = true });

            }
            else
            {
                return Ok(new { code = 200, success = false, message = _stringLocalizer["NotAllowedTab"].Value, hasFailedBefore = false });
            }

        }

        [HttpGet]
        public async Task<ActionResult> KYCGetRequiredFiles([FromQuery] KYCRequiredFiles kYCRequiredFiles)
        {
            try
            {
                kYCRequiredFiles.UserId = int.Parse(_userId);

                Tools.SetThreadCulture((int)kYCRequiredFiles.LangId);
                var response = await Task.FromResult(_user.KYCGetRequiredFiles(kYCRequiredFiles.UserId, kYCRequiredFiles.CountryId));
                return Ok(new { code = 200, success = true, KYCRequiredDocs = response });

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }
        [AllowAnonymous]
        [HttpGet]
        public IActionResult UserGetEntrepreneurType([Required] int langId)
        {
            try
            {
                Tools.SetThreadCulture(langId);
                List<object> entrepreneurType = new List<object>();
                entrepreneurType.Add(new { id = 0, value = _stringLocalizer["AllEntrepreneur"].Value });
                entrepreneurType.Add(new { id = 1, value = _stringLocalizer["FeaturedEntrepreneur"].Value });
                return Ok(new { code = 200, success = true, entrepreneurType });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }
        [AllowAnonymous]
        [HttpGet]
        public IActionResult UserGetInvestorType([Required] int langId)
        {
            try
            {
                Tools.SetThreadCulture(langId);
                List<object> investorType = new List<object>();
                investorType.Add(new { id = "All_Investors", value = _stringLocalizer["AllInvestors"].Value });
                investorType.Add(new { id = "Featured_Investor", value = _stringLocalizer["FeaturedInvestor"].Value });
                return Ok(new { code = 200, success = true, investorType });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }
        [AllowAnonymous]
        [HttpGet]
        public IActionResult UserInvestorSortFilter([Required] int langId)
        {
            try
            {
                Tools.SetThreadCulture(langId);
                List<object> investorSortFilter = new List<object>();
                investorSortFilter.Add(new { id = "Latest_Investment", value = _stringLocalizer["LatestInvestment"].Value });
                investorSortFilter.Add(new { id = "Higher_Investment", value = _stringLocalizer["HigherInvestment"].Value });
                return Ok(new { code = 200, success = true, investorSortFilter });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }
        [AllowAnonymous]
        [HttpGet]
        public IActionResult UserInvestorBadgeFilter([Required] int langId)
        {
            try
            {
                Tools.SetThreadCulture(langId);
                List<object> investorBadgeFilter = new List<object>();
                investorBadgeFilter.Add(new { id = -1, value = _stringLocalizer["ChooseBadge"].Value });
                investorBadgeFilter.Add(new { id = 1, value = _stringLocalizer["SilverInvestor"].Value });
                investorBadgeFilter.Add(new { id = 2, value = _stringLocalizer["GoldInvestor"].Value });
                investorBadgeFilter.Add(new { id = 3, value = _stringLocalizer["PlatinumInvestor"].Value });
                investorBadgeFilter.Add(new { id = 4, value = _stringLocalizer["DiamondInvestor"].Value });
                return Ok(new { code = 200, success = true, investorBadgeFilter });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult<EntrepreneursResponse>> UserGetEntrepreneursList(GetEntrepreneurs getEntrepreneurs)
        {
            try
            {
                Tools.SetThreadCulture((int)getEntrepreneurs.LangId);

                var response = await Task.FromResult(_entrepreneurs.EntrepreneursGetEntrepreneurs(getEntrepreneurs.ListEntrepreneurShowFilter, getEntrepreneurs.FilterCountryId, getEntrepreneurs.PageNo, getEntrepreneurs.PageSize, getEntrepreneurs.UserId, (int)getEntrepreneurs.LangId, (int)getEntrepreneurs.CurrencyId));
                return Ok(response);
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult<InvestorsResponse>> UserGetInvestorsList(GetInvestors getInvestors)
        {
            try
            {
                Tools.SetThreadCulture((int)getInvestors.LangId);
                var response = await Task.FromResult(_investor.InvestorsGetInvestorsList(getInvestors.ListInvestorShowFilter, getInvestors.SortFilterId, getInvestors.CountryId, getInvestors.BadgeId, getInvestors.InvestorName, (int)getInvestors.LangId, getInvestors.PageNo, getInvestors.PageSize, getInvestors.UserId, (int)getInvestors.CurrencyId));
                return Ok(response);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult<LoginResponse>> Login(LoginModel model)
        {
            try
            {
                DataTable dtUserInfo = await Task.FromResult(_user.UserGetUserInfo(model.Username, model.Password));
                RedirectType redirectType;
                LoginResponse loginResponse = await Task.FromResult(_user.UserAuthenticateUser(dtUserInfo, out redirectType));
                if (loginResponse == null) { return NotFound(); }
                if (loginResponse.RedirectType == (int)RedirectType.InvalidAuthentication)
                    return Ok(new { code = 200, success = false, loginResponse = loginResponse });
                else
                {
                    var claims = new[] {
                        new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                        new Claim("User_ID", dtUserInfo.Rows[0]["User_ID"].ToString()),
                        new Claim("User_Username", dtUserInfo.Rows[0]["User_Username"].ToString()),
                        new Claim("User_UserFormType", dtUserInfo.Rows[0]["User_UserFormType"].ToString()),
                        new Claim("User_Email", dtUserInfo.Rows[0]["User_Email"].ToString()) };

                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                    var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                    var token = new JwtSecurityToken(
                        _configuration["Jwt:Issuer"],
                        _configuration["Jwt:Audience"],
                        claims,
                        expires: DateTime.UtcNow.AddDays(7),
                        signingCredentials: signIn);

                    return Ok(new { code = 200, success = true, token = new JwtSecurityTokenHandler().WriteToken(token), loginResponse = loginResponse });
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult<LoginResponse>> GetUserByToken([Required] string token)
        {
            try
            {
                var userId = IsJWTTokenValid(token);
                if (userId > 0)
                {
                    DataTable dtUserInfo = await Task.FromResult(_user.UserSelectById(userId));
                    LoginResponse loginResponse = await Task.FromResult(_user.UserAuthenticateUser(dtUserInfo, out _));

                    if (loginResponse.RedirectType == (int)RedirectType.InvalidAuthentication)
                        return Ok(new { code = 200, success = false, loginResponse = loginResponse });

                    return Ok(new { code = 200, success = true, loginResponse = loginResponse });
                }

                return Ok(new { code = 200, success = false });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        private int IsJWTTokenValid(string jssoToken)
        {
            try
            {
                var userAgent = $"{this.Request?.HttpContext?.Request?.Headers["user-agent"]}";
                var xForwardedFor = $"{this.Request?.HttpContext?.Request?.Headers["X-Forwarded-For"]}";
                var ipAddress = Request?.HttpContext?.Connection?.RemoteIpAddress?.ToString();
                var jwtHandler = new JwtSecurityTokenHandler();

                var secret = _configuration["Jwt:Key"];
                var serverKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret));

                var b = jwtHandler.ValidateToken(jssoToken, new TokenValidationParameters
                {
                    IssuerSigningKey = serverKey,
                    ValidateIssuer = false,
                    ValidateAudience = false
                }, out var validationToken);

                if (DateTime.UtcNow >= validationToken.ValidTo)
                    return 0;

                if (b.Identity != null && b.Identity.IsAuthenticated && b.Claims.Any())
                {
                    // Validate the userAgent
                    var userAgentClaim = Tools.Decrypt(b.Claims.Where(a => a.Type == "UAG").Select(x => x.Value).FirstOrDefault());
                    if (userAgentClaim != userAgent)
                        return 0;

                    // Validate the IpAddress
                    var ipAddressClaim = Tools.Decrypt(b.Claims.Where(a => a.Type == "IPA").Select(x => x.Value).FirstOrDefault());
                    if (ipAddressClaim != xForwardedFor && ipAddressClaim != ipAddress)
                        return 0;


                    var sam = b.Claims.Where(a => a.Type == "User_ID").Select(x => x.Value).FirstOrDefault();
                    if (sam != null && Tools.IsValidNumber(sam))
                        return int.Parse(sam);
                }

                return 0;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
            }

            return 0;
        }


        [HttpPost]
        public async Task<ActionResult> UserUpdateInvestorCategory([FromForm] int userId, [FromForm] int investorClassification)
        {
            try
            {

                var response = await Task.FromResult(_user.UserUpdateInvestorCategory(int.Parse(_userId), investorClassification));
                if (response > 0)
                    return Ok(new { code = 200, success = true, message = _stringLocalizer["UpdatedSuccessfully"].Value });
                else
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["ErrorOccurred"].Value });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }
        private async Task<WriteFileResult> WriteFile(IFormFile file, string pathURL)
        {
            WriteFileResult writeFileResult = new WriteFileResult();
            bool isSaveSuccess = false;

            try
            {
                string fileName;

                var extension = "." + file.FileName.Split('.')[file.FileName.Split('.').Length - 1];
                fileName = DateTime.Now.Ticks + extension;
                writeFileResult.FileName = fileName;

                var pathBuilt = Path.Combine(pathURL);
                if (!Directory.Exists(pathBuilt))
                {
                    Directory.CreateDirectory(pathBuilt);
                }

                var path = Path.Combine(pathURL, fileName);
                using (var stream = new FileStream(path, FileMode.Create))
                {
                    await file.CopyToAsync(stream);

                }
                isSaveSuccess = true;

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);


            }
            writeFileResult.IsSaved = isSaveSuccess;
            return writeFileResult;

        }

        [HttpPost]
        public async Task<ActionResult> KYCUplaodFile([FromForm] int userId, [FromForm] int countryId, [FromForm] int docType, [FromForm] string? docName, IFormFile file)
        {
            try
            {
                userId = int.Parse(_userId);
                UploadKYCResponseModel response = await Task.FromResult(_user.KYCUploadFile(userId, countryId, docType, docName, file));
                if (response.ResponseStatus == (int)ResponseStatus.Success)
                {
                    await WriteFile(file, _configuration.GetValue<string>("AttachmentPath") + "KYC");
                    _message.MessageSendKYCUploadedEmailToInvestor(_user.UserGetSystemAdmin(), response.User);
                    _message.MessageSendKYCUploadedEmailToKYCTeam(_user.UserGetSystemAdmin(), response.User, response.ObjectTitle, response.ImageName);

                    if (response.OverallStatus == (int)KYCUserDocsStatus.PendingApproval)
                    {
                        _message.MessageSendKYCUploadedEmailToKYCAdmin(_user.UserGetSystemAdmin(), response.User, response.ObjectTitle, response.AllUploadedDocs);
                    }
                    return Ok(new { code = 200, success = true, responseStatus = response.ResponseStatus, message = _stringLocalizer["FileHasBeenUploadedSuccessfully"].Value });
                }
                else if (response.ResponseStatus == (int)ResponseStatus.FileAlreadyExists)
                {
                    return Ok(new { code = 200, success = false, responseStatus = response.ResponseStatus, message = _stringLocalizer["CannotUploadFileAlreadyExist"].Value });

                }
                else if (response.ResponseStatus == (int)ResponseStatus.FileAlreadyUploaded)
                {
                    return Ok(new { code = 200, success = false, responseStatus = response.ResponseStatus, message = _stringLocalizer["FileHasAlreadyBeenUploaded"].Value });

                }
                else if (response.ResponseStatus == (int)ResponseStatus.NotSupportedFileExtension)
                {
                    return Ok(new { code = 200, success = false, responseStatus = response.ResponseStatus, message = _stringLocalizer["NotValidFile"].Value });

                }
                else if (response.ResponseStatus == (int)ResponseStatus.EmptyPassportDocName)
                {
                    return Ok(new { code = 200, success = false, responseStatus = response.ResponseStatus, message = _stringLocalizer["FillPasportName"].Value });
                }
                else if (response.ResponseStatus == (int)ResponseStatus.EmptyPOADocName)
                {
                    return Ok(new { code = 200, success = false, responseStatus = response.ResponseStatus, message = _stringLocalizer["FillPOAAddress"].Value });
                }
                else
                {
                    return Ok(new { code = 200, success = false, responseStatus = response.ResponseStatus, message = _stringLocalizer["ErrorOccurred"].Value });
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        public async Task<IActionResult> UserUpdateLastLoginDate([FromForm] long userId)
        {
            try
            {
                int response = await Task.FromResult(_user.UserUpdateLastLoginDate(int.Parse(_userId)));
                if (response > 0)
                    return Ok(new { code = 200, success = true, message = _stringLocalizer["UpdatedSuccessfully"].Value });

                return Ok(new { code = 200, success = false, message = _stringLocalizer["ErrorOccurred"].Value });

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");

            }
        }

        [HttpGet]
        public async Task<ActionResult<GeneralResponseMessage>> UserGetKYCGeneralInfoAgreement([Required] int langId)
        {
            try
            {
                Tools.SetThreadCulture(langId);
                List<Agreement> agreement = new List<Agreement>();
                Agreement KYCAgreement = new Agreement();
                KYCAgreement.IsAgreement = true;
                KYCAgreement.MessageType = (int)MessageType.Agreement;
                KYCAgreement.Title = _stringLocalizer["KYCGeneralInfoTitle"].Value;
                KYCAgreement.CanClose = true;
                KYCAgreement.Details = _stringLocalizer["KYCGeneralInfo"].Value;

                agreement.Add(KYCAgreement);
                return await Task.FromResult(Ok(new { code = 200, success = true, agreement }));

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");

            }
        }

        [HttpPost]
        public async Task<ActionResult> SuitabilityTestSubmitAnswers([FromBody] SuitabilityTestSubmitAnswerModel model)
        {
            try
            {
                model.UserId = int.Parse(_userId);
                var response = await Task.FromResult(_user.SuitabilityTestSubmitAnswers(model.UserId, model.CountryId, model.Answers, model.LangId));
                if (response == null) { return NotFound(); }
                if (response.ResponseStatus == ResponseStatus.NullUserId)
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["NeedLogin"].Value, response.ResponseStatus });
                else if (response.ResponseStatus == ResponseStatus.UserDoesNotExist)
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["NotExistingUser"].Value, response.ResponseStatus });
                else if (response.ResponseStatus == ResponseStatus.SomeQuestionsNotAnswered)
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["RequirementQuestions"].Value, response.ResponseStatus });
                else if (response.ResponseStatus == ResponseStatus.NotAllowedTab)
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["NotAllowedTab"].Value, response.ResponseStatus });
                else
                {
                    _message.MessageSendSignupNotification(_user.UserGetSystemAdminEmail(), _configuration.GetValue<string>("InvestorsEmail"), response.User.Username, response.User.Phone, response.User.Email, response.CurrentActivation);
                    _message.MessageSendSignupNotification(_user.UserGetSystemAdminEmail(), _configuration.GetValue<string>("contactusEmail"), response.User.Username, response.User.Phone, response.User.Email, response.CurrentActivation);

                    return Ok(new { code = 200, success = true, response });
                }


            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        public async Task<ActionResult<UserFollowedProposalsResponseModel>> UserGetFollowedProposals(UserFollowedProposalsRequestModel userFollowedProposalsRequestModel)
        {
            try
            {
                int loggedInUserId = int.Parse(_userId);
                int recordCount = 0;
                bool hasMore = false;

                DataTable dtFollowedProposals = _user.UserGetFollowedPitches(loggedInUserId, userFollowedProposalsRequestModel.PitchLanguageId, userFollowedProposalsRequestModel.SoryBy, userFollowedProposalsRequestModel.PageNo, userFollowedProposalsRequestModel.PageSize, out recordCount);
                hasMore = recordCount > ((userFollowedProposalsRequestModel.PageNo + 1) * userFollowedProposalsRequestModel.PageSize);

                foreach (DataRow dr in dtFollowedProposals.Rows)
                {
                    if (_pitch.PitchIsProposalViewPrevented(dr, userFollowedProposalsRequestModel.UserCountry, _userId))
                        dr.Delete();
                }
                dtFollowedProposals.AcceptChanges();

                List<UserFollowedProposal> followedProposalsList = new List<UserFollowedProposal>();

                foreach (DataRow dr in dtFollowedProposals.Rows)
                {
                    UserFollowedProposal followedProposal = new UserFollowedProposal();

                    followedProposal.CurrentBlocksCount = dtFollowedProposals.Rows.Count;
                    followedProposal.SoFarPercentage = Math.Floor(float.Parse(dr["Pitch_InvestedSoFar"].ToString()));
                    followedProposal.PitchInvestors = int.Parse(dr["Pitch_Investors"].ToString());

                    DataTable DTGetFollowedPitchesRemindMints = _user.UserGetPitchRemindMints(int.Parse(dr["Pitch_ID"].ToString()));
                    int TimeParts = int.Parse(DTGetFollowedPitchesRemindMints.Rows[0]["RemindMint"].ToString());

                    followedProposal.IsClosed = TimeParts <= 0;
                    followedProposal.CanInvest = TimeParts > 0;

                    DataTable dtConnection = _pitchLikeFollower.PitchgetUserIsLikeFollower(loggedInUserId, int.Parse(dr["Pitch_ID"].ToString()));
                    bool follower = false;

                    if (dtConnection.Rows.Count > 0)
                        follower = dtConnection.Rows.Count > 0 && Boolean.Parse(dtConnection.Rows[0]["PUConnection_FollowType"].ToString());

                    followedProposal.IsFollower = follower;

                    if (!follower)
                        followedProposal.ActivitiesLogActivityID = (int)UserActivities.Follow_Proposal;
                    else
                        followedProposal.ActivitiesLogActivityID = (int)UserActivities.Unfollow_Proposal;

                    if (dr["Pitch_Status"].ToString() == "Early Access")
                    {
                        followedProposal.ActivitiesLogPStage = 0;
                        followedProposal.CanInvest = false;
                        followedProposal.IsComingSoon = true;
                    }
                    else
                    {
                        followedProposal.ActivitiesLogPStage = 1;
                        if ((dr["Pitch_Status"].ToString() == "Overfunding" || dr["Pitch_Status"].ToString() == "published") && bool.Parse(dr["Pitch_IsExtended"].ToString()))
                            followedProposal.HasExtraTime = true;
                        else
                        {
                            if (TimeParts > 0 && TimeParts < 60)
                            {
                                followedProposal.RemainingTime = (int)Math.Ceiling((decimal)TimeParts);

                                if ((int)Math.Ceiling((decimal)TimeParts) == 1)
                                    followedProposal.RemainingTimeUnit = _stringLocalizer["MinitLeft"].Value;
                                else
                                    followedProposal.RemainingTimeUnit = _stringLocalizer["MinitsLeft"].Value;
                            }
                            else if (TimeParts >= 60 && TimeParts < 2880)
                            {
                                followedProposal.RemainingTime = (int)Math.Ceiling((decimal)TimeParts / 60);

                                if ((int)Math.Ceiling((decimal)TimeParts / 60) == 1)
                                    followedProposal.RemainingTimeUnit = _stringLocalizer["HourLeft"].Value;
                                else
                                    followedProposal.RemainingTimeUnit = _stringLocalizer["HoursLeft"].Value;
                            }
                            else
                            {
                                followedProposal.RemainingTime = (int)Math.Ceiling((decimal)TimeParts / 60 / 24);

                                if ((int)Math.Ceiling((decimal)TimeParts / 60 / 24) == 1)
                                    followedProposal.RemainingTimeUnit = _stringLocalizer["DayLeft"].Value;
                                else
                                    followedProposal.RemainingTimeUnit = _stringLocalizer["DaysLeft"].Value;
                            }
                        }
                    }

                    followedProposal.ProfilePitchTitle = dr["Profile_PitchTitle"].ToString();
                    followedProposal.Pitch_ID = int.Parse(dr["Pitch_ID"].ToString());
                    followedProposalsList.Add(followedProposal);
                }

                return await Task.FromResult(Ok(new UserFollowedProposalsResponseModel(200, true, recordCount, hasMore, userFollowedProposalsRequestModel.PageNo, followedProposalsList)));
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet]
        public async Task<ActionResult> GetUserPropsoalStatus([Required] int userId, [Required] int langId, [Required] int currencyId)
        {
            try
            {
                userId = int.Parse(_userId);
                Tools.SetThreadCulture(langId);
                if (userId == 0)
                    return await Task.FromResult(Ok(new { code = 200, success = true, message = _stringLocalizer["NotValidUserId"].Value }));

                DataTable dtUser = _user.UserSelectById(userId);
                if (dtUser.Rows.Count == 0)
                    return await Task.FromResult(Ok(new { code = 200, success = true, message = _stringLocalizer["NotExistingUser"].Value }));

                if (int.Parse(dtUser.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.Enreprenuer && int.Parse(dtUser.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.InvestorAndEnreprenuer)
                    return await Task.FromResult(Ok(new { code = 200, success = true, message = _stringLocalizer["NotAllowedToCheckProposal"].Value }));

                SMEDashboardProposalSectionResponse SMEProposal = new SMEDashboardProposalSectionResponse();
                SMEProposal.IsProposalStarted = true;
                DataTable dtUserActivePitch = await Task.FromResult(_pitch.PitchGetUserActivePitch(userId));
                DataTable dtCheckList = _pitch.PitchGetCheckListApplication(userId);

                if (dtUserActivePitch.Rows.Count == 0 && dtCheckList.Rows.Count == 0)
                {
                    SMEProposal.IsProposalStarted = false;
                    return await Task.FromResult(Ok(new { code = 200, success = true, SMEProposal }));
                }
                ProposalStatus proposalStatus = new ProposalStatus();
                ProposalCheckList proposalCheckList = new ProposalCheckList();
                SMEDashboardProposal SMEPproposalInfo = new SMEDashboardProposal();

                if (dtUserActivePitch.Rows.Count == 0 || bool.Parse(dtUserActivePitch.Rows[0]["Pitch_IsCheckListOnly"].ToString()))
                {

                    int checklistStatus = Convert.ToInt32(dtCheckList.Rows[0]["CheckList_Status"]);
                    if (checklistStatus == (int)EntrepreneursCheckListStatus.New)
                    {
                        SMEProposal.IsProposalStarted = false;
                        return await Task.FromResult(Ok(new { code = 200, success = true, SMEProposal }));
                    }
                    else if (checklistStatus == (int)EntrepreneursCheckListStatus.Submitted || checklistStatus == (int)EntrepreneursCheckListStatus.OnHold)
                    {
                        proposalCheckList.IsCheckListOnly = true;
                        proposalCheckList.CheckListMessage = _stringLocalizer["ReviewingYourApplication"].Value;
                        proposalCheckList.CheckListStatus = checklistStatus;
                    }
                    else if (checklistStatus == (int)EntrepreneursCheckListStatus.Accepted)
                    {
                        proposalCheckList.IsCheckListOnly = false;
                        proposalCheckList.IsCheckListAccepted = true;
                        proposalCheckList.CheckListMessage = _stringLocalizer["BuildYourProposal"].Value;
                        proposalCheckList.CheckListStatus = checklistStatus;

                    }
                    else if (checklistStatus == (int)EntrepreneursCheckListStatus.Rejected)
                    {
                        proposalCheckList.IsCheckListOnly = true;
                        proposalCheckList.CheckListMessage = _stringLocalizer["ApplicationNotApproved"].Value;
                        proposalCheckList.CheckListStatus = checklistStatus;
                    }


                    proposalStatus.ProposalCheckList = proposalCheckList;
                    SMEProposal.ProposalStatus = proposalStatus;
                    return await Task.FromResult(Ok(new { code = 200, success = true, SMEProposal }));
                }

                SMEPproposalInfo.ProposalId = int.Parse(dtUserActivePitch.Rows[0]["Pitch_ID"].ToString());
                if (!string.IsNullOrEmpty(dtUserActivePitch.Rows[0]["pitch_status"].ToString()))
                {

                    if (dtUserActivePitch.Rows[0]["pitch_status"].ToString() == "submitted For Approval")
                    {
                        SMEPproposalInfo.ProposalStatus = (int)PitchStatus.SubmittedForApproval;

                    }
                    else if (dtUserActivePitch.Rows[0]["pitch_status"].ToString() == "not ready")
                    {
                        SMEPproposalInfo.ProposalStatus = (int)PitchStatus.NotReady;
                    }
                }

                DataTable dtPitchDetails = _pitch.PitchGetDedicatedPitchDetailsByLang(int.Parse(dtUserActivePitch.Rows[0]["Pitch_ID"].ToString()), langId);

                if (dtPitchDetails.Rows.Count == 0)
                    dtPitchDetails = _pitch.PitchGetDedicatedPitchDetailsByLang(int.Parse(dtUserActivePitch.Rows[0]["Pitch_ID"].ToString()), (int)Languages.English);

                if (dtPitchDetails.Rows.Count > 0)
                {
                    double rate = _pitch.PitchGetPitchRateAsDouble(SMEPproposalInfo.ProposalId, currencyId);

                    SMEPproposalInfo.ProposalTitle = dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString();

                    SMEPproposalInfo.Raised = string.Format("{0:n0}", (float.Parse(dtPitchDetails.Rows[0]["Pitch_Balance"].ToString()) * rate)).ToString();
                    SMEPproposalInfo.ProposalPercantage = Math.Floor(float.Parse(dtPitchDetails.Rows[0]["Pitch_InvestedSoFar"].ToString())).ToString();
                    SMEPproposalInfo.EquitySold = dtPitchDetails.Rows[0]["Pitch_Equity_Sold"].ToString();
                    SMEPproposalInfo.SharesSold = Tools.Format2DP(double.Parse(dtPitchDetails.Rows[0]["Pitch_Shares_Sold"].ToString()));
                    SMEPproposalInfo.InvestorNumber = int.Parse(dtPitchDetails.Rows[0]["Pitch_Investors"].ToString());
                    SMEPproposalInfo.FollowersNumber = int.Parse(dtPitchDetails.Rows[0]["Pitch_PitchFollow"].ToString());
                    SMEPproposalInfo.CompletePercentage = int.Parse(dtPitchDetails.Rows[0]["Profile_Progress"].ToString());

                    Investor mostRecentInvestor = new Investor();
                    DataTable dtPitchLastInvestments = _pitch.PitchGetMostRecentInvestment(int.Parse(dtPitchDetails.Rows[0]["Pitch_ID"].ToString()), langId);

                    if (dtPitchLastInvestments.Rows.Count > 0)
                    {
                        mostRecentInvestor.InvestmentAmount = string.Format("{0:n0}", (float.Parse(dtPitchLastInvestments.Rows[0]["investment_Amount"].ToString()) * rate)).ToString();
                        mostRecentInvestor.Id = int.Parse(dtPitchLastInvestments.Rows[0]["investment_userID"].ToString());
                        mostRecentInvestor.InvestmentSince = _pitch.PitchGetPublicDaysLeft(Convert.ToDateTime(dtPitchLastInvestments.Rows[0]["investment_date"].ToString()));
                        if (String.IsNullOrEmpty(dtPitchLastInvestments.Rows[0]["user_Pic"].ToString()) || !System.IO.File.Exists(_configuration.GetValue<string>("AttachementsEnvironmentURL") + "User/thumbs/thumb_" + dtPitchLastInvestments.Rows[0]["user_Pic"].ToString()))
                            mostRecentInvestor.UserImage = _configuration.GetValue<string>("EnvironmentURL") + "images/v2/Default.jpg";
                        else
                            mostRecentInvestor.UserImage = _configuration.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dtPitchLastInvestments.Rows[0]["user_Pic"].ToString();

                    }

                    Investor leadInvestor = new Investor();

                    DataTable dtPitchleadInvestment = _pitch.PitchGetLeadInvestment(int.Parse(dtPitchDetails.Rows[0]["Pitch_ID"].ToString()), langId, currencyId);
                    if (dtPitchleadInvestment.Rows.Count > 0)
                    {
                        leadInvestor.Id = int.Parse(dtPitchLastInvestments.Rows[0]["investment_userID"].ToString());
                        leadInvestor.InvestmentAmount = string.Format("{0:n0}", (float.Parse(dtPitchleadInvestment.Rows[0]["investment_Amount"].ToString()))).ToString();
                        leadInvestor.username = dtPitchleadInvestment.Rows[0]["user_FirstName"].ToString() + " " + dtPitchleadInvestment.Rows[0]["user_LastName"].ToString();
                        if (String.IsNullOrEmpty(dtPitchleadInvestment.Rows[0]["user_Pic"].ToString()) || !System.IO.File.Exists(_configuration.GetValue<string>("AttachementsEnvironmentURL") + "User/thumbs/thumb_" + dtPitchleadInvestment.Rows[0]["user_Pic"].ToString()))
                            leadInvestor.UserImage = _configuration.GetValue<string>("EnvironmentURL") + "images/v2/Default.jpg";
                        else
                            leadInvestor.UserImage = _configuration.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dtPitchLastInvestments.Rows[0]["user_Pic"].ToString();
                    }



                    #region Check Pitch Status

                    if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "completed" || (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dtPitchDetails.Rows[0]["Pitch_Balance"].ToString()) == float.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentRequired"].ToString()))))
                        SMEPproposalInfo.ProposalStatusTxt = _stringLocalizer["Funded"].Value;// "Closed: 100% Funded";

                    else if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "Overfunded" || (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dtPitchDetails.Rows[0]["Pitch_Balance"].ToString()) > float.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentRequired"].ToString()))))
                        SMEPproposalInfo.ProposalStatusTxt = _stringLocalizer["OverFunded"].Value; //"Over Funded ";

                    else if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "Minimum-Funded" || (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dtPitchDetails.Rows[0]["Pitch_Balance"].ToString()) < float.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentRequired"].ToString()))))
                        SMEPproposalInfo.ProposalStatusTxt = _stringLocalizer["Funded"].Value;//"Funded";

                    else if (bool.Parse(dtPitchDetails.Rows[0]["Pitch_IsExtended"].ToString()))//proposal with published status and has extended
                        SMEPproposalInfo.ProposalStatusTxt = _stringLocalizer["ExtraTime"].Value;//"Extended";

                    else if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "Overfunding")
                        SMEPproposalInfo.ProposalStatusTxt = _stringLocalizer["OverFunding"].Value; //"Over Funding";

                    SMEPproposalInfo.ProposalStatus = _pitch.PitchGetStatusNumber(dtPitchDetails.Rows[0]["Pitch_Status"].ToString());

                    #endregion


                    SMEPproposalInfo.MostRecentInvestor = mostRecentInvestor;
                    SMEPproposalInfo.LeadInvestor = leadInvestor;
                    proposalStatus.Proposal = SMEPproposalInfo;


                }
                else
                {
                    SMEPproposalInfo.ProposalStatus = (int)PitchStatus.NotReady;
                    return await Task.FromResult(Ok(new { code = 200, success = true, SMEProposal }));

                }


                SMEProposal.ProposalStatus = proposalStatus;
                return await Task.FromResult(Ok(new { code = 200, success = true, SMEProposal }));
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpPost]
        public async Task<ActionResult<PendingInvestmentsPercentageModel>> UserGetPendingInvestmentsPercentage(UserPendingInvestmentsPercentageRequestModel userPendingInvestmentsPercentageRequestModel)
        {
            try
            {
                int loggedInUserId = int.Parse(_userId);
                int recordCount = 0;
                bool hasMore = false;

                DataTable dtPendingInvestmentsPercentage = _investment.InvestmentGetPendingInvestmentsPercentage(loggedInUserId, userPendingInvestmentsPercentageRequestModel.PitchLanguageId, userPendingInvestmentsPercentageRequestModel.PageNo, userPendingInvestmentsPercentageRequestModel.PageSize, out recordCount);
                hasMore = recordCount > ((userPendingInvestmentsPercentageRequestModel.PageNo + 1) * userPendingInvestmentsPercentageRequestModel.PageSize);

                List<PendingInvestmentsPercentage> pendingInvestmentsPercentageList = new List<PendingInvestmentsPercentage>();

                foreach (DataRow dr in dtPendingInvestmentsPercentage.Rows)
                {
                    PendingInvestmentsPercentage pendingInvestmentsPercentage = new PendingInvestmentsPercentage();

                    pendingInvestmentsPercentage.PitchID = int.Parse(dr["Pitch_ID"].ToString());
                    pendingInvestmentsPercentage.PitchClosingDate = dr["Pitch_ClosingDate"].ToString();
                    pendingInvestmentsPercentage.InvestmentPercentage = dr["Investment_Percentage"].ToString();
                    pendingInvestmentsPercentage.ProfilePitchTitle = dr["Profile_PitchTitle"].ToString();
                    pendingInvestmentsPercentageList.Add(pendingInvestmentsPercentage);
                }

                return await Task.FromResult(Ok(new PendingInvestmentsPercentageModel(200, true, recordCount, hasMore, userPendingInvestmentsPercentageRequestModel.PageNo, _investment.InvestmentGetAllTotalUserInvesments(loggedInUserId, userPendingInvestmentsPercentageRequestModel.CurrencyId), pendingInvestmentsPercentageList)));

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet]
        public async Task<ActionResult<PreCommitmentsResponse>> UserGetAllPrecommitments([Required] int userId, [Required] int currencyId, [Required] int langId, [Required] int pageNo, int pageSize = 10)
        {
            try
            {
                double totalPreCommit = 0;
                int totalRows = 0;
                bool hasMore = true;
                string totalPreCommitAmountsFormatted = "0";
                List<PrecommitInvestor> investors = new List<PrecommitInvestor>();
                DataTable dtUserActivePitch = _pitch.PitchGetUserActivePitch(userId);

                if (dtUserActivePitch.Rows.Count == 0)
                    return await Task.FromResult(Ok(new PreCommitmentsResponse(200, true, totalPreCommitAmountsFormatted, totalRows, false, pageNo, investors)));

                DataTable dtPrecommits = _pitch.PitchGetAllPendingPreInvestmentsPaging(int.Parse(dtUserActivePitch.Rows[0]["Pitch_ID"].ToString()), langId, currencyId, pageNo, pageSize, out totalRows);

                if (dtPrecommits.Rows.Count == 0)
                    return await Task.FromResult(Ok(new PreCommitmentsResponse(200, true, totalPreCommitAmountsFormatted, totalRows, false, pageNo, investors)));

                hasMore = totalRows > ((pageNo + 1) * pageSize);

                foreach (DataRow dr in dtPrecommits.Rows)
                {
                    PrecommitInvestor proposalInvestor = new PrecommitInvestor();

                    proposalInvestor.UserID = int.Parse(dr["User_ID"].ToString());
                    proposalInvestor.User_UserName = dr["User_Username"].ToString();
                    proposalInvestor.ProfileFirstName = dr["Profile_FirstName"].ToString();
                    proposalInvestor.ProfileLastName = dr["Profile_LastName"].ToString();
                    proposalInvestor.Investment_Amount = double.Parse(dr["PreComInvestment_Amount"].ToString());

                    if (langId == (int)Languages.Arabic)
                        proposalInvestor.InvestmentAmountConverted = double.Parse(dr["PreComInvestment_Amount"].ToString()).ToString("#,##0") + dtPrecommits.Rows[0]["Currency_Symbol"].ToString();
                    else
                        proposalInvestor.InvestmentAmountConverted = dtPrecommits.Rows[0]["Currency_Symbol"].ToString() + double.Parse(dr["PreComInvestment_Amount"].ToString()).ToString("#,##0");


                    if (String.IsNullOrEmpty(dr["User_Picture"].ToString()) || !System.IO.File.Exists(Path.Combine(_configuration.GetValue<string>("AttachmentPath") + "User/thumbs/thumb_" + dr["User_Picture"].ToString())))
                        proposalInvestor.UserImage = _configuration.GetValue<string>("EnvironmentURL") + "/images/v2/Default.jpg";
                    else
                        proposalInvestor.UserImage = _configuration.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dr["User_Picture"].ToString();


                    totalPreCommit = !string.IsNullOrEmpty(dr["TotalPreComAmounts"].ToString()) ? double.Parse(dr["TotalPreComAmounts"].ToString()) : 0;
                    proposalInvestor.ProfileObject = dr["Profile_Object"].ToString();

                    int userConnectionId = _user.UserGetUserConnectionId(userId.ToString(), dr["User_ID"].ToString());
                    proposalInvestor.CanFollow = true;
                    if (dr["User_ID"].ToString() == userId.ToString())
                        proposalInvestor.CanFollow = false;

                    if (userConnectionId > 0)
                        proposalInvestor.IsFollowed = true;

                    investors.Add(proposalInvestor);

                }
                if (langId == (int)Languages.Arabic)
                    totalPreCommitAmountsFormatted = totalPreCommit.ToString("#,##0") + dtPrecommits.Rows[0]["Currency_Symbol"].ToString();
                else
                    totalPreCommitAmountsFormatted = dtPrecommits.Rows[0]["Currency_Symbol"].ToString() + totalPreCommit.ToString("#,##0");


                return await Task.FromResult(Ok(new PreCommitmentsResponse(200, true, totalPreCommitAmountsFormatted, totalRows, hasMore, pageNo, investors)));


            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        public async Task<ActionResult<List<UserInvestedProposalModel>>> UserGetNotRefundedInvestments(UserNotRefundedInvestmentsRequestModel userNotRefundedInvestmentsRequestModel)
        {
            try
            {
                int loggedInUserId = int.Parse(_userId);
                int recordCount = 0;
                bool hasMore = false;

                DataTable dtPendingInvestmentsPercentage = _user.UserGetNotRefundedInvestments(loggedInUserId, userNotRefundedInvestmentsRequestModel.PitchLanguageId, userNotRefundedInvestmentsRequestModel.mode, userNotRefundedInvestmentsRequestModel.PageNo, userNotRefundedInvestmentsRequestModel.PageSize, out recordCount);
                hasMore = recordCount > ((userNotRefundedInvestmentsRequestModel.PageNo + 1) * userNotRefundedInvestmentsRequestModel.PageSize);


                List<UserInvestedProposalModel> userInvestedProposalsList = new List<UserInvestedProposalModel>();

                foreach (DataRow dr in dtPendingInvestmentsPercentage.Rows)
                {
                    UserInvestedProposalModel userInvestedProposal = new UserInvestedProposalModel();

                    userInvestedProposal.PitchID = int.Parse(dr["Pitch_ID"].ToString());
                    userInvestedProposal.PitchClosingDate = dr["Pitch_ClosingDate"].ToString();
                    userInvestedProposal.ProfilePitchTitle = dr["Profile_PitchTitle"].ToString();
                    userInvestedProposal.SoFarPercentage = Math.Floor(float.Parse(dr["Pitch_InvestedSoFar"].ToString()));
                    userInvestedProposal.PitchInvestors = int.Parse(dr["Pitch_Investors"].ToString()).ToString("#,##0");

                    double rate = _pitch.PitchGetPitchRateAsDouble(int.Parse(dr["Pitch_ID"].ToString()), userNotRefundedInvestmentsRequestModel.CurrencyId);
                    userInvestedProposal.PitchBalance = (float.Parse(dr["Pitch_Balance"].ToString()) * rate).ToString("#,##0");
                    userInvestedProposal.PitchFollowers = int.Parse(dr["Pitch_Followers"].ToString()).ToString("#,##0");

                    DataTable DTGetFollowedPitchesRemindMints = _user.UserGetPitchRemindMints(int.Parse(dr["Pitch_ID"].ToString()));

                    double timeParts = double.Parse(DTGetFollowedPitchesRemindMints.Rows[0]["RemindMint"].ToString());

                    userInvestedProposal.IsClosed = timeParts <= 0;
                    userInvestedProposal.PitchBalanceStatus = timeParts <= 0 ? _stringLocalizer["Raised"].Value : _stringLocalizer["RaisedSoFar"].Value;

                    if ((dr["Pitch_Status"].ToString() == "Overfunding" || dr["Pitch_Status"].ToString() == "published") && bool.Parse(dr["Pitch_IsExtended"].ToString()))
                        userInvestedProposal.HasExtraTime = true;
                    else
                    {
                        if (timeParts > 0 && timeParts < 60)
                        {
                            userInvestedProposal.RemainingTime = (int)Math.Ceiling((decimal)timeParts);

                            if ((int)Math.Ceiling((decimal)timeParts) == 1)
                                userInvestedProposal.RemainingTimeUnit = _stringLocalizer["MinitLeft"].Value;
                            else
                                userInvestedProposal.RemainingTimeUnit = _stringLocalizer["MinitsLeft"].Value;
                        }
                        else if (timeParts >= 60 && timeParts < 2880)
                        {
                            userInvestedProposal.RemainingTime = (int)Math.Ceiling((decimal)timeParts / 60);

                            if ((int)Math.Ceiling((decimal)timeParts / 60) == 1)
                                userInvestedProposal.RemainingTimeUnit = _stringLocalizer["HourLeft"].Value;
                            else
                                userInvestedProposal.RemainingTimeUnit = _stringLocalizer["HoursLeft"].Value;
                        }
                        else
                        {
                            userInvestedProposal.RemainingTime = (int)Math.Ceiling((decimal)timeParts / 60 / 24);

                            if ((int)Math.Ceiling((decimal)timeParts / 60 / 24) == 1)
                                userInvestedProposal.RemainingTimeUnit = _stringLocalizer["DayLeft"].Value;
                            else
                                userInvestedProposal.RemainingTimeUnit = _stringLocalizer["DaysLeft"].Value;
                        }

                    }

                    if (dr["Pitch_Status"].ToString() == "completed" || (dr["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dr["Pitch_Balance"].ToString()) == float.Parse(dr["Pitch_InvestmentRequired"].ToString()))))
                        userInvestedProposal.SoFarStatus = _stringLocalizer["RaisedFunded"].Value;
                    else if (dr["Pitch_Status"].ToString() == "Overfunding")
                    {
                        if (bool.Parse(dr["Pitch_IsExtended"].ToString()))
                            userInvestedProposal.SoFarStatus = _stringLocalizer["RaisedSoFar"].Value;
                        else
                            userInvestedProposal.SoFarStatus = _stringLocalizer["RaisedSoFar"].Value;
                    }
                    else if (dr["Pitch_Status"].ToString() == "Overfunded" || (dr["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dr["Pitch_Balance"].ToString()) > float.Parse(dr["Pitch_InvestmentRequired"].ToString()))))
                        userInvestedProposal.SoFarStatus = _stringLocalizer["RaisedFunded"].Value;
                    else if (dr["Pitch_Status"].ToString() == "Minimum-Funded" || (dr["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dr["Pitch_Balance"].ToString()) < float.Parse(dr["Pitch_InvestmentRequired"].ToString()))))
                        userInvestedProposal.SoFarStatus = _stringLocalizer["MinimumReached"].Value;
                    else
                    {
                        if (bool.Parse(dr["Pitch_IsExtended"].ToString()))
                            userInvestedProposal.SoFarStatus = _stringLocalizer["RaisedSoFar"].Value;
                        else
                            userInvestedProposal.SoFarStatus = _stringLocalizer["RaisedSoFar"].Value;
                    }

                    DataTable DTLeadForInvestments = _pitch.PitchGetLeadInvestment(int.Parse(dr["Pitch_ID"].ToString()), userNotRefundedInvestmentsRequestModel.PitchLanguageId, userNotRefundedInvestmentsRequestModel.CurrencyId);

                    if (DTLeadForInvestments.Rows.Count > 0)
                    {
                        LeadInvestor leadInvestor = new LeadInvestor();

                        if (String.IsNullOrEmpty(DTLeadForInvestments.Rows[0]["user_Pic"].ToString()) || !System.IO.File.Exists(_configuration.GetValue<string>("AttachementsEnvironmentURL") + "User/thumbs/thumb_" + DTLeadForInvestments.Rows[0]["user_Pic"].ToString()))
                            leadInvestor.Image = _configuration.GetValue<string>("EnvironmentURL") + "images/v2/Default.jpg";
                        else
                            leadInvestor.Image = _configuration.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + DTLeadForInvestments.Rows[0]["user_Pic"].ToString();

                        leadInvestor.Name = DTLeadForInvestments.Rows[0]["user_FirstName"].ToString() + " " + DTLeadForInvestments.Rows[0]["user_LastName"].ToString();
                        leadInvestor.InvestmentAmount = float.Parse(DTLeadForInvestments.Rows[0]["Investment_Amount"].ToString()).ToString("#,##0");
                        leadInvestor.URL = _configuration.GetValue<string>("EnvironmentURL") + "Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + DTLeadForInvestments.Rows[0]["Investment_UserID"].ToString();

                        userInvestedProposal.LeadInvestor = leadInvestor;
                    }

                    userInvestedProposalsList.Add(userInvestedProposal);
                }

                return await Task.FromResult(Ok(new UserNotRefundedInvestmentsResponseModel(200, true, recordCount, hasMore, userNotRefundedInvestmentsRequestModel.PageNo, userInvestedProposalsList)));
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet]
        public async Task<ActionResult<List<UserPrecommittedProposalModel>>> UserGetAllUserPreCommitments([Required] int userId, [Required] int preComInvestmentStatus, [Required] int languageId, [Required] int currencyId)
        {
            try
            {
                List<UserPrecommittedProposalModel> userPrecommittedProposalsList = new List<UserPrecommittedProposalModel>();
                DataTable dtUserPreCommitments = _investment.InvestmentGetAllUserPreCommitments(userId, preComInvestmentStatus, languageId, currencyId);
                dtUserPreCommitments.Columns.Add(new DataColumn("PreCommitment_Status_Str", typeof(string)));
                dtUserPreCommitments.AcceptChanges();

                foreach (DataRow dr in dtUserPreCommitments.Rows)
                {
                    UserPrecommittedProposalModel userPrecommittedProposal = new UserPrecommittedProposalModel();

                    if (dr["PreComInvestment_Status"].ToString() == "0")
                        dr["PreCommitment_Status_Str"] = _stringLocalizer["PendingPrecommit"].Value;
                    else if (dr["PreComInvestment_Status"].ToString() == "1")
                        dr["PreCommitment_Status_Str"] = _stringLocalizer["AcceptedPrecommit"].Value;
                    else if (dr["PreComInvestment_Status"].ToString() == "2")
                        dr["PreCommitment_Status_Str"] = _stringLocalizer["RejectedPrecommit"].Value;

                    userPrecommittedProposal.ProfilePitchTitle = dr["Profile_PitchTitle"].ToString();
                    userPrecommittedProposal.PreComInvestmentStatus = dr["PreCommitment_Status_Str"].ToString();
                    userPrecommittedProposal.PreComInvestmentAmount = int.Parse(dr["PreComInvestment_Amount"].ToString()).ToString("#,##0");

                    userPrecommittedProposalsList.Add(userPrecommittedProposal);
                }

                return Ok(new { code = 200, success = true, userPrecommittedProposalsList });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet]
        public async Task<ActionResult<UserCommunityModel>> UserGetUserCommunity([Required] int userId, bool? getFollowers, bool? getFollowing, bool? getContacts, bool? getMembersToFollow, [Required] int languageId, int pageNo = 1, int pageSize = 10)
        {
            try
            {
                UserCommunityModel userCommunity = new UserCommunityModel();

                if (getFollowers != null && getFollowers == true)
                {
                    List<UserCommunityFollower> userCommunityFollowersList = new List<UserCommunityFollower>();
                    DataTable dtUserFollowers = _user.UserGetAllFollowersByPage(userId, languageId, pageNo, pageSize);

                    foreach (DataRow dr in dtUserFollowers.Rows)
                    {
                        UserCommunityFollower userCommunityFollower = new UserCommunityFollower();

                        userCommunityFollower.RowNumber = int.Parse(dr["RowNumber"].ToString());
                        userCommunityFollower.UserConnectionID = int.Parse(dr["UserConnection_ID"].ToString());
                        userCommunityFollower.Username = dr["NUser_Username"].ToString();

                        if (String.IsNullOrEmpty(dr["User_Picture"].ToString()) || !System.IO.File.Exists(Path.Combine(_configuration.GetValue<string>("AttachmentPath") + "User/thumbs/thumb_" + dr["User_Picture"].ToString())))
                            userCommunityFollower.UserPicture = _configuration.GetValue<string>("EnvironmentURL") + "images/v2/Default.jpg";
                        else
                            userCommunityFollower.UserPicture = _configuration.GetValue<string>("AttachementsEnvironmentURL") + "User/thumbs/thumb_" + dr["User_Picture"].ToString();

                        userCommunityFollower.UserID = int.Parse(dr["User_ID"].ToString());
                        userCommunityFollower.CanFollow = int.Parse(dr["UserConnection_ID"].ToString()) == 0;
                        userCommunityFollower.ProfileObject = dr["Profile_Object"].ToString();

                        if (dr["Profile_Object"] != null && dr["Profile_Object"].ToString() != "Regular Member")
                            userCommunityFollower.ProfileObject = dr["Profile_Object"].ToString();
                        else
                            userCommunityFollower.ProfileObject = _stringLocalizer["RegularUser"].Value;

                        userCommunityFollowersList.Add(userCommunityFollower);
                    }

                    userCommunity.UserCommunityFollowers = userCommunityFollowersList;
                }

                if (getFollowing != null && getFollowing == true)
                {
                    List<UserCommunityFollowing> userCommunityFollowingList = new List<UserCommunityFollowing>();

                    int tempFollowsCount = 0;
                    DataTable dtUserFollows = _user.UserGetAllUserFollowingByPage(userId, languageId, pageNo, pageSize, out tempFollowsCount);

                    foreach (DataRow dr in dtUserFollows.Rows)
                    {
                        UserCommunityFollowing userCommunityFollowing = new UserCommunityFollowing();

                        userCommunityFollowing.RowNumber = int.Parse(dr["RowNumber"].ToString());
                        userCommunityFollowing.UserConnectionID = int.Parse(dr["UserConnection_ID"].ToString());
                        userCommunityFollowing.Username = dr["NUser_Username"].ToString();

                        if (String.IsNullOrEmpty(dr["User_Picture"].ToString()) || !System.IO.File.Exists(Path.Combine(_configuration.GetValue<string>("AttachmentPath") + "User/thumbs/thumb_" + dr["User_Picture"].ToString())))
                            userCommunityFollowing.UserPicture = _configuration.GetValue<string>("EnvironmentURL") + "images/v2/Default.jpg";
                        else
                            userCommunityFollowing.UserPicture = _configuration.GetValue<string>("AttachementsEnvironmentURL") + "User/thumbs/thumb_" + dr["User_Picture"].ToString();

                        userCommunityFollowing.UserID = int.Parse(dr["User_ID"].ToString());
                        userCommunityFollowing.CanFollow = int.Parse(dr["UserConnection_ID"].ToString()) == 0;
                        userCommunityFollowing.ProfileObject = dr["Profile_Object"].ToString();

                        if (dr["Profile_Object"] != null && dr["Profile_Object"].ToString() != "Regular Member")
                            userCommunityFollowing.ProfileObject = dr["Profile_Object"].ToString();
                        else
                            userCommunityFollowing.ProfileObject = _stringLocalizer["RegularUser"].Value;

                        userCommunityFollowingList.Add(userCommunityFollowing);
                    }

                    userCommunity.UserCommunityFollowings = userCommunityFollowingList;
                }

                if (getContacts != null && getContacts == true)
                {
                    List<UserCommunityContact> userCommunityContactsList = new List<UserCommunityContact>();
                    DataTable dtUserContacts = _user.UserGetAllContactsByPage(userId, languageId, pageNo, pageSize);

                    foreach (DataRow dr in dtUserContacts.Rows)
                    {
                        UserCommunityContact userCommunityContact = new UserCommunityContact();

                        userCommunityContact.RowNumber = int.Parse(dr["RowNumber"].ToString());
                        userCommunityContact.Username = dr["NUser_Username"].ToString();

                        if (String.IsNullOrEmpty(dr["User_Picture"].ToString()) || !System.IO.File.Exists(Path.Combine(_configuration.GetValue<string>("AttachmentPath") + "User/thumbs/thumb_" + dr["User_Picture"].ToString())))
                            userCommunityContact.UserPicture = _configuration.GetValue<string>("EnvironmentURL") + "images/v2/Default.jpg";
                        else
                            userCommunityContact.UserPicture = _configuration.GetValue<string>("AttachementsEnvironmentURL") + "User/thumbs/thumb_" + dr["User_Picture"].ToString();

                        userCommunityContact.UserID = int.Parse(dr["User_ID"].ToString());
                        userCommunityContact.ProfileObject = dr["Profile_Object"].ToString();

                        if (dr["Profile_Object"] != null && dr["Profile_Object"].ToString() != "Regular Member")
                            userCommunityContact.ProfileObject = dr["Profile_Object"].ToString();
                        else
                            userCommunityContact.ProfileObject = _stringLocalizer["RegularUser"].Value;

                        userCommunityContactsList.Add(userCommunityContact);
                    }

                    userCommunity.UserCommunityContacts = userCommunityContactsList;
                }

                if (getMembersToFollow != null && getMembersToFollow == true)
                {
                    List<UserCommunityMemberToFollow> userCommunityMembersToFollowList = new List<UserCommunityMemberToFollow>();
                    DataTable dtMembersToFollow = _user.UserGetMembersToFollow(userId, languageId, pageNo, pageSize);

                    foreach (DataRow dr in dtMembersToFollow.Rows)
                    {
                        UserCommunityMemberToFollow userCommunityMemberToFollow = new UserCommunityMemberToFollow();

                        userCommunityMemberToFollow.RowNumber = int.Parse(dr["RowNumber"].ToString());
                        userCommunityMemberToFollow.Username = dr["NUser_Username"].ToString();

                        if (String.IsNullOrEmpty(dr["User_Picture"].ToString()) || !System.IO.File.Exists(Path.Combine(_configuration.GetValue<string>("AttachmentPath") + "User/thumbs/thumb_" + dr["User_Picture"].ToString())))
                            userCommunityMemberToFollow.UserPicture = _configuration.GetValue<string>("EnvironmentURL") + "images/v2/Default.jpg";
                        else
                            userCommunityMemberToFollow.UserPicture = _configuration.GetValue<string>("AttachementsEnvironmentURL") + "User/thumbs/thumb_" + dr["User_Picture"].ToString();

                        userCommunityMemberToFollow.UserID = int.Parse(dr["User_ID"].ToString());
                        userCommunityMemberToFollow.ProfileObject = dr["Profile_Object"].ToString();

                        if (dr["Profile_Object"] != null && dr["Profile_Object"].ToString() != "Regular Member")
                            userCommunityMemberToFollow.ProfileObject = dr["Profile_Object"].ToString();
                        else
                            userCommunityMemberToFollow.ProfileObject = _stringLocalizer["RegularUser"].Value;

                        userCommunityMembersToFollowList.Add(userCommunityMemberToFollow);
                    }

                    userCommunity.UserCommunityMembersToFollow = userCommunityMembersToFollowList;
                }

                return Ok(new { code = 200, success = true, userCommunity });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet]
        public async Task<ActionResult<UserCommunityUserData>> UserCommunityGetUserDataByID([Required] int currentUserId, [Required] int destinationUserId, [Required] int languageId)
        {
            try
            {
                UserCommunityUserData userCommunityUserData = new UserCommunityUserData();
                DataTable dtUserData = _user.UserCommunityGetUserDataByID(currentUserId, destinationUserId, languageId);
                DataTable dtUserObject = _userObjects.UserObjectsGetUserEnrollmentsByLang(destinationUserId, languageId, (int)ObjectsGroups.Badges);

                if (dtUserData.Rows.Count > 0)
                {
                    if (String.IsNullOrEmpty(dtUserData.Rows[0]["User_Picture"].ToString()) || !System.IO.File.Exists(Path.Combine(_configuration.GetValue<string>("AttachmentPath") + "User/thumbs/thumb_" + dtUserData.Rows[0]["User_Picture"].ToString())))
                        userCommunityUserData.UserPicture = _configuration.GetValue<string>("EnvironmentURL") + "images/v2/Default.jpg";
                    else
                        userCommunityUserData.UserPicture = _configuration.GetValue<string>("AttachementsEnvironmentURL") + "User/thumbs/thumb_" + dtUserData.Rows[0]["User_Picture"].ToString();

                    if (dtUserObject.Rows.Count > 0)
                    {
                        userCommunityUserData.ObjectTitle = dtUserObject.Rows[0]["Profile_ObjectTitle"].ToString();
                        userCommunityUserData.ObjectImage = _configuration.GetValue<string>("EnvironmentURL") + dtUserObject.Rows[0]["Master_ImageUrlBig"].ToString();
                    }
                    else
                    {
                        userCommunityUserData.ObjectTitle = _stringLocalizer["MyCommunityRegularMember"].Value;
                        userCommunityUserData.ObjectImage = _configuration.GetValue<string>("AssetsEnvironmentURL") + "images/badge_Regular.png";
                    }

                    if (_user.UserGetTotalFollowersCount(destinationUserId) > 200)
                    {
                        userCommunityUserData.IsExpert = true;
                        userCommunityUserData.ExpertTitle = _stringLocalizer["MyCommunityExpert"].Value;
                        userCommunityUserData.ExpertImage = _configuration.GetValue<string>("AssetsEnvironmentURL") + "images/circle-arrowsup.png";
                    }
                    else
                    {
                        userCommunityUserData.IsExpert = false;
                        userCommunityUserData.ExpertTitle = "";
                        userCommunityUserData.ExpertImage = "";
                    }

                    userCommunityUserData.UserType = _user.UserGetUserTypeName(int.Parse(dtUserData.Rows[0]["User_UserType"].ToString()), int.Parse(dtUserData.Rows[0]["User_InvestorType"].ToString()), languageId);
                    userCommunityUserData.Username = dtUserData.Rows[0]["User_Username"].ToString();
                    userCommunityUserData.CanFollow = int.Parse(dtUserData.Rows[0]["UserConnection_ID"].ToString()) == 0;
                    userCommunityUserData.CountryCode = dtUserData.Rows[0]["CountryCode"].ToString();
                    userCommunityUserData.CountryName = dtUserData.Rows[0]["CountryName"].ToString();
                    userCommunityUserData.FollowersCount = int.Parse(dtUserData.Rows[0]["FollowersCount"].ToString());
                    userCommunityUserData.FollowingCount = int.Parse(dtUserData.Rows[0]["FollowingCount"].ToString());
                }

                return Ok(new { code = 200, success = true, userCommunityUserData });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet]
        public async Task<ActionResult<UserInvestorPortfolioModel>> UserGetPortfolio([Required] int userId, bool? getInvestmentsPercentPerCategory, bool? getInvestmentsPercentPerProposal, bool? getInvestmentPercentsPerStatus, int? languageId, int? currencyId)
        {
            try
            {
                UserInvestorPortfolioModel userInvestorPortfolioModel = new UserInvestorPortfolioModel();

                if (getInvestmentsPercentPerCategory != null && getInvestmentsPercentPerCategory == true)
                {
                    List<InvestmentPercentPerCategory> investmentPercentsPerCategoryList = new List<InvestmentPercentPerCategory>();
                    DataTable dtInvestments = _investment.InvestmentGetInvestmentsSectors(userId, languageId.Value);

                    foreach (DataRow dr in dtInvestments.Rows)
                    {
                        InvestmentPercentPerCategory investmentPercentPerCategory = new InvestmentPercentPerCategory();

                        investmentPercentPerCategory.CategoryName = dr["Category_Name"].ToString();
                        investmentPercentPerCategory.SectorPercent = dr["Sector_Percent"].ToString();

                        investmentPercentsPerCategoryList.Add(investmentPercentPerCategory);
                    }

                    userInvestorPortfolioModel.InvestmentPercentsPerCategory = investmentPercentsPerCategoryList;
                }

                if (getInvestmentsPercentPerProposal != null && getInvestmentsPercentPerProposal == true)
                {
                    List<InvestmentPercentPerProposal> investmentPercentsPerProposalList = new List<InvestmentPercentPerProposal>();
                    DataTable dtInvestments = _investment.InvestmentGetInvestmentsBreakdown(userId, languageId.Value, currencyId.Value);

                    foreach (DataRow dr in dtInvestments.Rows)
                    {
                        userInvestorPortfolioModel.TotalInvestmentsAmount = int.Parse(dr["Total_Investments"].ToString()).ToString("#,##0");
                        InvestmentPercentPerProposal investmentPercentPerProposal = new InvestmentPercentPerProposal();

                        investmentPercentPerProposal.SectorPercent = dr["Sector_Percent"].ToString();
                        investmentPercentPerProposal.InvestmentAmount = int.Parse(dr["Investment_Amount"].ToString());
                        investmentPercentPerProposal.ProfilePitchTitle = dr["Profile_PitchTitle"].ToString();

                        investmentPercentsPerProposalList.Add(investmentPercentPerProposal);
                    }

                    userInvestorPortfolioModel.InvestmentPercentsPerProposal = investmentPercentsPerProposalList;
                }

                if (getInvestmentPercentsPerStatus != null && getInvestmentPercentsPerStatus == true)
                {
                    List<InvestmentPercentPerStatus> investmentPercentsPerStatusList = new List<InvestmentPercentPerStatus>();
                    DataTable dtInvestments = _investment.InvestmentGetInvestmentActiveClosed(userId);

                    int pendingInvestmentsCount = 0;

                    foreach (DataRow dr in dtInvestments.Rows)
                    {
                        InvestmentPercentPerStatus investmentPercentPerStatus = new InvestmentPercentPerStatus();

                        investmentPercentPerStatus.SectorPercent = dr["Sector_Percent"].ToString();
                        investmentPercentPerStatus.InvestmentStatus = dr["Investment_Status"].ToString();
                        investmentPercentPerStatus.ProposalsCount = int.Parse(dr["Sector_Count"].ToString());

                        if (dr["Investment_Status"].ToString() == "pending")
                            pendingInvestmentsCount++;

                        investmentPercentsPerStatusList.Add(investmentPercentPerStatus);
                    }

                    userInvestorPortfolioModel.PendingInvestmentsCount = pendingInvestmentsCount;
                    userInvestorPortfolioModel.InvestmentPercentsPerStatus = investmentPercentsPerStatusList;
                }

                return Ok(new { code = 200, success = true, userInvestorPortfolioModel });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        public async Task<ActionResult<UserBadgeStatsModel>> GetUserBadgeStats(UserBadgeRequest userBadge)
        {
            try
            {
                int userId = int.Parse(_userId);
                UserBadgeStatsModel userBadgeStatsModel = new UserBadgeStatsModel();

                userBadgeStatsModel.ExpertIcon = _configuration.GetValue<string>("AssetsEnvironmentURL") + "images/circle-arrowsup-big.png";
                userBadgeStatsModel.PlatinumIcon = _configuration.GetValue<string>("AssetsEnvironmentURL") + "images/circle-starwhite-68.png";

                if (userBadge.GetExpertStats)
                {
                    int mustHaveFollowers = 200;
                    int totalFollowers = _user.UserGetTotalFollowersCount(userId);

                    userBadgeStatsModel.Current = totalFollowers;
                    userBadgeStatsModel.AmountToBe = mustHaveFollowers;

                    if (totalFollowers <= mustHaveFollowers)
                    {
                        userBadgeStatsModel.Needed = (mustHaveFollowers - totalFollowers).ToString("#,##0");
                        userBadgeStatsModel.Percent = totalFollowers * 100 / mustHaveFollowers;
                    }
                    else if (totalFollowers > mustHaveFollowers)
                    {
                        userBadgeStatsModel.Needed = "0";
                        userBadgeStatsModel.Percent = 100;
                    }
                }
                else if (userBadge.GetPlatinumStats)
                {
                    int mustHaveInvestmentsUSD = 100000;
                    double rate = _general.CurrencyGetGlobalRate((int)userBadge.CurrencyId);
                    int mustInvested = Convert.ToInt32(mustHaveInvestmentsUSD * rate);
                    int totalInvestments = _investment.InvestmentGetAllTotalUserInvesments(userId, (int)userBadge.CurrencyId);

                    userBadgeStatsModel.Current = totalInvestments;
                    userBadgeStatsModel.AmountToBe = mustHaveInvestmentsUSD;

                    if (totalInvestments <= mustInvested)
                    {
                        userBadgeStatsModel.Needed = (mustInvested - totalInvestments).ToString("#,##0");
                        userBadgeStatsModel.Percent = totalInvestments * 100 / mustInvested;
                    }
                    else if (totalInvestments > mustInvested)
                    {
                        userBadgeStatsModel.Needed = "0";
                        userBadgeStatsModel.Percent = 100;
                    }
                }

                return await Task.FromResult(Ok(new { code = 200, success = true, userBadgeStatsModel }));
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        public async Task<ActionResult<GeneralResponseMessage>> FollowUser(FolowUserRequestModel requestModel)
        {
            requestModel.UserId = int.Parse(_userId);
            if (requestModel.UserId <= 0)
                return await Task.FromResult(BadRequest());
            //Follow 
            if (!(_user.UserCheckUserFollow(requestModel.UserId, requestModel.FollowedUserId) > 0))
            {

                if (_user.UserGetTotalFollowersCount(requestModel.FollowedUserId) > 300)
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["MyCommunityFollowExceed"].Value)));

                int loggedInUID = requestModel.UserId;
                _user.UserAddFollower(loggedInUID, requestModel.FollowedUserId);

                _user.UserAddNotification(requestModel.UserId.ToString(), requestModel.FollowedUserId.ToString(), "", NotificationType.FollowMe);
                _message.MessageSendMessageForUserFollowedBy(_user.UserGetSystemAdmin(), _user.UserSelectById(loggedInUID).Rows[0], _user.UserSelectById(requestModel.FollowedUserId).Rows[0]);
                _message.MessageSendMessageForUserFollowers(_user.UserGetSystemAdmin(), _user.UserGetAllUserFollowersForUser(loggedInUID), _user.UserSelectById(loggedInUID).Rows[0], "", 0, _user.UserSelectById(requestModel.FollowedUserId).Rows[0]["User_Username"].ToString(), requestModel.FollowedUserId, UserAction.FollowUser);
                return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, "", _stringLocalizer["FollowedSuccess"].Value)));
            }

            //UnFollow User
            int userConnectionId = _user.UserGetUserConnectionId(requestModel.UserId.ToString(), requestModel.FollowedUserId.ToString());
            if (userConnectionId == 0)
                return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["CouldNotUnFollow"].Value)));

            _user.UserUnfollowUserFollower(userConnectionId.ToString());
            return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, "", _stringLocalizer["UnFollowedSuccess"].Value)));


        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult<UserDetails>> UserGetDetails(GetUserDetails request)
        {
            try
            {

                DataTable dtUserDetails = _user.UserGetDetails(request.UserId, (int)request.LangId);
                bool isProfileOwner = request.LoggedInUserId != 0 && request.LoggedInUserId == request.UserId;

                if (dtUserDetails.Rows.Count > 0 && (_user.UserCheckProfileVisible(request.UserId, (int)request.LangId) || isProfileOwner))
                {

                    int userStatus = int.Parse(dtUserDetails.Rows[0]["User_Status"].ToString());

                    if (userStatus == (int)UserStatus.Canceled)
                        return await Task.FromResult(Ok(new { code = 200, success = false, message = _stringLocalizer["ProfileRemovedAlert"].Value, isLangIssue = false }));


                    if (userStatus == (int)UserStatus.Active)
                    {
                        if (!isProfileOwner && bool.Parse(dtUserDetails.Rows[0]["User_IsProfileHidden"].ToString()))
                            return await Task.FromResult(Ok(new { code = 200, success = false, message = _stringLocalizer["ProfileHiddenAlert"].Value, isLangIssue = false }));


                        UserDetails userDetails = new UserDetails();

                        if (String.IsNullOrEmpty(dtUserDetails.Rows[0]["User_Picture"].ToString()) || !System.IO.File.Exists(_configuration.GetValue<string>("AttachmentPath") + "User/thumbs/thumb_" + dtUserDetails.Rows[0]["User_Picture"].ToString()))
                            userDetails.UserImage = _configuration.GetValue<string>("EnvironmentURL") + "images/v2/Default.jpg";
                        else
                            userDetails.UserImage = _configuration.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dtUserDetails.Rows[0]["User_Picture"].ToString();

                        userDetails.UserId = int.Parse(dtUserDetails.Rows[0]["User_ID"].ToString());
                        userDetails.Username = dtUserDetails.Rows[0]["User_Username"].ToString();
                        userDetails.Email = dtUserDetails.Rows[0]["User_Email"].ToString();
                        userDetails.FirstName = dtUserDetails.Rows[0]["Profile_FirstName"].ToString();
                        userDetails.LastName = dtUserDetails.Rows[0]["Profile_LastName"].ToString();
                        userDetails.Phone = dtUserDetails.Rows[0]["User_Phone"].ToString();
                        userDetails.Street = dtUserDetails.Rows[0]["Profile_StreetAddress"].ToString();
                        userDetails.PostCode = dtUserDetails.Rows[0]["Profile_PostalCode"].ToString();
                        userDetails.CustomForumId = int.Parse(dtUserDetails.Rows[0]["CustomForum_UserID"].ToString());



                        bool publicPorfile = bool.Parse(dtUserDetails.Rows[0]["User_ShowPersonalInfoFlag"].ToString());


                        userDetails.FullName = string.Format("{0} {1}", dtUserDetails.Rows[0]["Profile_FirstName_Custom"].ToString(), dtUserDetails.Rows[0]["Profile_LastName_Custom"].ToString());

                        if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["Profile_City"].ToString()))
                            userDetails.City = dtUserDetails.Rows[0]["Profile_City"].ToString();

                        if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["Profile_State"].ToString()))
                            userDetails.State = dtUserDetails.Rows[0]["Profile_State"].ToString();

                        userDetails.Followers = _user.UserGetTotalFollowersCount(request.UserId);
                        userDetails.Following = _user.UserGetTotalFollowing(request.UserId);
                        userDetails.UserType = _user.UserGetUserTypeName(Int32.Parse(dtUserDetails.Rows[0]["User_UserFormType"].ToString()), int.Parse(dtUserDetails.Rows[0]["User_InvestorType"].ToString()), (int)request.LangId);
                        userDetails.UserTypeId = int.Parse(dtUserDetails.Rows[0]["User_UserFormType"].ToString());

                        if (!String.IsNullOrEmpty(dtUserDetails.Rows[0]["User_Country"].ToString()))
                        {
                            userDetails.CountryId = int.Parse(dtUserDetails.Rows[0]["User_Country"].ToString());
                            DataTable dtUserCountry = _countryBasedControl.CountryBasedGetCountryDetails(int.Parse(dtUserDetails.Rows[0]["User_Country"].ToString()), (int)request.LangId);
                            if (dtUserCountry.Rows.Count > 0)
                                userDetails.Country = dtUserCountry.Rows[0]["Profile_Country_Name"].ToString();
                        }


                        DataTable dTObject = _user.UserGetUserEnrollmentsByLang(Convert.ToInt32(request.UserId), (int)request.LangId, (int)ObjectsGroups.Badges);
                        if (dTObject.Rows.Count > 0)
                        {
                            userDetails.BadgeName = dTObject.Rows[0]["Profile_ObjectTitle"].ToString();
                            userDetails.BadgeImage = _configuration.GetValue<string>("EnvironmentURL") + dTObject.Rows[0]["Master_ImageUrlBig"].ToString();
                        }
                        else
                        {
                            userDetails.BadgeName = _stringLocalizer["RegularUser"].Value;
                            userDetails.BadgeImage = _configuration.GetValue<string>("AssetsEnvironmentURL") + "images/badge_Regular.png";
                        }


                        userDetails.IsExpert = _user.UserIsExpert(request.UserId);
                        userDetails.ExpertImage = _configuration.GetValue<string>("AssetsEnvironmentURL") + "images/circle-arrowsup.png";


                        int userConnectionId = _user.UserGetUserConnectionId(request.LoggedInUserId.ToString(), request.UserId.ToString());
                        userDetails.CanFollow = request.LoggedInUserId != request.UserId;


                        if (userConnectionId > 0)
                            userDetails.IsFollowed = true;

                        userDetails.UserConnectionId = userConnectionId;
                        userDetails.UserProfileSummary = dtUserDetails.Rows[0]["Profile_Summary"].ToString();

                        return await Task.FromResult(Ok(new { code = 200, success = true, userDetails }));

                    }
                }
                else
                {
                    bool englishProfile = _user.UserGetDetails(request.UserId, (int)Languages.English).Rows.Count > 0;
                    bool arabicProfile = _user.UserGetDetails(request.UserId, (int)Languages.Arabic).Rows.Count > 0;
                    bool spanishProfile = _user.UserGetDetails(request.UserId, (int)Languages.Spanish).Rows.Count > 0;
                    bool englishProfileVisable = false;
                    bool arabicProfileVisable = false;
                    bool spanishProfileVisable = false;


                    if (arabicProfile || spanishProfile || englishProfile)
                    {
                        englishProfileVisable = _user.UserCheckProfileVisible(request.UserId, (int)Languages.English);
                        arabicProfileVisable = _user.UserCheckProfileVisible(request.UserId, (int)Languages.Arabic);
                        spanishProfileVisable = _user.UserCheckProfileVisible(request.UserId, (int)Languages.Spanish);

                        List<Language> languages = _general.CONSTGetLanguages();

                        if (!englishProfileVisable)
                        {

                            languages.Remove(languages.Single(x => x.Language_ID == (int)Languages.English));
                        }

                        if (!arabicProfileVisable)
                        {
                            languages.Remove(languages.Single(x => x.Language_ID == (int)Languages.Arabic));
                        }
                        if (!spanishProfileVisable)
                        {
                            languages.Remove(languages.Single(x => x.Language_ID == (int)Languages.Spanish));
                        }
                        return await Task.FromResult(Ok(new { code = 200, success = false, languages, isLangIssue = true }));
                    }

                }

                return await Task.FromResult(Ok(new { code = 200, success = false, message = _stringLocalizer[""].Value, isLangIssue = false }));//Waiting the general message from alaa


            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");

            }
        }

        [HttpPost]
        public async Task<ActionResult> UserUpdatesPersonalDetails([FromForm] PersonalDetailsModel model)
        {
            try
            {
                int userId = int.Parse(_userId);
                DataTable dtUserDetails = _user.UserSelectById(userId);
                string email = dtUserDetails.Rows[0]["User_Email"].ToString();
                string profileSummary = Regex.Replace(model.ProfileSummary, "<.*?>", String.Empty);
                string userPicture = dtUserDetails.Rows[0]["User_Picture"].ToString();
                if (model.Image != null)
                {
                    WriteFileResult result = await WriteFile(model.Image, _configuration.GetValue<string>("AttachmentPath") + "user");
                    userPicture = result.FileName;
                    if (result.IsSaved)
                        _customForumUser.ForumUpdateUserPicture(result.FileName, Int32.Parse(dtUserDetails.Rows[0]["CustomForum_UserID"].ToString()));
                }


                int countryId = int.Parse(dtUserDetails.Rows[0]["User_Country"].ToString()),
                   bankCountryId = int.Parse(dtUserDetails.Rows[0]["User_Country"].ToString()),
                   User_Gender = 0;

                bool HideProfile = bool.Parse(dtUserDetails.Rows[0]["User_IsProfileHidden"].ToString());

                string bankName = dtUserDetails.Rows[0]["Profile_BankName"].ToString();
                string bankAccount = dtUserDetails.Rows[0]["User_AccountNumber"].ToString();
                string userIBAN = dtUserDetails.Rows[0]["User_SwiftIbanNumber"].ToString();
                string bankAddress = dtUserDetails.Rows[0]["Profile_BankAddress"].ToString();

                if (!string.IsNullOrEmpty(dtUserDetails.Rows[0]["User_BankCountry"].ToString()))
                    bankCountryId = int.Parse(dtUserDetails.Rows[0]["User_BankCountry"].ToString());

                DataTable dtEmail = _user.SelectUserByEmail(email);

                //if there is a user who has this email in DB => 3
                if (dtEmail.Rows.Count > 0 && dtEmail.Rows[0]["User_ID"].ToString() != userId.ToString())
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["ExistEmail"].Value });
                else
                {
                    int type = 2;

                    if (model.IsInvestor && !model.IsEntrepreneur)
                        type = (int)UserType.Investor;
                    else if (!model.IsInvestor && model.IsEntrepreneur)
                        type = (int)UserType.Enreprenuer;
                    else if (model.IsInvestor && model.IsEntrepreneur)
                        type = (int)UserType.InvestorAndEnreprenuer;

                    DataTable dtUserEnDetails = _user.UserGetDetails(userId, (int)Languages.English);

                    if (model.LangId == Languages.English || dtUserEnDetails.Rows.Count == 0)
                        _account.AccountEditUserAccount(dtUserDetails.Rows[0]["User_Username"].ToString(), model.FirstName.Trim(), model.LastName.Trim(), userId);

                    _user.UserUpdateUserInfo(userId,
                        int.Parse(dtUserDetails.Rows[0]["CustomForum_UserID"].ToString()),
                        dtUserDetails.Rows[0]["User_Username"].ToString(), dtUserDetails.Rows[0]["User_Username"].ToString(), "",
                        model.FirstName.Trim(), model.LastName.Trim(), User_Gender, 4, type, model.StreetAddress, countryId,
                        model.State, model.City, model.PostalCode, model.Phone, email, bankName, bankAccount,
                        userIBAN, bankAddress, bankCountryId, dtUserDetails.Rows[0]["User_Status"].ToString(),
                        dtUserDetails.Rows[0]["User_DateOFBirth"].ToString(), (int)model.LangId, HideProfile,
                        (int)model.LangId, Regex.Replace(profileSummary, "<.*?>", String.Empty), userPicture);
                    _user.UserupdateLastUpdateDate(userId);

                    return Ok(new { code = 200, success = true, message = _stringLocalizer["UpdatedSuccessfully"].Value });
                }

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpPost]
        public async Task<ActionResult<GeneralResponseMessage>> UserAddContact(AddContact request)
        {
            int userId = int.Parse(_userId);

            if (!_user.UserCheckUsersContact(userId, request.TargetUserId))
            {
                _user.UserAddContact(userId, request.TargetUserId);
                return Ok(new GeneralResponseMessage(200, true, "", _stringLocalizer["MyCommunityContactAddedSuccess"].Value));
            }
            else
                return Ok(new GeneralResponseMessage(200, true, "", _stringLocalizer["MyCommunityContactAddedFailed"].Value));

        }

        [HttpPost]
        public async Task<ActionResult> UserSetProfilePreferredCurrency(ChangePrefferedCurrency model)
        {
            try
            {
                int userId = int.Parse(_userId);
                if (_user.UserSelectById(userId).Rows.Count > 0)
                {
                    DataTable dtCurrency = _general.CurrencyGetCurrencyByID((int)model.CurrencyId);
                    if (dtCurrency.Rows.Count <= 0)
                    {
                        return Ok(new { code = 200, success = false, response = 3, message = _stringLocalizer["InvalidCurrency"].Value });
                    }
                    _user.UserChangePreferredCurrency(dtCurrency.Rows[0]["Currency_App"].ToString(), userId);
                    return Ok(new { code = 200, success = true, response = 1, message = _stringLocalizer["UpdatedSuccessfully"].Value });
                }
                else
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidUserId"].Value });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

    }
}
