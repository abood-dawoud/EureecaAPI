﻿using Microsoft.AspNetCore.Mvc;
using Eureeca_API.Interface;
using Microsoft.AspNetCore.Authorization;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using Eureeca_API.General;
using Microsoft.Extensions.Localization;
using System.Data;
using Newtonsoft.Json;
using Eureeca_API.Models.PitchModels.RequestModel;
using Eureeca_API.Enums;
using Eureeca_API.Models.PitchModels.ViewModels;
using Eureeca_API.Models.PitchModels.Dto;
using Eureeca_API.Models.UserModels.ViewModesl;
using Eureeca_API.Interface.CountryBasedInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Interface.InboxInterface;
using Eureeca_API.Models.GeneralModels.ViewModels;
using System.Security.Cryptography;
using Eureeca_API.Models.UserModels.Dto;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Net.Mail;

namespace Eureeca_API.Controllers
{
    [Route("Api/Pitch/[action]")]
    [ApiController]
    public class PitchController : BaseController
    {
        private readonly IPitch _pitch;
        private readonly IPitchAttachements _pitchAttachementsRepository;
        private readonly IPitchLikeFollower _pitchLikeFollower;
        private readonly IUser _user;
        private readonly IGeneral _general;
        private readonly ITopic _topic;
        private readonly ICustomForumUser _forumUser;
        private readonly IConfiguration _config;
        private readonly IMessage _message;
        private readonly ICountryBasedControl _countryBasedControl;
        private readonly ILead _lead;
        private readonly ErrHandler _errHandler;
        private readonly IStringLocalizer<Resources.PitchController> _stringLocalizer;



        public PitchController(IHttpContextAccessor httpContextAccessor, IPitch pitch, IStringLocalizer<Resources.PitchController> stringLocalizer, IPitchAttachements pitchAttachementsRepository, IPitchLikeFollower pitchLikeFollower, IUser user, IConfiguration config, IGeneral general, ITopic topic, ICustomForumUser forumUser, IMessage message, ICountryBasedControl countryBasedControl, ILead lead) : base(httpContextAccessor)
        {
            _pitch = pitch;
            _pitchAttachementsRepository = pitchAttachementsRepository;
            _pitchLikeFollower = pitchLikeFollower;
            _user = user;
            _config = config;
            _errHandler = new ErrHandler();
            _stringLocalizer = stringLocalizer;
            _general = general;
            _topic = topic;
            _forumUser = forumUser;
            _message = message;
            _countryBasedControl = countryBasedControl;
            _lead = lead;
        }

        [HttpGet]
        public async Task<ActionResult<Pitch>> PitchGetPitchById(Int64 id)
        {
            var response = await Task.FromResult(_pitch.PitchGetPitchById(id));
            if (response == null) { return NotFound(); }
            return response;
        }
        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult<HomePageProposals>> PitchGetHomeProposals([FromQuery]HomePageProposalList requestModel)
        {
            try
            {
             
                Tools.SetThreadCulture((int)requestModel.LangId);
                HomePageProposals homePageProposals = new HomePageProposals();
                DataTable DTHomePageProposals = _pitch.PitchGetHomeLiveProposals((int)requestModel.LangId, (int)requestModel.CurrencyId);
                DTHomePageProposals.Columns.Add(new DataColumn("VideoId", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("WidgetImage", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("Logo", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("SME_firstName", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("SME_lastName", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("ProgressLbl", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("offlineProgressWidth", typeof(int)));
                DTHomePageProposals.Columns.Add(new DataColumn("preRaisedProgressWidth", typeof(int)));
                DTHomePageProposals.Columns.Add(new DataColumn("InstitutionalProgressWidth", typeof(int)));
                DTHomePageProposals.Columns.Add(new DataColumn("progressWidth", typeof(int)));
                DTHomePageProposals.Columns.Add(new DataColumn("viewTooltip", typeof(bool)));
                DTHomePageProposals.Columns.Add(new DataColumn("viewInstitutionalInvestmentNote", typeof(bool)));
                DTHomePageProposals.Columns.Add(new DataColumn("privateToolTip", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("PreRaisedTooltip", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("crowdFundingTooltip", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("InstitutionalInvestmentTooltip", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("InstitutionalInvestmentSoFarNote", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("Badges", typeof(List<Badge>)));
                DTHomePageProposals.Columns.Add(new DataColumn("MinArrowVisiblity", typeof(bool)));
                DTHomePageProposals.Columns.Add(new DataColumn("MinArrowDistance", typeof(int)));
                DTHomePageProposals.Columns.Add(new DataColumn("MinAmountText", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("MinNote", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("isFollowed", typeof(bool)));
                DTHomePageProposals.Columns.Add(new DataColumn("canFollow", typeof(bool)));
                DTHomePageProposals.Columns.Add(new DataColumn("isInvestEnabled", typeof(bool)));
                DTHomePageProposals.Columns.Add(new DataColumn("country_flag", typeof(string)));

                DTHomePageProposals.Columns.Add(new DataColumn("PreMoneyValuation", typeof(double)));
                DTHomePageProposals.Columns.Add(new DataColumn("EquityOffered", typeof(double)));
                DTHomePageProposals.Columns.Add(new DataColumn("HighestInvestment", typeof(double)));
                DTHomePageProposals.Columns.Add(new DataColumn("OverfundingTaget", typeof(double)));

                DTHomePageProposals.Columns.Add(new DataColumn("EarlyAccessCode", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("EarlyAccessMode", typeof(bool)));
                DTHomePageProposals.Columns.Add(new DataColumn("IsBlured", typeof(bool)));
                DTHomePageProposals.Columns.Add(new DataColumn("IsKYCBlured", typeof(bool)));
                DTHomePageProposals.Columns.Add(new DataColumn("IsConfidetnial", typeof(bool)));
                DTHomePageProposals.Columns.Add(new DataColumn("SMEId", typeof(int)));

                DTHomePageProposals.Columns.Add(new DataColumn("Pitch_InvestmentRequiredFormatted", typeof(string)));
                DTHomePageProposals.Columns.Add(new DataColumn("Pitch_BalanceFormatted", typeof(string)));

                if (DTHomePageProposals.Rows.Count > 0)
                {
                    foreach (DataRow dr in DTHomePageProposals.Rows)
                    {
                        int tempout = 0;
                        _pitch.PitchTestExpiration((int)requestModel.LangId, int.Parse(dr["Pitch_ID"].ToString()));
                        DataTable dtCurreny = _general.CurrencyGetCurrencyByID((int)requestModel.CurrencyId);
                        string currencySymbol = dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$";


                        dr["Pitch_InvestmentRequiredFormatted"] = Tools.FormatNumberWithCurrency((int)requestModel.LangId, currencySymbol, double.Parse(dr["Pitch_InvestmentRequired"].ToString()).ToString("#,##0"));
                        dr["Pitch_BalanceFormatted"] = Tools.FormatNumberWithCurrency((int)requestModel.LangId, currencySymbol, double.Parse(dr["Pitch_Balance"].ToString()).ToString("#,##0"));

                        #region badges
                        DataTable dtBadges = _pitch.PitchBadgesAssignedGetAll(1, 100,(int) requestModel.LangId, int.Parse(dr["Pitch_ID"].ToString()), out tempout);
                        List<Badge> badges = new List<Badge>();
                        if (dtBadges.Rows.Count > 0)
                        {
                            badges = JsonConvert.DeserializeObject<List<Badge>>(dtBadges.Rows[0]["Badges"].ToString());
                        }
                        dr["Badges"] = badges;
                        #endregion
                        dr["profile_country_name"] = dr["Profile_PitchCity"].ToString() + (!String.IsNullOrEmpty(dr["Profile_PitchCity"].ToString()) ? ", " : "") + dr["Profile_Country_Name"].ToString();

                        dr["SME_firstName"] = dr["User_FirstName"].ToString();
                        dr["SME_lastName"] = dr["User_LastName"].ToString();
                        dr["SMEId"] = dr["Pitch_UserID"].ToString();

                        dr["PreMoneyValuation"] = !string.IsNullOrEmpty(dr["Pitch_Pre_Money_Val_Converted"].ToString()) ? double.Parse(dr["Pitch_Pre_Money_Val_Converted"].ToString()) : 0;
                        dr["EquityOffered"] = !string.IsNullOrEmpty(dr["Pitch_EquityOffered"].ToString()) ? double.Parse(dr["Pitch_EquityOffered"].ToString()) : 0;
                        dr["HighestInvestment"] = !string.IsNullOrEmpty(dr["MaxInvAmount"].ToString()) ? double.Parse(dr["MaxInvAmount"].ToString()) : 0;
                        dr["OverfundingTaget"] = !string.IsNullOrEmpty(dr["OverSubAmount"].ToString()) ? double.Parse(dr["OverSubAmount"].ToString()) : 0;

                        dr["EarlyAccessCode"] = dr["Pitch_AccessCode"].ToString();
                        dr["EarlyAccessMode"] = Convert.ToBoolean(int.Parse(dr["Pitch_EarlyAccess_Access_Mode"].ToString()));
                        dr["IsConfidetnial"] = bool.Parse(dr["Pitch_IsOpaque"].ToString());
                        
                        #region Proposal widget Image
                        dr["WidgetImage"] = "";
                        if (!string.IsNullOrEmpty(dr["Profile_PitchWidgetImageID"].ToString().Trim()))
                        {
                            DataTable dtPitchAttachInf = _pitchAttachementsRepository.PitchGetAttachementDetails(Int32.Parse(dr["Profile_PitchWidgetImageID"].ToString()));
                            if (dtPitchAttachInf.Rows.Count > 0)
                            {
                                string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                                if (System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "pitch/thumbs/thumb_" + img)))
                                    dr["WidgetImage"] = _config.GetValue<string>("AttachementsEnvironmentURL") + "pitch/thumbs/thumb_" + img;
                                else
                                    dr["WidgetImage"] = _config.GetValue<string>("EnvironmentURL") + "Images/v2/pitchDefault.jpg";

                            }
                        }
                        #endregion
                        #region Proposal Video 
                        dr["VideoId"] = "";

                        if (!string.IsNullOrEmpty(dr["Profile_PitchMainVideoID"].ToString().Trim()))
                        {
                            DataTable dtPitchAttachInf = _pitchAttachementsRepository.PitchGetAttachementDetails(Int32.Parse(dr["Profile_PitchMainVideoID"].ToString()));
                            if (dtPitchAttachInf.Rows.Count > 0)
                            {
                                string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                                if (System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "pitch/thumbs/thumb_" + img)))
                                    dr["VideoId"] = img;

                            }
                        }
                        #endregion

                        #region Proposal Main Image
                        dr["Logo"] = "";
                        if (!string.IsNullOrEmpty(dr["Profile_PitchMainImageID"].ToString().Trim()))
                        {
                            DataTable dtPitchAttachInf = _pitchAttachementsRepository.PitchGetAttachementDetails(Int32.Parse(dr["Profile_PitchMainImageID"].ToString()));
                            if (dtPitchAttachInf.Rows.Count > 0)
                            {
                                string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                                if (System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "pitch/thumbs/thumb_" + img)))
                                    dr["Logo"] = _config.GetValue<string>("AttachementsEnvironmentURL") + "pitch/thumbs/thumb_" + img;
                                else
                                    dr["Logo"] = _config.GetValue<string>("EnvironmentURL") + "Images/v2/logoDefault.png";
                            }
                        }
                        #endregion


                        #region set progress label
                        if (bool.Parse(dr["Pitch_IsOpaque"].ToString()))
                        {
                            #region Opaque Published

                            dr["ProgressLbl"] = _stringLocalizer["Confidential_Request_access_code_to_view"].Value;

                            #endregion
                        }
                        else
                        {

                            #region Check Pitch Status 
                            dr["ProgressLbl"] = "";
                            if (dr["Pitch_Status"].ToString() == "completed" || (dr["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dr["Pitch_Balance"].ToString()) == float.Parse(dr["Pitch_InvestmentRequired"].ToString()))))
                            {//100% funded and closed
                                dr["Pitch_Status"] = _stringLocalizer["Funded1"].Value;
                                dr["ProgressLbl"] = _stringLocalizer.GetString("Closed1").Value + " " + (Math.Floor(float.Parse(dr["Pitch_InvestedSoFar"].ToString()))).ToString() + " " + _stringLocalizer["FundPercent"].Value;

                            }
                            else if (dr["Pitch_Status"].ToString() == "Overfunding")
                            {
                                if (bool.Parse(dr["Pitch_IsExtended"].ToString()))
                                {
                                    dr["ProgressLbl"] = _stringLocalizer["Overfunding1"].Value + " " + (Math.Floor(float.Parse(dr["Pitch_InvestedSoFar"].ToString()))).ToString() + " " +
                                        _stringLocalizer["raisedpercent"].Value + " - " + _stringLocalizer["Extra_Time"].Value; ;

                                }
                                else
                                {
                                    dr["ProgressLbl"] = _stringLocalizer["Overfunding1"].Value + " " + (Math.Floor(float.Parse(dr["Pitch_InvestedSoFar"].ToString()))).ToString() + _stringLocalizer["raisedpercent"].Value;

                                }
                            }
                            else if (dr["Pitch_Status"].ToString() == "Overfunded" || (dr["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dr["Pitch_Balance"].ToString()) > float.Parse(dr["Pitch_InvestmentRequired"].ToString()))))
                            {
                                dr["ProgressLbl"] = _stringLocalizer.GetString("Closed1").Value + " " + (Math.Floor(float.Parse(dr["Pitch_InvestedSoFar"].ToString()))).ToString() + " " + _stringLocalizer["FundPercent"].Value;
                            }
                            else if (dr["Pitch_Status"].ToString() == "Minimum-Funded" || (dr["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dr["Pitch_Balance"].ToString()) < float.Parse(dr["Pitch_InvestmentRequired"].ToString()))))
                            {
                                if (dr["Pitch_Status"].ToString() == "Minimum-Funded")
                                    dr["ProgressLbl"] = _stringLocalizer["Closed1"].Value + " " + _stringLocalizer["Funded"].Value;
                                else
                                    dr["ProgressLbl"] = _stringLocalizer["Closed1"].Value + " " + "100%" + " " + _stringLocalizer["Funded"].Value;

                                dr["MinArrowVisiblity"] = false;
                            }
                            else
                            {
                                if (bool.Parse(dr["Pitch_IsExtended"].ToString()))//proposal with published status and has extended
                                {
                                    dr["ProgressLbl"] = _stringLocalizer["Progress"].Value + " " + (Math.Floor(float.Parse(dr["Pitch_InvestedSoFar"].ToString()))).ToString() + " " +
                                    _stringLocalizer["raisedpercent"].Value + " - " + _stringLocalizer["Extra_Time"].Value;

                                }
                                else
                                {
                                    dr["ProgressLbl"] = _stringLocalizer["Progress"].Value + " " + (Math.Floor(float.Parse(dr["Pitch_InvestedSoFar"].ToString()))).ToString() + " " +
                                    _stringLocalizer["raisedpercent"].Value;
                                }

                            }
                        }
                        #endregion
                        #endregion
                        #region minimumArrow
                        dr["MinArrowDistance"] = 0;
                        dr["MinNote"] = "";
                        dr["MinAmountText"] = "";
                        if (!string.IsNullOrEmpty(dr["Pitch_HasMinInvestmentRequired"].ToString()) && bool.Parse(dr["Pitch_HasMinInvestmentRequired"].ToString()))
                        {
                            float minNeeded = float.Parse(dr["Pitch_MinInvestmentRequired"].ToString());
                            float needed = float.Parse(dr["Pitch_InvestmentRequired"].ToString());
                            string minNeededLeftMargin = (Math.Ceiling(decimal.Parse(((minNeeded * 100) / needed).ToString()))).ToString();
                            dr["MinArrowDistance"] = minNeededLeftMargin;

                            if (dr["Pitch_Status"].ToString() == "Minimum-Funded" || (dr["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dr["Pitch_Balance"].ToString()) < float.Parse(dr["Pitch_InvestmentRequired"].ToString()))))
                                dr["MinArrowVisiblity"] = false;
                            else
                                dr["MinArrowVisiblity"] = true;

                            double rate = _pitch.PitchGetPitchRateAsDouble(Int32.Parse(dr["Pitch_ID"].ToString()), (int)requestModel.CurrencyId);
                            string minAmount = "";
                            if (requestModel.LangId == Languages.Arabic)
                            {
                                dr["MinAmountText"] = string.Format("{0:n0}", (float.Parse(dr["Pitch_MinInvestmentRequired"].ToString()) * rate)).ToString() + currencySymbol;
                            }
                            else
                            {
                                dr["MinAmountText"] = currencySymbol + string.Format("{0:n0}", (float.Parse(dr["Pitch_MinInvestmentRequired"].ToString()) * rate)).ToString();
                            }
                            dr["minNote"] = _stringLocalizer["Please_note_this_proposal_has_a_minimum_target_of"].Value + minAmount + _stringLocalizer["The_proposal_will_be_marked_as_successful"].Value;

                        }
                        else
                        {
                            dr["MinArrowVisiblity"] = false;
                        }

                        #endregion



                        DataTable DTPitchDetais = _pitch.PitchGetDedicatedPitchDetailsByLang(Int32.Parse(dr["Pitch_ID"].ToString()), (int)requestModel.LangId);
                        if (DTPitchDetais.Rows.Count == 0 && (int)requestModel.LangId != 1)
                        {
                            DTPitchDetais = _pitch.PitchGetDedicatedPitchDetailsByLang(Int32.Parse(dr["Pitch_ID"].ToString()), 1);
                        }

                        if (DTPitchDetais.Rows.Count > 0)
                        {
                            int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Proposal_Widgets_Blur, requestModel.CountryId);
                            if (!string.IsNullOrEmpty(requestModel.UserId) && groupId > 0 && (DTPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Early Access" || DTPitchDetais.Rows[0]["Pitch_Status"].ToString() == "published" || DTPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Overfunding"))
                                dr["IsBlured"] = true;


                            if (!string.IsNullOrEmpty(requestModel.UserId))
                            {
                                DataTable dtUserInfo = _user.UserSelectById(int.Parse(requestModel.UserId));

                                if (dtUserInfo.Rows.Count > 0)
                                {
                                    if (int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.Enreprenuer && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.Admin && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.BIAdmin && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.SystemAdmin)
                                    {
                                        KYCModel kycModel = _user.KYCGetRequiredFiles(int.Parse(requestModel.UserId), requestModel.CountryId);
                                        if (kycModel.KYCOverAllStatus != (int)KYCUserDocsStatus.Accepted && groupId > 0 && (DTPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Early Access" || DTPitchDetais.Rows[0]["Pitch_Status"].ToString() == "published" || DTPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Overfunding"))
                                            dr["IsKYCBlured"] = true;

                                    }
                                }

                            }




                            if (requestModel.LangId == Languages.Arabic && int.Parse(DTPitchDetais.Rows[0]["Profile_LanguageID"].ToString()) == (int)Languages.English)
                            {
                                dr["Profile_PitchTitle"] = DTPitchDetais.Rows[0]["Pitch_Admin_Arabic_Title"];
                                dr["Profile_PitchShortSummary"] = "هذه الشركة متاحة باللغة الإنجليزية فقط، إضغط على عرض الشركة لعرض صفحة الشركة باللغة الإنجليزية";
                            }
                            dr["country_flag"] = _config.GetValue<string>("AssetsEnvironmentURL") + "circle_flags/" + DTPitchDetais.Rows[0]["Country_Flag_URL"].ToString();

                            #region progress values
                            decimal pitchInvestedSoFar = decimal.Parse(DTPitchDetais.Rows[0]["Pitch_InvestedSoFar"].ToString());
                            decimal pitchOfflineSoFar = decimal.Parse(DTPitchDetais.Rows[0]["Pitch_Offline_SoFar"].ToString());
                            decimal pitchPreRaisedSoFar = decimal.Parse(DTPitchDetais.Rows[0]["Pitch_PreRaised_SoFar"].ToString());
                            decimal pitchInstitutionalSoFar = decimal.Parse(DTPitchDetais.Rows[0]["Pitch_Institutional_SoFar"].ToString());

                            string institutionalInvestmentSoFarNote = _stringLocalizer["InstitutionalInvestmentSoFar"].Value;
                            string privateToolTip = "";
                            string preRaisedTooltip = "";
                            string institutionalInvestmentTooltip = "";
                            string crowdFundingTooltip = "";
                            dr["viewInstitutionalInvestmentNote"] = false;

                            decimal pitchCrowdFundingSoFar = pitchInvestedSoFar - pitchOfflineSoFar - pitchPreRaisedSoFar - pitchInstitutionalSoFar;

                            if (pitchInvestedSoFar >= 100)
                            {
                                dr["offlineProgressWidth"] = (pitchOfflineSoFar / pitchInvestedSoFar * 100);
                                dr["preRaisedProgressWidth"] = (pitchPreRaisedSoFar / pitchInvestedSoFar * 100);
                                dr["InstitutionalProgressWidth"] = (pitchInstitutionalSoFar / pitchInvestedSoFar * 100);
                                dr["progressWidth"] = (pitchCrowdFundingSoFar / pitchInvestedSoFar * 100);
                            }
                            else
                            {
                                if (dr["Pitch_Status"].ToString() == "Minimum-Funded" || (dr["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dr["Pitch_Balance"].ToString()) < float.Parse(dr["Pitch_InvestmentRequired"].ToString()))))
                                {
                                    dr["offlineProgressWidth"] = pitchOfflineSoFar;
                                    dr["preRaisedProgressWidth"] = pitchPreRaisedSoFar;
                                    dr["InstitutionalProgressWidth"] = pitchInstitutionalSoFar;
                                    dr["progressWidth"] = (100 - pitchOfflineSoFar - pitchPreRaisedSoFar - pitchInstitutionalSoFar);
                                }
                                else
                                {

                                    dr["offlineProgressWidth"] = pitchOfflineSoFar;
                                    dr["preRaisedProgressWidth"] = pitchPreRaisedSoFar;
                                    dr["InstitutionalProgressWidth"] = pitchInstitutionalSoFar;
                                    dr["progressWidth"] = (pitchInvestedSoFar - pitchOfflineSoFar - pitchPreRaisedSoFar - pitchInstitutionalSoFar);
                                }
                            }

                            if (pitchOfflineSoFar > 0 || pitchPreRaisedSoFar > 0 || pitchInstitutionalSoFar > 0)
                            {
                                dr["viewTooltip"] = true;

                                string preRaisedCapital = _stringLocalizer["PreRaisedCapital"].Value;
                                string Offline = _stringLocalizer["Offline"].Value;
                                string indtitutionalInvestment = _stringLocalizer["INSTITUTIONAL_INVESTMENT"].Value;
                                string crowdFundedCapital = _stringLocalizer["CrowdFundedCapital"].Value;
                                if (pitchOfflineSoFar > 0)
                                {
                                    privateToolTip = Math.Floor(pitchOfflineSoFar) + "% " + Offline;
                                }
                                if (pitchPreRaisedSoFar > 0)
                                {
                                    preRaisedTooltip = Math.Floor(pitchPreRaisedSoFar) + "% " + preRaisedCapital;
                                }
                                if (pitchInstitutionalSoFar > 0)
                                {
                                    institutionalInvestmentTooltip = Math.Floor(pitchInstitutionalSoFar) + "% " + indtitutionalInvestment;
                                    dr["viewInstitutionalInvestmentNote"] = true;
                                }


                                crowdFundingTooltip = Math.Floor((pitchInvestedSoFar - pitchOfflineSoFar - pitchPreRaisedSoFar - pitchInstitutionalSoFar)) + "% " + crowdFundedCapital;

                            }
                            else
                                dr["viewTooltip"] = false;

                            dr["privateToolTip"] = privateToolTip;
                            dr["PreRaisedTooltip"] = preRaisedTooltip;
                            dr["crowdFundingTooltip"] = crowdFundingTooltip;
                            dr["InstitutionalInvestmentTooltip"] = institutionalInvestmentTooltip;
                            dr["InstitutionalInvestmentSoFarNote"] = institutionalInvestmentSoFarNote;


                            #endregion

                            #region check when the user is loggedin 
                            dr["isFollowed"] = false;
                            dr["canFollow"] = true;
                            dr["isInvestEnabled"] = true;

                            if ((dr["Pitch_Status"].ToString() != "published" && dr["Pitch_Status"].ToString() != "Overfunding"
                                    && dr["Pitch_Status"].ToString() != "Early Access"))
                                dr["isInvestEnabled"] = false;
                            if (requestModel.UserId != null)
                            {
                                DataTable dtConnection = _pitchLikeFollower.PitchgetUserIsLikeFollower(int.Parse(requestModel.UserId), int.Parse(dr["Pitch_ID"].ToString()));
                                bool follower = dtConnection.Rows.Count > 0 && Boolean.Parse(dtConnection.Rows[0]["PUConnection_FollowType"].ToString());
                                if (!follower)
                                {
                                    dr["isFollowed"] = false;
                                }
                                else
                                {
                                    dr["isFollowed"] = true;
                                }

                                if (requestModel.UserId.ToString() == dr["Pitch_UserID"].ToString())
                                {
                                    dr["canFollow"] = false;

                                }

                                DataTable dtLoggedInUserInfo = _user.UserSelectById(Int32.Parse(requestModel.UserId));

                                if (dtLoggedInUserInfo.Rows[0]["User_UserType"].ToString() != "2" && dtLoggedInUserInfo.Rows[0]["User_UserType"].ToString() != "4")
                                {
                                    dr["isInvestEnabled"] = false;
                                }

                                if (Convert.ToInt32(dtLoggedInUserInfo.Rows[0]["User_UserFormType"]) == (int)UserType.Enreprenuer)
                                {
                                    dr["isInvestEnabled"] = false;

                                }
                            }
                            #endregion
                        }

                        if (_pitch.PitchIsProposalViewPrevented(dr, requestModel.CountryId, requestModel.UserId))
                            dr.Delete();
                    }
                    DTHomePageProposals.AcceptChanges();

                    homePageProposals.LiveProposals = Tools.ConvertDataTable<Pitch>(DTHomePageProposals);
                }

                DataTable dtHomeEAProposals = _pitch.PitchGetHomeEAProposals((int)requestModel.LangId, (int)requestModel.CurrencyId);
                dtHomeEAProposals.Columns.Add(new DataColumn("VideoId", typeof(string)));
                dtHomeEAProposals.Columns.Add(new DataColumn("WidgetImage", typeof(string)));
                dtHomeEAProposals.Columns.Add(new DataColumn("Logo", typeof(string)));
                dtHomeEAProposals.Columns.Add(new DataColumn("SME_firstName", typeof(string)));
                dtHomeEAProposals.Columns.Add(new DataColumn("SME_lastName", typeof(string)));
                dtHomeEAProposals.Columns.Add(new DataColumn("Badges", typeof(List<Badge>)));
                dtHomeEAProposals.Columns.Add(new DataColumn("ProgressLbl", typeof(string)));
                dtHomeEAProposals.Columns.Add(new DataColumn("isFollowed", typeof(bool)));
                dtHomeEAProposals.Columns.Add(new DataColumn("canFollow", typeof(bool)));
                dtHomeEAProposals.Columns.Add(new DataColumn("isInvestEnabled", typeof(bool)));
                dtHomeEAProposals.Columns.Add(new DataColumn("country_flag", typeof(string)));
                dtHomeEAProposals.Columns.Add(new DataColumn("EarlyAccessCode", typeof(string)));
                dtHomeEAProposals.Columns.Add(new DataColumn("EarlyAccessMode", typeof(bool)));
                dtHomeEAProposals.Columns.Add(new DataColumn("IsBlured", typeof(bool)));
                dtHomeEAProposals.Columns.Add(new DataColumn("IsKYCBlured", typeof(bool)));
                dtHomeEAProposals.Columns.Add(new DataColumn("SMEId", typeof(int)));


                if (dtHomeEAProposals.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtHomeEAProposals.Rows)
                    {
                        int tempout = 0;
                        _pitch.PitchTestExpiration((int)requestModel.LangId, int.Parse(dr["Pitch_ID"].ToString()));

                        #region badges
                        DataTable dtBadges = _pitch.PitchBadgesAssignedGetAll(1, 100, (int)requestModel.LangId, int.Parse(dr["Pitch_ID"].ToString()), out tempout);
                        List<Badge> badges = new List<Badge>();
                        if (dtBadges.Rows.Count > 0)
                        {
                            //badges = Tools.ConvertDataTable<Badge>(dtBadges);
                            badges = JsonConvert.DeserializeObject<List<Badge>>(dtBadges.Rows[0]["Badges"].ToString());

                        }
                        dr["Badges"] = badges;
                        #endregion
                        dr["profile_country_name"] = dr["Profile_PitchCity"].ToString() + (!String.IsNullOrEmpty(dr["Profile_PitchCity"].ToString()) ? ", " : "") + dr["Profile_Country_Name"].ToString();
                        dr["SME_firstName"] = dr["User_FirstName"].ToString();
                        dr["SME_lastName"] = dr["User_LastName"].ToString();
                        dr["SMEId"] = dr["Pitch_UserID"].ToString();

                        #region Proposal widget Image
                        if (!string.IsNullOrEmpty(dr["Profile_PitchWidgetImageID"].ToString().Trim()))
                        {
                            DataTable dtPitchAttachInf = _pitchAttachementsRepository.PitchGetAttachementDetails(Int32.Parse(dr["Profile_PitchWidgetImageID"].ToString()));
                            if (dtPitchAttachInf.Rows.Count > 0)
                            {
                                string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                                //if (System.IO.File.Exists(System.Web.HttpContext.Current.Server.MapPath("~/attachments/pitch/thumbs/thumb_" + img)))
                                dr["WidgetImage"] = _config.GetValue<string>("AttachementsEnvironmentURL") + "pitch/thumbs/thumb_" + img;

                            }
                        }
                        #endregion
                        #region Proposal Video 
                        if (!string.IsNullOrEmpty(dr["Profile_PitchMainVideoID"].ToString().Trim()))
                        {
                            DataTable dtPitchAttachInf = _pitchAttachementsRepository.PitchGetAttachementDetails(Int32.Parse(dr["Profile_PitchMainVideoID"].ToString()));
                            if (dtPitchAttachInf.Rows.Count > 0)
                            {
                                string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                                //if (System.IO.File.Exists(System.Web.HttpContext.Current.Server.MapPath("~/attachments/pitch/thumbs/thumb_" + img)))
                                dr["VideoId"] = img;

                            }
                        }
                        #endregion

                        #region Proposal Main Image
                        if (!string.IsNullOrEmpty(dr["Profile_PitchMainImageID"].ToString().Trim()))
                        {
                            DataTable dtPitchAttachInf = _pitchAttachementsRepository.PitchGetAttachementDetails(Int32.Parse(dr["Profile_PitchMainImageID"].ToString()));
                            if (dtPitchAttachInf.Rows.Count > 0)
                            {
                                string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                                //if (System.IO.File.Exists(System.Web.HttpContext.Current.Server.MapPath("~/attachments/pitch/thumbs/thumb_" + img)))
                                dr["Logo"] = _config.GetValue<string>("AttachementsEnvironmentURL") + "pitch/thumbs/thumb_" + img;

                            }
                        }
                        #endregion

                        dr["EarlyAccessCode"] = dr["Pitch_AccessCode"].ToString();
                        dr["EarlyAccessMode"] = Convert.ToBoolean(int.Parse(dr["Pitch_EarlyAccess_Access_Mode"].ToString()));

                        DataTable DTPitchDetais = _pitch.PitchGetDedicatedPitchDetailsByLang(Int32.Parse(dr["Pitch_ID"].ToString()), (int)requestModel.LangId);
                        if (DTPitchDetais.Rows.Count == 0 && (int)requestModel.LangId != 1)
                        {
                            DTPitchDetais = _pitch.PitchGetDedicatedPitchDetailsByLang(Int32.Parse(dr["Pitch_ID"].ToString()), 1);
                        }

                        if (DTPitchDetais.Rows.Count > 0)
                        {
                            int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Proposal_Widgets_Blur, requestModel.CountryId);
                            if (!string.IsNullOrEmpty(requestModel.UserId) && groupId > 0 && (DTPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Early Access" || DTPitchDetais.Rows[0]["Pitch_Status"].ToString() == "published" || DTPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Overfunding"))
                                dr["IsBlured"] = true;


                            if (!string.IsNullOrEmpty(requestModel.UserId))
                            {
                                DataTable dtUserInfo = _user.UserSelectById(int.Parse(requestModel.UserId));

                                if (dtUserInfo.Rows.Count > 0)
                                {
                                    if (int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.Enreprenuer && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.Admin && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.BIAdmin && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.SystemAdmin)
                                    {
                                        KYCModel kycModel = _user.KYCGetRequiredFiles(int.Parse(requestModel.UserId), requestModel.CountryId);
                                        if (kycModel.KYCOverAllStatus != (int)KYCUserDocsStatus.Accepted && groupId > 0 && (DTPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Early Access" || DTPitchDetais.Rows[0]["Pitch_Status"].ToString() == "published" || DTPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Overfunding"))
                                            dr["IsKYCBlured"] = true;

                                    }
                                }
                            }

                            if (requestModel.LangId == Languages.Arabic && int.Parse(DTPitchDetais.Rows[0]["Profile_LanguageID"].ToString()) == (int)Languages.English)
                            {
                                dr["Profile_PitchTitle"] = DTPitchDetais.Rows[0]["Pitch_Admin_Arabic_Title"];
                                dr["Profile_PitchShortSummary"] = "هذه الشركة متاحة باللغة الإنجليزية فقط، إضغط على عرض الشركة لعرض صفحة الشركة باللغة الإنجليزية";
                            }
                            dr["country_flag"] = _config.GetValue<string>("AssetsEnvironmentURL") + "circle_flags/" + DTPitchDetais.Rows[0]["Country_Flag_URL"].ToString();
                        }
                        #region check when the user is loggedin 
                        dr["isFollowed"] = false;
                        dr["canFollow"] = true;
                        dr["isInvestEnabled"] = true;
                        if ((dr["Pitch_Status"].ToString() != "published" && dr["Pitch_Status"].ToString() != "Overfunding"
                                    && dr["Pitch_Status"].ToString() != "Early Access"))
                            dr["isInvestEnabled"] = false;
                        if (requestModel.UserId != null)
                        {
                            DataTable dtConnection = _pitchLikeFollower.PitchgetUserIsLikeFollower(int.Parse(requestModel.UserId), int.Parse(dr["Pitch_ID"].ToString()));
                            bool follower = dtConnection.Rows.Count > 0 && Boolean.Parse(dtConnection.Rows[0]["PUConnection_FollowType"].ToString());
                            if (!follower)
                            {
                                dr["isFollowed"] = false;
                            }
                            else
                            {
                                dr["isFollowed"] = true;
                            }

                            if (requestModel.UserId.ToString() == dr["Pitch_UserID"].ToString())
                            {
                                dr["canFollow"] = false;

                            }

                            DataTable dtLoggedInUserInfo = _user.UserSelectById(Int32.Parse(requestModel.UserId));

                            if ((dtLoggedInUserInfo.Rows[0]["User_UserType"].ToString() != "2" && dtLoggedInUserInfo.Rows[0]["User_UserType"].ToString() != "4"))
                            {
                                dr["isInvestEnabled"] = false;
                            }

                            if (Convert.ToInt32(dtLoggedInUserInfo.Rows[0]["User_UserFormType"]) == (int)UserType.Enreprenuer)
                            {
                                dr["isInvestEnabled"] = false;

                            }
                        }
                        #endregion

                        dr["ProgressLbl"] = _stringLocalizer["EarlyAccess"].Value;
                        if (_pitch.PitchIsProposalViewPrevented(dr, requestModel.CountryId, requestModel.UserId))
                            dr.Delete();
                    }
                    dtHomeEAProposals.AcceptChanges();
                    homePageProposals.EAProposals = Tools.ConvertDataTable<Pitch>(dtHomeEAProposals);
                }


                return await Task.FromResult(Ok(new { code = 200, success = true,   homePageProposals }));

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }


        [HttpPost]
        public async Task<ActionResult<GeneralResponseMessage>> ProposalFollow(FollowProposalRequestModel model)
        {
            try
            {
                model.UserId = _userId; 
                GeneralResponseMessage generalResponseMessage;
                Tools.SetThreadCulture(model.LangId);
                var response = await Task.FromResult(_pitch.ProposalFollow(model.ProposalId, model.UserId, model.LangId));
                if (response == null) { return NotFound(); }
                if (response == "-2")
                {
                    generalResponseMessage = new GeneralResponseMessage(200, true, "Follow", "there is no userId provided");
                    return Ok(generalResponseMessage);
                }
                else if (response == "2")
                {
                    generalResponseMessage = new GeneralResponseMessage(200, true, "Follow", "Unfollow successeded");
                    return Ok(generalResponseMessage);

                }
                else 
                {
                    generalResponseMessage = new GeneralResponseMessage(200, true, "Follow","follow successeded");
                    return Ok(generalResponseMessage);

                }
                
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500,"Internal server error");
            }
        }

        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult> PitchGetUpdates([FromQuery] PitchGeneral pitchGeneral)
        {
            try
            {
                List<PitchUpdate> updates = new List<PitchUpdate>();
                var dtPitchUpdates = await Task.FromResult(_pitch.PitchGetUpdates(pitchGeneral.PitchId, (int) pitchGeneral.LangId, PitchUpdateStatus.Accepted));
                if (dtPitchUpdates.Rows.Count > 0)
                {
                    updates = Tools.ConvertDataTable<PitchUpdate>(dtPitchUpdates);
                    return Ok(new { code = 200, success = true, updates });
                }
                else
                {
                    return Ok(new { code = 200, success = true, message = _stringLocalizer["NoUpdatesYes"].Value, updates});
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500,"Internal servr error");
            }


        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult<PitchOverview>> PitchGetOverview(PitchGetOverview pitchGetOverview)
        {
            try
            {
                Tools.SetThreadCulture((int) pitchGetOverview.LangId);
                PitchOverview pitchOverview = new PitchOverview();
                DataTable dtPitchDetails = await Task.FromResult(_pitch.PitchGetDedicatedPitchDetailsByLang(pitchGetOverview.PitchId, (int)pitchGetOverview.LangId, (int)pitchGetOverview.CurrencyId));
                DataTable DtCheckForActive = await Task.FromResult(_pitch.PitchGetDedicatedPitchDetailsByLang(pitchGetOverview.PitchId, (int)Languages.English));
                pitchOverview.CanFollow = true; // set the default value
                pitchOverview.IsInvestEnabled = true; // set the default value
                string pitchStatus = DtCheckForActive.Rows[0]["Pitch_Status"].ToString();

                if (DtCheckForActive.Rows.Count > 0 && bool.Parse(DtCheckForActive.Rows[0]["Pitch_IsActive"].ToString()))
                {
                    pitchOverview.PitchId = pitchGetOverview.PitchId;
                    string preventionFlag1, preventionFlag2, preventionFlag3, preventionFlag4, preventionFlag5;
                    pitchGetOverview.UserId = !string.IsNullOrEmpty(pitchGetOverview.UserId) ? pitchGetOverview.UserId : "0";

                    if (_pitch.PitchCheckProfileVisible(pitchGetOverview.PitchId, (int)pitchGetOverview.LangId))
                    {
                        _pitch.PitchTestExpiration((int)pitchGetOverview.LangId, pitchGetOverview.PitchId);

                        //proposal prevented due to pitch status
                        if (pitchGetOverview.UserId != "0")
                        {
                            if (pitchStatus == "not ready" || pitchStatus == "submitted For Approval" || pitchStatus == "coming soon" || pitchStatus == "expired" || pitchStatus == "expired and closed" || pitchStatus == "cancelled" || pitchStatus == "cancelled and closed")
                                if (pitchGetOverview.UserId != dtPitchDetails.Rows[0]["Pitch_UserID"].ToString() && !_user.UserIsAdmin(long.Parse(pitchGetOverview.UserId)) && !_user.UserIsBIAdmin(long.Parse(pitchGetOverview.UserId)))
                                {
                                    pitchOverview.IsViewPrevented = true;
                                    return Ok(new { code = 200, success = false, title = _stringLocalizer["ProposalPrevention"].Value, message = _stringLocalizer["ProposalPreventionGeneralMessage"].Value, pitchOverview });
                                }
                        }
                        else
                        {
                            if (pitchStatus == "not ready" || pitchStatus == "submitted For Approval" || pitchStatus == "coming soon" || pitchStatus == "expired" || pitchStatus == "expired and closed" || pitchStatus == "cancelled" || pitchStatus == "cancelled and closed")
                            {
                                pitchOverview.IsViewPrevented = true;
                                return Ok(new { code = 200, success = false, title = _stringLocalizer["ProposalPrevention"].Value, message = _stringLocalizer["ProposalPreventionGeneralMessage"].Value, pitchOverview });

                            }
                        }
                        string userCountryName = "";
                        DataTable dtCountry = _countryBasedControl.CountryBasedGetCountryDetails(pitchGetOverview.CountryId, (int)pitchGetOverview.LangId);
                        if (dtCountry.Rows.Count > 0)
                            userCountryName = dtCountry.Rows[0]["Profile_Country_Name"].ToString();

                        _pitch.PitchViewProposalPrevention(Convert.ToBoolean(dtPitchDetails.Rows[0]["Pitch_Prevent_Exeption"].ToString()), pitchGetOverview.CountryId, int.Parse(dtPitchDetails.Rows[0]["Pitch_Country"].ToString()), int.Parse(pitchGetOverview.UserId), int.Parse(dtPitchDetails.Rows[0]["Pitch_UserID"].ToString()), pitchGetOverview.PitchId, out preventionFlag1, out preventionFlag2, out preventionFlag3, out preventionFlag4);
                        if (preventionFlag1 == "1")
                        {
                            pitchOverview.IsViewPrevented = true;
                            return Ok(new { code = 200, success = false, title = _stringLocalizer["ProposalPrevention"].Value, message = _stringLocalizer["RequestYouMustLoginInto"].Value, pitchOverview });

                        }
                        if (preventionFlag2 == "1")
                        {
                            pitchOverview.IsViewPrevented = true;
                            return Ok(new { code = 200, success = false, title = _stringLocalizer["ProposalPrevention"].Value, message = _stringLocalizer["YourRequestToViewTheProposalIsStillPending"].Value, pitchOverview });
                        }
                        if (preventionFlag3 == "1")
                        {
                            pitchOverview.IsViewPrevented = true;
                            return Ok(new { code = 200, success = false, title = _stringLocalizer["ProposalPrevention"].Value, message = _stringLocalizer["ThisProposalUsers"].Value + "[" + userCountryName + "]" + _stringLocalizer["ThisProposalUsers2"].Value, pitchOverview });
                        }
                        if (preventionFlag4 == "1")
                        {
                            pitchOverview.IsViewPrevented = true;
                            return Ok(new { code = 200, success = false, title = _stringLocalizer["ProposalPrevention"].Value, message = _stringLocalizer["ThisProposalUsers"].Value + "[" + userCountryName + "]" + _stringLocalizer["ThisProposalUsers2"].Value, pitchOverview });
                        }
                        if (_pitch.PitchViewProposalPreventionByProposal(Convert.ToBoolean(dtPitchDetails.Rows[0]["Pitch_Prevent_Exeption"].ToString()), pitchGetOverview.CountryId, int.Parse(pitchGetOverview.UserId), int.Parse(dtPitchDetails.Rows[0]["Pitch_UserID"].ToString()), pitchGetOverview.PitchId) == "1")
                        {
                            pitchOverview.IsViewPrevented = true;
                            return Ok(new { code = 200, success = false, title = _stringLocalizer["ProposalPrevention"].Value, message = _stringLocalizer["ThisProposalUsers"].Value + "[" + userCountryName + "]", pitchOverview });
                        }
                        bool VisibleToPublic = false;
                        string pitchCountry = (dtPitchDetails.Rows.Count > 0) ? dtPitchDetails.Rows[0]["Pitch_Country"].ToString() : "";
                        if (pitchGetOverview.CountryId == 159 && (pitchCountry != "159" && pitchCountry != ""))
                        {
                            pitchOverview.ShowMalaysianPopup = true;
                            pitchOverview.MalaysianPopupText = _stringLocalizer["AnonMalaysiaMessage"].Value;
                            pitchOverview.MalaysianPopupMessageType = (int)MessageType.warning;
                        }
                        if (pitchGetOverview.UserId != "0")
                        {
                            if (!bool.Parse(dtPitchDetails.Rows[0]["Pitch_VisibleToPublic"].ToString()) && (pitchGetOverview.UserId != dtPitchDetails.Rows[0]["Pitch_UserID"].ToString()) && !_user.UserIsAdmin(long.Parse(pitchGetOverview.UserId)) && !_user.UserIsBIAdmin(long.Parse(pitchGetOverview.UserId)))
                                VisibleToPublic = UserIsUserAllowToViewInvisiblePitch(long.Parse(pitchGetOverview.UserId));
                        }
                        else
                        {
                            VisibleToPublic = !bool.Parse(dtPitchDetails.Rows[0]["Pitch_VisibleToPublic"].ToString());
                        }

                        if (VisibleToPublic)
                        {
                            pitchOverview.IsViewPrevented = true;
                            return Ok(new { code = 200, success = false, title = _stringLocalizer["ProposalPrevention"].Value, message = _stringLocalizer["OnlyDiamond"].Value, pitchOverview });
                        }
                        #region stage
                        if (pitchStatus == "completed")
                            pitchOverview.Stage = _stringLocalizer["Completed"];//"أكملت";
                        else if (pitchStatus == "completed and closed")
                            pitchOverview.Stage = _stringLocalizer["CompletedAndClosed"];//"أكملت وأغلقت";
                        else if (pitchStatus == "coming soon")
                            pitchOverview.Stage = _stringLocalizer["EarlyAccess"];// "قريباً";
                        else if (pitchStatus == "Early Access")
                            pitchOverview.Stage = _stringLocalizer["EarlyAccessPublished"];// "أعلنت قريباً";
                        else if (pitchStatus == "Overfunding")
                            pitchOverview.Stage = _stringLocalizer["OverfundingStatus"];//"تمويل زائد";
                        else if (pitchStatus == "Overfunded")
                            pitchOverview.Stage = _stringLocalizer["Overfunded"];// "ممولة بزيادة";
                        else if (pitchStatus == "Minimum-Funded")
                            pitchOverview.Stage = _stringLocalizer["Funded"];// "ممولة بالحد الأدنى";
                        else if (pitchStatus == "published")
                            pitchOverview.Stage = _stringLocalizer["Published"];//"أعلنت";               
                        #endregion
                        #region follow and invest enable 
                        if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() != "published" && dtPitchDetails.Rows[0]["Pitch_Status"].ToString() != "Overfunding"
                              && dtPitchDetails.Rows[0]["Pitch_Status"].ToString() != "Early Access")
                        {
                            pitchOverview.IsInvestEnabled = false;
                        }
                        if (pitchGetOverview.UserId != "0")
                        {
                            DataTable dtConnection = await Task.FromResult(_pitchLikeFollower.PitchgetUserIsLikeFollower(int.Parse(pitchGetOverview.UserId), int.Parse(dtPitchDetails.Rows[0]["Pitch_ID"].ToString())));
                            bool follower = dtConnection.Rows.Count > 0 && Boolean.Parse(dtConnection.Rows[0]["PUConnection_FollowType"].ToString());
                            if (!follower)
                            {
                                pitchOverview.IsFollowed = false;
                            }
                            else
                            {
                                pitchOverview.IsFollowed = true;
                            }

                            if (pitchGetOverview.UserId.ToString() == dtPitchDetails.Rows[0]["Pitch_UserID"].ToString())
                            {
                                pitchOverview.CanFollow = false;

                            }




                            DataTable dtLoggedInUserInfo = await Task.FromResult(_user.UserSelectById(int.Parse(pitchGetOverview.UserId)));
                            if (_pitch.PitchCheckProposalViewingPreventionByUserKYC(Convert.ToBoolean(dtPitchDetails.Rows[0]["Pitch_Prevent_Exeption"].ToString()), pitchGetOverview.CountryId, int.Parse(dtPitchDetails.Rows[0]["Pitch_Country"].ToString()), int.Parse(pitchGetOverview.UserId), int.Parse(dtPitchDetails.Rows[0]["Pitch_UserID"].ToString()), pitchGetOverview.PitchId, pitchStatus, int.Parse(dtLoggedInUserInfo.Rows[0]["User_UserFormType"].ToString())) == "1")
                            {
                                pitchOverview.IsViewPrevented = true;
                                return Ok(new { code = 200, success = false, title = _stringLocalizer["ProposalPrevention"].Value, message = _stringLocalizer["ViewingUponAcceptedKYC"].Value, pitchOverview });

                            }

                            if ((dtLoggedInUserInfo.Rows[0]["User_UserType"].ToString() != "2" && dtLoggedInUserInfo.Rows[0]["User_UserType"].ToString() != "4") ||
                                Convert.ToInt32(dtLoggedInUserInfo.Rows[0]["User_UserFormType"]) == (int)UserType.Enreprenuer)
                            {
                                pitchOverview.IsInvestEnabled = false;

                            }


                        }
                        #endregion
                        #region secondary locations 
                        List<PitchSecondayLocation> secondayLocations = new List<PitchSecondayLocation>();
                        DataTable DTSecondaryCountryLocation = await Task.FromResult(_pitch.PitchGetPitchSecondaryCountryLocation(pitchGetOverview.PitchId, (int)pitchGetOverview.LangId, "View"));
                        if (DTSecondaryCountryLocation.Rows.Count > 0)
                        {
                            foreach (DataRow dr in DTSecondaryCountryLocation.Rows)
                            {
                                PitchSecondayLocation location = new PitchSecondayLocation();
                                location.CountryId = int.Parse(dr["Secondary_CountryID"].ToString());
                                location.CountryFlag = _config.GetValue<string>("AssetsEnvironmentURL") + "circle_flags/" + dr["Country_Flag_URL"].ToString();
                                location.CountryName = dr["Profile_Country_Name"].ToString();
                                secondayLocations.Add(location);
                            }
                        }
                        pitchOverview.SecondayLocations = secondayLocations;
                        #endregion
                        #region Proposal background Image
                        if (!string.IsNullOrEmpty(dtPitchDetails.Rows[0]["Profile_PitchBannerID"].ToString().Trim()))
                        {
                            DataTable dtPitchAttachInf = await Task.FromResult(_pitchAttachementsRepository.PitchGetAttachementDetails(Int32.Parse(dtPitchDetails.Rows[0]["Profile_PitchBannerID"].ToString())));
                            if (dtPitchAttachInf.Rows.Count > 0)
                            {
                                string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                                if (System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "pitch/" + img)))
                                    pitchOverview.BackgroundImg = _config.GetValue<string>("AttachementsEnvironmentURL") + "pitch/" + img;
                                else
                                    pitchOverview.BackgroundImg = _config.GetValue<string>("AssetsEnvironmentURL") + "Images/default.jpg";
                            }
                        }
                        #endregion
                        #region Proposal Main Image
                        if (!string.IsNullOrEmpty(dtPitchDetails.Rows[0]["Profile_PitchMainImageID"].ToString().Trim()))
                        {
                            DataTable dtPitchAttachInf = await Task.FromResult(_pitchAttachementsRepository.PitchGetAttachementDetails(Int32.Parse(dtPitchDetails.Rows[0]["Profile_PitchMainImageID"].ToString())));
                            if (dtPitchAttachInf.Rows.Count > 0)
                            {
                                string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                                if (System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "pitch/thumbs/thumb_" + img)))
                                    pitchOverview.Logo = _config.GetValue<string>("AttachementsEnvironmentURL") + "pitch/thumbs/thumb_" + img;
                                else
                                    pitchOverview.Logo = _config.GetValue<string>("EnvironmentURL") + "Images/v2/logoDefault.png";
                            }
                        }
                        #endregion
                        #region closing date
                        if ((pitchStatus == "published" || pitchStatus == "Overfunding") && bool.Parse(dtPitchDetails.Rows[0]["Pitch_IsExtended"].ToString()))
                            pitchOverview.ClosingDate = _stringLocalizer["Extended"];
                        else if (pitchStatus == "Early Access")
                            pitchOverview.ClosingDate = _stringLocalizer["Early_accessStatus"];
                        else
                        {
                            pitchOverview.ClosingDate = dtPitchDetails.Rows[0]["Pitch_ClosingDate"].ToString();
                            DateTime PichClosingDateView = Convert.ToDateTime(dtPitchDetails.Rows[0]["Pitch_ClosingDate"].ToString());
                            pitchOverview.ClosingDate = String.Format("{0:d MMM  yyyy}", PichClosingDateView);
                        }
                        #endregion
                        #region social media
                        string PitchOwnerID = dtPitchDetails.Rows[0]["Pitch_UserID"].ToString();
                        DataTable dtPitchOwner = await Task.FromResult(_user.UserGetDetails(Int32.Parse(PitchOwnerID), (int)pitchGetOverview.LangId));
                        if (dtPitchOwner.Rows.Count == 0)
                            dtPitchOwner = await Task.FromResult(_user.UserGetDetails(Int32.Parse(PitchOwnerID), (int)Languages.English));

                        if (!string.IsNullOrWhiteSpace(dtPitchOwner.Rows[0]["User_FB_Link"].ToString()))
                            pitchOverview.FacebookLink = dtPitchOwner.Rows[0]["User_FB_Link"].ToString();

                        if (!string.IsNullOrWhiteSpace(dtPitchOwner.Rows[0]["User_Twitter_Link"].ToString()))
                            pitchOverview.TwitterLink = dtPitchOwner.Rows[0]["User_Twitter_Link"].ToString();

                        if (!string.IsNullOrWhiteSpace(dtPitchOwner.Rows[0]["User_LinkedIn_Link"].ToString()))
                            pitchOverview.LinkedInLink = dtPitchOwner.Rows[0]["User_LinkedIn_Link"].ToString();
                        #endregion

                        #region proposal owner
                        pitchOverview.ProposalOwnerId = int.Parse(dtPitchDetails.Rows[0]["Pitch_UserID"].ToString());
                        pitchOverview.ProposalOwnerLastName = dtPitchOwner.Rows[0]["profile_lastname"].ToString();
                        pitchOverview.ProposalOwnerFirstName = dtPitchOwner.Rows[0]["profile_firstname"].ToString();

                        if (String.IsNullOrEmpty(dtPitchOwner.Rows[0]["User_Picture"].ToString()) ||
                            !System.IO.File.Exists(_config.GetValue<string>("AttachmentPath") + "User/thumbs/thumb_" + dtPitchOwner.Rows[0]["User_Picture"].ToString()))
                            pitchOverview.ProposalOwnerImage = _config.GetValue<string>("EnvironmentURL") + "images/v2/Default.jpg";
                        else
                            pitchOverview.ProposalOwnerImage = _config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dtPitchOwner.Rows[0]["User_Picture"].ToString();

                        #endregion

                        #region tags
                        List<Tag> tags = new List<Tag>();
                        DataTable dtTags = await Task.FromResult(_pitch.PitchGetTags(pitchGetOverview.PitchId));
                        if (dtTags.Rows.Count > 0)
                        {
                            foreach (DataRow dr in dtTags.Rows)
                            {
                                Tag tag = new Tag();
                                tag.Id = int.Parse(dr["Tag_ID"].ToString());
                                tag.TagName = dr["Tag_Name"].ToString();
                                tag.TagArName = dr["Tag_Ar_Name"].ToString();
                                tags.Add(tag);
                            }

                        }
                        pitchOverview.Tags = tags;
                        #endregion
                        #region category
                        if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_CategoryID"].ToString()))
                        {
                            DataTable dtPitchCat = await Task.FromResult(_pitch.PitchGetCategoryDeatils(Int32.Parse(dtPitchDetails.Rows[0]["Pitch_CategoryID"].ToString())));
                            if (dtPitchCat.Rows.Count > 0)
                            {
                                pitchOverview.CategoryName = dtPitchCat.Rows[0]["Category_Name"].ToString();
                                pitchOverview.CategoryArName = dtPitchCat.Rows[0]["Category_Ar_Name"].ToString();
                            }
                        }
                        #endregion
                        #region badges
                        int tempout = 0;
                        DataTable dtBadges = await Task.FromResult(_pitch.PitchBadgesAssignedGetAll(1, 100, (int)pitchGetOverview.LangId, int.Parse(dtPitchDetails.Rows[0]["Pitch_ID"].ToString()), out tempout));
                        List<Badge> badges = new List<Badge>();
                        if (dtBadges.Rows.Count > 0)
                        {
                            badges = JsonConvert.DeserializeObject<List<Badge>>(dtBadges.Rows[0]["Badges"].ToString());
                        }
                        pitchOverview.Badges = badges;
                        #endregion
                        DataTable dtCurreny = _general.CurrencyGetCurrencyByID((int)pitchGetOverview.CurrencyId);
                        string currencySymbol = dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$";

                        pitchOverview.InvestorsNumbers = long.Parse(dtPitchDetails.Rows[0]["Pitch_Investors"].ToString());
                        pitchOverview.PreMoneyVal = decimal.Parse(dtPitchDetails.Rows[0]["Pitch_Pre_Money_Val"].ToString());
                        pitchOverview.PreMoneyValText = Tools.FormatNumberWithCurrency((int)pitchGetOverview.LangId, currencySymbol, pitchOverview.PreMoneyVal.ToString("#,##0"));
                        pitchOverview.HighestInvestment = int.Parse(dtPitchDetails.Rows[0]["MaxInvAmount"].ToString());
                        pitchOverview.HighestInvestmentText = Tools.FormatNumberWithCurrency((int)pitchGetOverview.LangId, currencySymbol, pitchOverview.HighestInvestment.ToString("#,##0"));

                        if (!string.IsNullOrEmpty(dtPitchDetails.Rows[0]["OverSubAmount"].ToString()))
                            pitchOverview.OverfundingFormatted = Tools.FormatNumberWithCurrency((int)pitchGetOverview.LangId, currencySymbol, double.Parse(dtPitchDetails.Rows[0]["OverSubAmount"].ToString()).ToString("#,##0"));


                        pitchOverview.ShortSummary = dtPitchDetails.Rows[0]["Profile_PitchShortSummary"].ToString();
                        pitchOverview.PitchTitle = dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString();
                        pitchOverview.HasDiscount = bool.Parse(dtPitchDetails.Rows[0]["Pitch_HasDiscount"].ToString());
                        double currentTrachDiscount = 0;
                        double currentRemainingTrancheSize = 0;
                        _pitch.PitchGetCurrentTrancheDiscAndRemSizeByBalanceAfterDiscount(dtPitchDetails.Rows[0], _pitch.PitchGetSumPendingPreInvestmentsAfterDiscount(pitchGetOverview.PitchId), out currentTrachDiscount, out currentRemainingTrancheSize);
                        pitchOverview.CurrentTranchDiscount = currentTrachDiscount;
                        pitchOverview.CurrentRemainingTrancheSize = currentRemainingTrancheSize;
                        pitchOverview.CountryId = dtPitchDetails.Rows[0]["Pitch_Country"].ToString();
                        pitchOverview.CountryName = dtPitchDetails.Rows[0]["profile_country_name"].ToString();
                        pitchOverview.CountryFlag = _config.GetValue<string>("AssetsEnvironmentURL") + "circle_flags/" + dtPitchDetails.Rows[0]["Country_Flag_URL"].ToString();
                        pitchOverview.IsAllowedSecondaryMarket = bool.Parse(dtPitchDetails.Rows[0]["Pitch_IsAllowSecondaryMarket"].ToString());
                        pitchOverview.Equity = !string.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_EquityOffered"].ToString()) ? double.Parse(dtPitchDetails.Rows[0]["Pitch_EquityOffered"].ToString()) : 0;
                        pitchOverview.EarlyAccessMode = int.Parse(dtPitchDetails.Rows[0]["Pitch_EarlyAccess_Access_Mode"].ToString());
                        pitchOverview.AccessCode = dtPitchDetails.Rows[0]["Pitch_AccessCode"].ToString();
                        pitchOverview.PitchPercantage = Math.Floor(float.Parse(dtPitchDetails.Rows[0]["Pitch_InvestedSoFar"].ToString())) + "%";
                        _pitch.PitchUpdatePitchViewed(pitchGetOverview.PitchId);
                        return Ok(new { code = 200, success = true, pitchOverview });
                    }
                    else
                    {
                        pitchOverview.IsViewPrevented = true;
                        return Ok(new { code = 200, success = false, title = _stringLocalizer["ProposalPrevention"].Value, message = _stringLocalizer["ProposalPreventionGeneralMessage"].Value, pitchOverview });

                    }
                }
                else
                {
                    //Proposal is not available in this language
                    pitchOverview.IsViewPrevented = true;
                    pitchOverview.IsLanguageNotSupport = true;
                    return Ok(new { code = 200, success = false, title = _stringLocalizer["ProposalPrevention"].Value, message = _stringLocalizer["ProposalPreventionLanguage"].Value, pitchOverview });
                }



            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }
        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult> PitchGetBusiness([FromQuery]PitchGeneral pitchGetBusiness)
        {
            try
            {
                #region business info
                DataTable dtProposalBusiness = await Task.FromResult(_pitch.PitchBusenissProfileGetAll(pitchGetBusiness.PitchId,(int) pitchGetBusiness.LangId));
                ProposalBusinessDetails businessDetails = new ProposalBusinessDetails();
                if (dtProposalBusiness.Rows.Count > 0)
                {

                    businessDetails.AtGlanceTitle1 = dtProposalBusiness.Rows[0]["Profile_Title1"].ToString();
                    businessDetails.AtGlaceDescription1 = dtProposalBusiness.Rows[0]["Profile_Description1"].ToString();
                    businessDetails.AtGlaceIcon1 = "fa " + dtProposalBusiness.Rows[0]["Profile_ImageClass1"].ToString() + " fa-2x";

                    businessDetails.AtGlanceTitle2 = dtProposalBusiness.Rows[0]["Profile_Title2"].ToString();
                    businessDetails.AtGlaceDescription2 = dtProposalBusiness.Rows[0]["Profile_Description2"].ToString();
                    businessDetails.AtGlaceIcon2 = "fa " + dtProposalBusiness.Rows[0]["Profile_ImageClass2"].ToString() + " fa-2x";

                    businessDetails.AtGlanceTitle3 = dtProposalBusiness.Rows[0]["Profile_Title3"].ToString();
                    businessDetails.AtGlaceDescription3 = dtProposalBusiness.Rows[0]["Profile_Description3"].ToString();
                    businessDetails.AtGlaceIcon3 = "fa " + dtProposalBusiness.Rows[0]["Profile_ImageClass3"].ToString() + " fa-2x";

                    businessDetails.IdeaTxt = dtProposalBusiness.Rows[0]["Profile_Idia"].ToString();
                    if (String.IsNullOrEmpty(dtProposalBusiness.Rows[0]["Profile_IdiaImage"].ToString()) || !System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "/Attachments/Pitch/TheBussniss/" + dtProposalBusiness.Rows[0]["Profile_IdiaImage"].ToString())))
                        businessDetails.IdeaImage = _config.GetValue<string>("EnvironmentURL") + "/images/v2/pitchDefault.jpg";
                    else
                        businessDetails.IdeaImage = _config.GetValue<string>("AttachementsEnvironmentURL") + "Pitch/TheBussniss/" + dtProposalBusiness.Rows[0]["Profile_IdiaImage"].ToString();

                    businessDetails.CompanyTxt = dtProposalBusiness.Rows[0]["Profile_TheCompany"].ToString();
                    if (String.IsNullOrEmpty(dtProposalBusiness.Rows[0]["Profile_TheCompanyImage"].ToString()) || !System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "/Attachments/Pitch/TheBussniss/" + dtProposalBusiness.Rows[0]["Profile_TheCompanyImage"].ToString())))
                        businessDetails.CompanyImage = _config.GetValue<string>("EnvironmentURL") + "/images/v2/pitchDefault.jpg";
                    else
                        businessDetails.CompanyImage = _config.GetValue<string>("AttachementsEnvironmentURL") + "Pitch/TheBussniss/" + dtProposalBusiness.Rows[0]["Profile_TheCompanyImage"].ToString();

                    businessDetails.MoneyText = dtProposalBusiness.Rows[0]["Profile_TheMoney"].ToString();
                    businessDetails.StratigyText = dtProposalBusiness.Rows[0]["Profile_Strategy"].ToString();

                    businessDetails.KeyInvestorPerson = dtProposalBusiness.Rows[0]["Profile_KeyInvestorPerson"].ToString();
                    businessDetails.WhyTxt = dtProposalBusiness.Rows[0]["Profile_KeyInvestorText"].ToString();
                    if (String.IsNullOrEmpty(dtProposalBusiness.Rows[0]["Profile_KeyInvestorImg"].ToString()) || !System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "Pitch/TheBussniss/" + dtProposalBusiness.Rows[0]["Profile_KeyInvestorImg"].ToString())))
                        businessDetails.WhyImage = _config.GetValue<string>("EnvironmentURL") + "/images/v2/Default.jpg";
                    else
                        businessDetails.WhyImage = _config.GetValue<string>("AttachementsEnvironmentURL") + "Pitch/TheBussniss/" + dtProposalBusiness.Rows[0]["Profile_KeyInvestorImg"].ToString();

                    businessDetails.KeyPressJornal = dtProposalBusiness.Rows[0]["Profile_KeyPressJornal"].ToString();
                    businessDetails.NotablePressTxt = dtProposalBusiness.Rows[0]["Profile_KeyPressText"].ToString();

                    return Ok(new { code = 200, success = true, businessDetails });

                }
                return Ok(new { code = 200, success = false, message = _stringLocalizer["ErrorOccurred"].Value });

                #endregion
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }
        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult> PitchGetTranches([FromQuery]CurrencyPitchGeneral pitchGeneral)
        {
            try
            {
                DataTable dtPitchDetails = await Task.FromResult(_pitch.PitchGetDedicatedPitchDetailsByLang(pitchGeneral.PitchId, (int)pitchGeneral.LangId));
                ProposalTranches proposalTranches = new ProposalTranches();
                if (dtPitchDetails.Rows.Count > 0)
                {

                    proposalTranches.HasDiscount = bool.Parse(dtPitchDetails.Rows[0]["Pitch_HasDiscount"].ToString());
                    if (proposalTranches.HasDiscount)
                    {
                        if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "Early Access")
                        {
                            double CurrentRemainingTrancheSize = 0, TranchDiscount = 0;
                            _pitch.PitchGetCurrentTrancheDiscAndRemSizeByBalanceAfterDiscount(dtPitchDetails.Rows[0], _pitch.PitchGetSumPendingPreInvestmentsAfterDiscount(pitchGeneral.PitchId), out TranchDiscount, out CurrentRemainingTrancheSize);
                            proposalTranches.EarlyAaccessTranchDiscountLblVisibility = true;
                            proposalTranches.EarlyAaccessTranchDiscountShares = TranchDiscount.ToString() + " % " + _stringLocalizer["DiscountOnSharesAvailable"];
                            proposalTranches.EarlyAaccessTranchDiscountLbl = TranchDiscount + "%";
                        }
                        else
                        {
                            double TranchSize1 = 0;
                            double TranchSize2 = 0;
                            double TranchSize3 = 0;
                            double TranchSize4 = 0;
                            double Pitch_TranchEdge1;
                            double Pitch_TranchEdge2;
                            double Pitch_TranchEdge3;
                            double Pitch_TranchEdge4;
                            double SharePrice = 0;
                            DataTable dtCurreny = _general.CurrencyGetCurrencyByID((int)pitchGeneral.CurrencyId);
                            string currencySymbol = dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$" ;


                            SharePrice = _pitch.PitchGetExactAmountAfterExchange(double.Parse(dtPitchDetails.Rows[0]["Pitch_Share_Price"].ToString()), (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId);

                            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString()))
                                proposalTranches.Tranch1Discount = dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString();
                            else
                                proposalTranches.Tranch1Discount = "0";

                            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchSize1"].ToString()))
                                proposalTranches.Tranch1Size = TranchSize1 = double.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize1"].ToString());

                            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_Tranche1_Share_Price"].ToString()))
                                proposalTranches.Tranch1SharePrice = currencySymbol + Tools.Format2DP(_pitch.PitchGetExactAmountAfterExchange(double.Parse(dtPitchDetails.Rows[0]["Pitch_Tranche1_Share_Price"].ToString()), (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId));
                            else
                                proposalTranches.Tranch1SharePrice = currencySymbol + Tools.Format2DP(SharePrice);

                            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString()))
                                proposalTranches.Tranch2Discount = dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString();
                            else
                                proposalTranches.Tranch2Discount = "0";

                            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchSize2"].ToString()))
                                proposalTranches.Tranch2Size = TranchSize2 = double.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize2"].ToString());

                            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_Tranche2_Share_Price"].ToString()))
                                proposalTranches.Tranch2SharePrice = currencySymbol + Tools.Format2DP(_pitch.PitchGetExactAmountAfterExchange(double.Parse(dtPitchDetails.Rows[0]["Pitch_Tranche2_Share_Price"].ToString()), (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId));
                            else
                                proposalTranches.Tranch2SharePrice = currencySymbol + Tools.Format2DP(SharePrice);

                            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString()))
                                proposalTranches.Tranch3Discount = dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString();
                            else
                                proposalTranches.Tranch3Discount = "0";

                            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchSize3"].ToString()))
                                proposalTranches.Tranch3Size = TranchSize3 = double.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize3"].ToString());

                            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_Tranche3_Share_Price"].ToString()))
                                proposalTranches.Tranch3SharePrice = currencySymbol + Tools.Format2DP(_pitch.PitchGetExactAmountAfterExchange(double.Parse(dtPitchDetails.Rows[0]["Pitch_Tranche3_Share_Price"].ToString()), (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId));
                            else
                                proposalTranches.Tranch3SharePrice = currencySymbol + Tools.Format2DP(SharePrice);

                            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString()))
                                proposalTranches.Tranch4Discount = dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString();
                            else
                                proposalTranches.Tranch4Discount = "0";

                            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchSize4"].ToString()))
                                proposalTranches.Tranch4Size = TranchSize4 = double.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize4"].ToString());

                            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_Tranche4_Share_Price"].ToString()))
                                proposalTranches.Tranch4SharePrice = currencySymbol + Tools.Format2DP(_pitch.PitchGetExactAmountAfterExchange(double.Parse(dtPitchDetails.Rows[0]["Pitch_Tranche4_Share_Price"].ToString()), (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId));
                            else
                                proposalTranches.Tranch4SharePrice = currencySymbol + Tools.Format2DP(SharePrice);

                            double Pitch_Balance = double.Parse(dtPitchDetails.Rows[0]["Pitch_Balance"].ToString());

                            Pitch_TranchEdge1 = TranchSize1;
                            Pitch_TranchEdge2 = Pitch_TranchEdge1 + TranchSize2;
                            Pitch_TranchEdge3 = Pitch_TranchEdge2 + TranchSize3;
                            Pitch_TranchEdge4 = Pitch_TranchEdge3 + TranchSize4;

                            double CurrentRemainingShares1 = 0, CurrentRemainingShares2 = 0, CurrentRemainingShares3 = 0, CurrentRemainingShares4 = 0;
                            string Tranch1RemainingSharesRegex = "", Tranch2RemainingSharesRegex = "", Tranch3RemainingSharesRegex = "", Tranch4RemainingSharesRegex = "";

                            if (Pitch_Balance < Pitch_TranchEdge1)
                            {
                                proposalTranches.ActiveTranch = 1;
                                if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString()))
                                    proposalTranches.EarlyAaccessTranchDiscountLbl = dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString() + "% ";
                                else
                                    proposalTranches.EarlyAaccessTranchDiscountLblVisibility = false;


                                CurrentRemainingShares1 = _pitch.PitchGetExactAmountAfterExchange(Pitch_TranchEdge1 - Pitch_Balance, (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId);
                                CurrentRemainingShares2 = _pitch.PitchGetExactAmountAfterExchange(TranchSize2, (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId);
                                CurrentRemainingShares3 = _pitch.PitchGetExactAmountAfterExchange(TranchSize3, (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId);
                                CurrentRemainingShares4 = _pitch.PitchGetExactAmountAfterExchange(TranchSize4, (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId);

                                Tranch1RemainingSharesRegex = CurrentRemainingShares1 % 1 == 0 ? "{0:n0}" : "{0:n}";
                                Tranch2RemainingSharesRegex = CurrentRemainingShares2 % 1 == 0 ? "{0:n0}" : "{0:n}";
                                Tranch3RemainingSharesRegex = CurrentRemainingShares3 % 1 == 0 ? "{0:n0}" : "{0:n}";
                                Tranch4RemainingSharesRegex = CurrentRemainingShares4 % 1 == 0 ? "{0:n0}" : "{0:n}";

                                if (TranchSize1 == 0)
                                    proposalTranches.Tranch1RemainingShares = "-";
                                else
                                    proposalTranches.Tranch1RemainingShares = currencySymbol + string.Format(Tranch1RemainingSharesRegex, CurrentRemainingShares1);

                                if (TranchSize2 == 0)
                                    proposalTranches.Tranch2RemainingShares = "-";
                                else
                                    proposalTranches.Tranch2RemainingShares = currencySymbol + string.Format(Tranch2RemainingSharesRegex, CurrentRemainingShares2);

                                if (TranchSize3 == 0)
                                    proposalTranches.Tranch3RemainingShares = "-";
                                else
                                    proposalTranches.Tranch3RemainingShares = currencySymbol + string.Format(Tranch3RemainingSharesRegex, CurrentRemainingShares3);

                                if (TranchSize4 == 0)
                                    proposalTranches.Tranch4RemainingShares = "-";
                                else
                                    proposalTranches.Tranch4RemainingShares = currencySymbol + string.Format(Tranch4RemainingSharesRegex, CurrentRemainingShares4);
                            }
                            else if (Pitch_Balance >= Pitch_TranchEdge1 && Pitch_Balance < Pitch_TranchEdge2)
                            {
                                proposalTranches.ActiveTranch = 2;
                                if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString()))
                                    proposalTranches.EarlyAaccessTranchDiscountLbl = dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString() + "% ";
                                else
                                    proposalTranches.EarlyAaccessTranchDiscountLblVisibility = false;

                                CurrentRemainingShares2 = _pitch.PitchGetExactAmountAfterExchange(Pitch_TranchEdge2 - Pitch_Balance, (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId);
                                CurrentRemainingShares3 = _pitch.PitchGetExactAmountAfterExchange(TranchSize3, (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId);
                                CurrentRemainingShares4 = _pitch.PitchGetExactAmountAfterExchange(TranchSize4, (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId);

                                Tranch2RemainingSharesRegex = CurrentRemainingShares2 % 1 == 0 ? "{0:n0}" : "{0:n}";
                                Tranch3RemainingSharesRegex = CurrentRemainingShares3 % 1 == 0 ? "{0:n0}" : "{0:n}";
                                Tranch4RemainingSharesRegex = CurrentRemainingShares4 % 1 == 0 ? "{0:n0}" : "{0:n}";

                                if (TranchSize1 == 0)
                                    proposalTranches.Tranch1RemainingShares = "-";
                                else
                                    proposalTranches.Tranch1RemainingShares = currencySymbol + "0";

                                if (TranchSize2 == 0)
                                    proposalTranches.Tranch2RemainingShares = "-";
                                else
                                    proposalTranches.Tranch2RemainingShares = currencySymbol + string.Format(Tranch2RemainingSharesRegex, CurrentRemainingShares2);

                                if (TranchSize3 == 0)
                                    proposalTranches.Tranch3RemainingShares = "-";
                                else
                                    proposalTranches.Tranch3RemainingShares = currencySymbol + string.Format(Tranch3RemainingSharesRegex, CurrentRemainingShares3);

                                if (TranchSize4 == 0)
                                    proposalTranches.Tranch4RemainingShares = "-";
                                else
                                    proposalTranches.Tranch4RemainingShares = currencySymbol + string.Format(Tranch4RemainingSharesRegex, CurrentRemainingShares4);
                            }
                            else if (Pitch_Balance >= Pitch_TranchEdge2 && Pitch_Balance < Pitch_TranchEdge3)
                            {
                                proposalTranches.ActiveTranch = 3;

                                if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString()))
                                    proposalTranches.EarlyAaccessTranchDiscountLbl = dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString() + "% ";
                                else
                                    proposalTranches.EarlyAaccessTranchDiscountLblVisibility = false;

                                CurrentRemainingShares3 = _pitch.PitchGetExactAmountAfterExchange(Pitch_TranchEdge3 - Pitch_Balance, (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId);
                                CurrentRemainingShares4 = _pitch.PitchGetExactAmountAfterExchange(TranchSize4, (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId);

                                Tranch3RemainingSharesRegex = CurrentRemainingShares3 % 1 == 0 ? "{0:n0}" : "{0:n}";
                                Tranch4RemainingSharesRegex = CurrentRemainingShares4 % 1 == 0 ? "{0:n0}" : "{0:n}";

                                if (TranchSize1 == 0)
                                    proposalTranches.Tranch1RemainingShares = "-";
                                else
                                    proposalTranches.Tranch1RemainingShares = currencySymbol + "0";

                                if (TranchSize2 == 0)
                                    proposalTranches.Tranch2RemainingShares = "-";
                                else
                                    proposalTranches.Tranch2RemainingShares = currencySymbol + "0";

                                if (TranchSize3 == 0)
                                    proposalTranches.Tranch3RemainingShares = "-";
                                else
                                    proposalTranches.Tranch3RemainingShares = currencySymbol + string.Format(Tranch3RemainingSharesRegex, CurrentRemainingShares3);

                                if (TranchSize4 == 0)
                                    proposalTranches.Tranch4RemainingShares = "-";
                                else
                                    proposalTranches.Tranch4RemainingShares = currencySymbol + string.Format(Tranch4RemainingSharesRegex, CurrentRemainingShares4);
                            }
                            else if (Pitch_Balance >= Pitch_TranchEdge3 && Pitch_Balance < Pitch_TranchEdge4)
                            {
                                proposalTranches.ActiveTranch = 4;

                                if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString()))
                                    proposalTranches.EarlyAaccessTranchDiscountLbl = dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString() + "% ";
                                else
                                    proposalTranches.EarlyAaccessTranchDiscountLblVisibility = false;

                                CurrentRemainingShares4 = _pitch.PitchGetExactAmountAfterExchange(Pitch_TranchEdge4 - Pitch_Balance, (int)pitchGeneral.CurrencyId, "1", pitchGeneral.PitchId);

                                Tranch4RemainingSharesRegex = CurrentRemainingShares4 % 1 == 0 ? "{0:n0}" : "{0:n}";

                                if (TranchSize1 == 0)
                                    proposalTranches.Tranch1RemainingShares = "-";
                                else
                                    proposalTranches.Tranch1RemainingShares = currencySymbol + "0";

                                if (TranchSize2 == 0)
                                    proposalTranches.Tranch2RemainingShares = "-";
                                else
                                    proposalTranches.Tranch2RemainingShares = currencySymbol + "0";

                                if (TranchSize3 == 0)
                                    proposalTranches.Tranch3RemainingShares = "-";
                                else
                                    proposalTranches.Tranch3RemainingShares = currencySymbol + "0";

                                if (TranchSize4 == 0)
                                    proposalTranches.Tranch4RemainingShares = "-";
                                else
                                    proposalTranches.Tranch4RemainingShares = currencySymbol + string.Format(Tranch4RemainingSharesRegex, CurrentRemainingShares4);
                            }
                            else
                            {

                                if (TranchSize1 == 0)
                                    proposalTranches.Tranch1RemainingShares = "-";
                                else
                                    proposalTranches.Tranch1RemainingShares = currencySymbol + "0";

                                if (TranchSize2 == 0)
                                    proposalTranches.Tranch2RemainingShares = "-";
                                else
                                    proposalTranches.Tranch2RemainingShares = currencySymbol + "0";

                                if (TranchSize3 == 0)
                                    proposalTranches.Tranch3RemainingShares = "-";
                                else
                                    proposalTranches.Tranch3RemainingShares = currencySymbol + "0";

                                if (TranchSize4 == 0)
                                    proposalTranches.Tranch4RemainingShares = "-";
                                else
                                    proposalTranches.Tranch4RemainingShares = currencySymbol + "0";

                                proposalTranches.ActiveTranch = 0;

                                proposalTranches.EarlyAaccessTranchDiscountLblVisibility = false;
                            }
                        }
                        return Ok(new { code = 200, success = true, proposalTranches });
                    }
                    return Ok(new { code = 200, success = true, message = _stringLocalizer["ThereIsNoDiscount"].Value });

                }
                return Ok(new { code = 200, success = false, message = _stringLocalizer["ErrorOccurred"].Value });

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        
        [HttpPost]
        public async Task<ActionResult<ProposalInvestorsResponse>> PitchGetInvestorsByPage(ProposalInvestorRequestModel requestModel)
        {
            try
            {
                requestModel.UserId = int.Parse(_userId);
                requestModel.LangId = Enum.IsDefined(typeof(Languages), requestModel.LangId) ? requestModel.LangId : (int)Languages.English;
                requestModel.CurrencyId = Enum.IsDefined(typeof(Currencies), requestModel.CurrencyId) ? requestModel.CurrencyId : (int)Currencies.USD;
                Tools.SetThreadCulture(requestModel.LangId);
                List<ProposalInvestor> proposalInvestors = new List<ProposalInvestor>();
                int recordCount = 0;
                bool hasMore = false;
                DataTable dtInvestor = await Task.FromResult(_pitch.PitchGetInvestorsByPage(requestModel.PitchId, requestModel.CurrencyId, requestModel.Fund, requestModel.LangId, (requestModel.PageNo +1), requestModel.PageSize, out recordCount));//we have add 1 to page no becsues the paging in stored procedure start form 1 not 0
                hasMore = recordCount > ((requestModel.PageNo + 1) * requestModel.PageSize);

                if (dtInvestor != null)
                {
                    foreach (DataRow dr in dtInvestor.Rows)
                    {
                        ProposalInvestor proposalInvestor = new ProposalInvestor();
                        proposalInvestor.UserID = int.Parse(dr["User_ID"].ToString());
                        proposalInvestor.User_UserName = dr["User_UserName"].ToString();
                        proposalInvestor.Investment_Amount = double.Parse(dr["InvAmmount"].ToString());
                        
                        DataTable dtCurreny = _general.CurrencyGetCurrencyByID(requestModel.CurrencyId);
                        string currencySymbol = dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$";

                        proposalInvestor.InvestmentAmountFormatted = Tools.FormatNumberWithCurrency(requestModel.LangId, currencySymbol, double.Parse(dr["InvAmmount"].ToString()).ToString("#,##0"));
                        
                        
                        if (String.IsNullOrEmpty(dr["User_Picture"].ToString()) || !System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "User/thumbs/thumb_" + dr["User_Picture"].ToString())))
                            proposalInvestor.UserImage = _config.GetValue<string>("EnvironmentURL") + "/images/v2/Default.jpg";
                        else
                            proposalInvestor.UserImage = _config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dr["User_Picture"].ToString();

                        DataTable dtUserDetails = _user.UserGetDetails(int.Parse(dr["User_ID"].ToString()), requestModel.LangId);
                        if (dtUserDetails.Rows.Count > 0)
                        {
                            proposalInvestor.ProfileFirstName = dtUserDetails.Rows[0]["Profile_FirstName"].ToString() != null ? dtUserDetails.Rows[0]["Profile_FirstName"].ToString() : " ";
                            proposalInvestor.ProfileLastName = dtUserDetails.Rows[0]["Profile_LastName"].ToString() != null ? dtUserDetails.Rows[0]["Profile_LastName"].ToString() : " ";
                            DataTable DTObject = _user.UserGetUserEnrollmentsByLang(int.Parse(dtUserDetails.Rows[0]["User_ID"].ToString()), requestModel.LangId, (int)ObjectsGroups.Badges);
                            if (DTObject.Rows.Count > 0)
                            {
                                proposalInvestor.ProfileObject = DTObject.Rows[0]["Profile_ObjectTitle"].ToString() != null ? DTObject.Rows[0]["Profile_ObjectTitle"].ToString(): ""  ;
                            }
                            else
                            {
                                proposalInvestor.ProfileObject = _stringLocalizer["RegularUser"].Value ;
                            }
                        }

                        if (requestModel.UserId != null)
                        {
                            int userConnectionId = _user.UserGetUserConnectionId(requestModel.UserId.ToString(), dr["User_ID"].ToString());

                            proposalInvestor.CanFollow = true;
                            if (dr["User_ID"].ToString() == requestModel.UserId.ToString())
                                proposalInvestor.CanFollow = false;

                            if (userConnectionId > 0)
                                proposalInvestor.IsFollowed = true;
                        }

                        proposalInvestors.Add(proposalInvestor);
                    }

                }
                return Ok(new ProposalInvestorsResponse (200,true, recordCount,hasMore, requestModel.PageNo, proposalInvestors ));
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal Server Error");
            }
        }

        [HttpGet]
        public async Task<ActionResult> PitchGetQuestionsAndAnswers([FromQuery]PitchGeneral pitchGeneral)
        {
            try
            {
                Tools.SetThreadCulture((int)pitchGeneral.LangId);
                
                DataTable dtPitchDetails = await Task.FromResult(_pitch.PitchGetPitchNotLocalizedDetails(pitchGeneral.PitchId));
                List<Question> questions = new List<Question>();

                if (dtPitchDetails.Rows.Count > 0)
                {

                    #region questions and answers 
                    if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["CustomForum_TopicID"].ToString()))
                    {
                        DataTable dtQuestions = _topic.TopicGetAcceptedQuestionsOfTopic(int.Parse(dtPitchDetails.Rows[0]["CustomForum_TopicID"].ToString()), (int)pitchGeneral.LangId);
                        if (dtQuestions.Rows.Count > 0)
                        {
                            foreach (DataRow dr in dtQuestions.Rows)
                            {
                                Question question = new Question();
                                question.QuestionId = int.Parse(dr["QUESTION_ID"].ToString());
                                question.RelationToSME = !string.IsNullOrEmpty(dr["QUESTION_RelationshipToSME"].ToString())  ? int.Parse(dr["QUESTION_RelationshipToSME"].ToString()) : 0;
                                //question.UserId = int.Parse(dr["QUESTION_QUESTIONER_ID"].ToString());
                                question.QuestionText = dr["QUESTION_TEXT"].ToString();
                                question.QuestionDate = dr["QUESTION_DATE"].ToString();
                                question.RelationToSMEWhenOther = dr["QUESTION_RelationshipToSMEWhenOther"].ToString();
                                List<Answer> answers = new List<Answer>();
                                DataTable dtAcceptedAnswers = _topic.TopicGetAcceptedAnswersOfQuestion(int.Parse(dr["QUESTION_ID"].ToString()));
                                if (dtAcceptedAnswers.Rows.Count > 0)
                                {
                                    foreach (DataRow drAnwer in dtAcceptedAnswers.Rows)
                                    {
                                        Answer answer = new Answer();
                                        answer.AnswerId = int.Parse(drAnwer["ANSWER_ID"].ToString());
                                        answer.AnswerText = drAnwer["ANSWER_TEXT"].ToString();
                                        answer.AnswerDate = drAnwer["ANSWER_DATE"].ToString();
                                        DataTable dtAnswererDetails = _user.UserGetDetails(int.Parse(drAnwer["USER_ID"].ToString()), (int)pitchGeneral.LangId);
                                        if (dtAnswererDetails.Rows.Count > 0)
                                        {
                                            answer.Answerer = SetUser(dtAnswererDetails, drAnwer["USER_ID"].ToString(), (int)pitchGeneral.LangId, int.Parse(drAnwer["USER_WALL_ID"].ToString()));
                                        }
                                        answers.Add(answer);
                                    }
                                }

                                DataTable dtQuestionerDetails = _user.UserGetDetails(int.Parse(dr["QUESTION_QUESTIONER_ID"].ToString()), (int)pitchGeneral.LangId);
                                DataTable dtForumQuestionerDetails = _forumUser.ForumGetUserDetails(int.Parse(dr["QUESTION_QUESTIONER_ID"].ToString()), 0);
                                if (dtQuestionerDetails.Rows.Count > 0)
                                {
                                    question.Questioner = SetUser(dtQuestionerDetails, dr["QUESTION_QUESTIONER_ID"].ToString(), (int)pitchGeneral.LangId, int.Parse(dtForumQuestionerDetails.Rows[0]["USER_WALL_ID"].ToString()));
                                }

                                question.Answers = answers;                                                                                                                                                             
                                questions.Add(question);
                            }

                        }
                    }
                    return Ok(new { code = 200, success = true, topicId = int.Parse(dtPitchDetails.Rows[0]["CustomForum_TopicID"].ToString()), questions });
                }
                #endregion

                return Ok(new { code = 200, success = true, topicId = int.Parse(dtPitchDetails.Rows[0]["CustomForum_TopicID"].ToString()), questions });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        private User SetUser(DataTable dtUserDetails , string userId, int langId, int userWallId)
        {
            User user = new User();
            user.Id = userId;
            user.Username = dtUserDetails.Rows[0]["User_Username"].ToString();
            user.Email = dtUserDetails.Rows[0]["User_Email"].ToString();
            user.FirstName = dtUserDetails.Rows[0]["Profile_FirstName"].ToString();
            user.LastName = dtUserDetails.Rows[0]["Profile_LastName"].ToString();
            user.Phone = dtUserDetails.Rows[0]["User_Phone"].ToString();
            user.IsPartner = bool.Parse(dtUserDetails.Rows[0]["Is_Partner"].ToString());
            user.Guid = dtUserDetails.Rows[0]["User_guid"].ToString();
            user.LanguageId = int.Parse(dtUserDetails.Rows[0]["User_LanguageId"].ToString());
            user.CurrencyId = int.Parse(dtUserDetails.Rows[0]["User_Preferred_Currency"].ToString());

            if (String.IsNullOrEmpty(dtUserDetails.Rows[0]["USER_PICTURE"].ToString()) || !System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "User/Thumbs/Thumb_" + dtUserDetails.Rows[0]["USER_PICTURE"].ToString())))
                user.Image = _config.GetValue<string>("EnvironmentURL") + "/Images/v2/Default.jpg";
            else
                user.Image = _config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dtUserDetails.Rows[0]["USER_PICTURE"].ToString();


            DataTable DTObjectAq = _user.UserGetUserEnrollmentsByLang(userWallId, langId, (int)ObjectsGroups.Badges);
            if (DTObjectAq.Rows.Count > 0)
            {
                user.BadgeName = DTObjectAq.Rows[0]["Profile_ObjectTitle"].ToString();
                user.BadgeImage = _config.GetValue<string>("EnvironmentURL") +DTObjectAq.Rows[0]["Master_ImageUrlBig"].ToString();
                //((Image)e.Item.FindControl("ImageExpert")).ImageUrl = "~/assets/images/circle-arrowsup.png";
            }
            else
            {
                user.BadgeName = _stringLocalizer["RegularUser"].Value;
                user.BadgeImage = _config.GetValue<string>("AssetsEnvironmentURL") + "images/badge_Regular.png";
            }
            return user;

        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult<ProposalFollowersResponse>> PitchGetFollowersByPage(ProposalFollowerRequestModel requestModel)
        {
            try
            {
                requestModel.LangId = Enum.IsDefined(typeof(Languages), requestModel.LangId) ? requestModel.LangId : (int)Languages.English;

                Tools.SetThreadCulture(requestModel.LangId);
                int recordCount = 0;
                bool hasMore = false;
                DataTable dtFollowers = await Task.FromResult(_pitch.PitchGetFollowersByPage(requestModel.PitchId,  (requestModel.PageNo + 1), requestModel.PageSize, out recordCount));
                hasMore = recordCount > ((requestModel.PageNo + 1) * requestModel.PageSize);

                List<Follower> proposalFollowers = new List<Follower>();

                if (dtFollowers != null)
                {
                    foreach (DataRow dr in dtFollowers.Rows)
                    {
                        Follower follower = new Follower();
                        follower.UserId = int.Parse(dr["User_ID"].ToString());
                        follower.Username = dr["User_Username"].ToString();
                        
                        DataTable dtUserDetails = _user.UserGetDetails(int.Parse(dr["User_ID"].ToString()), requestModel.LangId);
                        if (dtUserDetails.Rows.Count > 0)
                        {
                            follower.FirstName = dtUserDetails.Rows[0]["Profile_FirstName"].ToString() != null ? dtUserDetails.Rows[0]["Profile_FirstName"].ToString() : " " ;
                            follower.LastName = dtUserDetails.Rows[0]["Profile_LastName"].ToString() != null ? dtUserDetails.Rows[0]["Profile_LastName"].ToString() : " " ;
                            DataTable DTObject = _user.UserGetUserEnrollmentsByLang(follower.UserId, requestModel.LangId, (int)ObjectsGroups.Badges);
                            if (DTObject.Rows.Count > 0)
                            {
                                follower.ProfileObject = DTObject.Rows[0]["Profile_ObjectTitle"].ToString();
                            }
                            else
                            {
                                follower.ProfileObject = _stringLocalizer["RegularUser"].Value;
                            }
                        }
                        if (String.IsNullOrEmpty(dr["User_Picture"].ToString()) || !System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "User/thumbs/thumb_" + dr["User_Picture"].ToString())))
                            follower.UserImage = _config.GetValue<string>("EnvironmentURL") + "images/v2/Default.jpg";
                        else
                            follower.UserImage = _config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dr["User_Picture"].ToString();
                        
                        if (requestModel.UserId != null)
                        {
                            int userConnectionId = _user.UserGetUserConnectionId(requestModel.UserId.ToString(), dr["User_ID"].ToString());

                            follower.CanFollow = true;
                            if (dr["User_ID"].ToString() == requestModel.UserId.ToString())
                                follower.CanFollow = false;

                            if (userConnectionId > 0)
                                follower.IsFollowed = true;
                        }

                        proposalFollowers.Add(follower);
                    }

                }
                return Ok(new ProposalFollowersResponse (200, true, recordCount, hasMore, requestModel.PageNo, proposalFollowers));

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }
        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult> PitchGetTeam([FromQuery] PitchGeneral pitchGeneral)
        {
            try
            {
                Tools.SetThreadCulture((int)pitchGeneral.LangId);
                List<TeamMember> teamMembers = new List<TeamMember>();
                DataTable dtTeams = _pitch.PitchGetTeamsForPitch(pitchGeneral.PitchId, (int)pitchGeneral.LangId);
                if (dtTeams != null)
                {
                    if (dtTeams.Rows.Count > 0)
                    {
                        foreach (DataRow dr in dtTeams.Rows)
                        {
                            TeamMember member = new TeamMember();
                            member.Teams_Name = dr["Teams_Name"].ToString();
                            member.Teams_Image = _config.GetValue<string>("AttachementsEnvironmentURL") + "Pitch/team/thumbs/thumb_" + dr["Teams_Image"].ToString();
                            member.Teams_Position = dr["Teams_Position"].ToString();
                            member.Teams_Profile_ID = int.Parse(dr["Teams_Profile_ID"].ToString());

                            DataTable dtTeamProfile = _pitch.PitchGetTeamProfile(member.Teams_Profile_ID, (int)pitchGeneral.LangId);
                            if (dtTeamProfile.Rows.Count > 0)
                            {
                                member.Teams_Biography = dtTeamProfile.Rows[0]["Teams_Biography"].ToString();
                            }
                            teamMembers.Add(member);
                        }
                    }
                    return Ok(new { code = 200, success = true, teamMembers });
                }
                return Ok(new { code = 200, success = false, message = _stringLocalizer["ErrorOccurred"].Value });

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }
        [AllowAnonymous]
        [HttpGet]
        public async Task<ActionResult> PitchGetAttachment([FromQuery] PitchGetAttachment pitchGetAttachment)
        {
            try
            {
                PitchAttachment attachments = new PitchAttachment();
                DataTable dtAttachmentImages = await Task.FromResult(_pitchAttachementsRepository.PitchGetPitchAttachmentsByLangID(pitchGetAttachment.PitchId, (int)pitchGetAttachment.LangId, PitchAttachmentType.Image));
                List<string> images = new List<string>();

                if (dtAttachmentImages.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtAttachmentImages.Rows)
                    {
                        if (dr["PitchAttachment_Type"].ToString() == "image")
                        {
                            if (System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "Pitch/Thumbs/Thumb_" + dr["PitchAttachment_Name"].ToString())))
                            {
                                images.Add(_config.GetValue<string>("AttachementsEnvironmentURL") + "Pitch/Thumbs/Thumb_" + dr["PitchAttachment_Name"].ToString());

                            }
                            else
                                images.Add(_config.GetValue<string>("EnvironmentURL") + "/Images/v2/pitchDefault.jpg");
                        }
                    }

                    attachments.images = images;
                }

                DataTable dtAttachmentVideo = await Task.FromResult(_pitchAttachementsRepository.PitchGetPitchAttachmentsByLangID(pitchGetAttachment.PitchId, (int)pitchGetAttachment.LangId, PitchAttachmentType.Video));
                foreach (DataRow dr in dtAttachmentVideo.Rows)
                {

                    if (dr["PitchAttachment_Type"].ToString() == "video")
                    {
                        attachments.videoDescription = dr["PitchAttachment_VidDesc"].ToString();
                        attachments.videoId = dr["PitchAttachment_Name"].ToString();

                        if (pitchGetAttachment.PitchId == 10706)
                        {//special code for 9855 ticket 
                            if (pitchGetAttachment.LangId == Languages.Arabic)
                                attachments.videoId = "e1tmzo4dg7";
                            else
                                attachments.videoId = "93rpakx29j";
                        }
                    }
                }
                if (pitchGetAttachment.UserId != 0)
                {

                    DataTable dtPitchPrivateFiles = _pitchAttachementsRepository.PitchGetPitchAttachmentDocs(pitchGetAttachment.PitchId, (int)pitchGetAttachment.LangId, PitchAttachmentDocument.PrivateDocs);
                    if (dtPitchPrivateFiles.Rows.Count > 0) // this proposal has private docs
                    {

                        RequestAccessStatus status = _user.UserGetRequestStatus(pitchGetAttachment.UserId, pitchGetAttachment.PitchId, (int)RequestType.ViewingProposalPrivateDocument);
                        if (status == RequestAccessStatus.Pending || status == RequestAccessStatus.Rejected || status == RequestAccessStatus.NotRequested)
                        {
                            // show private and public
                            attachments.PrivateDoc = PrivateAttachmentDocs(pitchGetAttachment.PitchId, (int)pitchGetAttachment.LangId);
                            attachments.PublicDoc = PublicAttachmentDocs(pitchGetAttachment.PitchId, (int)pitchGetAttachment.LangId, "Public");
                        }
                        else if (status == RequestAccessStatus.Accepted)
                        {
                            // show all in one database
                            attachments.PublicDoc = PublicAttachmentDocs(pitchGetAttachment.PitchId, (int)pitchGetAttachment.LangId, "All");
                        }


                    }
                    else
                    {
                        attachments.PublicDoc = PublicAttachmentDocs(pitchGetAttachment.PitchId, (int)pitchGetAttachment.LangId, "Public");
                    }
                }

                return Ok(new { code = 200, success = true, attachments });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        protected List<ProposalDoc> PrivateAttachmentDocs(int pitchId, int langId)
        {

            DataTable dtPitchPrivateFiles = _pitchAttachementsRepository.PitchGetPitchAttachmentDocs(pitchId, langId, PitchAttachmentDocument.PrivateDocs);
            List<ProposalDoc> proposalDocs = new List<ProposalDoc>();
            if (dtPitchPrivateFiles.Rows.Count > 0)
            {
                foreach (DataRow dr in dtPitchPrivateFiles.Rows)
                {
                    ProposalDoc proposalDoc = new ProposalDoc();
                    proposalDoc.Id = dr["PitchAttachment_ID"].ToString();
                    proposalDoc.IsPrivate = true;
                    string imgName = proposalDoc.AttachementName = dr["PitchAttachment_Name"].ToString();
                    string[] spName = imgName.Split('.');
                    string imgType = spName[spName.Length - 1].ToLower();
                    proposalDoc.FileExtension = imgName.Split('.')[imgName.Split('.').Length - 1];
                    if (dr["PitchAttachment_Title"].ToString().Length < 15)
                        proposalDoc.AttachementTitle = dr["PitchAttachment_Title"].ToString();
                    else
                        proposalDoc.AttachementTitle = dr["PitchAttachment_Title"].ToString().Substring(0, 15) + "...";
                    proposalDoc.Icon = Tools.FileTypeImageMapping(_config.GetValue<string>("EnvironmentURL"), imgType);

                    proposalDocs.Add(proposalDoc);

                }

            }
            return proposalDocs;
        }

        protected List<ProposalDoc> PublicAttachmentDocs(int pitchId, int langId, string mode)
        {
            List<ProposalDoc> proposalDocs = new List<ProposalDoc>();
            DataTable dtPitchFiles;

            if (mode == "Public")
                dtPitchFiles = _pitchAttachementsRepository.PitchGetPitchAttachmentDocs(pitchId, langId, PitchAttachmentDocument.PublicDocs);
            else
                dtPitchFiles = _pitchAttachementsRepository.PitchGetPitchAttachmentDocs(pitchId, langId, PitchAttachmentDocument.All);

            if (dtPitchFiles.Rows.Count > 0)
            {
                foreach (DataRow dr in dtPitchFiles.Rows)
                {
                    ProposalDoc proposalDoc = new ProposalDoc();
                    proposalDoc.Id = dr["PitchAttachment_ID"].ToString();
                    proposalDoc.IsPrivate = true;
                    string imgName = proposalDoc.AttachementName = dr["PitchAttachment_Name"].ToString();
                    string[] spName = imgName.Split('.');
                    string imgType = spName[spName.Length - 1].ToLower();

                    if (dr["PitchAttachment_Title"].ToString().Length < 15)
                        proposalDoc.AttachementTitle = dr["PitchAttachment_Title"].ToString();
                    else
                        proposalDoc.AttachementTitle = dr["PitchAttachment_Title"].ToString().Substring(0, 15) + "...";

                    proposalDoc.Icon = Tools.FileTypeImageMapping(_config.GetValue<string>("EnvironmentURL"), imgType);

                    proposalDoc.FileURL = _config.GetValue<string>("AttachementsEnvironmentURL") + "Pitch/Files/" + dr["PitchAttachment_Guid"].ToString() + dr["PitchAttachment_Name"].ToString();
                    proposalDoc.FileExtension = imgName.Split('.')[imgName.Split('.').Length - 1];

                    proposalDocs.Add(proposalDoc);

                }

            }
            return proposalDocs;
        }

        [HttpGet]
        public async Task<ActionResult<Financials>> PitchGetFinancial([FromQuery] PitchFinancial pitchFinancial )
        {
            try
            {
                
                pitchFinancial.LangId = Enum.IsDefined(typeof(Languages), pitchFinancial.LangId) ? pitchFinancial.LangId : Languages.English;
                pitchFinancial.CurrencyId = Enum.IsDefined(typeof(Currencies), pitchFinancial.CurrencyId) ? pitchFinancial.CurrencyId : Currencies.USD;

                Financials financials = new Financials();
                DataTable dtPitchDetails = await Task.FromResult(_pitch.PitchGetDedicatedPitchDetailsByLang(pitchFinancial.PitchId, (int)pitchFinancial.LangId, (int)pitchFinancial.CurrencyId));
                
                if (dtPitchDetails.Rows.Count > 0)
                {
                    financials.Raised = Tools.FormatNumberWithCurrency((int)pitchFinancial.LangId, _general.CurrencyGetCurrencySymbol(pitchFinancial.CurrencyId), double.Parse(dtPitchDetails.Rows[0]["Pitch_Balance"].ToString()).ToString("#,##0"));
                    financials.BaseTarget = Tools.FormatNumberWithCurrency((int)pitchFinancial.LangId, _general.CurrencyGetCurrencySymbol(pitchFinancial.CurrencyId), double.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentRequired"].ToString()).ToString("#,##0"));
                    if (!string.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_HasMinInvestmentRequired"].ToString()) && bool.Parse(dtPitchDetails.Rows[0]["Pitch_HasMinInvestmentRequired"].ToString()))
                        financials.MinimumTarget = Tools.FormatNumberWithCurrency((int)pitchFinancial.LangId, _general.CurrencyGetCurrencySymbol(pitchFinancial.CurrencyId), double.Parse(dtPitchDetails.Rows[0]["Pitch_MinInvestmentRequired"].ToString()).ToString("#,##0"));

                }

                List<FinancialForecastModel> financialForecastModels = new List<FinancialForecastModel>();
                FinancialForecastModel totalRevenues = new FinancialForecastModel();
                FinancialForecastModel costOfSales = new FinancialForecastModel();
                FinancialForecastModel totalOperatingCosts = new FinancialForecastModel();
                FinancialForecastModel EBITDA = new FinancialForecastModel();
                FinancialForecastModel netIncome = new FinancialForecastModel();
                FinancialForecastModel taxes = new FinancialForecastModel();

                DataTable DTNumber_Text = await Task.FromResult(_pitch.PitchNumberTextGetAll(pitchFinancial.PitchId, (int)pitchFinancial.LangId));
                if (DTNumber_Text.Rows.Count > 0)
                {
                    financials.TableTitle = DTNumber_Text.Rows[0]["Number_Text_Content"].ToString();
                    financials.Currency = DTNumber_Text.Rows[1]["Number_Text_Content"].ToString();
                    financials.RowTableIndex = DTNumber_Text.Rows[2]["Number_Text_Content"].ToString();

                    if ((!String.IsNullOrEmpty(DTNumber_Text.Rows[2]["Number_Text_Content"].ToString())) && (DTNumber_Text.Rows[2]["Number_Text_Content"].ToString() == "ch1"))
                    {
                        financials.TableTitleForcast = _stringLocalizer["TotalRevenues"].Value;
                        totalRevenues.IsSelected = true;
                    }
                    else if ((!String.IsNullOrEmpty(DTNumber_Text.Rows[2]["Number_Text_Content"].ToString())) && (DTNumber_Text.Rows[2]["Number_Text_Content"].ToString() == "ch2"))
                    {
                        financials.TableTitleForcast = _stringLocalizer["TotalOperatingCosts"].Value;
                        totalOperatingCosts.IsSelected = true;
                    }
                    else if ((!String.IsNullOrEmpty(DTNumber_Text.Rows[2]["Number_Text_Content"].ToString())) && (DTNumber_Text.Rows[2]["Number_Text_Content"].ToString() == "ch3"))
                    {
                        financials.TableTitleForcast = _stringLocalizer["EBIDTA"].Value;
                        EBITDA.IsSelected = true;
                    }
                    else if ((!String.IsNullOrEmpty(DTNumber_Text.Rows[2]["Number_Text_Content"].ToString())) && (DTNumber_Text.Rows[2]["Number_Text_Content"].ToString() == "ch4"))
                    {
                        financials.TableTitleForcast = _stringLocalizer["Taxes"].Value;
                        taxes.IsSelected = true;
                    }
                    else if ((!String.IsNullOrEmpty(DTNumber_Text.Rows[2]["Number_Text_Content"].ToString())) && (DTNumber_Text.Rows[2]["Number_Text_Content"].ToString() == "ch5"))
                    {
                        financials.TableTitleForcast = _stringLocalizer["NetIncomeProfit"].Value;
                        netIncome.IsSelected = true;
                    }
                    else if ((!String.IsNullOrEmpty(DTNumber_Text.Rows[2]["Number_Text_Content"].ToString())) && (DTNumber_Text.Rows[2]["Number_Text_Content"].ToString() == "ch6"))
                    {
                        financials.TableTitleForcast = _stringLocalizer["CostSales"].Value;
                        costOfSales.IsSelected = true;
                    }

                }
                //Set the title
                totalRevenues.Title = _stringLocalizer["TotalRevenues"].Value;
                totalOperatingCosts.Title = _stringLocalizer["TotalOperatingCosts"].Value;
                EBITDA.Title = _stringLocalizer["EBIDTA"].Value;
                costOfSales.Title = _stringLocalizer["CostSales"].Value;
                netIncome.Title = _stringLocalizer["NetIncomeProfit"].Value;
                taxes.Title = _stringLocalizer["Taxes"].Value;

                List<string> summary = new List<string>();
                List<string> totalRevenuesList = new List<string>();
                List<string> costOfSalesList = new List<string>();
                List<string> totalOperatingCostsList = new List<string>();
                List<string> EBITDAList = new List<string>();
                List<string> netIncomeList = new List<string>();
                List<string> taxesList = new List<string>();
                DataTable dtNumbers = await Task.FromResult(_pitch.PitchTheNumbersGetAll(pitchFinancial.PitchId));
                int dtNumbersRowIndex = 0;
                if (dtNumbers.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtNumbers.Rows)
                    {
                        summary.Add(dr["Number_Summary"].ToString());
                        totalRevenuesList.Add(dr["Number_Total_Revenues"].ToString());
                        costOfSalesList.Add(dr["Number_Cost_Sales"].ToString());
                        totalOperatingCostsList.Add(dr["Number_Fixed_Operating_Costs"].ToString());
                        EBITDAList.Add(dr["Number_Operating_Profit"].ToString());
                        netIncomeList.Add(dr["Number_Profit"].ToString());
                        taxesList.Add(dr["Number_Taxes"].ToString());
                    }
                }

                financials.Summary = summary;
                //Set the Data S

                if (!CheckIfListJustContainZero(totalRevenuesList))
                {
                    totalRevenues.Data = totalRevenuesList;
                    SetTheZeroColumn(totalRevenues.Data);
                    financialForecastModels.Add(totalRevenues);
                }
                if (!CheckIfListJustContainZero(costOfSalesList) )
                {
                    costOfSales.Data = costOfSalesList;
                    SetTheZeroColumn(costOfSales.Data);
                    financialForecastModels.Add(costOfSales);

                }
                if (!CheckIfListJustContainZero(totalOperatingCostsList))
                {
                    totalOperatingCosts.Data = totalOperatingCostsList;
                    SetTheZeroColumn(totalOperatingCosts.Data);
                    financialForecastModels.Add(totalOperatingCosts);


                }
                if (!CheckIfListJustContainZero(EBITDAList))
                {
                    EBITDA.Data = EBITDAList;
                    SetTheZeroColumn(EBITDA.Data);
                    financialForecastModels.Add(EBITDA);

                }
                if (!CheckIfListJustContainZero(netIncomeList))
                {
                    netIncome.Data = netIncomeList;
                    SetTheZeroColumn(netIncome.Data);
                    financialForecastModels.Add(netIncome);

                }
                if (!CheckIfListJustContainZero(taxesList))
                {
                    taxes.Data = taxesList;
                    SetTheZeroColumn(taxes.Data);
                    financialForecastModels.Add(taxes);
                }


                double totalInvPercent = 0;
                int rowIndex = 0;
                List<FinancialInvestementModel> investors = new List<FinancialInvestementModel>();
                DataTable dtInvestmentChart = _pitch.PitchGetInvestorsForPitchByFund(pitchFinancial.PitchId, 7, (int)pitchFinancial.LangId, (int)pitchFinancial.CurrencyId);
                if (dtInvestmentChart.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtInvestmentChart.Rows)
                    {
                        FinancialInvestementModel financialInvestementModel = new FinancialInvestementModel();
                        financialInvestementModel.UserId = dr["User_ID"].ToString();
                        financialInvestementModel.FirstName = dr["Profile_FirstName"].ToString();
                        financialInvestementModel.LastName = dr["Profile_LastName"].ToString();
                        if (string.IsNullOrEmpty(dr["User_Picture"].ToString()) || (!string.IsNullOrEmpty(dr["User_Picture"].ToString()) && !System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "User/thumbs/thumb_" + dr["User_Picture"].ToString()))))
                            financialInvestementModel.Picture = _config.GetValue<string>("EnvironmentURL") + "/images/v2/Default.jpg";
                        else
                            financialInvestementModel.Picture = _config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dr["User_Picture"].ToString();

                        financialInvestementModel.Username = dr["User_Username"].ToString();
                        financialInvestementModel.UserObject = dr["Profile_Object"].ToString();
                        financialInvestementModel.UserScore = dr["User_Score"].ToString();
                        financialInvestementModel.InvestmentAmount = !string.IsNullOrEmpty(dr["InvAmmount"].ToString()) ? Double.Parse(dr["InvAmmount"].ToString()) : 0;
                        financialInvestementModel.InvestmentDate = dr["investemntDate"].ToString();
                        financialInvestementModel.InvestmentPercent = dr["invpercent"].ToString();
                        totalInvPercent += double.Parse(dr["invpercent"].ToString());
                        financialInvestementModel.XAxis = rowIndex;
                        financialInvestementModel.YAxis = totalInvPercent;
                        rowIndex++;
                        investors.Add(financialInvestementModel);
                    }
                }
                financials.FinancialForecastModels = financialForecastModels;
                financials.InvestmentChartData = investors;
                return Ok(new { code = 200, success = true, totalInvPercent = totalInvPercent, financials });

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");

            }

        }

        private bool CheckIfListJustContainZero(List<string> list)
        {
            for (int i =0; i< list.Count; i++)
            {
                if (!string.IsNullOrEmpty(list[i]) && list[i] != "0")
                {
                    return false;

                }

            }

            return true;
        }

        [HttpGet]
        public async Task<ActionResult> PitchGetAllEOIProposals(int langId, string? searchText, bool allActiveNotActiveProposals)
        {
            try
            {
                List<EOIProposal> proposals = new List<EOIProposal>();
                if (langId == (int) Languages.Arabic)
                {
                    var cultureInfo = CultureInfo.GetCultureInfo("ar-SA");
                    Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = cultureInfo;
                }
                DataTable response = await Task.FromResult(_pitch.PitchGetAllEOIProposals( langId, searchText, allActiveNotActiveProposals));
                if (response == null) { return NotFound(); }
                if (response.Rows.Count > 0)
                {
                    foreach (DataRow dr in response.Rows)
                    {
                        EOIProposal proposal = new EOIProposal();
                        proposal.PitchId = int.Parse(dr["id"].ToString());
                        proposal.PitchTitle = dr["text"].ToString();
                        proposals.Add(proposal);
                    }
                }

                return Ok(new { code = 200, success = true, proposals });

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        public async Task<IActionResult> UserContatSME(UserContatSME userContatSME)
        {
            try
            {
                userContatSME.UserId = int.Parse(_userId); 
                DataTable dtUserDetails = await Task.FromResult(_user.UserSelectById(userContatSME.UserId));
                if (dtUserDetails.Rows.Count > 0)
                {
                    if (userContatSME.RequestType == (int)RequestType.RequestMeetingWithEnt)
                    {
                        _message.MessageSendMessageWhenUserRequestToContactProposalOwner(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), dtUserDetails.Rows[0], _pitch.PitchGetPitchOwner(userContatSME.PitchId), "", RequestType.RequestMeetingWithEnt);
                        return Ok(new { code = 200, success = true, message = _stringLocalizer["RequestMeetingSent"].Value });

                    }
                    else if (userContatSME.RequestType == (int)RequestType.RequestCallWithEnt)
                    {
                        _message.MessageSendMessageWhenUserRequestToContactProposalOwner(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), dtUserDetails.Rows[0], _pitch.PitchGetPitchOwner(userContatSME.PitchId), "", RequestType.RequestCallWithEnt);
                        return Ok(new { code = 200, success = true, message = _stringLocalizer["RequestCallSent"].Value });

                    }
                }
                return Ok(new { code = 200, success = true, message = _stringLocalizer["ErrorOccurred"].Value });

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }
        protected bool UserIsUserAllowToViewInvisiblePitch(long UserID)
        {
            try
            {
                bool display = true;

                DataTable dtUserObjects = _user.UserGetUserEnrollments(UserID, (int)ObjectsGroups.Badges);

                foreach (DataRow dr in dtUserObjects.Rows)
                {
                    if (!string.IsNullOrEmpty(dr["Details_ObjectID"].ToString()))
                    {
                        if (int.Parse(dr["Details_ObjectID"].ToString()) != (int)InvestorBadges.DiamondInvestor)
                        {
                            display = true;  // display only public to view pitches
                        }
                        else if (int.Parse(dr["Details_ObjectID"].ToString()) == (int)InvestorBadges.DiamondInvestor)
                        {
                            display = false; // Display private pitches
                        }
                    }
                }

                return display;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return true;
            }
        }

        [HttpPost]
        public async Task<IActionResult> PitchRequestPrivateDocs(PrivateDocumentRequestModel request)
        {
            try
            {
                request.UserId = int.Parse(_userId);
                if (request.UserId != 0)
                {
                    var response = _user.UserGetRequestStatus(request.UserId, request.PitchId, (int)RequestType.ViewingOpaqueProposal);
                    if (response == RequestAccessStatus.Pending)
                        return Ok(new { code = 200, success = false, message = _stringLocalizer["PendingRequest"].Value });
                    else if (response == RequestAccessStatus.Accepted)
                        return Ok(new { code = 200, success = false, message = _stringLocalizer["ApprovedRequest"].Value });
                    else if (response == RequestAccessStatus.Rejected || response == RequestAccessStatus.NotRequested)
                    {
                        if (request.PitchId != 0  && request.PitchTitle != null)
                        {
                            
                            _user.AddRequest(request.UserId, request.PitchId, "Request to access the opaque proposal:" + Tools.FilterHTML(request.PitchTitle), (int)RequestType.ViewingOpaqueProposal);
                            DataTable getUserDetails = _user.UserGetDetails(request.UserId, (int) Languages.English);
                            if (getUserDetails.Rows.Count == 0)
                            {
                                _user.UserGetDetails(request.UserId, (int)Languages.Spanish);
                                if (getUserDetails.Rows.Count == 0)
                                    _user.UserGetDetails(request.UserId, (int)Languages.Arabic);
                            }

                            _message.MessageSendMessageWhenUserRequest(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), getUserDetails.Rows[0], _pitch.PitchGetPitchOwner(request.PitchId), request.PitchTitle, RequestType.ViewingOpaqueProposal);
                            return Ok(new { code = 200, success = true, message = _stringLocalizer["SuccessViewRequestSent"].Value });
                        }
                        else
                            return Ok(new { code = 200, success = false, message = _stringLocalizer["TryAgain"].Value });

                    }
                }
                return Ok(new { code = 200, success = false, message = _stringLocalizer["NeedLogin"].Value });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpGet]
        public async Task<IActionResult> PitchRequestPrivateDocsPopupText([Required] int langId)
        {
            try 
            {
                Tools.SetThreadCulture(langId);
                return Ok(new { code = 200, success = true, title = _stringLocalizer["LblPrivateDocConfirmTitle"].Value ,message = _stringLocalizer["LblPrivateDocConfirmBody"].Value });

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet]
        public async Task<IActionResult> PitchGetInvestorsFilterList([FromQuery]CurrencyPitchGeneral pitchGeneral)
        {
            try
            {
               

                List< InvestorFilter> filters = new List< InvestorFilter>();
                double rate = await Task.FromResult(_pitch.PitchGetPitchRateAsDouble(pitchGeneral.PitchId, (int)pitchGeneral.CurrencyId));
                double investRangeFirst = 10000 * rate;
                double investRangeSecond = 100000 * rate;
                DataTable dtCurreny = _general.CurrencyGetCurrencyByID((int)pitchGeneral.CurrencyId);
                string currencySymbol = dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$";


                if (pitchGeneral.LangId == Languages.Arabic)
                {
                    var cultureInfo = CultureInfo.GetCultureInfo("ar-SA");
                    Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = cultureInfo;  
                    
                    filters.Add(new InvestorFilter(1,String.Format("0 - {0}{1}", investRangeFirst.ToString("#,##0"), currencySymbol), 1));
                    filters.Add(new InvestorFilter(2,String.Format("{0}{2} - {1}{2}", investRangeFirst.ToString("#,##0"), investRangeSecond.ToString("#,##0"), currencySymbol), 2));
                    filters.Add(new InvestorFilter(3, String.Format("{0}{1}+", investRangeSecond.ToString("#,##0"), currencySymbol), 3));

                }
                else
                {
                    filters.Add(new InvestorFilter(1, String.Format("0 - {1}{0}", investRangeFirst.ToString("#,##0"), currencySymbol), 1));
                    filters.Add(new InvestorFilter(2, String.Format("{2}{0} - {2}{1}", investRangeFirst.ToString("#,##0"), investRangeSecond.ToString("#,##0"), currencySymbol), 2));
                    filters.Add(new InvestorFilter(3, String.Format("{1}{0}+", investRangeSecond.ToString("#,##0"), currencySymbol), 3));
                }

                filters.Add(new InvestorFilter(4, _stringLocalizer["ViewAllByInvestmentSize"].Value, 4));
                return Ok(new { code = 200, success = true, filters });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }



        }
        private void SetTheZeroColumn(List<string> data)
        {
            if (data.Count >= 5)
                for (int i = 3; i < 5; i++)
                {
                    if (data[i] == "0" || data[i] == "-")
                        data[i] = "-";

                }            
        }
        [HttpPost]
        public async Task<ActionResult<GeneralResponseMessage>> PitchAddUpdate(AddUpdateRequestModel addUpdateRequestModel)
        {
            try
            {
                
                Tools.SetThreadCulture(addUpdateRequestModel.LangId);
                int pitchUpdateId = _pitch.PitchAddPitchUpdate("", addUpdateRequestModel.PitchId, addUpdateRequestModel.Update, addUpdateRequestModel.LangId);
                if (pitchUpdateId > 0)
                {
                    _pitch.PitchAddPitchUpdateAttachment(pitchUpdateId, "", addUpdateRequestModel.Update, "");
                    DataTable pitchDetail = _pitch.PitchGetDedicatedPitchDetails(addUpdateRequestModel.PitchId, addUpdateRequestModel.LangId);
                    if(pitchDetail.Rows.Count > 0)
                    {
                        _message.MessageSendAddProposalUpdateEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), pitchDetail.Rows[0]);
                        return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, "", _stringLocalizer["PitchSavedSuccessfully"].Value)));
                    }
                    return await Task.FromResult(NotFound(new GeneralResponseMessage(404, true, "", _stringLocalizer["OperationFailed"].Value)));
                }
                return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["OperationFailed"].Value)));
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet]
        public async Task<ActionResult<ProposalRequestResponse>> PitchGetAllUserRequest([FromQuery]PitchGetAllUserRequest pitchGetAllUserRequest)
        {
            try
            {
                Tools.SetThreadCulture((int)pitchGetAllUserRequest.LangId);
                int totalRows = 0;
                bool hasMore = true;
                bool enableApprovaAllBtn = false;
                List<ProposalRequest> proposalRequests = new List<ProposalRequest>();
                DataTable dtPropsoalRequests = _pitch.PitchGetProposalRequestsPaging(pitchGetAllUserRequest.ProposalId, (int)pitchGetAllUserRequest.LangId, 0, pitchGetAllUserRequest.PageNo, pitchGetAllUserRequest.PageSize, out totalRows);
                if (dtPropsoalRequests.Rows.Count == 0)
                    return await Task.FromResult(Ok(new ProposalRequestResponse( 200,true, totalRows, false, pitchGetAllUserRequest.PageNo, enableApprovaAllBtn, proposalRequests )));

                hasMore = totalRows > ((pitchGetAllUserRequest.PageNo + 1) * pitchGetAllUserRequest.PageSize);

                foreach (DataRow dr in dtPropsoalRequests.Rows)
                {
                    ProposalRequest proposalRequest = new ProposalRequest();
                    proposalRequest.UserId = int.Parse(dr["User_ID"].ToString());
                    proposalRequest.RequestId = int.Parse(dr["Request_ID"].ToString());
                    proposalRequest.RequestType = int.Parse(dr["Request_Type"].ToString());
                    proposalRequest.Username = dr["UserName"].ToString();

                    
                    proposalRequest.Status = (int) _user.UserGetRequestStatusByRequestId(proposalRequest.RequestId);

                    if (dr["PendingPrivDocRequestsNum"].ToString() != "0")
                        enableApprovaAllBtn = true;

                    switch (dr["Request_Type"].ToString())
                    {
                        case "9":
                            proposalRequest.RequestTypeText = _stringLocalizer["PrivateDocuments"].Value;
                            break;
                        case "23":
                            proposalRequest.RequestTypeText = _stringLocalizer["AccessCodeRequest"].Value;
                            break;
                        case "12":
                            proposalRequest.RequestTypeText = _stringLocalizer["OpaqueRequest"].Value;
                            break;
                    }

                    proposalRequests.Add(proposalRequest);



                }


                return await Task.FromResult(Ok(new ProposalRequestResponse (200, true, totalRows, hasMore, pitchGetAllUserRequest.PageNo, enableApprovaAllBtn, proposalRequests )));

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpPost]
        public async Task<ActionResult<GeneralResponseMessage>> PitchRejectRequest(ProccessRequest rejectRequest)
        {
            try
            {
                rejectRequest.UserId = int.Parse(_userId);
                Tools.SetThreadCulture(rejectRequest.LangId);

                if (rejectRequest.UserId == 0)
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["NeedLogin"].Value)));

                RequestAccessStatus status = _user.UserGetRequestStatusByRequestId(rejectRequest.RequestId);

                if (status == RequestAccessStatus.Pending)
                {
                    DataTable dtPitchDetails = _pitch.PitchGetDedicatedPitchDetailsByLang(rejectRequest.ProposalId, (int) Languages.English);
                    if (dtPitchDetails.Rows.Count > 0)
                    {
                        DataTable getUserDetails = _user.UserGetDetails(rejectRequest.UserId, (int)Languages.English);
                        if (getUserDetails.Rows.Count == 0)
                        {
                            getUserDetails = _user.UserGetDetails(rejectRequest.UserId, (int)Languages.Spanish);
                            if (getUserDetails.Rows.Count == 0)
                                getUserDetails = _user.UserGetDetails(rejectRequest.UserId, (int)Languages.Arabic);
                        }
                        _user.UserUpdateRequestRejectFlag(rejectRequest.RequestId);
                        _message.MessageSendRequestRejectionEmail(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), getUserDetails.Rows[0], dtPitchDetails.Rows[0], RequestType.ViewingProposalPrivateDocument);
                        return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, "", _stringLocalizer["TheRequestRejected"].Value)));
                    }

                }
                else if (status == RequestAccessStatus.Accepted)
                {
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["TheRequestApprovedByAdmin"].Value))); 
                }
                else if (status == RequestAccessStatus.Rejected)
                {
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["TheRequestRejectedByAdmin"].Value))); 
                }

                return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["TryAgain"].Value))); 
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        public async Task<ActionResult<GeneralResponseMessage>> PitchAcceptRequest(AcceptRequest acceptRequest)
        {
            try
            {
                acceptRequest.UserId = int.Parse(_userId);
                Tools.SetThreadCulture(acceptRequest.LangId);

                if (acceptRequest.UserId == 0)
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["NeedLogin"].Value)));

                RequestAccessStatus status = _user.UserGetRequestStatusByRequestId(acceptRequest.RequestId);

                if (status == RequestAccessStatus.Pending)
                {
                    DataTable dtPitchDetails = _pitch.PitchGetDedicatedPitchDetailsByLang(acceptRequest.ProposalId, (int)Languages.English);
                    if (dtPitchDetails.Rows.Count > 0)
                    {
                        DataTable getUserDetails = _user.UserGetDetails(acceptRequest.UserId, (int)Languages.English);
                        if (getUserDetails.Rows.Count == 0)
                        {
                            getUserDetails = _user.UserGetDetails(acceptRequest.UserId, (int)Languages.Spanish);
                            if (getUserDetails.Rows.Count == 0)
                                getUserDetails = _user.UserGetDetails(acceptRequest.UserId, (int)Languages.Arabic);
                        }
                        _user.UserUpdateUserRequestFlag(acceptRequest.RequestId);
                        _message.MessageSendUserRequestWhenAcceptance(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), getUserDetails.Rows[0], dtPitchDetails.Rows[0], acceptRequest.RequestType);
                        return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, "", _stringLocalizer["TheRequestApproved"].Value)));
                    }

                }
                else if (status == RequestAccessStatus.Accepted)
                {
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["TheRequestApprovedByAdmin"].Value)));
                }
                else if (status == RequestAccessStatus.Rejected)
                {
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["TheRequestRejectedByAdmin"].Value)));
                }

                return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["TryAgain"].Value)));
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPost]
        public async Task<ActionResult<GeneralResponseMessage>> PitchApproveAllRequest(ApproveAllUserRequest approveAllUserRequest)
        {
            try
            {
                approveAllUserRequest.UserId = int.Parse(_userId);
                Tools.SetThreadCulture(approveAllUserRequest.LangId);

                if (approveAllUserRequest.UserId == 0)
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["NeedLogin"].Value)));


                DataTable dtPitchDetails = _pitch.PitchGetDedicatedPitchDetailsByLang(approveAllUserRequest.ProposalId, approveAllUserRequest.LangId);
                if (dtPitchDetails.Rows.Count == 0)
                    dtPitchDetails = _pitch.PitchGetDedicatedPitchDetailsByLang(approveAllUserRequest.ProposalId, (int)Languages.English);

                if (dtPitchDetails.Rows.Count == 0 || dtPitchDetails.Rows[0]["Pitch_UserID"].ToString() != approveAllUserRequest.UserId.ToString())
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["NoPrivDocReq"].Value)));


                DataTable dtUserRequestList = _user.UserGetProposalRequests(approveAllUserRequest.ProposalId, approveAllUserRequest.LangId, (int) RequestType.ViewingProposalPrivateDocument);

                if (dtUserRequestList.Rows.Count == 0)
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["NoPrivDocReq"].Value)));


                foreach (DataRow drUserRequestList in dtUserRequestList.Rows)
                {
                    if (!bool.Parse(drUserRequestList["flag"].ToString()) && !bool.Parse(drUserRequestList["Reject_Flag"].ToString()))
                    {
                        DataTable getUserDetails = _user.UserGetDetails(int.Parse(drUserRequestList["User_ID"].ToString()), (int) Languages.English);
                        if (getUserDetails.Rows.Count == 0)
                        {
                            getUserDetails = _user.UserGetDetails(int.Parse(drUserRequestList["User_ID"].ToString()), (int)Languages.Spanish);
                            if (getUserDetails.Rows.Count == 0)
                                getUserDetails = _user.UserGetDetails(int.Parse(drUserRequestList["User_ID"].ToString()), (int)Languages.Arabic);
                        }
                        _user.UserUpdateUserRequestFlag(int.Parse(drUserRequestList["Request_ID"].ToString()));
                        _message.MessageSendUserRequestWhenAcceptance(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), getUserDetails.Rows[0], dtPitchDetails.Rows[0], (int)RequestType.ViewingProposalPrivateDocument);
                    }
                }
                return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, "", _stringLocalizer["TheRequestApproved"].Value)));

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }
        [HttpPost]
        public async Task<ActionResult> PitchRequestAccessEarlyAccess(AddNewInterest requestModel)
        {
            try
            {
                Tools.SetThreadCulture((int)requestModel.LangId);
                int loggedUserID = int.Parse(_userId);
                DataTable dtUserDetails = _user.UserSelectById(loggedUserID);
                if (dtUserDetails.Rows.Count <= 0)
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["NotExistingUser"].Value)));
                DataTable dtPitchDetails = _pitch.PitchGetDedicatedPitchDetails(requestModel.PitchId, (int)requestModel.LangId);
                if (dtPitchDetails.Rows.Count <= 0)
                {
                    dtPitchDetails = _pitch.PitchGetDedicatedPitchDetails(requestModel.PitchId, (int)Languages.English);
                    if (dtPitchDetails.Rows.Count <= 0)
                        return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["ErrorOccurred"].Value)));

                }

                RequestAccessStatus requestStatus = _user.UserGetRequestStatus(loggedUserID, requestModel.PitchId, (int)RequestType.RequestAccessCode);

                if (requestStatus == RequestAccessStatus.Pending)
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, "", _stringLocalizer["PendingRequest"].Value)));
                else
                {
                    _user.AddRequest(loggedUserID, requestModel.PitchId, "The user " + dtUserDetails.Rows[0]["User_Username"].ToString() + " with email address: " + dtUserDetails.Rows[0]["user_email"] + " is requesting to access the proposal " + dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString(), (int)RequestType.RequestAccessCode);
                    _message.MessageSendMessageWhenUserRequest(_user.UserGetSystemAdmin(), _user.UserGetAdmins(), dtUserDetails.Rows[0], _pitch.PitchGetPitchOwner(requestModel.PitchId), dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString(), RequestType.RequestAccessCode);
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, _stringLocalizer[""].Value, _stringLocalizer["SuccessViewRequestSent"].Value)));

                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");

            }
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult<GeneralResponseMessage>> PitchAddNewInterest(AddNewInterest newInterest)
        {
            try
            {
                if (!Tools.IsValidEmail(newInterest.Email))
                    return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["ValidEmailOrAccessCode"].Value)));


                DataTable dtPitchDetails = _pitch.PitchGetDedicatedPitchDetailsByLang(newInterest.PitchId, (int)newInterest.LangId);
                if (dtPitchDetails.Rows.Count > 0)
                {
                    if (_lead.LeadUsersGetLeadByEmail(newInterest.Email).Rows.Count > 0)
                        return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, "", "")));

                    _lead.LeadUsersAddNewLead(0, (int)UserType.Investor, newInterest.Email, newInterest.FirstName, newInterest.LastName, (int)LeadSource.EarlyAccessPage, new string[] { newInterest.PitchId.ToString() }, "", "Early access page", newInterest.CountryId, newInterest.Phone, "", "", "", 0, true);
                    DataTable dtInvestorContactableBySME = _user.UserCheckInvestorContactableBySME(newInterest.Email, newInterest.PitchId);
                    if (dtInvestorContactableBySME.Rows.Count == 0 && (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "Early Access" || dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "published" || dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "Overfunding"))
                        if (_user.UserSMEContactAdd(newInterest.Email, newInterest.PitchId, true) > 0)
                            return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, "", "")));
                        else
                            return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", "")));
                    else
                        return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, "", "")));
                }
                return await Task.FromResult(Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["ErrorOccurred"].Value)));

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");

            }




        }


        [HttpPost]
        public async Task<ActionResult<GeneralResponseMessage>> PitchAddNewLead(AddNewLead newLead)
        {
            if (string.IsNullOrEmpty(newLead.Email) || !Tools.IsValidEmail(newLead.Email))
                return await Task.FromResult(Ok(new { code = 200, success = false ,message = _stringLocalizer["ValidEmailOrAccessCode"].Value, openNewInterest = false }));



            DataTable DTUserData = _user.SelectUserByEmail(newLead.Email);
            if (DTUserData.Rows.Count > 0)
            {
                _lead.LeadUsersAddNewLead(0, int.Parse(DTUserData.Rows[0]["User_UserType"].ToString()), newLead.Email, DTUserData.Rows[0]["Profile_FirstName"].ToString(), DTUserData.Rows[0]["Profile_LastName"].ToString(), (int)LeadSource.EarlyAccessPage, new string[] { newLead.PitchId.ToString() }, "", "Early access page", int.Parse(DTUserData.Rows[0]["User_Country"].ToString()), DTUserData.Rows[0]["User_Phone"].ToString(), "", "", "", int.Parse(DTUserData.Rows[0]["User_ID"].ToString()), true);
                return await Task.FromResult(Ok(new { code = 200, success = true, openNewInterest = false }));

            }
            else
            {
                DataTable dtLeadData = _lead.LeadUsersGetLeadByEmail(newLead.Email);
                if (dtLeadData.Rows.Count > 0)
                {
                    _lead.LeadUsersAddNewLead(0, (int)UserType.Investor, newLead.Email, dtLeadData.Rows[0]["Lead_FirstName"].ToString(), dtLeadData.Rows[0]["Lead_LastName"].ToString(), (int)LeadSource.EarlyAccessPage, new string[] { newLead.PitchId.ToString() }, "", "Early access page", newLead.CountryId, dtLeadData.Rows[0]["Lead_Phone"].ToString(), "", "", "", 0, true);
                    return await Task.FromResult(Ok(new { code = 200, success = true, openNewInterest = false }));

                }
            }


            return await Task.FromResult(Ok(new {code = 200, success = true,  openNewInterest = true}));



        }



        [HttpPost]
		public async Task<ActionResult<PitchListResponse>> PitchGetCompletedPitchs(GetCompletedPitchListRequest requestModel)
		{
			try
			{
				Tools.SetThreadCulture((int)requestModel.LangId);

				if ((int)requestModel.LangId == 2)
				{
					var cultureInfo = CultureInfo.GetCultureInfo("ar-SA");
					Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = cultureInfo;
				}

				DataTable dtCurreny = _general.CurrencyGetCurrencyByID((int)requestModel.CurrencyId);
				string currencySymbol = (dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$") ?? "$";


				var response = await Task.FromResult(_pitch.PitchGetCompletedPitchsList((int)requestModel.LangId, (int)requestModel.CurrencyId,
					requestModel.CountryId, requestModel.UserId, (int)requestModel.CategoryID, Tools.GetEnumDescription(requestModel.Sorting),
					requestModel.TagID, requestModel.PageNo, requestModel.PageSize, currencySymbol, out var recordCount));

				var hasMore = recordCount > ((requestModel.PageNo + 1) * requestModel.PageSize);

				return Ok(new PitchListResponse(200, true, recordCount, hasMore, requestModel.PageNo, response));
			}
			catch (Exception ex)
			{
				_errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
				return StatusCode(500, ex.Message);
			}
		}

		/// <summary>
		/// Returns the List of Proposals based on the filtration criteria
		/// </summary>
		/// <returns></returns>
		[HttpPost]
		public async Task<ActionResult<PitchListResponse>> PitchGetLivePitchs(GetLivePitchListRequest requestModel)
		{
			try
			{
				Tools.SetThreadCulture((int)requestModel.LangId);

				if ((int)requestModel.LangId == 2)
				{
					var cultureInfo = CultureInfo.GetCultureInfo("ar-SA");
					Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = cultureInfo;
				}

				DataTable dtCurreny = _general.CurrencyGetCurrencyByID((int)requestModel.CurrencyId);
				string currencySymbol = (dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$") ?? "$";


				var response = await Task.FromResult(_pitch.PitchGetLivePitchsList((int)requestModel.LangId, (int)requestModel.CurrencyId,
					requestModel.CountryId, requestModel.UserId, (int)requestModel.CategoryID, Tools.GetEnumDescription(requestModel.Sorting),
					requestModel.TagID, requestModel.PageNo, requestModel.PageSize, currencySymbol, requestModel.IsPublished, out var recordCount));

				var hasMore = recordCount > ((requestModel.PageNo + 1) * requestModel.PageSize);

				return Ok(new PitchListResponse(200, true, recordCount, hasMore, requestModel.PageNo, response));
			}
			catch (Exception ex)
			{
				_errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
				return StatusCode(500, ex.Message);
			}
		}
        
		
		[HttpGet]
		public async Task<IActionResult> PitchGetAllCategories([Required] int langId)
		{
			try
			{
				if (langId == (int)Languages.Arabic)
				{
					var cultureInfo = CultureInfo.GetCultureInfo("ar-SA");
					Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = cultureInfo;
				}

				var categories = Tools.ConvertDataTable<Category>(_pitch.PitchGetAllPitchCategories(langId));

				return Ok(new { code = 200, success = true, categories });

			}
			catch (Exception ex)
			{
				_errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
				return StatusCode(500, ex.Message);
			}
		}

        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult> UserGetActiveProposal(GetPitchOnViewProfilePage requestModel)
        {
            try
            {
                double rate = 0;
                Pitch pitch = new Pitch();
                DataTable dtActiveProposal = _pitch.PitchGetUserActivePitchAndValid(requestModel.UserId);
                if (dtActiveProposal.Rows.Count <= 0)
                    return Ok(new { code = 200, success = true, hasProposal = false });

                int pitchId = int.Parse(dtActiveProposal.Rows[0]["Pitch_ID"].ToString());


                DataTable dtActiveProposalDetails = _pitch.PitchGetDedicatedPitchDetailsByLang(pitchId, (int)requestModel.LangId, requestModel.CurrecnyId);
                if (dtActiveProposalDetails.Rows.Count <= 0 || _pitch.PitchIsProposalViewPrevented(dtActiveProposalDetails.Rows[0], requestModel.CountryId, _userId))
                    return Ok(new { code = 200, success = true, hasProposal = false });

                int tempout = 0;
                _pitch.PitchTestExpiration((int)requestModel.LangId, pitchId);
                DataTable dtCurreny = _general.CurrencyGetCurrencyByID((int)requestModel.CurrecnyId);
                string currencySymbol = dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$";

                pitch.Pitch_ID = pitchId;
                pitch.Pitch_InvestmentRequiredFormatted = Tools.FormatNumberWithCurrency((int)requestModel.LangId, currencySymbol, double.Parse(dtActiveProposal.Rows[0]["Pitch_InvestmentRequired"].ToString()).ToString("#,##0"));
                pitch.Pitch_BalanceFormatted = Tools.FormatNumberWithCurrency((int)requestModel.LangId, currencySymbol, double.Parse(dtActiveProposal.Rows[0]["Pitch_Balance"].ToString()).ToString("#,##0"));
                pitch.Pitch_Balance = double.Parse(dtActiveProposal.Rows[0]["Pitch_Balance"].ToString());
                pitch.Pitch_InvestmentRequired = double.Parse(dtActiveProposal.Rows[0]["pitch_InvestmentRequired"].ToString());
                pitch.Pitch_Investors = int.Parse(dtActiveProposalDetails.Rows[0]["pitch_Investors"].ToString());
                pitch.Profile_PitchTitle = dtActiveProposalDetails.Rows[0]["Profile_PitchTitle"].ToString();
                pitch.Pitch_HasDiscount = bool.Parse(dtActiveProposalDetails.Rows[0]["Pitch_HasDiscount"].ToString());

                #region badges
                DataTable dtBadges = _pitch.PitchBadgesAssignedGetAll(1, 100, (int)requestModel.LangId, pitchId, out tempout);
                List<Badge> badges = new List<Badge>();
                if (dtBadges.Rows.Count > 0)
                {
                    badges = JsonConvert.DeserializeObject<List<Badge>>(dtBadges.Rows[0]["Badges"].ToString());
                }
                pitch.Badges = badges;
                #endregion
                pitch.profile_country_name = dtActiveProposalDetails.Rows[0]["Profile_PitchCity"].ToString() + (!String.IsNullOrEmpty(dtActiveProposalDetails.Rows[0]["Profile_PitchCity"].ToString()) ? ", " : "") + dtActiveProposalDetails.Rows[0]["Profile_Country_Name"].ToString();
                pitch.Profile_PitchCity = dtActiveProposalDetails.Rows[0]["Profile_PitchCity"].ToString();
                pitch.SME_firstName = dtActiveProposalDetails.Rows[0]["Profile_FirstName"].ToString();
                pitch.SME_lastName = dtActiveProposalDetails.Rows[0]["Profile_LastName"].ToString();

                pitch.PreMoneyValuation = !string.IsNullOrEmpty(dtActiveProposalDetails.Rows[0]["Pitch_Pre_Money_Val"].ToString()) ? double.Parse(dtActiveProposalDetails.Rows[0]["Pitch_Pre_Money_Val"].ToString()) : 0;
                pitch.Pitch_Post_Money_Val = !string.IsNullOrEmpty(dtActiveProposalDetails.Rows[0]["Pitch_Post_Money_Val"].ToString()) ? decimal.Parse(dtActiveProposalDetails.Rows[0]["Pitch_Post_Money_Val"].ToString()) : 0;
                pitch.EquityOffered = !string.IsNullOrEmpty(dtActiveProposalDetails.Rows[0]["Pitch_EquityOffered"].ToString()) ? double.Parse(dtActiveProposalDetails.Rows[0]["Pitch_EquityOffered"].ToString()) : 0;
                pitch.HighestInvestment = !string.IsNullOrEmpty(dtActiveProposalDetails.Rows[0]["MaxInvAmount"].ToString()) ? double.Parse(dtActiveProposalDetails.Rows[0]["MaxInvAmount"].ToString()) : 0;
                pitch.OverfundingTaget = !string.IsNullOrEmpty(dtActiveProposalDetails.Rows[0]["OverSubAmount"].ToString()) ? double.Parse(dtActiveProposalDetails.Rows[0]["OverSubAmount"].ToString()) : 0;
                //pitch.Pitch_IsInvestmentFrozen = bool.Parse(dtActiveProposalDetails.Rows[0]["Pitch_IsInvestmentFrozen"].ToString());
                pitch.EarlyAccessCode = dtActiveProposalDetails.Rows[0]["Pitch_AccessCode"].ToString();
                pitch.EarlyAccessMode = Convert.ToBoolean(int.Parse(dtActiveProposalDetails.Rows[0]["Pitch_EarlyAccess_Access_Mode"].ToString()));
                pitch.IsConfidetnial = bool.Parse(dtActiveProposalDetails.Rows[0]["Pitch_IsOpaque"].ToString());
                pitch.Pitch_Status = dtActiveProposalDetails.Rows[0]["Pitch_Status"].ToString();
                #region Proposal widget Image
                pitch.WidgetImage = "";
                if (!string.IsNullOrEmpty(dtActiveProposalDetails.Rows[0]["Profile_PitchWidgetImageID"].ToString().Trim()))
                {
                    DataTable dtPitchAttachInf = _pitchAttachementsRepository.PitchGetAttachementDetails(Int32.Parse(dtActiveProposalDetails.Rows[0]["Profile_PitchWidgetImageID"].ToString()));
                    if (dtPitchAttachInf.Rows.Count > 0)
                    {
                        string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                        if (System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "pitch/thumbs/thumb_" + img)))
                            pitch.WidgetImage = _config.GetValue<string>("AttachementsEnvironmentURL") + "pitch/thumbs/thumb_" + img;
                        else
                            pitch.WidgetImage = _config.GetValue<string>("EnvironmentURL") + "Images/v2/pitchDefault.jpg";

                    }
                }
                #endregion
                #region Proposal Video 
                pitch.VideoId = "";

                if (!string.IsNullOrEmpty(dtActiveProposalDetails.Rows[0]["Profile_PitchMainVideoID"].ToString().Trim()))
                {
                    DataTable dtPitchAttachInf = _pitchAttachementsRepository.PitchGetAttachementDetails(Int32.Parse(dtActiveProposalDetails.Rows[0]["Profile_PitchMainVideoID"].ToString()));
                    if (dtPitchAttachInf.Rows.Count > 0)
                    {
                        string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                        if (System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "pitch/thumbs/thumb_" + img)))
                            pitch.VideoId = img;

                    }
                }
                #endregion

                #region Proposal Main Image
                pitch.Logo = "";
                if (!string.IsNullOrEmpty(dtActiveProposalDetails.Rows[0]["Profile_PitchMainImageID"].ToString().Trim()))
                {
                    DataTable dtPitchAttachInf = _pitchAttachementsRepository.PitchGetAttachementDetails(Int32.Parse(dtActiveProposalDetails.Rows[0]["Profile_PitchMainImageID"].ToString()));
                    if (dtPitchAttachInf.Rows.Count > 0)
                    {
                        string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                        if (System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "pitch/thumbs/thumb_" + img)))
                            pitch.Logo = _config.GetValue<string>("AttachementsEnvironmentURL") + "pitch/thumbs/thumb_" + img;
                        else
                            pitch.Logo = _config.GetValue<string>("EnvironmentURL") + "Images/v2/logoDefault.png";
                    }
                }
                #endregion


                #region set progress label
                if (bool.Parse(dtActiveProposal.Rows[0]["Pitch_IsOpaque"].ToString()))
                {
                    #region Opaque Published

                    pitch.ProgressLbl = _stringLocalizer["Confidential_Request_access_code_to_view"].Value;

                    #endregion
                }
                else
                {

                    #region Check Pitch Status 
                    pitch.ProgressLbl = "";
                    if (dtActiveProposal.Rows[0]["Pitch_Status"].ToString() == "completed" || (dtActiveProposal.Rows[0]["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dtActiveProposal.Rows[0]["Pitch_Balance"].ToString()) == float.Parse(dtActiveProposal.Rows[0]["Pitch_InvestmentRequired"].ToString()))))
                    {//100% funded and closed
                        pitch.Pitch_Status = _stringLocalizer["Funded1"].Value;
                        pitch.ProgressLbl = _stringLocalizer.GetString("Closed1").Value + " " + (Math.Floor(float.Parse(dtActiveProposal.Rows[0]["Pitch_InvestedSoFar"].ToString()))).ToString() + " " + _stringLocalizer["FundPercent"].Value;

                    }
                    else if (dtActiveProposal.Rows[0]["Pitch_Status"].ToString() == "Overfunding")
                    {
                        if (bool.Parse(dtActiveProposal.Rows[0]["Pitch_IsExtended"].ToString()))
                        {
                            pitch.ProgressLbl = _stringLocalizer["Overfunding1"].Value + " " + (Math.Floor(float.Parse(dtActiveProposal.Rows[0]["Pitch_InvestedSoFar"].ToString()))).ToString() + " " +
                                _stringLocalizer["raisedpercent"].Value + " - " + _stringLocalizer["Extra_Time"].Value; ;

                        }
                        else
                        {
                            pitch.ProgressLbl = _stringLocalizer["Overfunding1"].Value + " " + (Math.Floor(float.Parse(dtActiveProposal.Rows[0]["Pitch_InvestedSoFar"].ToString()))).ToString() + _stringLocalizer["raisedpercent"].Value;

                        }
                    }
                    else if (dtActiveProposal.Rows[0]["Pitch_Status"].ToString() == "Overfunded" || (dtActiveProposal.Rows[0]["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dtActiveProposal.Rows[0]["Pitch_Balance"].ToString()) > float.Parse(dtActiveProposal.Rows[0]["Pitch_InvestmentRequired"].ToString()))))
                    {
                        pitch.ProgressLbl = _stringLocalizer.GetString("Closed1").Value + " " + (Math.Floor(float.Parse(dtActiveProposal.Rows[0]["Pitch_InvestedSoFar"].ToString()))).ToString() + " " + _stringLocalizer["FundPercent"].Value;
                    }
                    else if (dtActiveProposal.Rows[0]["Pitch_Status"].ToString() == "Minimum-Funded" || (dtActiveProposal.Rows[0]["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dtActiveProposal.Rows[0]["Pitch_Balance"].ToString()) < float.Parse(dtActiveProposal.Rows[0]["Pitch_InvestmentRequired"].ToString()))))
                    {
                        if (dtActiveProposal.Rows[0]["Pitch_Status"].ToString() == "Minimum-Funded")
                            pitch.ProgressLbl = _stringLocalizer["Closed1"].Value + " " + _stringLocalizer["Funded"].Value;
                        else
                            pitch.ProgressLbl = _stringLocalizer["Closed1"].Value + " " + "100%" + " " + _stringLocalizer["Funded"].Value;

                        pitch.MinArrowVisiblity = false;
                    }
                    else
                    {
                        if (bool.Parse(dtActiveProposal.Rows[0]["Pitch_IsExtended"].ToString()))//proposal with published status and has extended
                        {
                            pitch.ProgressLbl = _stringLocalizer["Progress"].Value + " " + (Math.Floor(float.Parse(dtActiveProposal.Rows[0]["Pitch_InvestedSoFar"].ToString()))).ToString() + " " +
                            _stringLocalizer["raisedpercent"].Value + " - " + _stringLocalizer["Extra_Time"].Value;

                        }
                        else
                        {
                            pitch.ProgressLbl = _stringLocalizer["Progress"].Value + " " + (Math.Floor(float.Parse(dtActiveProposal.Rows[0]["Pitch_InvestedSoFar"].ToString()))).ToString() + " " +
                            _stringLocalizer["raisedpercent"].Value;
                        }

                    }
                }
                #endregion
                #endregion
                #region minimumArrow
                pitch.MinArrowDistance = 0;
                pitch.MinNote = "";
                pitch.MinAmountText = "";
                if (!string.IsNullOrEmpty(dtActiveProposal.Rows[0]["Pitch_HasMinInvestmentRequired"].ToString()) && bool.Parse(dtActiveProposal.Rows[0]["Pitch_HasMinInvestmentRequired"].ToString()))
                {
                    float minNeeded = float.Parse(dtActiveProposal.Rows[0]["Pitch_MinInvestmentRequired"].ToString());
                    float needed = float.Parse(dtActiveProposal.Rows[0]["Pitch_InvestmentRequired"].ToString());
                    string minNeededLeftMargin = (Math.Ceiling(decimal.Parse(((minNeeded * 100) / needed).ToString()))).ToString();
                    pitch.MinArrowDistance = int.Parse(minNeededLeftMargin);

                    if (dtActiveProposal.Rows[0]["Pitch_Status"].ToString() == "Minimum-Funded" || (dtActiveProposal.Rows[0]["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dtActiveProposal.Rows[0]["Pitch_Balance"].ToString()) < float.Parse(dtActiveProposal.Rows[0]["Pitch_InvestmentRequired"].ToString()))))
                        pitch.MinArrowVisiblity = false;
                    else
                        pitch.MinArrowVisiblity = true;

                    string minAmount = "";
                    if (requestModel.LangId == Languages.Arabic)
                    {
                        pitch.MinAmountText = string.Format("{0:n0}", (float.Parse(dtActiveProposal.Rows[0]["Pitch_MinInvestmentRequired"].ToString()) * rate)).ToString() + currencySymbol;
                    }
                    else
                    {
                        pitch.MinAmountText = currencySymbol + string.Format("{0:n0}", (float.Parse(dtActiveProposal.Rows[0]["Pitch_MinInvestmentRequired"].ToString()) * rate)).ToString();
                    }
                    pitch.MinNote = _stringLocalizer["Please_note_this_proposal_has_a_minimum_target_of"].Value + minAmount + _stringLocalizer["The_proposal_will_be_marked_as_successful"].Value;

                }
                else
                {
                    pitch.MinArrowVisiblity = false;
                }

                #endregion



                DataTable dtPitchDetais = _pitch.PitchGetDedicatedPitchDetailsByLang(pitchId, (int)requestModel.LangId);
                if (dtPitchDetais.Rows.Count == 0 && (int)requestModel.LangId != 1)
                {
                    dtPitchDetais = _pitch.PitchGetDedicatedPitchDetailsByLang(pitchId, 1);
                }

                if (dtPitchDetais.Rows.Count > 0)
                {
                    int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Proposal_Widgets_Blur, requestModel.CountryId);
                    if (!string.IsNullOrEmpty(requestModel.LoggedinUserId) && groupId > 0 && (dtPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Early Access" || dtPitchDetais.Rows[0]["Pitch_Status"].ToString() == "published" || dtPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Overfunding"))
                        pitch.IsBlured = true;


                    if (!string.IsNullOrEmpty(requestModel.LoggedinUserId))
                    {
                        DataTable dtUserInfo = _user.UserSelectById(int.Parse(requestModel.LoggedinUserId));

                        if (dtUserInfo.Rows.Count > 0)
                        {
                            if (int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.Enreprenuer && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.Admin && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.BIAdmin && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.SystemAdmin)
                            {
                                KYCModel kycModel = _user.KYCGetRequiredFiles(int.Parse(requestModel.LoggedinUserId), requestModel.CountryId);
                                if (kycModel.KYCOverAllStatus != (int)KYCUserDocsStatus.Accepted && groupId > 0 && (dtPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Early Access" || dtPitchDetais.Rows[0]["Pitch_Status"].ToString() == "published" || dtPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Overfunding"))
                                    pitch.IsKYCBlured = true;

                            }
                        }

                    }

                    pitch.Profile_PitchTitle = dtPitchDetais.Rows[0]["Profile_PitchTitle"].ToString();
                    pitch.Profile_PitchShortSummary = dtPitchDetais.Rows[0]["Profile_PitchShortSummary"].ToString();


                    if (requestModel.LangId == Languages.Arabic && int.Parse(dtPitchDetais.Rows[0]["Profile_LanguageID"].ToString()) == (int)Languages.English)
                    {
                        pitch.Profile_PitchTitle = dtPitchDetais.Rows[0]["Pitch_Admin_Arabic_Title"].ToString();
                        pitch.Profile_PitchShortSummary = "هذه الشركة متاحة باللغة الإنجليزية فقط، إضغط على عرض الشركة لعرض صفحة الشركة باللغة الإنجليزية";
                    }
                    pitch.country_flag = _config.GetValue<string>("AssetsEnvironmentURL") + "circle_flags/" + dtPitchDetais.Rows[0]["Country_Flag_URL"].ToString();

                    #region progress values
                    decimal pitchInvestedSoFar = decimal.Parse(dtPitchDetais.Rows[0]["Pitch_InvestedSoFar"].ToString());
                    decimal pitchOfflineSoFar = decimal.Parse(dtPitchDetais.Rows[0]["Pitch_Offline_SoFar"].ToString());
                    decimal pitchPreRaisedSoFar = decimal.Parse(dtPitchDetais.Rows[0]["Pitch_PreRaised_SoFar"].ToString());
                    decimal pitchInstitutionalSoFar = decimal.Parse(dtPitchDetais.Rows[0]["Pitch_Institutional_SoFar"].ToString());

                    string institutionalInvestmentSoFarNote = _stringLocalizer["InstitutionalInvestmentSoFar"].Value;
                    string privateToolTip = "";
                    string preRaisedTooltip = "";
                    string institutionalInvestmentTooltip = "";
                    string crowdFundingTooltip = "";
                    pitch.viewInstitutionalInvestmentNote = false;

                    decimal pitchCrowdFundingSoFar = pitchInvestedSoFar - pitchOfflineSoFar - pitchPreRaisedSoFar - pitchInstitutionalSoFar;

                    if (pitchInvestedSoFar >= 100)
                    {
                        pitch.offlineProgressWidth = (int)(pitchOfflineSoFar / pitchInvestedSoFar * 100);
                        pitch.preRaisedProgressWidth = (int)(pitchPreRaisedSoFar / pitchInvestedSoFar * 100);
                        pitch.InstitutionalProgressWidth = (int)(pitchInstitutionalSoFar / pitchInvestedSoFar * 100);
                        pitch.progressWidth = (int)(pitchCrowdFundingSoFar / pitchInvestedSoFar * 100);
                    }
                    else
                    {
                        if (dtActiveProposal.Rows[0]["Pitch_Status"].ToString() == "Minimum-Funded" || (dtActiveProposal.Rows[0]["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dtActiveProposal.Rows[0]["Pitch_Balance"].ToString()) < float.Parse(dtActiveProposal.Rows[0]["Pitch_InvestmentRequired"].ToString()))))
                        {
                            pitch.offlineProgressWidth = (int)pitchOfflineSoFar;
                            pitch.preRaisedProgressWidth = (int)pitchPreRaisedSoFar;
                            pitch.InstitutionalProgressWidth = (int)pitchInstitutionalSoFar;
                            pitch.progressWidth = (int)(100 - pitchOfflineSoFar - pitchPreRaisedSoFar - pitchInstitutionalSoFar);
                        }
                        else
                        {

                            pitch.offlineProgressWidth = (int)pitchOfflineSoFar;
                            pitch.preRaisedProgressWidth = (int)pitchPreRaisedSoFar;
                            pitch.InstitutionalProgressWidth = (int)pitchInstitutionalSoFar;
                            pitch.progressWidth = (int)(pitchInvestedSoFar - pitchOfflineSoFar - pitchPreRaisedSoFar - pitchInstitutionalSoFar);
                        }
                    }

                    if (pitchOfflineSoFar > 0 || pitchPreRaisedSoFar > 0 || pitchInstitutionalSoFar > 0)
                    {
                        pitch.viewTooltip = true;

                        string preRaisedCapital = _stringLocalizer["PreRaisedCapital"].Value;
                        string Offline = _stringLocalizer["Offline"].Value;
                        string indtitutionalInvestment = _stringLocalizer["INSTITUTIONAL_INVESTMENT"].Value;
                        string crowdFundedCapital = _stringLocalizer["CrowdFundedCapital"].Value;
                        if (pitchOfflineSoFar > 0)
                        {
                            privateToolTip = Math.Floor(pitchOfflineSoFar) + "% " + Offline;
                        }
                        if (pitchPreRaisedSoFar > 0)
                        {
                            preRaisedTooltip = Math.Floor(pitchPreRaisedSoFar) + "% " + preRaisedCapital;
                        }
                        if (pitchInstitutionalSoFar > 0)
                        {
                            institutionalInvestmentTooltip = Math.Floor(pitchInstitutionalSoFar) + "% " + indtitutionalInvestment;
                            pitch.viewInstitutionalInvestmentNote = true;
                        }


                        crowdFundingTooltip = Math.Floor((pitchInvestedSoFar - pitchOfflineSoFar - pitchPreRaisedSoFar - pitchInstitutionalSoFar)) + "% " + crowdFundedCapital;

                    }
                    else
                        pitch.viewTooltip = false;

                    pitch.privateToolTip = privateToolTip;
                    pitch.PreRaisedTooltip = preRaisedTooltip;
                    pitch.crowdFundingTooltip = crowdFundingTooltip;
                    pitch.InstitutionalInvestmentTooltip = institutionalInvestmentTooltip;
                    pitch.InstitutionalInvestmentSoFarNote = institutionalInvestmentSoFarNote;


                    #endregion

                    #region check when the user is loggedin 
                    pitch.isFollowed = false;
                    pitch.canFollow = true;
                    pitch.isInvestEnabled = true;

                    if ((dtActiveProposal.Rows[0]["Pitch_Status"].ToString() != "published" && dtActiveProposal.Rows[0]["Pitch_Status"].ToString() != "Overfunding"
                            && dtActiveProposal.Rows[0]["Pitch_Status"].ToString() != "Early Access"))
                        pitch.isInvestEnabled = false;
                    if (requestModel.LoggedinUserId != null)
                    {
                        DataTable dtConnection = _pitchLikeFollower.PitchgetUserIsLikeFollower(int.Parse(requestModel.LoggedinUserId), pitchId);
                        bool follower = dtConnection.Rows.Count > 0 && Boolean.Parse(dtConnection.Rows[0]["PUConnection_FollowType"].ToString());
                        if (!follower)
                        {
                            pitch.isFollowed = false;
                        }
                        else
                        {
                            pitch.isFollowed = true;
                        }

                        if (requestModel.LoggedinUserId.ToString() == dtActiveProposal.Rows[0]["Pitch_UserID"].ToString())
                        {
                            pitch.canFollow = false;

                        }

                        DataTable dtLoggedInUserInfo = _user.UserSelectById(Int32.Parse(requestModel.LoggedinUserId));

                        if (dtLoggedInUserInfo.Rows[0]["User_UserType"].ToString() != "2" && dtLoggedInUserInfo.Rows[0]["User_UserType"].ToString() != "4")
                        {
                            pitch.isInvestEnabled = false;
                        }

                        if (Convert.ToInt32(dtLoggedInUserInfo.Rows[0]["User_UserFormType"]) == (int)UserType.Enreprenuer)
                        {
                            pitch.isInvestEnabled = false;

                        }
                    }
                    #endregion

                }
                return Ok(new { code = 200, success = true, pitch , hasProposal = true  });

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");

            }
        }

        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult> UserProfileGetInvestment(GetPitchOnViewProfilePage requestModel)
        {
            try
            {
                List<Pitch> Pitches = new List<Pitch>();
                DataTable dtProposals = _user.UserGetInvestmentsForProfile(requestModel.UserId,(int) requestModel.LangId, (int)requestModel.CurrecnyId);
                if (dtProposals.Rows.Count <= 0)
                    return Ok(new { code = 200, success = true, hasProposal = false });

                int pitchId = int.Parse(dtProposals.Rows[0]["Pitch_ID"].ToString());

                foreach (DataRow row in dtProposals.Rows)
                {
                    double rate = 0;
                    Pitch pitch = new Pitch();
                    DataTable dtProposalDetails = _pitch.PitchGetDedicatedPitchDetailsByLang(pitchId, (int)requestModel.LangId, (int)requestModel.CurrecnyId);
                    if (dtProposalDetails.Rows.Count <= 0 || _pitch.PitchIsProposalViewPrevented(dtProposalDetails.Rows[0], requestModel.CountryId, _userId))
                        row.Delete();
                    dtProposals.AcceptChanges();
                    int tempout = 0;
                    _pitch.PitchTestExpiration((int)requestModel.LangId, pitchId);
                    DataTable dtCurreny = _general.CurrencyGetCurrencyByID((int)requestModel.CurrecnyId);
                    string currencySymbol = dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$";

                    pitch.Pitch_InvestmentRequiredFormatted = Tools.FormatNumberWithCurrency((int)requestModel.LangId, currencySymbol, double.Parse(dtProposalDetails.Rows[0]["Pitch_InvestmentRequired"].ToString()).ToString("#,##0"));
                    pitch.Pitch_BalanceFormatted = Tools.FormatNumberWithCurrency((int)requestModel.LangId, currencySymbol, double.Parse(dtProposalDetails.Rows[0]["Pitch_Balance"].ToString()).ToString("#,##0"));
                    pitch.Pitch_Balance = double.Parse(dtProposalDetails.Rows[0]["Pitch_Balance"].ToString());
                    pitch.Pitch_InvestmentRequired = double.Parse(dtProposalDetails.Rows[0]["pitch_InvestmentRequired"].ToString());
                    pitch.Pitch_Investors = int.Parse(dtProposalDetails.Rows[0]["pitch_Investors"].ToString());
                    pitch.Profile_PitchTitle = dtProposalDetails.Rows[0]["Profile_PitchTitle"].ToString();
                    pitch.Pitch_HasDiscount = bool.Parse(dtProposalDetails.Rows[0]["Pitch_HasDiscount"].ToString());

                    #region badges
                    DataTable dtBadges = _pitch.PitchBadgesAssignedGetAll(1, 100, (int)requestModel.LangId, pitchId, out tempout);
                    List<Badge> badges = new List<Badge>();
                    if (dtBadges.Rows.Count > 0)
                    {
                        badges = JsonConvert.DeserializeObject<List<Badge>>(dtBadges.Rows[0]["Badges"].ToString());
                    }
                    pitch.Badges = badges;
                    #endregion
                    pitch.profile_country_name = dtProposalDetails.Rows[0]["Profile_PitchCity"].ToString() + (!String.IsNullOrEmpty(dtProposalDetails.Rows[0]["Profile_PitchCity"].ToString()) ? ", " : "") + dtProposalDetails.Rows[0]["Profile_Country_Name"].ToString();
                    pitch.Profile_PitchCity = dtProposalDetails.Rows[0]["Profile_PitchCity"].ToString();
                    pitch.SME_firstName = dtProposalDetails.Rows[0]["Profile_FirstName"].ToString();
                    pitch.SME_lastName = dtProposalDetails.Rows[0]["Profile_LastName"].ToString();

                    pitch.PreMoneyValuation = !string.IsNullOrEmpty(dtProposalDetails.Rows[0]["Pitch_Pre_Money_Val"].ToString()) ? double.Parse(dtProposalDetails.Rows[0]["Pitch_Pre_Money_Val"].ToString()) : 0;
                    pitch.Pitch_Post_Money_Val = !string.IsNullOrEmpty(dtProposalDetails.Rows[0]["Pitch_Post_Money_Val"].ToString()) ? decimal.Parse(dtProposalDetails.Rows[0]["Pitch_Post_Money_Val"].ToString()) : 0;
                    pitch.EquityOffered = !string.IsNullOrEmpty(dtProposalDetails.Rows[0]["Pitch_EquityOffered"].ToString()) ? double.Parse(dtProposalDetails.Rows[0]["Pitch_EquityOffered"].ToString()) : 0;
                    pitch.HighestInvestment = !string.IsNullOrEmpty(dtProposalDetails.Rows[0]["MaxInvAmount"].ToString()) ? double.Parse(dtProposalDetails.Rows[0]["MaxInvAmount"].ToString()) : 0;
                    pitch.OverfundingTaget = !string.IsNullOrEmpty(dtProposalDetails.Rows[0]["OverSubAmount"].ToString()) ? double.Parse(dtProposalDetails.Rows[0]["OverSubAmount"].ToString()) : 0;
                    //pitch.Pitch_IsInvestmentFrozen = bool.Parse(dtActiveProposalDetails.Rows[0]["Pitch_IsInvestmentFrozen"].ToString());
                    pitch.EarlyAccessCode = dtProposalDetails.Rows[0]["Pitch_AccessCode"].ToString();
                    pitch.EarlyAccessMode = Convert.ToBoolean(int.Parse(dtProposalDetails.Rows[0]["Pitch_EarlyAccess_Access_Mode"].ToString()));
                    pitch.IsConfidetnial = bool.Parse(dtProposalDetails.Rows[0]["Pitch_IsOpaque"].ToString());
                    pitch.Pitch_Status = dtProposalDetails.Rows[0]["Pitch_Status"].ToString();
                    #region Proposal widget Image
                    pitch.WidgetImage = "";
                    if (!string.IsNullOrEmpty(dtProposalDetails.Rows[0]["Profile_PitchWidgetImageID"].ToString().Trim()))
                    {
                        DataTable dtPitchAttachInf = _pitchAttachementsRepository.PitchGetAttachementDetails(Int32.Parse(dtProposalDetails.Rows[0]["Profile_PitchWidgetImageID"].ToString()));
                        if (dtPitchAttachInf.Rows.Count > 0)
                        {
                            string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                            if (System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "pitch/thumbs/thumb_" + img)))
                                pitch.WidgetImage = _config.GetValue<string>("AttachementsEnvironmentURL") + "pitch/thumbs/thumb_" + img;
                            else
                                pitch.WidgetImage = _config.GetValue<string>("EnvironmentURL") + "Images/v2/pitchDefault.jpg";

                        }
                    }
                    #endregion
                    #region Proposal Video 
                    pitch.VideoId = "";

                    if (!string.IsNullOrEmpty(dtProposalDetails.Rows[0]["Profile_PitchMainVideoID"].ToString().Trim()))
                    {
                        DataTable dtPitchAttachInf = _pitchAttachementsRepository.PitchGetAttachementDetails(Int32.Parse(dtProposalDetails.Rows[0]["Profile_PitchMainVideoID"].ToString()));
                        if (dtPitchAttachInf.Rows.Count > 0)
                        {
                            string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                            if (System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "pitch/thumbs/thumb_" + img)))
                                pitch.VideoId = img;

                        }
                    }
                    #endregion

                    #region Proposal Main Image
                    pitch.Logo = "";
                    if (!string.IsNullOrEmpty(dtProposalDetails.Rows[0]["Profile_PitchMainImageID"].ToString().Trim()))
                    {
                        DataTable dtPitchAttachInf = _pitchAttachementsRepository.PitchGetAttachementDetails(Int32.Parse(dtProposalDetails.Rows[0]["Profile_PitchMainImageID"].ToString()));
                        if (dtPitchAttachInf.Rows.Count > 0)
                        {
                            string img = dtPitchAttachInf.Rows[0]["PitchAttachment_Name"].ToString();
                            if (System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "pitch/thumbs/thumb_" + img)))
                                pitch.Logo = _config.GetValue<string>("AttachementsEnvironmentURL") + "pitch/thumbs/thumb_" + img;
                            else
                                pitch.Logo = _config.GetValue<string>("EnvironmentURL") + "Images/v2/logoDefault.png";
                        }
                    }
                    #endregion


                    #region set progress label
                    if (bool.Parse(dtProposalDetails.Rows[0]["Pitch_IsOpaque"].ToString()))
                    {
                        #region Opaque Published

                        pitch.ProgressLbl = _stringLocalizer["Confidential_Request_access_code_to_view"].Value;

                        #endregion
                    }
                    else
                    {

                        #region Check Pitch Status 
                        pitch.ProgressLbl = "";
                        if (dtProposalDetails.Rows[0]["Pitch_Status"].ToString() == "completed" || (dtProposalDetails.Rows[0]["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dtProposalDetails.Rows[0]["Pitch_Balance"].ToString()) == float.Parse(dtProposalDetails.Rows[0]["Pitch_InvestmentRequired"].ToString()))))
                        {//100% funded and closed
                            pitch.Pitch_Status = _stringLocalizer["Funded1"].Value;
                            pitch.ProgressLbl = _stringLocalizer.GetString("Closed1").Value + " " + (Math.Floor(float.Parse(dtProposalDetails.Rows[0]["Pitch_InvestedSoFar"].ToString()))).ToString() + " " + _stringLocalizer["FundPercent"].Value;

                        }
                        else if (dtProposalDetails.Rows[0]["Pitch_Status"].ToString() == "Overfunding")
                        {
                            if (bool.Parse(dtProposalDetails.Rows[0]["Pitch_IsExtended"].ToString()))
                            {
                                pitch.ProgressLbl = _stringLocalizer["Overfunding1"].Value + " " + (Math.Floor(float.Parse(dtProposalDetails.Rows[0]["Pitch_InvestedSoFar"].ToString()))).ToString() + " " +
                                    _stringLocalizer["raisedpercent"].Value + " - " + _stringLocalizer["Extra_Time"].Value; ;

                            }
                            else
                            {
                                pitch.ProgressLbl = _stringLocalizer["Overfunding1"].Value + " " + (Math.Floor(float.Parse(dtProposalDetails.Rows[0]["Pitch_InvestedSoFar"].ToString()))).ToString() + _stringLocalizer["raisedpercent"].Value;

                            }
                        }
                        else if (dtProposalDetails.Rows[0]["Pitch_Status"].ToString() == "Overfunded" || (dtProposalDetails.Rows[0]["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dtProposalDetails.Rows[0]["Pitch_Balance"].ToString()) > float.Parse(dtProposalDetails.Rows[0]["Pitch_InvestmentRequired"].ToString()))))
                        {
                            pitch.ProgressLbl = _stringLocalizer.GetString("Closed1").Value + " " + (Math.Floor(float.Parse(dtProposalDetails.Rows[0]["Pitch_InvestedSoFar"].ToString()))).ToString() + " " + _stringLocalizer["FundPercent"].Value;
                        }
                        else if (dtProposalDetails.Rows[0]["Pitch_Status"].ToString() == "Minimum-Funded" || (dtProposalDetails.Rows[0]["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dtProposalDetails.Rows[0]["Pitch_Balance"].ToString()) < float.Parse(dtProposalDetails.Rows[0]["Pitch_InvestmentRequired"].ToString()))))
                        {
                            if (dtProposalDetails.Rows[0]["Pitch_Status"].ToString() == "Minimum-Funded")
                                pitch.ProgressLbl = _stringLocalizer["Closed1"].Value + " " + _stringLocalizer["Funded"].Value;
                            else
                                pitch.ProgressLbl = _stringLocalizer["Closed1"].Value + " " + "100%" + " " + _stringLocalizer["Funded"].Value;

                            pitch.MinArrowVisiblity = false;
                        }
                        else
                        {
                            if (bool.Parse(dtProposalDetails.Rows[0]["Pitch_IsExtended"].ToString()))//proposal with published status and has extended
                            {
                                pitch.ProgressLbl = _stringLocalizer["Progress"].Value + " " + (Math.Floor(float.Parse(dtProposalDetails.Rows[0]["Pitch_InvestedSoFar"].ToString()))).ToString() + " " +
                                _stringLocalizer["raisedpercent"].Value + " - " + _stringLocalizer["Extra_Time"].Value;

                            }
                            else
                            {
                                pitch.ProgressLbl = _stringLocalizer["Progress"].Value + " " + (Math.Floor(float.Parse(dtProposalDetails.Rows[0]["Pitch_InvestedSoFar"].ToString()))).ToString() + " " +
                                _stringLocalizer["raisedpercent"].Value;
                            }

                        }
                    }
                    #endregion
                    #endregion
                    #region minimumArrow
                    pitch.MinArrowDistance = 0;
                    pitch.MinNote = "";
                    pitch.MinAmountText = "";
                    if (!string.IsNullOrEmpty(dtProposalDetails.Rows[0]["Pitch_HasMinInvestmentRequired"].ToString()) && bool.Parse(dtProposalDetails.Rows[0]["Pitch_HasMinInvestmentRequired"].ToString()))
                    {
                        float minNeeded = float.Parse(dtProposalDetails.Rows[0]["Pitch_MinInvestmentRequired"].ToString());
                        float needed = float.Parse(dtProposalDetails.Rows[0]["Pitch_InvestmentRequired"].ToString());
                        string minNeededLeftMargin = (Math.Ceiling(decimal.Parse(((minNeeded * 100) / needed).ToString()))).ToString();
                        pitch.MinArrowDistance = int.Parse(minNeededLeftMargin);

                        if (dtProposalDetails.Rows[0]["Pitch_Status"].ToString() == "Minimum-Funded" || (dtProposalDetails.Rows[0]["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dtProposalDetails.Rows[0]["Pitch_Balance"].ToString()) < float.Parse(dtProposalDetails.Rows[0]["Pitch_InvestmentRequired"].ToString()))))
                            pitch.MinArrowVisiblity = false;
                        else
                            pitch.MinArrowVisiblity = true;

                        string minAmount = "";
                        if (requestModel.LangId == Languages.Arabic)
                        {
                            pitch.MinAmountText = string.Format("{0:n0}", (float.Parse(dtProposalDetails.Rows[0]["Pitch_MinInvestmentRequired"].ToString()) * rate)).ToString() + currencySymbol;
                        }
                        else
                        {
                            pitch.MinAmountText = currencySymbol + string.Format("{0:n0}", (float.Parse(dtProposalDetails.Rows[0]["Pitch_MinInvestmentRequired"].ToString()) * rate)).ToString();
                        }
                        pitch.MinNote = _stringLocalizer["Please_note_this_proposal_has_a_minimum_target_of"].Value + minAmount + _stringLocalizer["The_proposal_will_be_marked_as_successful"].Value;

                    }
                    else
                    {
                        pitch.MinArrowVisiblity = false;
                    }

                    #endregion



                    DataTable dtPitchDetais = _pitch.PitchGetDedicatedPitchDetailsByLang(pitchId, (int)requestModel.LangId);
                    if (dtPitchDetais.Rows.Count == 0 && (int)requestModel.LangId != 1)
                    {
                        dtPitchDetais = _pitch.PitchGetDedicatedPitchDetailsByLang(pitchId, 1);
                    }

                    if (dtPitchDetais.Rows.Count > 0)
                    {
                        int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.Proposal_Widgets_Blur, requestModel.CountryId);
                        if (!string.IsNullOrEmpty(requestModel.LoggedinUserId) && groupId > 0 && (dtPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Early Access" || dtPitchDetais.Rows[0]["Pitch_Status"].ToString() == "published" || dtPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Overfunding"))
                            pitch.IsBlured = true;


                        if (!string.IsNullOrEmpty(requestModel.LoggedinUserId))
                        {
                            DataTable dtUserInfo = _user.UserSelectById(int.Parse(requestModel.LoggedinUserId));

                            if (dtUserInfo.Rows.Count > 0)
                            {
                                if (int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.Enreprenuer && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.Admin && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.BIAdmin && int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) != (int)UserType.SystemAdmin)
                                {
                                    KYCModel kycModel = _user.KYCGetRequiredFiles(int.Parse(requestModel.LoggedinUserId), requestModel.CountryId);
                                    if (kycModel.KYCOverAllStatus != (int)KYCUserDocsStatus.Accepted && groupId > 0 && (dtPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Early Access" || dtPitchDetais.Rows[0]["Pitch_Status"].ToString() == "published" || dtPitchDetais.Rows[0]["Pitch_Status"].ToString() == "Overfunding"))
                                        pitch.IsKYCBlured = true;

                                }
                            }

                        }

                        pitch.Profile_PitchTitle = dtPitchDetais.Rows[0]["Profile_PitchTitle"].ToString();
                        pitch.Profile_PitchShortSummary = dtPitchDetais.Rows[0]["Profile_PitchShortSummary"].ToString();


                        if (requestModel.LangId == Languages.Arabic && int.Parse(dtPitchDetais.Rows[0]["Profile_LanguageID"].ToString()) == (int)Languages.English)
                        {
                            pitch.Profile_PitchTitle = dtPitchDetais.Rows[0]["Pitch_Admin_Arabic_Title"].ToString();
                            pitch.Profile_PitchShortSummary = "هذه الشركة متاحة باللغة الإنجليزية فقط، إضغط على عرض الشركة لعرض صفحة الشركة باللغة الإنجليزية";
                        }
                        pitch.country_flag = _config.GetValue<string>("AssetsEnvironmentURL") + "circle_flags/" + dtPitchDetais.Rows[0]["Country_Flag_URL"].ToString();

                        #region progress values
                        decimal pitchInvestedSoFar = decimal.Parse(dtPitchDetais.Rows[0]["Pitch_InvestedSoFar"].ToString());
                        decimal pitchOfflineSoFar = decimal.Parse(dtPitchDetais.Rows[0]["Pitch_Offline_SoFar"].ToString());
                        decimal pitchPreRaisedSoFar = decimal.Parse(dtPitchDetais.Rows[0]["Pitch_PreRaised_SoFar"].ToString());
                        decimal pitchInstitutionalSoFar = decimal.Parse(dtPitchDetais.Rows[0]["Pitch_Institutional_SoFar"].ToString());

                        string institutionalInvestmentSoFarNote = _stringLocalizer["InstitutionalInvestmentSoFar"].Value;
                        string privateToolTip = "";
                        string preRaisedTooltip = "";
                        string institutionalInvestmentTooltip = "";
                        string crowdFundingTooltip = "";
                        pitch.viewInstitutionalInvestmentNote = false;

                        decimal pitchCrowdFundingSoFar = pitchInvestedSoFar - pitchOfflineSoFar - pitchPreRaisedSoFar - pitchInstitutionalSoFar;

                        if (pitchInvestedSoFar >= 100)
                        {
                            pitch.offlineProgressWidth = (int)(pitchOfflineSoFar / pitchInvestedSoFar * 100);
                            pitch.preRaisedProgressWidth = (int)(pitchPreRaisedSoFar / pitchInvestedSoFar * 100);
                            pitch.InstitutionalProgressWidth = (int)(pitchInstitutionalSoFar / pitchInvestedSoFar * 100);
                            pitch.progressWidth = (int)(pitchCrowdFundingSoFar / pitchInvestedSoFar * 100);
                        }
                        else
                        {
                            if (dtProposalDetails.Rows[0]["Pitch_Status"].ToString() == "Minimum-Funded" || (dtProposalDetails.Rows[0]["Pitch_Status"].ToString() == "completed and closed" && (float.Parse(dtProposalDetails.Rows[0]["Pitch_Balance"].ToString()) < float.Parse(dtProposalDetails.Rows[0]["Pitch_InvestmentRequired"].ToString()))))
                            {
                                pitch.offlineProgressWidth = (int)pitchOfflineSoFar;
                                pitch.preRaisedProgressWidth = (int)pitchPreRaisedSoFar;
                                pitch.InstitutionalProgressWidth = (int)pitchInstitutionalSoFar;
                                pitch.progressWidth = (int)(100 - pitchOfflineSoFar - pitchPreRaisedSoFar - pitchInstitutionalSoFar);
                            }
                            else
                            {

                                pitch.offlineProgressWidth = (int)pitchOfflineSoFar;
                                pitch.preRaisedProgressWidth = (int)pitchPreRaisedSoFar;
                                pitch.InstitutionalProgressWidth = (int)pitchInstitutionalSoFar;
                                pitch.progressWidth = (int)(pitchInvestedSoFar - pitchOfflineSoFar - pitchPreRaisedSoFar - pitchInstitutionalSoFar);
                            }
                        }

                        if (pitchOfflineSoFar > 0 || pitchPreRaisedSoFar > 0 || pitchInstitutionalSoFar > 0)
                        {
                            pitch.viewTooltip = true;

                            string preRaisedCapital = _stringLocalizer["PreRaisedCapital"].Value;
                            string Offline = _stringLocalizer["Offline"].Value;
                            string indtitutionalInvestment = _stringLocalizer["INSTITUTIONAL_INVESTMENT"].Value;
                            string crowdFundedCapital = _stringLocalizer["CrowdFundedCapital"].Value;
                            if (pitchOfflineSoFar > 0)
                            {
                                privateToolTip = Math.Floor(pitchOfflineSoFar) + "% " + Offline;
                            }
                            if (pitchPreRaisedSoFar > 0)
                            {
                                preRaisedTooltip = Math.Floor(pitchPreRaisedSoFar) + "% " + preRaisedCapital;
                            }
                            if (pitchInstitutionalSoFar > 0)
                            {
                                institutionalInvestmentTooltip = Math.Floor(pitchInstitutionalSoFar) + "% " + indtitutionalInvestment;
                                pitch.viewInstitutionalInvestmentNote = true;
                            }


                            crowdFundingTooltip = Math.Floor((pitchInvestedSoFar - pitchOfflineSoFar - pitchPreRaisedSoFar - pitchInstitutionalSoFar)) + "% " + crowdFundedCapital;

                        }
                        else
                            pitch.viewTooltip = false;

                        pitch.privateToolTip = privateToolTip;
                        pitch.PreRaisedTooltip = preRaisedTooltip;
                        pitch.crowdFundingTooltip = crowdFundingTooltip;
                        pitch.InstitutionalInvestmentTooltip = institutionalInvestmentTooltip;
                        pitch.InstitutionalInvestmentSoFarNote = institutionalInvestmentSoFarNote;


                        #endregion

                        #region check when the user is loggedin 
                        pitch.isFollowed = false;
                        pitch.canFollow = true;
                        pitch.isInvestEnabled = true;

                        if ((dtProposalDetails.Rows[0]["Pitch_Status"].ToString() != "published" && dtProposalDetails.Rows[0]["Pitch_Status"].ToString() != "Overfunding"
                                && dtProposalDetails.Rows[0]["Pitch_Status"].ToString() != "Early Access"))
                            pitch.isInvestEnabled = false;
                        if (requestModel.LoggedinUserId != null)
                        {
                            DataTable dtConnection = _pitchLikeFollower.PitchgetUserIsLikeFollower(int.Parse(requestModel.LoggedinUserId), pitchId);
                            bool follower = dtConnection.Rows.Count > 0 && Boolean.Parse(dtConnection.Rows[0]["PUConnection_FollowType"].ToString());
                            if (!follower)
                            {
                                pitch.isFollowed = false;
                            }
                            else
                            {
                                pitch.isFollowed = true;
                            }

                            if (requestModel.LoggedinUserId.ToString() == dtProposalDetails.Rows[0]["Pitch_UserID"].ToString())
                            {
                                pitch.canFollow = false;

                            }

                            DataTable dtLoggedInUserInfo = _user.UserSelectById(Int32.Parse(requestModel.LoggedinUserId));

                            if (dtLoggedInUserInfo.Rows[0]["User_UserType"].ToString() != "2" && dtLoggedInUserInfo.Rows[0]["User_UserType"].ToString() != "4")
                            {
                                pitch.isInvestEnabled = false;
                            }

                            if (Convert.ToInt32(dtLoggedInUserInfo.Rows[0]["User_UserFormType"]) == (int)UserType.Enreprenuer)
                            {
                                pitch.isInvestEnabled = false;

                            }
                        }
                        #endregion
                        Pitches.Add(pitch);
                    }

                }
                
                return Ok(new { code = 200, success = true, Pitches });

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");

            }

        }
    }
}
