﻿using Eureeca_API.TokenAuth;
using Microsoft.AspNetCore.Mvc;

namespace Eureeca_API.Controllers
{
    [AuthFilter]
    [Route("Api/[controller]")]
    [ApiController]
    public class BaseController : ControllerBase
    {
        protected string _userId; 
        protected string _countryId; 
        private readonly IHttpContextAccessor _contextAccessor;
        public BaseController(IHttpContextAccessor httpContextAccessor)
        {
            _contextAccessor = httpContextAccessor;
                if (_contextAccessor.HttpContext.User != null && _contextAccessor.HttpContext.User.Identity.IsAuthenticated)
            {
                _userId = _contextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "User_ID").Value;
            }

        }
    }
}
