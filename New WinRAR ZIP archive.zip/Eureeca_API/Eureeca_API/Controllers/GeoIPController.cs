﻿using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Interface.CountryBasedInterface;
using Eureeca_API.Models.GeneralModels.Dto;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace Eureeca_API.Controllers
{
    [Route("api/geoIP")]
    [ApiController]

    public class GeoIPController : ControllerBase
    {
        private readonly IGeoIP _geoIP;
        private readonly ICountryBasedControl _countryBasedControl;
        private readonly IConfiguration _config;
        private readonly ErrHandler _errHandler;

        public GeoIPController(IGeoIP geoIP, ICountryBasedControl countryBasedControl, IConfiguration config)
        {
            _geoIP = geoIP;
            _countryBasedControl = countryBasedControl;
            _errHandler = new ErrHandler();
            _config = config;
        }

        [HttpPost("GeoGetCountryId")]
        public async Task<ActionResult> GeoGetCountryId(GeoIPRequestModel geoIPRequestModel)
        {
            try
            {
                var response = await Task.FromResult(_geoIP.GeoGetCountryId(geoIPRequestModel.UserIP));
                if (response == null) { return NotFound(); }
                if (response != -1)
                {
                    DataTable dtCountry = await Task.FromResult(_countryBasedControl.CountryBasedGetCountryDetails(response, geoIPRequestModel.LangId));
                    if (dtCountry.Rows.Count > 0)
                    {
                        List<Country> countries = Tools.ConvertDataTable<Country>(dtCountry);
                        foreach(Country country in countries)
                        {
                            country.Country_Flag_URL = _config.GetValue<string>("AssetsEnvironmentURL") + "circle_flags/" + country.Country_Flag_URL;

                        }

                        return Ok(new { code = 200, success = true, Country = countries[0] });
                    }
                }

                return Ok(new { code = 200, success = false, countryId = response });

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

    }
}
