﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Interface.AccountInterface;
using Eureeca_API.Interface.CountryBasedInterface;
using Eureeca_API.Interface.InboxInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.Register;
using Eureeca_API.Repository;
using MaxMind.GeoIP2.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Data;
using System.Diagnostics.Metrics;
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;
using System.Xml.Linq;

namespace Eureeca_API.Controllers.Register
{
    [Route("api/[controller]")]
    [ApiController]

    public class RegisterController : ControllerBase
    {
        private readonly IUser _user;
        private readonly IAgreement _agreement;
        private readonly IMessage _message;
        private readonly IConfiguration _configuration;
        private readonly IStringLocalizer<Resources.RegisterController> _stringLocalizer;
        private readonly ICountryBasedControl _countryBasedControl;
        private readonly ILead _lead;
        private readonly IAlert _alert;
        private readonly ICustomForumUser _customForumUser;
        private readonly ITopic _topic;
        private readonly IAccount _account;
        private readonly ErrHandler _errHandler;


        public RegisterController(IUser user, IAgreement agreement, IMessage message, IConfiguration configuration, IStringLocalizer<Resources.RegisterController> stringLocalizer, ICountryBasedControl countryBasedControl, ILead lead, IAlert alert, ICustomForumUser customForumUser, ITopic topic, IAccount account)
        {
            _user = user;
            _agreement = agreement;
            _message = message;
            _configuration = configuration;
            _stringLocalizer = stringLocalizer;
            _countryBasedControl = countryBasedControl;
            _lead = lead;
            _errHandler = new ErrHandler();
            _alert = alert;
            _customForumUser = customForumUser;
            _topic = topic;
            _account = account;
        }

        [HttpPost("UserValidateData")]
        public async Task<ActionResult<ValidateUserResponseModel>> UserValidateData(ValidateUserModel validateUserModel)
        {
            try
            {
                ValidateUserResponseModel response;
                Tools.SetThreadCulture(validateUserModel.LangId);
                //Check if the username has correct format and not existing in the database
                if (string.IsNullOrEmpty(validateUserModel.Username) || !Tools.IsValidUserName(validateUserModel.Username))
                {
                    response = new ValidateUserResponseModel(200, false, _stringLocalizer["InvalidName"].Value, "username");
                    return Ok(response);
                }
                else if (await Task.FromResult(_user.SelectByUserName(validateUserModel.Username).Rows.Count > 0))
                {
                    response = new ValidateUserResponseModel(200, false, _stringLocalizer["ExistUserName"].Value, "username");
                    return Ok(response);
                }

                //Check if the email has correct format
                if (string.IsNullOrEmpty(validateUserModel.Email) || !Tools.IsValidEmail(validateUserModel.Email))
                {
                    response = new ValidateUserResponseModel(200, false, _stringLocalizer["InvalidUserEmail"].Value, "email");
                    return Ok(response);
                }
                //Check if the email exists on the database
                DataTable dtUser = await Task.FromResult(_user.SelectUserByEmail(validateUserModel.Email));
                if (dtUser.Rows.Count > 0 && int.Parse(dtUser.Rows[0]["User_Status"].ToString()) != (int)UserStatus.Incomplete)
                {
                    response = new ValidateUserResponseModel(200, false, _stringLocalizer["ExistEmail"].Value, "email");
                    return Ok(response);
                }
                //Check the password length
                if (validateUserModel.RegistrationType == (int)RegistrationType.Normal && (string.IsNullOrEmpty(validateUserModel.Password) || !Tools.IsValidPassword(validateUserModel.Password)))
                {
                    response = new ValidateUserResponseModel(200, false, _stringLocalizer["PasswordLength"].Value, "password");
                    return Ok(response);
                }

                response = new ValidateUserResponseModel(200, true, "Valid username and email", "");
                return Ok(response);

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpGet("RegistrationPrerequisites")]
        public async Task<ActionResult<RegistrationPrerequisite>> RegistrationPrerequisites([FromQuery] RegistrationPrerequisitesModel registrationPrerequisites)
        {
            try
            {
                /*This method is used to handle the registration prerequisites
                 * the ability to register
                 * warning messages
                 * regulates message
                 * the agreements list depends on the user type and country id
                */

                Tools.SetThreadCulture(registrationPrerequisites.LangId);

                RegistrationPrerequisite registrationPrerequisite = new RegistrationPrerequisite();
                List<Agreement> registrationPopupMessages = new List<Agreement>();
                //Check if the user prevented to registered on our site
                Agreement registrationPrevention = await Task.FromResult(_agreement.AgreementGetRegistrationPrevention(registrationPrerequisites.CountryId, registrationPrerequisites.LangId));
                if (registrationPrevention != null)
                {
                    registrationPrerequisite.IsEnabledToRegister = false;
                    registrationPopupMessages.Add(registrationPrevention);
                    registrationPrerequisite.RegistrationPopupMessages = registrationPopupMessages;
                    return Ok(new { code = 200, success = true, registrationPrerequisite });
                }

                registrationPrerequisite.IsEnabledToRegister = true;

                //Check if we need to show warning message before registration
                Agreement registrationWarning = await Task.FromResult(_agreement.AgreementGetRegistrationWarning(registrationPrerequisites.CountryId, registrationPrerequisites.LangId));
                if (registrationWarning != null)
                    registrationPopupMessages.Add(registrationWarning);

                //Check if we need to show regulates message before registration
                Agreement registrationRegulatorsAgreement = await Task.FromResult(_agreement.AgreementGetRegistrationRegulatorsAgreement(registrationPrerequisites.CountryId, registrationPrerequisites.LangId));
                if (registrationRegulatorsAgreement != null)
                    registrationPopupMessages.Add(registrationRegulatorsAgreement);
                //Return the investorTermsOfBusiness Agreement
                Agreement investorTermsOfBusinessAgreement = await Task.FromResult(_agreement.AgreementGetEureecaTermsOfBusiness(registrationPrerequisites.CountryId, registrationPrerequisites.LangId));
                if (investorTermsOfBusinessAgreement != null)
                {
                    investorTermsOfBusinessAgreement.MessageTypeLbl = _stringLocalizer["accept"].Value + _stringLocalizer["InvestorsTerms"].Value;
                    investorTermsOfBusinessAgreement.IsAgreement = true;
                    registrationPopupMessages.Add(investorTermsOfBusinessAgreement);
                }
                //Return the privacyPolicy Agreement
                Agreement privacyPolicyAgreement = await Task.FromResult(_agreement.AgreementGetEureecaPrivacyPolicy(registrationPrerequisites.CountryId, registrationPrerequisites.LangId));
                if (privacyPolicyAgreement != null)
                {
                    privacyPolicyAgreement.MessageTypeLbl = _stringLocalizer["accept"].Value + _stringLocalizer["PrivacyPolicy"].Value;
                    privacyPolicyAgreement.IsAgreement = true;
                    registrationPopupMessages.Add(privacyPolicyAgreement);
                }

                //Check if user investor Return the EureecaTermsOfUse Agreement
                if (registrationPrerequisites.UserType == (int)UserType.Investor || registrationPrerequisites.UserType == (int)UserType.InvestorAndEnreprenuer)
                {
                    Agreement USTermsAgreement = await Task.FromResult(_agreement.AgreementGetEureecaUSTerms(registrationPrerequisites.LangId));
                    if (USTermsAgreement != null)
                    {
                        USTermsAgreement.MessageTypeLbl = _stringLocalizer["USTerms"].Value;
                        USTermsAgreement.IsAgreement = true;
                        registrationPopupMessages.Add(USTermsAgreement);
                    }
                }

                //Check if user Enreprenuer Return the EureecaTermsOfBusiness Agreement
                if (registrationPrerequisites.UserType == (int)UserType.Enreprenuer || registrationPrerequisites.UserType == (int)UserType.InvestorAndEnreprenuer)
                {
                    Agreement termsOfUseAgreement = await Task.FromResult(_agreement.AgreementGetEureecaTermsOfBusiness(registrationPrerequisites.CountryId, registrationPrerequisites.LangId));
                    if (termsOfUseAgreement != null)
                    {
                        termsOfUseAgreement.MessageTypeLbl = _stringLocalizer["accept_terms_of_use"].Value;
                        termsOfUseAgreement.IsAgreement = true;
                        registrationPopupMessages.Add(termsOfUseAgreement);
                    }
                }
                //Return the riskDisclosure Agreement
                Agreement riskDisclosureAgreement = await Task.FromResult(_agreement.AgreementGetRiskAgreement(registrationPrerequisites.CountryId, registrationPrerequisites.LangId));
                if (riskDisclosureAgreement != null)
                {
                    riskDisclosureAgreement.MessageTypeLbl = _stringLocalizer["RiskDisclosure"].Value;
                    riskDisclosureAgreement.IsAgreement = true;
                    registrationPopupMessages.Add(riskDisclosureAgreement);
                }

                //Return PEP agreement if the user comes from UAE-DIFC
                if (registrationPrerequisites.CountryId == 260)
                {
                    Agreement PEPAgreement = await Task.FromResult(_agreement.AgreementGetExposedPerson(registrationPrerequisites.LangId));
                    if (PEPAgreement != null)
                    {
                        PEPAgreement.MessageTypeLbl = _stringLocalizer["NotPoliticallyExposedPerson"].Value;
                        PEPAgreement.IsAgreement = true;
                        PEPAgreement.HasCheckBox = true;
                        registrationPopupMessages.Add(PEPAgreement);
                    }
                }

                registrationPrerequisite.MinimumAge = await Task.FromResult(_agreement.GetMinimunAge(registrationPrerequisites.CountryId));
                registrationPrerequisite.RegistrationPopupMessages = registrationPopupMessages;

                return Ok(new { code = 200, success = true, registrationPrerequisite });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpPost("UserRegisterUser")]
        public async Task<ActionResult> UserRegisterUser(RegisterUserRequestModel user)
        {
            try
            {
                user.UserName = Tools.FilterHTML(user.UserName);
                user.FName = Tools.FilterHTML(user.FName);
                user.LName = Tools.FilterHTML(user.LName);
                user.Email = Tools.FilterHTML(user.Email);
                user.Phone = Tools.FilterHTML(user.Phone);
                user.PromotionCode = Tools.FilterHTML(user.PromotionCode);

                int eureecaUserId;

                DateTimeFormatInfo dtfi = new DateTimeFormatInfo();
                dtfi.ShortDatePattern = "MM/dd/yyyy";
                dtfi.DateSeparator = "/";
                DateTime SelectedDate = Convert.ToDateTime(user.Month + "/" + user.Day + "/" + user.Year, dtfi);

                if (!Tools.IsValidNumber(user.Country.ToString()) || (Tools.IsValidNumber(user.Country.ToString()) && await Task.FromResult(_countryBasedControl.CountryBasedGetCountryDetailsByID(user.Country.ToString()) == 0)))
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["NotExistUserCountry"].Value });
                

                if (!Tools.IsValidNumber(user.Country.ToString()) || (Tools.IsValidNumber(user.Nationality) && await Task.FromResult(_countryBasedControl.CountryBasedGetCountryDetailsByID(user.Nationality) == 0)))
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["NotExistUserNationality"].Value });
                
                if (!Tools.IsValidDateTime(user.Month + "/" + user.Day + "/" + user.Year))
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidDateOfBirth"].Value });

                if (Tools.IsValidDateTime(user.Month + "/" + user.Day + "/" + user.Year) && !(Tools.CompareDates(SelectedDate.ToShortDateString(), DateTime.Now.AddYears(await Task.FromResult(_agreement.GetMinimunAge(int.Parse(user.Country)))).ToShortDateString()) == -1))
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidDOB"].Value });
                

                if (user.RegType == (int)RegistrationType.Normal)
                {
                    if (user.UserType == 0)
                        return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidUserType"].Value });

                    if (!Tools.IsValidUserName(user.UserName))
                    {
                        return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidName"].Value });
                    }
                    if (string.IsNullOrEmpty(user.Email) || !Tools.IsValidEmail(user.Email))
                    {
                        return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidUserEmail"].Value });
                    }
                    if ((!Tools.IsValidUserName(user.FName) && (user.RegisterLanguage == (int)Languages.English || user.RegisterLanguage == (int)Languages.Spanish)) || (!Tools.IsValidFormula(user.FName, "AR") && user.RegisterLanguage == (int)Languages.Arabic))
                    {
                        return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidName"].Value });
                    }
                    if ((!Tools.IsValidUserName(user.LName) && (user.RegisterLanguage == (int)Languages.English || user.RegisterLanguage == (int)Languages.Spanish)) || (!Tools.IsValidFormula(user.LName, "AR") && user.RegisterLanguage == (int)Languages.Arabic))
                        return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidName"].Value });

                    if (await Task.FromResult(_user.SelectByUserName(user.UserName).Rows.Count > 0))
                        return Ok(new { code = 200, success = false, message = _stringLocalizer["ExistUserName"].Value });

                    DataTable dtUserByEmail = await Task.FromResult(_user.SelectUserByEmail(user.Email));
                    if (dtUserByEmail.Rows.Count > 0)
                        if (int.Parse(dtUserByEmail.Rows[0]["User_Status"].ToString()) != (int)UserStatus.Incomplete)
                            return Ok(new { code = 200, success = false, message = _stringLocalizer["ExistEmail"].Value });
                        else
                        {
                            int UserID = int.Parse(dtUserByEmail.Rows[0]["User_ID"].ToString());
                            string user_status = ((int)UserStatus.NotVerified).ToString();
                            _user.UserUpdateUserInfo(UserID, int.Parse(dtUserByEmail.Rows[0]["CustomForum_UserID"].ToString()),
                                dtUserByEmail.Rows[0]["User_Username"].ToString(), user.UserName, user.Password, user.FName, user.LName, 0, 4, user.UserType, "", int.Parse(user.Country), "", "", "", user.Phone,
                                user.Email, "", "", "", "", int.Parse(user.Country), user_status, SelectedDate.ToShortDateString(), user.RegisterLanguage, false, user.RegisterLanguage, "", null);

                            // Agree User
                            _user.UserCheckAndUpdateUKAgreementFlag(user.UserName);
                            if (!string.IsNullOrEmpty(user.PromotionCode.Trim()))
                            {
                                _user.UserAddPromotionCode(UserID, user.PromotionCode.Trim());
                            }

                            var claims = new[] {
                        new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                        new Claim("User_ID", UserID.ToString()),
                        new Claim("User_Username", user.UserName),
                        new Claim("User_Email", user.Email) };

                            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                            var token = new JwtSecurityToken(
                                _configuration["Jwt:Issuer"],
                                _configuration["Jwt:Audience"],
                                claims,
                                expires: DateTime.UtcNow.AddDays(7),
                                signingCredentials: signIn);
                            return Ok(new { code = 200, success = true, userId = UserID, token = new JwtSecurityTokenHandler().WriteToken(token) });

                        }
                    string utmCampaign = "";
                    string utmSource = "";

                    string guid = Guid.NewGuid().ToString();
                    eureecaUserId = await Task.FromResult(_user.UserAddUser(4, user.UserName, user.FName, user.LName, int.Parse(user.Country), "", user.Phone, "", "",
                        user.Password, user.Email, SelectedDate.ToShortDateString(), "", guid, user.RegisterLanguage, user.IsPartner, utmSource, int.Parse(user.Country), user.UserIsPEP));
                    _lead.LeadUserCheckIfEureecaUpdateEureecaId(user.Email);
                    // Agree User
                    _user.UserCheckAndUpdateUKAgreementFlag(user.UserName);
                    if (!string.IsNullOrEmpty(user.PromotionCode.Trim()))
                    {
                        _user.UserAddPromotionCode(eureecaUserId, user.PromotionCode.Trim());
                    }

                    _user.UserUpdateFormType(eureecaUserId, user.UserType);
                    DataTable DtAlert = _alert.AlertGetAllShowInLogin();
                    if (DtAlert.Rows.Count > 0)
                    {
                        _alert.AlertUserAddAcceptUser(int.Parse(DtAlert.Rows[0]["Alert_ID"].ToString()), eureecaUserId, true);
                    }
                    if (user.UserType == (int)UserType.Enreprenuer)
                    {
                        _user.UserUpdateUserStatus(eureecaUserId, UserStatus.Active);
                    }

                    _user.UserUpdateUTMData(eureecaUserId, utmCampaign, utmSource);

                    /*********Custom Forum Code***********/
                    int forumUserId = _customForumUser.ForumAddUser(user.FName, user.LName, "Default.jpg", eureecaUserId, user.RegisterLanguage);
                    int topicId = _topic.TopicAddTopic(Int32.Parse(_topic.TopicGetTopicTypeDetailsByName("WALL").Rows[0]["TOPIC_TYPE_ID"].ToString()), user.UserName + " WALL TOPIC", forumUserId, String.Format("{0:dd/MM/yyyy hh:mm:ss tt}", DateTime.Now));
                    _user.UserUpdateForumUserID(eureecaUserId, topicId, forumUserId);
                    /******End*******/

                    _user.UserupdateLastUpdateDate(eureecaUserId);

                    _account.AccountCreateUserAccount(user.UserName, user.FName, user.LName, eureecaUserId);


                    DataTable dtCountry = _countryBasedControl.CountryBasedGetCountryDetails(int.Parse(user.Country), user.RegisterLanguage);
                    _user.AddUserToGoogleSheet(eureecaUserId, user.UserName, user.FName, user.LName, Enum.GetName(typeof(UserType), 4), Enum.GetName(typeof(UserType), user.UserType), SelectedDate.ToShortDateString(), DateTime.Now.Date.ToShortDateString(), user.Email, "", "'" + user.Phone + "'", "", "", dtCountry.Rows[0]["Profile_Country_Name"].ToString(), dtCountry.Rows[0]["Country_Code"].ToString(), "", Enum.GetName(typeof(Languages), user.RegisterLanguage));

                    var dtUserInfo = _user.UserGetUserInfo(user.UserName, user.Password);

                    if (dtUserInfo == null)
                    {
                        return Ok(new { code = 200, success = false, userId = eureecaUserId });
                    }
                    else
                    {

                        if (user.RegType != (int)RegistrationType.Facebook && user.RegType != (int)RegistrationType.LinkedIn)
                            _message.MessageSendAccountVerificationEmail(_user.UserGetSystemAdmin()["User_Email"].ToString(), user.Email, user.FName, _user.SelectUserByEmail(user.Email).Rows[0]["User_guid"].ToString());

                        //create claims details based on the user information
                        var claims = new[] {
                        new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                        new Claim("User_ID", eureecaUserId.ToString()),
                        new Claim("User_Username", user.UserName),
                        new Claim("User_Email", user.Email) };

                        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                        var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                        var token = new JwtSecurityToken(
                            _configuration["Jwt:Issuer"],
                            _configuration["Jwt:Audience"],
                            claims,
                            expires: DateTime.UtcNow.AddDays(7),
                            signingCredentials: signIn);
                        return Ok(new { code = 200, success = true, userId = eureecaUserId, token = new JwtSecurityTokenHandler().WriteToken(token) });

                    }
                }
                else
                    return Ok(new { code = 200, success = false, message = "invalid registration type" }); //This shoulb be changed when implement social media

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }


    }
}
