﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Interface.InboxInterface;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.PitchModels.Dto;
using Eureeca_API.Models.PitchModels.ViewModels;
using Eureeca_API.Models.UserModels.Dto;
using Eureeca_API.Models.UserModels.ViewModesl;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace Eureeca_API.Controllers
{
    [Route("api/topic/[action]")]
    [ApiController]
    public class TopicController : BaseController
    {
        private readonly ITopic _topic;
        private readonly IUser _user;
        private readonly ICustomForumUser _forumUser;
        private readonly IPitch _pitch;
        private readonly IMessage _message;
        private readonly IConfiguration _config;
        private readonly ErrHandler _errHandler;
        private readonly IStringLocalizer<Resources.TopicController> _stringLocalizer;


        public TopicController(IHttpContextAccessor httpContextAccessor, ITopic topic, IUser user, ICustomForumUser forumUser, IPitch pitch, IMessage message, IStringLocalizer<Resources.TopicController> stringLocalizer, IConfiguration config) : base(httpContextAccessor)
        {
            _topic = topic;
            _errHandler = new ErrHandler();
            _user = user;
            _forumUser = forumUser;
            _pitch = pitch;
            _message = message;
            _stringLocalizer = stringLocalizer;
            _config = config;
        }

        [HttpGet]
        public async Task<ActionResult> TopicGetQuestionsAffiliationDisclosure( [Required] int langId)
        {
            try
            {
                Tools.SetThreadCulture(langId);
                var response = await Task.FromResult(_topic.TopicGetQuestionsAffiliationDisclosure(langId));
                return Ok(new { code = 200, success = true, data = response });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpPost]
        public async Task<ActionResult> TopicPitchAddQuestion([FromForm] int pitchId, [FromForm]int userId, [FromForm] int langId, [FromForm] string questionTxt, [FromForm] int topicId,  [FromForm] int relationshipToSME, [FromForm] string? relationshipToSMEWhenOther)
        {
            try
            {
                userId = int.Parse(_userId);
                Tools.SetThreadCulture(langId);
                if (questionTxt != "")
                {
                    if (userId != 0)
                    {
                        string HhtopicWithoutModeratorAccess = "";
                        int topicTypeId = 0;
                        int hOriginalforumId = 0;
                        int HquestionerAnswererID = 0 ;
                        int topicUserId = 0;
                        DataTable dtTopic = _topic.TopicGetTopicDetails(topicId);
                        if (dtTopic.Rows.Count > 0)
                        {
                            HhtopicWithoutModeratorAccess = dtTopic.Rows[0]["TOPIC_WITHOUT_MODERATOR_ACCESS"].ToString();
                            topicTypeId = Int32.Parse(dtTopic.Rows[0]["TOPIC_TOPICTYPE_ID"].ToString());

                            hOriginalforumId = pitchId;
                            topicUserId = int.Parse(dtTopic.Rows[0]["TOPIC_USERID"].ToString());
                            DataTable dtUserDetails = _user.UserSelectById(userId);
                            if (dtUserDetails.Rows.Count > 0)
                             HquestionerAnswererID = int.Parse(dtUserDetails.Rows[0]["CustomForum_UserID"].ToString());



                        }

                        questionTxt = Tools.FilterHTML(questionTxt);
                        relationshipToSMEWhenOther = Tools.FilterHTML(relationshipToSMEWhenOther);
                        string QADate = "";
                        string userName = "";
                        string userPicture = "";
                        string userWallPath = "";
                        string lblObject = "";
                        string imageObject = "";
                        string imageExpert = "";
                        string rxpertTxt = "";

                        string lang = "";
                        if (langId == (int)Languages.English)
                        {
                            lang = "EN";
                        }
                        if (langId == (int)Languages.Arabic)
                        {
                            lang = "AR";

                        }
                        else
                        {
                            lang = "SP";
                        }

                        if (!Tools.IsValidFormula(questionTxt.Replace("\n", ""), lang))  //if text is in legal formula
                        {
                            return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidCharacters"].Value });
                            
                        }
                        else
                        {
                            QADate = String.Format("{0:dd/MM/yyyy hh:mm:ss tt}", DateTime.Now);

                            int questionId = _topic.TopicAddQuestion(questionTxt.Replace("\n", "<br />"), QADate, HquestionerAnswererID, topicId, HhtopicWithoutModeratorAccess, langId, relationshipToSME, relationshipToSMEWhenOther);
                            DataTable dtQuestionOwnerDetails = _forumUser.ForumGetUserDetails(HquestionerAnswererID, 0);
                            _user.UserUpdateUserScore(Int32.Parse(dtQuestionOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()), 2);
                            _user.UserupdateLastUpdateDate(Int32.Parse(dtQuestionOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()));

                            DataTable dtTopicType = _topic.TopicGetTopicTypeDetails(topicTypeId);

                            DataTable dtTopicOwnerDetails = _forumUser.ForumGetUserDetails(topicUserId, 0);
                            DataTable dtTopicOwnerEureecaDetails = _user.UserSelectById(Int32.Parse(dtTopicOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()));

                            if (dtTopicType.Rows[0]["TOPIC_TYPE_NAME"].ToString() == "PITCH") // if pitch topic
                            {
                                DataTable dPitchProfile = _pitch.PitchGetDedicatedPitchDetailsByLang(pitchId,(int)Languages.English);
                                if (dPitchProfile.Rows.Count == 0)
                                    dPitchProfile = _pitch.PitchGetDedicatedPitchDetailsByLang(pitchId, (int)Languages.Spanish);
                                if (dPitchProfile.Rows.Count == 0)
                                    dPitchProfile = _pitch.PitchGetDedicatedPitchDetailsByLang(pitchId, (int)Languages.Arabic);

                                _message.MessageSendCustomForumEmailsToOwner(_user.UserGetSystemAdmin(), dtTopicOwnerEureecaDetails.Rows[0], dtTopicOwnerEureecaDetails.Rows[0]["Profile_FirstName"].ToString(), dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString(), dPitchProfile.Rows[0]["Profile_PitchTitle"].ToString(), "", questionTxt.Replace("\n", "<br />"), dtTopicOwnerEureecaDetails.Rows[0]["User_guid"].ToString(), UserAction.AddQuestionToProposal);
                                _message.MessageSendMessageForUserFollowers(_user.UserGetSystemAdmin(), _user.UserGetAllUserFollowersForUser(userId), _user.UserSelectById(userId).Rows[0], "", pitchId, "", 0, UserAction.AddQuestionToProposal);
                            }
                            else if (dtTopicType.Rows[0]["TOPIC_TYPE_NAME"].ToString() == "WALL")
                            {
                                _message.MessageSendCustomForumEmailsToOwner(_user.UserGetSystemAdmin(), dtTopicOwnerEureecaDetails.Rows[0], dtTopicOwnerEureecaDetails.Rows[0]["Profile_FirstName"].ToString(), "", "", dtTopicOwnerDetails.Rows[0]["USER_WALL_ID"].ToString(), questionTxt.Replace("\n", "<br />"), dtTopicOwnerEureecaDetails.Rows[0]["User_guid"].ToString(), UserAction.AddQuestionToUser);
                                _message.MessageSendMessageForUserFollowers(_user.UserGetSystemAdmin(), _user.UserGetAllUserFollowersForUser(userId), _user.UserSelectById(userId).Rows[0], "", 0, "", hOriginalforumId, UserAction.AddQuestionToUser);
                            }

                            ////////////////////////////////
                            DataTable DTObject = _user.UserGetUserEnrollmentsByLang(Int32.Parse(dtQuestionOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()), langId, (int)ObjectsGroups.Badges);
                            if (DTObject.Rows.Count > 0)
                            {
                                lblObject = DTObject.Rows[0]["Profile_ObjectTitle"].ToString();
                                imageObject = _config.GetValue<string>("EnvironmentURL") +  DTObject.Rows[0]["Master_ImageUrlBig"].ToString();
                                imageExpert = _config.GetValue<string>("AssetsEnvironmentURL") + "images/circle-arrowsup.png";
                                rxpertTxt = "";
                            }
                            else
                            {
                                lblObject = _stringLocalizer["RegularUser"].Value;
                                imageObject = _config.GetValue<string>("AssetsEnvironmentURL") + "images/badge_Regular.png";
                                imageExpert = "";
                                rxpertTxt = "";
                            }

                            ///////////////////////////////////////
                            if (String.IsNullOrEmpty(dtQuestionOwnerDetails.Rows[0]["USER_PICTURE"].ToString()) || !System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + ("User/Thumbs/Thumb_" + dtQuestionOwnerDetails.Rows[0]["USER_PICTURE"].ToString()))))
                                userPicture = _config.GetValue<string>("EnvironmentURL") + "Images/v2/Default.jpg";
                            else
                                userPicture = _config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/" + "Thumb_" + dtQuestionOwnerDetails.Rows[0]["User_PICTURE"].ToString();

                            userWallPath = _config.GetValue<string>("EnvironmentURL") + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + dtQuestionOwnerDetails.Rows[0]["USER_WALL_ID"].ToString();

                            
                            return Ok(new { code = 200, success = true, message = _stringLocalizer["AddedSuccessfully"].Value  });

                            //return "" + QADate + "," + UserName + "," + LblObject + "," + ImageObject + "," + ImageExpert + "," + ExpertTxt + "," + UserPicture + "," + userWallPath + "," + hdnQuestionID.ToString() + "";
                        }
                    }
                    else
                    {
                        return Ok(new { code = 200, success = false, message = _stringLocalizer["AddedFails"].Value });
                    }

                }
                else
                {
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["AddedFails"].Value });
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }


        [HttpPost]
        public async Task<ActionResult> TopicPitchAddAnswer([FromForm] int userId, [FromForm] int langId, [FromForm] int pitchId, [FromForm] int topicId, [FromForm] string answerText, [FromForm] string questionId)
        {
            try
            {
                userId = int.Parse(_userId);
                if (userId != 0)
                {
                    string QADate = "";
                    string UserName = "";
                    string UserPicture = "";
                    string userWallPath = "";
                    string LblObject = "";
                    string ImageObject = "";
                    string ImageExpert = "";
                    string ExpertTxt = "";
                    string lang = "";

                    string topicWithoutModeratorAccess = "";
                    int topicTypeId = 0;
                    int hOriginalforumId = 0;
                    int questionerAnswererId = 0;
                    string topicUSERID = "";
                    DataTable dtTopic = _topic.TopicGetTopicDetails(topicId);
                    if (dtTopic.Rows.Count > 0)
                    {
                        topicWithoutModeratorAccess = dtTopic.Rows[0]["TOPIC_WITHOUT_MODERATOR_ACCESS"].ToString();
                        topicTypeId = Int32.Parse(dtTopic.Rows[0]["TOPIC_TOPICTYPE_ID"].ToString());
                        topicUSERID = dtTopic.Rows[0]["TOPIC_USERID"].ToString();

                        hOriginalforumId = pitchId;

                        DataTable dtUserDetails = _user.UserSelectById(userId);
                        if (dtUserDetails.Rows.Count > 0)
                            questionerAnswererId = int.Parse(dtUserDetails.Rows[0]["CustomForum_UserID"].ToString());



                    }
                    answerText = Tools.FilterHTML(answerText);
                    if (langId == (int) Languages.English)
                    {
                        lang = "EN";
                    }
                    else if (langId == (int)Languages.Arabic)
                    {
                        lang = "AR";

                    }
                    else
                    {
                        lang = "SP";
                    }

                    if (!Tools.IsValidFormula(answerText.Replace("\n", "<br />"), lang))  //if text is in legal formula
                    {
                        return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidCharacters"].Value });


                    }
                    else
                    {
                        // string TheAnswerText = QandABody.FilterHTML(answerText.Replace("\n", ""));
                        //int TheQuestionID = questionID;
                        QADate = String.Format("{0:dd/MM/yyyy hh:mm:ss tt}", DateTime.Now);
                        _topic.TopicAddAnswer(topicId, answerText.Replace("\n", "<br />"), QADate, userId, int.Parse(questionId), topicWithoutModeratorAccess);
                        DataTable dtAnswerOwnerDetails = _forumUser.ForumGetUserDetails(userId, 0);
                        _user.UserUpdateUserScore(Int32.Parse(dtAnswerOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()), 5);
                        _user.UserupdateLastUpdateDate(Int32.Parse(dtAnswerOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()));

                        DataTable dtUserDetails = _user.UserSelectById(Int32.Parse(dtAnswerOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()));
                        DataTable dtTopicType = _topic.TopicGetTopicTypeDetails(topicTypeId);

                        // txtQuestion.Text = "";
                        //showQuestionAnswers(int.Parse(ddlLanguage.SelectedValue));

                        DataTable dtTopicOwnerDetails = _forumUser.ForumGetUserDetails(Int32.Parse(topicUSERID), 0);
                        DataTable dtTopicOwnerEureecaDetails = _user.UserSelectById(Int32.Parse(dtTopicOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()));

                        if (dtTopicType.Rows[0]["TOPIC_TYPE_NAME"].ToString() == "PITCH") // if pitch topic
                        {
                            DataTable dPitchProfile = _pitch.PitchGetDedicatedPitchDetailsByLang(int.Parse(dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString()),  (int) Languages.English);
                            if (dPitchProfile.Rows.Count == 0)
                                dPitchProfile = _pitch.PitchGetDedicatedPitchDetailsByLang(int.Parse(dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString()), (int)Languages.Spanish);
                            if (dPitchProfile.Rows.Count == 0)
                                dPitchProfile = _pitch.PitchGetDedicatedPitchDetailsByLang(int.Parse(dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString()), (int) Languages.Arabic);

                            _message.MessageSendCustomForumEmailsToOwner(_user.UserGetSystemAdmin(), dtTopicOwnerEureecaDetails.Rows[0], dtTopicOwnerEureecaDetails.Rows[0]["Profile_FirstName"].ToString(), dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString(), dPitchProfile.Rows[0]["Profile_PitchTitle"].ToString(), "", answerText.Replace("\n", "<br />"), dtTopicOwnerEureecaDetails.Rows[0]["User_guid"].ToString(), UserAction.AddAnswerToProposal);
                            _message.MessageSendMessageForUserFollowers(_user.UserGetSystemAdmin(), _user.UserGetAllUserFollowersForUser(userId), _user.UserSelectById(userId).Rows[0], "", Int32.Parse(dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString()), "", 0, UserAction.AddAnswerToProposal);
                        }
                        else if (dtTopicType.Rows[0]["TOPIC_TYPE_NAME"].ToString() == "WALL")
                        {
                            _message.MessageSendCustomForumEmailsToOwner(_user.UserGetSystemAdmin(), dtTopicOwnerEureecaDetails.Rows[0], dtTopicOwnerEureecaDetails.Rows[0]["Profile_FirstName"].ToString(), "", "", dtTopicOwnerDetails.Rows[0]["USER_WALL_ID"].ToString(), answerText.Replace("\n", "<br />"), dtTopicOwnerEureecaDetails.Rows[0]["User_guid"].ToString(), UserAction.AddAnswerToUser);
                            _message.MessageSendMessageForUserFollowers(_user.UserGetSystemAdmin(), _user.UserGetAllUserFollowersForUser(userId), _user.UserSelectById(userId).Rows[0], "", 0, "", Convert.ToInt32(hOriginalforumId), UserAction.AddAnswerToUser);
                        }


                        ////////////////////////////////
                        DataTable DTObject = _user.UserGetUserEnrollmentsByLang(userId, langId, (int)ObjectsGroups.Badges);
                        if (DTObject.Rows.Count > 0)
                        {
                            LblObject = DTObject.Rows[0]["Profile_ObjectTitle"].ToString();
                            ImageObject = _config.GetValue<string>("EnvironmentURL") + DTObject.Rows[0]["Master_ImageUrlBig"].ToString();
                            ImageExpert = _config.GetValue<string>("AssetsEnvironmentURL") +  "images/circle-arrowsup.png";
                            ExpertTxt = "";
                        }
                        else
                        {
                            LblObject = _stringLocalizer["RegularUser"].Value;
                            ImageObject = _config.GetValue<string>("AssetsEnvironmentURL") + "images/badge_Regular.png";
                            ImageExpert = "";
                            ExpertTxt = "";
                        }
                        ///////////////////////////////////////
                        if (String.IsNullOrEmpty(dtAnswerOwnerDetails.Rows[0]["USER_PICTURE"].ToString()) || !System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + ("User/Thumbs/Thumb_" + dtAnswerOwnerDetails.Rows[0]["USER_PICTURE"].ToString()))))
                            UserPicture = _config.GetValue<string>("EnvironmentURL")  + "Images/v2/Default.jpg";
                        else
                            UserPicture = _config.GetValue<string>("AttachementsEnvironmentURL")  + "User/Thumbs/" + "Thumb_" + dtAnswerOwnerDetails.Rows[0]["User_PICTURE"].ToString();

                        userWallPath = _config.GetValue<string>("EnvironmentURL") +  "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + dtAnswerOwnerDetails.Rows[0]["USER_WALL_ID"].ToString();

                        return Ok(new { code = 200, success = true, message = _stringLocalizer["AddedAnswerSuccessfully"].Value });
                    }
                }
                else
                {
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["AddedFails"].Value });
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpPost]
        public async Task<ActionResult> TopicUserAddQuestion(AddQuestion request)
        {

            try
            {
                int userId = int.Parse(_userId);

                if (request.QuestionText != "")
                {

                    request.QuestionText = Tools.FilterHTML(request.QuestionText);
                    string CommentDate = "";
                    string siteLang = "EN";
                    switch (request.LangId)
                    {
                        case Languages.English:
                            siteLang = "EN";
                            break;
                        case Languages.Arabic:
                            siteLang = "AR";
                            break;
                        case Languages.Spanish:
                            siteLang = "SP";
                            break;
                    }
                    if (!Tools.IsValidFormula(request.QuestionText, siteLang))  //if text is in legal formula
                    {
                        return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidCharacters"].Value });
                    }
                    else
                    {
                        string defaultPicturePath = _config.GetValue<string>("EnvironmentURL") + "Images/v2/Default.jpg";
                        string PicturePath = _config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/";
                        
                        DataTable dtUserDetails = _user.UserSelectById(userId);
                        int HcommenterID = int.Parse(dtUserDetails.Rows[0]["CustomForum_UserID"].ToString());


                        
                        
                        DataTable dtTopic = _topic.TopicGetTopicDetails(request.TopicId);
                        string topicWithoutModeratorAccess = dtTopic.Rows[0]["TOPIC_WITHOUT_MODERATOR_ACCESS"].ToString();
                        int HtopicTypeID = Int32.Parse(dtTopic.Rows[0]["TOPIC_TOPICTYPE_ID"].ToString());
                        int HtopicUSERID = int.Parse(dtTopic.Rows[0]["TOPIC_USERID"].ToString());
                        
                        int questionId = _topic.TopicAddQuestion(request.QuestionText.Replace("\n", "<br />"), String.Format("{0:dd/MM/yyyy hh:mm:ss tt}", DateTime.Now), HcommenterID, request.TopicId, topicWithoutModeratorAccess, (int) request.LangId, 0, null);


                        DataTable dtQuestionOwnerDetails = _forumUser.ForumGetUserDetails(HcommenterID, (int)request.LangId);
                        string userName = dtQuestionOwnerDetails.Rows[0]["Profile_FirstName"].ToString() + " " + dtQuestionOwnerDetails.Rows[0]["Profile_LastName"].ToString();

                        string userURL = _config.GetValue<string>("EnvironmentURL") + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + dtQuestionOwnerDetails.Rows[0]["USER_WALL_ID"].ToString();
                        string imgCommenter = defaultPicturePath;
                        if (String.IsNullOrEmpty(dtQuestionOwnerDetails.Rows[0]["USER_PICTURE"].ToString()) || !System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "User/Thumbs/Thumb_" + dtQuestionOwnerDetails.Rows[0]["USER_PICTURE"].ToString())))
                            imgCommenter = (defaultPicturePath).Substring(1);
                        else
                            imgCommenter = (PicturePath + "Thumb_" + dtQuestionOwnerDetails.Rows[0]["USER_PICTURE"].ToString()).Substring(1);
                        CommentDate = String.Format("{0:dd/MM/yyyy hh:mm:ss tt}", DateTime.Now);

                        _user.UserUpdateUserScore(Int32.Parse(dtQuestionOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()), 2);
                        _user.UserupdateLastUpdateDate(Int32.Parse(dtQuestionOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()));

                        DataTable dtTopicType = _topic.TopicGetTopicTypeDetails(HtopicTypeID);//TOPIC_TOPICTYPE_ID

                        DataTable dtTopicOwnerDetails = _forumUser.ForumGetUserDetails(HtopicUSERID,(int) request.LangId);
                        DataTable dtTopicOwnerEureecaDetails = _user.UserSelectById(Int32.Parse(dtTopicOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()));

                        if (dtTopicType.Rows[0]["TOPIC_TYPE_NAME"].ToString() == "PITCH") // if pitch topic
                        {
                            DataTable dPitchProfile = _pitch.PitchGetDedicatedPitchDetails(int.Parse(dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString()), (int)Languages.English);
                            if (dPitchProfile.Rows.Count == 0)
                                dPitchProfile = _pitch.PitchGetDedicatedPitchDetails(int.Parse(dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString()), (int)Languages.Spanish);
                            if (dPitchProfile.Rows.Count == 0)
                                dPitchProfile = _pitch.PitchGetDedicatedPitchDetails(int.Parse(dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString()), (int)Languages.Arabic);

                            _message.MessageSendCustomForumEmailsToOwner(_user.UserGetSystemAdmin(), dtTopicOwnerEureecaDetails.Rows[0], dtTopicOwnerEureecaDetails.Rows[0]["Profile_FirstName"].ToString(), dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString(), dPitchProfile.Rows[0]["Profile_PitchTitle"].ToString(), "", request.QuestionText.Replace("\n", "<br />"), dtTopicOwnerEureecaDetails.Rows[0]["User_guid"].ToString(), UserAction.AddQuestionToProposal);
                            _message.MessageSendMessageForUserFollowers(_user.UserGetSystemAdmin(), _user.UserGetAllUserFollowersForUser(Int32.Parse(userId.ToString())), dtUserDetails.Rows[0], "", Int32.Parse(dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString()), "", 0, UserAction.AddQuestionToProposal);
                        }
                        else if (dtTopicType.Rows[0]["TOPIC_TYPE_NAME"].ToString() == "WALL")
                        {
                            _message.MessageSendCustomForumEmailsToOwner(_user.UserGetSystemAdmin(), dtTopicOwnerEureecaDetails.Rows[0], dtTopicOwnerEureecaDetails.Rows[0]["Profile_FirstName"].ToString(), "", "", dtTopicOwnerDetails.Rows[0]["USER_WALL_ID"].ToString(), request.QuestionText.Replace("\n", "<br />"), dtTopicOwnerEureecaDetails.Rows[0]["User_guid"].ToString(), UserAction.AddQuestionToUser);
                            _message.MessageSendMessageForUserFollowers(_user.UserGetSystemAdmin(), _user.UserGetAllUserFollowersForUser(userId), dtUserDetails.Rows[0], "", 0, "", userId, UserAction.AddQuestionToUser);
                        }

                        //DataTable DTObject = _user.UserGetUserEnrollmentsByLang(Int32.Parse(dtQuestionOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()), langId, (int)ObjectsGroups.Badges);
                        //if (DTObject.Rows.Count > 0)
                        //{
                        //    LblObject = DTObject.Rows[0]["Profile_ObjectTitle"].ToString();
                        //    ImageObject = "/" + DTObject.Rows[0]["Master_ImageUrlBig"].ToString();
                        //}
                        //else
                        //{
                        //    LblObject = "Regular Member ";
                        //    ImageObject = "/assets/images/badge_Regular.png";
                        //}

                        //ImageExpert = "/" + "assets/images/circle-arrowsup.png";
                        //string lblExpert = "Expert";

                        return Ok(new { code = 200, success = true, message = _stringLocalizer["AddedSuccessfully"].Value });

                    }


                }
                else
                {
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["AddedFails"].Value });
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPost]
        public async Task<ActionResult> UserGetQuestionsAndAnswers(UserGeneral request)
        {
            List<Question> questions = new List<Question>();
            #region questions and answers 
            DataTable dtUserDetails = _user.UserSelectById(request.UserId);
            if (dtUserDetails.Rows.Count <= 0)
                return Ok(new GeneralResponseMessage(200, false, "", _stringLocalizer["NotExistingUser"].Value));

            DataTable dtQuestions = _topic.TopicGetAcceptedQuestionsOfTopic(int.Parse(dtUserDetails.Rows[0]["CustomForum_TopicID"].ToString()), (int)request.LangId);
            if (dtQuestions.Rows.Count > 0)
            {
                foreach (DataRow dr in dtQuestions.Rows)
                {
                    Question question = new Question();
                    question.QuestionId = int.Parse(dr["QUESTION_ID"].ToString());
                    question.RelationToSME = !string.IsNullOrEmpty(dr["QUESTION_RelationshipToSME"].ToString()) ? int.Parse(dr["QUESTION_RelationshipToSME"].ToString()) : 0;
                    //question.UserId = int.Parse(dr["QUESTION_QUESTIONER_ID"].ToString());
                    question.QuestionText = dr["QUESTION_TEXT"].ToString();
                    question.QuestionDate = dr["QUESTION_DATE"].ToString();
                    question.RelationToSMEWhenOther = dr["QUESTION_RelationshipToSMEWhenOther"].ToString();
                    List<Answer> answers = new List<Answer>();
                    DataTable dtAcceptedAnswers = _topic.TopicGetAcceptedAnswersOfQuestion(int.Parse(dr["QUESTION_ID"].ToString()));
                    if (dtAcceptedAnswers.Rows.Count > 0)
                    {
                        foreach (DataRow drAnwer in dtAcceptedAnswers.Rows)
                        {
                            Answer answer = new Answer();
                            answer.AnswerId = int.Parse(drAnwer["ANSWER_ID"].ToString());
                            answer.AnswerText = drAnwer["ANSWER_TEXT"].ToString();
                            answer.AnswerDate = drAnwer["ANSWER_DATE"].ToString();
                            DataTable dtAnswererDetails = _user.UserGetDetails(int.Parse(drAnwer["USER_ID"].ToString()), (int)request.LangId);
                            if (dtAnswererDetails.Rows.Count > 0)
                            {
                                answer.Answerer = SetUser(dtAnswererDetails, drAnwer["USER_ID"].ToString(), (int)request.LangId, int.Parse(drAnwer["USER_WALL_ID"].ToString()));
                            }
                            answers.Add(answer);
                        }
                    }

                    DataTable dtQuestionerDetails = _user.UserGetDetails(int.Parse(dr["QUESTION_QUESTIONER_ID"].ToString()), (int)request.LangId);
                    DataTable dtForumQuestionerDetails = _forumUser.ForumGetUserDetails(int.Parse(dr["QUESTION_QUESTIONER_ID"].ToString()), 0);
                    if (dtQuestionerDetails.Rows.Count > 0)
                    {
                        question.Questioner = SetUser(dtQuestionerDetails, dr["QUESTION_QUESTIONER_ID"].ToString(), (int)request.LangId, int.Parse(dtForumQuestionerDetails.Rows[0]["USER_WALL_ID"].ToString()));
                    }

                    question.Answers = answers;
                    questions.Add(question);
                }

            }

            return Ok(new { code = 200, success = true, topicId = int.Parse(dtUserDetails.Rows[0]["CustomForum_TopicID"].ToString()), questions });

            #endregion

        }

        private User SetUser(DataTable dtUserDetails, string userId, int langId, int userWallId)
        {
            User user = new User();
            user.Id = userId;
            user.Username = dtUserDetails.Rows[0]["User_Username"].ToString();
            user.Email = dtUserDetails.Rows[0]["User_Email"].ToString();
            user.FirstName = dtUserDetails.Rows[0]["Profile_FirstName"].ToString();
            user.LastName = dtUserDetails.Rows[0]["Profile_LastName"].ToString();
            user.Phone = dtUserDetails.Rows[0]["User_Phone"].ToString();
            user.IsPartner = bool.Parse(dtUserDetails.Rows[0]["Is_Partner"].ToString());
            user.Guid = dtUserDetails.Rows[0]["User_guid"].ToString();
            user.LanguageId = int.Parse(dtUserDetails.Rows[0]["User_LanguageId"].ToString());
            user.CurrencyId = int.Parse(dtUserDetails.Rows[0]["User_Preferred_Currency"].ToString());

            if (String.IsNullOrEmpty(dtUserDetails.Rows[0]["USER_PICTURE"].ToString()) || !System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachmentPath") + "User/Thumbs/Thumb_" + dtUserDetails.Rows[0]["USER_PICTURE"].ToString())))
                user.Image = _config.GetValue<string>("EnvironmentURL") + "/Images/v2/Default.jpg";
            else
                user.Image = _config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dtUserDetails.Rows[0]["USER_PICTURE"].ToString();


            DataTable DTObjectAq = _user.UserGetUserEnrollmentsByLang(userWallId, langId, (int)ObjectsGroups.Badges);
            if (DTObjectAq.Rows.Count > 0)
            {
                user.BadgeName = DTObjectAq.Rows[0]["Profile_ObjectTitle"].ToString();
                user.BadgeImage = _config.GetValue<string>("EnvironmentURL") + DTObjectAq.Rows[0]["Master_ImageUrlBig"].ToString();
                //((Image)e.Item.FindControl("ImageExpert")).ImageUrl = "~/assets/images/circle-arrowsup.png";
            }
            else
            {
                user.BadgeName = _stringLocalizer["RegularUser"].Value;
                user.BadgeImage = _config.GetValue<string>("AssetsEnvironmentURL") + "images/badge_Regular.png";
            }
            return user;

        }
        [HttpPost]
        public async Task<ActionResult> TopicUserAddAnswer(AddAnswer request)
        {
            try
            {
                int userId = int.Parse(_userId); // int.Parse(_userId);
                if (request.AnswerText != "")
                {
                    request.AnswerText = Tools.FilterHTML(request.AnswerText);
                    string CommentDate = "";


                    string siteLang = "EN";
                    switch (request.LangId)
                    {
                        case Languages.English:
                            siteLang = "EN";
                            break;
                        case Languages.Arabic:
                            siteLang = "AR";
                            break;
                        case Languages.Spanish:
                            siteLang = "SP";
                            break;
                    }
                    if (!Tools.IsValidFormula(request.AnswerText, siteLang))  //if text is in legal formula
                    {
                        return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidCharacters"].Value });
                    }
                    else
                    {

                        int questionID = request.QuestionId;
                        DataTable dtTopic = _topic.TopicGetTopicDetails(request.TopicId);

                        string topicWithoutModeratorAccess = dtTopic.Rows[0]["TOPIC_WITHOUT_MODERATOR_ACCESS"].ToString();
                        int topicTypeId = Int32.Parse(dtTopic.Rows[0]["TOPIC_TOPICTYPE_ID"].ToString());
                        int topicUserId = int.Parse(dtTopic.Rows[0]["TOPIC_USERID"].ToString());



                        _topic.TopicAddAnswer(request.TopicId, request.AnswerText.Replace("\n", "<br />"), String.Format("{0:dd/MM/yyyy hh:mm:ss tt}", DateTime.Now), userId, questionID, topicWithoutModeratorAccess);
                        DataTable dtAnswerOwnerDetails = _forumUser.ForumGetUserDetails(userId, (int)request.LangId);
                        _user.UserUpdateUserScore(Int32.Parse(dtAnswerOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()), 5);
                        _user.UserupdateLastUpdateDate(Int32.Parse(dtAnswerOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()));

                        DataTable dtUserDetails = _user.UserSelectById(Int32.Parse(dtAnswerOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()));
                        DataTable dtTopicType = _topic.TopicGetTopicTypeDetails(topicTypeId);

                        DataTable dtTopicOwnerDetails = _forumUser.ForumGetUserDetails(Int32.Parse(dtTopic.Rows[0]["TOPIC_USERID"].ToString()), 0);
                        DataTable dtTopicOwnerEureecaDetails = _user.UserSelectById(Int32.Parse(dtTopicOwnerDetails.Rows[0]["USER_WALL_ID"].ToString()));

                        if (dtTopicType.Rows[0]["TOPIC_TYPE_NAME"].ToString() == "PITCH") // if pitch topic
                        {
                            DataTable dPitchProfile = _pitch.PitchGetDedicatedPitchDetails(int.Parse(dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString()),(int) Languages.English);
                            if (dPitchProfile.Rows.Count == 0)
                                dPitchProfile = _pitch.PitchGetDedicatedPitchDetails(int.Parse(dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString()), (int)Languages.Spanish);
                            if (dPitchProfile.Rows.Count == 0)
                                dPitchProfile = _pitch.PitchGetDedicatedPitchDetails(int.Parse(dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString()), (int)Languages.Arabic);

                            _message.MessageSendCustomForumEmailsToOwner(_user.UserGetSystemAdmin(), dtTopicOwnerEureecaDetails.Rows[0], dtTopicOwnerEureecaDetails.Rows[0]["Profile_FirstName"].ToString(), dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString(), dPitchProfile.Rows[0]["Profile_PitchTitle"].ToString(), "", request.AnswerText.Replace("\n", "<br />"), dtTopicOwnerEureecaDetails.Rows[0]["User_guid"].ToString(), UserAction.AddAnswerToProposal);
                            _message.MessageSendMessageForUserFollowers(_user.UserGetSystemAdmin(), _user.UserGetAllUserFollowersForUser(userId), _user.UserSelectById(userId).Rows[0], "", Int32.Parse(dtTopicOwnerDetails.Rows[0]["USER_PITCH_ID"].ToString()), "", 0, UserAction.AddAnswerToProposal);
                        }
                        else if (dtTopicType.Rows[0]["TOPIC_TYPE_NAME"].ToString() == "WALL")
                        {
                            _message.MessageSendCustomForumEmailsToOwner(_user.UserGetSystemAdmin(), dtTopicOwnerEureecaDetails.Rows[0], dtTopicOwnerEureecaDetails.Rows[0]["Profile_FirstName"].ToString(), "", "", dtTopicOwnerDetails.Rows[0]["USER_WALL_ID"].ToString(),request. AnswerText.Replace("\n", "<br />"), dtTopicOwnerEureecaDetails.Rows[0]["User_guid"].ToString(), UserAction.AddAnswerToUser);
                            _message.MessageSendMessageForUserFollowers(_user.UserGetSystemAdmin(), _user.UserGetAllUserFollowersForUser(userId), _user.UserSelectById(userId).Rows[0], "", 0, "", userId, UserAction.AddAnswerToUser);
                        }

                        string UserName = dtAnswerOwnerDetails.Rows[0]["Profile_FirstName"].ToString() + " " + dtAnswerOwnerDetails.Rows[0]["Profile_LastName"].ToString();

                        return Ok(new { code = 200, success = true, message = _stringLocalizer["AddedAnswerSuccessfully"].Value });

                    }


                }
                else
                {
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["AddedFails"].Value });
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }




    }
}
