﻿using Eureeca_API.General;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Models.PitchModels.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace Eureeca_API.Controllers
{
    [Route("Api/PitchScore")]
    [ApiController]
    public class PitchScoreController : ControllerBase
    {
        private readonly IPitchScore _pitchScore;
        private readonly IPitch _pitch;
        private readonly ErrHandler _errHandler;

        public PitchScoreController(IPitchScore pitchScore, IPitch pitch)
        {
            _pitchScore = pitchScore;
            _errHandler = new ErrHandler();
            _pitch = pitch;
        }

        [HttpGet("PitchScoreGetData")]
        public async Task<ActionResult> PitchScoreGetData(int? pitchId)
        {
            try
            {
                var response = await Task.FromResult(_pitchScore.PitchScoreGetData(pitchId));
                if (response == null) { return NotFound(); }
                return Ok(new { code = 200, success = true,  response });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpPost("PitchScoreAddEdit")]
        public async Task<ActionResult> PitchScoreAddEdit(PitchScore pitchScore)
        {
            try
            {
                var response = await Task.FromResult(_pitchScore.PitchScoreAddEdit(pitchScore.PitchId, pitchScore.HasPitchDeckRank, pitchScore.FinancialsHasHistoricalsAndProjectionsRank, pitchScore.CountryRank, pitchScore.IsReligiouslyPoliticallySexuallyAffiliatedRank, pitchScore.ProblemsInThePastRank, pitchScore.RecognizableBuisnessRank, pitchScore.HowComplicatedRank, pitchScore.IsBadRank, pitchScore.YearsInOperationRank, pitchScore.IdeaRank, pitchScore.TeamViewRank, pitchScore.SucceedingRank, pitchScore.ScalabilityRank, pitchScore.BusinessIsAlreadyRevenueRank, pitchScore.WebsiteRank, pitchScore.HowMuchCompanyRaisingRank, pitchScore.Score, pitchScore.BDNotes, pitchScore.PrefferedLinks, pitchScore.RM));
                if (response == null) { return NotFound(); }
                if (response == 0)
                    return Ok(new { code = 200, success = true, message = "Error Occured" });
                else
                    return Ok(new { code = 200, success = true, message = "Success" });

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("PitchScoreGetPitchDetails")]
        public async Task<ActionResult> PitchScoreGetPitchDetails([Required]int pitchId)
        {
            try
            {
                DataTable dtPitchDetails = await Task.FromResult(_pitch.PitchGetDedicatedPitchDetailsByLang(pitchId, 1));
                if (dtPitchDetails == null) { return NotFound(); }
                if (dtPitchDetails.Rows.Count > 0)
                {
                    PitchScorePitchDetails pitchScorePitchDetails = new PitchScorePitchDetails();
                    pitchScorePitchDetails.PitchTitle = dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString() != null ? dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString() : "";

                    if (!string.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_ClosingDate"].ToString()))
                    {
                        DateTime PichClosingDateView = Convert.ToDateTime(dtPitchDetails.Rows[0]["Pitch_ClosingDate"].ToString());
                        pitchScorePitchDetails.ClosingDate = String.Format("{0:d MMM  yyyy}", PichClosingDateView);
                    }

                    if (!string.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_CreationDate"].ToString()))
                    {
                        DateTime PichCreationDateView = Convert.ToDateTime(dtPitchDetails.Rows[0]["Pitch_CreationDate"].ToString());
                        pitchScorePitchDetails.CreationDate = String.Format("{0:d MMM  yyyy}", PichCreationDateView);
                    }

                    pitchScorePitchDetails.Target = !string.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_InvestmentRequired"].ToString()) ? double.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentRequired"].ToString()) : 0 ;
                    pitchScorePitchDetails.PreMoney = !string.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_Pre_Money_Val"].ToString())  ?double.Parse(dtPitchDetails.Rows[0]["Pitch_Pre_Money_Val"].ToString()) : 0;
                    pitchScorePitchDetails.ShortSummary = dtPitchDetails.Rows[0]["Profile_PitchShortSummary"].ToString() != null ? dtPitchDetails.Rows[0]["Profile_PitchShortSummary"].ToString() : "";
                    pitchScorePitchDetails.Country = dtPitchDetails.Rows[0]["profile_country_name"].ToString() != null ? dtPitchDetails.Rows[0]["profile_country_name"].ToString() : "" ;
                    pitchScorePitchDetails.Equity = !string.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_EquityOffered"].ToString()) ? double.Parse(dtPitchDetails.Rows[0]["Pitch_EquityOffered"].ToString()): 0;

                    return Ok(new { code = 200, success = true, pitchScorePitchDetails });
                }
                return Ok(new { code = 200, success = true, message = "Error Occured" });
               

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("PitchScoreGetProposalList")]
        public async Task<ActionResult> PitchScoreGetProposalList([Required] int langId, [Required] int pageNo, [Required] int pageSize)
        {
            try
            {
                int recordCount = 0;
                DataTable dtPitchList = await Task.FromResult(_pitchScore.PitchScoreProposalList(langId, pageNo, pageSize, out recordCount));
                List<PitchScoreProposalListModel> proposalList = new List<PitchScoreProposalListModel>();
                if (dtPitchList == null) { return NotFound(); }
                if (dtPitchList.Rows.Count > 0)
                {
                    foreach (DataRow row in dtPitchList.Rows)
                    {
                        PitchScoreProposalListModel proposalModel = new PitchScoreProposalListModel();
                        proposalModel.PitchTitle = row["Profile_PitchTitle"].ToString() ?? "";
                        proposalModel.PitchId = int.Parse(row["Pitch_ID"].ToString());
                        
                        proposalModel.PitchScore = row["PitchScore_Score"].ToString();
                        proposalList.Add(proposalModel);

                    }
                }
                return Ok(new { code = 200, success = true, proposalList });


            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }

    }
}
