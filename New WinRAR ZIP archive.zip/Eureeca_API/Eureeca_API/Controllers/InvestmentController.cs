﻿using Eureeca_API.Controllers.Investment;
using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Interface.AccountInterface;
using Eureeca_API.Interface.CountryBasedInterface;
using Eureeca_API.Interface.InboxInterface;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.InvestmentModels.Dto;
using Eureeca_API.Models.InvestmentModels.ViewModels;
using Eureeca_API.Models.UserModels.ViewModesl;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Localization;
using Microsoft.Xrm.Sdk;

using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Net;

//----
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Client;

namespace Eureeca_API.Controllers
{
    [Authorize]
    [Route("api/investment/[action]")]
    [ApiController]
    public class InvestmentController : BaseController
    {
        private readonly IInvestment _investment;
        private readonly ErrHandler _errHandler;
        private readonly IMemoryCache _memoryCache;
        private readonly IUser _user;
        private readonly IPitch _pitch;
        private readonly IGeneral _general;
        private readonly ICountryBasedControl _countryBasedControl;
        private readonly IMessage _message;
        private readonly IAccount _account;
        private readonly IConfiguration _config;
        private readonly IPitchLikeFollower _pitchLikeFollower;

        private readonly IStringLocalizer<Resources.InvestmentController> _stringLocalizer;



        public InvestmentController(IHttpContextAccessor httpContextAccessor, IInvestment investment, IMemoryCache memoryCache, IUser user, IPitch pitch, IGeneral general, ICountryBasedControl countryBasedControl, IMessage message, IAccount account, IPitchLikeFollower pitchLikeFollower, IConfiguration config, IStringLocalizer<Resources.InvestmentController> stringLocalizer) : base(httpContextAccessor)
        {
            _investment = investment;
            _errHandler = new ErrHandler();
            _memoryCache = memoryCache;
            _user = user;
            _pitch = pitch;
            _general = general;
            _countryBasedControl = countryBasedControl;
            _message = message;
            _account = account;
            _pitchLikeFollower = pitchLikeFollower;
            _config = config;
            _stringLocalizer = stringLocalizer;

        }
        [HttpPost]
        public async Task<ActionResult<string>> PostInvestmentDetailsToCRMAsync()
        {
            IOrganizationService organizationService = null;
            try
            {
                ClientCredentials clientCredentials = new ClientCredentials();
                clientCredentials.UserName.UserName = "@.onmicrosoft.com";
                clientCredentials.UserName.Password = "";
                // For Dynamics 365 Customer Engagement V9.X, set Security Protocol as TLS12
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                // Get the URL from CRM, Navigate to Settings -> Customizations -> Developer Resources
                // Copy and Paste Organization Service Endpoint Address URL
                organizationService = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://.api..dynamics.com/XRMServices/2011/Organization.svc"),
                 null, clientCredentials, null);
                if (organizationService != null)
                {
                    Guid userid = ((WhoAmIResponse)organizationService.Execute(new WhoAmIRequest())).UserId;
                    if (userid != Guid.Empty)
                    {
                        Console.WriteLine("Connection Successful!...");
                    }
                }
                else
                {
                    Console.WriteLine("Failed to Established Connection!!!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught - " + ex.Message);
            }
            Console.ReadKey();

        }
        private void CreateRecord(CdsServiceClient cdsServiceClient)
        {
            try
            {
                Entity newAccount = new Entity("account");
                newAccount["name"] = "Subhash and Company";
                cdsServiceClient.Create(newAccount);
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void ReadAccount(CdsServiceClient cdsServiceClient)
        {
            try
            {
                QueryExpression query = new QueryExpression("account");
                query.ColumnSet = new ColumnSet(true);
                var response = cdsServiceClient.RetrieveMultiple(query);


                foreach (Entity item in response.Entities)
                {
                    Console.WriteLine($"Account: {item.GetAttributeValue<string>("name")} [{item.GetAttributeValue<EntityReference>("ownerid").Name}]");
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        //public static async Task<string> PostInvestmentDetailsAsync()
        //{
        //    string organizationUrl = "https://eureeca-demo.crm4.dynamics.com/";
        //    string clientId = "f4d35a2b-4270-470c-b5ce-1f371381d6ca";
        //    string userName = "eureeca@powerapssdemo.onmicrosoft.com";
        //    string password = "LogictecaCRM$";
        //    //string appKey = "Xxxx81H/7TUFErt5C/xxxxxxxxxxxxxxxxxxxxxxx=";
        //    //string aadInstance = "https://login.microsoftonline.com/";
        //    //string tenantID = "xxxxxxxx.onmicrosoft.com";

        //    var userCredential = new UserCredential(userName);
        //    //var credentials = new UserPasswordCredential(userName, password);


        //    string apiVersion = "9.2";
        //    string webApiUrl = $"{organizationUrl}/api/data/v{apiVersion}/";

        //    var authParameters = AuthenticationParameters.CreateFromUrlAsync(new Uri(webApiUrl)).Result;
        //    var authContext = new AuthenticationContext(authParameters.Authority, false);
        //    var authResult = authContext.AcquireTokenAsync(organizationUrl, clientId, userCredential);
        //    var authHeader = new AuthenticationHeaderValue("Bearer", authResult.AccessToken);
        //    try
        //    {
        //        ClientCredential clientcred = new ClientCredential(clientId, appKey);
        //        AuthenticationContext authenticationContext = new AuthenticationContext(aadInstance + tenantID);

        //        AuthenticationResult authenticationResult = await authenticationContext.AcquireTokenAsync(organizationUrl, clientcred);
        //        var requestedToken = authenticationResult.AccessToken;

        //        var webRequest = (HttpWebRequest)WebRequest.Create(new Uri("https://xxxxxxxxxx.api.crmx.dynamics.com/api/data/v9.1/contacts()?$select=fullname,contactid,emailaddress1&$filter=mobilephone eq '" + History.userMobile + "'"));
        //        webRequest.KeepAlive = false;
        //        webRequest.ServicePoint.ConnectionLimit = 1;

        //        webRequest.Method = "GET";
        //        webRequest.ContentLength = 0;
        //        webRequest.Headers.Add("Authorization", String.Format("Bearer {0}", requestedToken));
        //        webRequest.Headers.Add("OData-MaxVersion", "4.0");
        //        webRequest.Headers.Add("OData-Version", "4.0");
        //        webRequest.Accept = "application/json";
        //        webRequest.ContentType = "application/json";

        //        //if contact with user provided phone number found, ask for problem description
        //        try
        //        {
        //            using (var response1 = webRequest.GetResponse() as System.Net.HttpWebResponse)
        //            {
        //                using (var reader = new System.IO.StreamReader(response1.GetResponseStream()))
        //                {
        //                    var response = reader.ReadToEnd();
        //                }
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            //History.isUserFound = false;
        //            string error = ex.Message;
        //            return "Sorry, I found that you are not using any of our services...";
        //        }
        //    }
        //    catch (Exception ex) { return ex.ToString(); }

        //}
        [HttpPost]
        public async Task<ActionResult<InvestmentInfoResponseModel>> InvestmentGetData(InvestmentGetData investmentGetData)
        {
            try
            {
                investmentGetData.UserId = int.Parse(_userId);
                Tools.SetThreadCulture((int)investmentGetData.LangId);

                var response = await Task.FromResult(_investment.InvestmentGetData(investmentGetData.PitchId, investmentGetData.UserId, (int)investmentGetData.CurrencyId, (int)investmentGetData.LangId));
                if (response == null) { return NotFound(); }

                if (response.ResponseStatus == (int)ResponseStatus.NullUserId)
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["NeedLogin"].Value, showKYC = false });
                else if (response.ResponseStatus == (int)ResponseStatus.UserDoesNotExist)
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["NotExistingUser"].Value, showKYC = false });
                else if (response.ResponseStatus == (int)ResponseStatus.InActiveOrCanceledUser)
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["NotExistingUser"].Value, showKYC = false });
                else if (response.ResponseStatus == (int)ResponseStatus.InvestmentFrozen)
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["InvestmentFrozen"].Value, showKYC = false });
                else if (response.ResponseStatus == (int)ResponseStatus.InvestmentPrevention)
                    return Ok(new { code = 200, success = false, message = response.PreventionReason, showKYC = false });
                else if (response.ResponseStatus == (int)ResponseStatus.EmptyDataTable)
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidPitchId"].Value, showKYC = false });
                else if (response.ResponseStatus == (int)ResponseStatus.KYCNotVerified || response.ResponseStatus == (int)ResponseStatus.KYCIssue)
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidPitchId"].Value, showKYC = true });

                return Ok(new { code = 200, success = true, response });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }


        }

        [HttpGet]
        public async Task<ActionResult<GeneralResponseMessage>> InvestmentGetPreCommitMessage([Required] int langId)
        {
            try
            {
                Tools.SetThreadCulture(langId);
                return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, _stringLocalizer["PreCommitMessageTitle"].Value, _stringLocalizer["PreCommitMessage"].Value)));

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");

            }
        }

        [HttpPost]
        public async Task<ActionResult<GeneralResponseMessage>> InvestmentQuickInvest(QuickInvestmentRequestModel model)
        {
            try
            {
                model.UserId = int.Parse(_userId);
                Tools.SetThreadCulture(model.LangId);
                DataTable dtPitchDetails = await Task.FromResult(_pitch.PitchGetDedicatedPitchDetailsByLang(model.ProposalId, (int)Languages.English));

                if (!_memoryCache.TryGetValue(model.ProposalId, out DateTime value))
                {
                    bool isInvestmentCompleted = false;
                    QuickInvestResponseModel responseModel = new QuickInvestResponseModel();

                    if (model.UserId == 0)
                        return await Task.FromResult(Ok(new { code = 200, success = false, message = _stringLocalizer["NeedLogin"].Value, showKYC = false, requestAccess = false }));

                    DataTable dtUserInfo = _user.UserSelectById(model.UserId);

                    if (dtUserInfo == null || dtUserInfo.Rows.Count == 0)
                        return await Task.FromResult(Ok(new { code = 200, success = false, message = _stringLocalizer["NotExistingUser"].Value, showKYC = false, requestAccess = false }));

                    if (!(int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) == (int)UserType.InvestorAndEnreprenuer || int.Parse(dtUserInfo.Rows[0]["User_UserFormType"].ToString()) == (int)UserType.Investor))
                        return await Task.FromResult(Ok(new { code = 200, success = false, message = _stringLocalizer["UserTypeNotAllowedToInvest"].Value, showKYC = false, requestAccess = false }));


                    KYCModel kyc = _user.KYCGetRequiredFiles(model.UserId, int.Parse(dtUserInfo.Rows[0]["User_Country"].ToString()));
                    if (kyc != null && !kyc.UserCanPay && kyc.KYCOverAllStatus == (int)KYCUserDocsStatus.PendingApproval)
                        return await Task.FromResult(Ok(new { code = 200, success = false, message = _stringLocalizer["KYCMessage"].Value, showKYC = true, requestAccess = false }));

                    else if (kyc != null && !kyc.UserCanPay && kyc.KYCOverAllStatus == (int)KYCUserDocsStatus.NotUploaded)
                        return await Task.FromResult(Ok(new { code = 200, success = false, message = _stringLocalizer["KYCMessage"].Value, showKYC = true, requestAccess = false }));

                    if (dtPitchDetails == null || dtPitchDetails.Rows.Count <= 0)
                        return Ok(new { code = 200, success = false, message = _stringLocalizer["InvalidPitchId"].Value, showKYC = false, requestAccess = false });

                    if (bool.Parse(dtPitchDetails.Rows[0]["Pitch_HasDiscount"].ToString()) && GetCurrentTranchEdge(dtPitchDetails) != 0)
                        InvestmentSingleton.Instance.AddProposalToMemory(model.ProposalId, _memoryCache);

                    DataTable dtCurreny = _general.CurrencyGetCurrencyByID(model.CurrencyId);
                    string currencySymbol = dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$";

                    responseModel.IsInvestmentCompleted = false;

                    string amountCurrency = _investment.GetMoneyAfterExchange(model.UserId, model.ProposalId, model.CurrencyId, model.Amount.ToString(), "2");

                    int IAADAfterExchange = model.Amount;
                    string IAAD = Tools.FilterHTML(amountCurrency);

                    InvestmentCheckResponseModel investmentCheckResponse = CheckInvestmentAmounts(IAAD, IAADAfterExchange, model.UserId, model.LangId, model.ProposalId, model.CurrencyId, model.PreCommitProcess);
                    if (!investmentCheckResponse.IsAllowedInvestment)
                    {
                        InvestmentSingleton.Instance.RemoveProposalFromMemory(model.ProposalId, _memoryCache);
                        return await Task.FromResult(Ok(new { code = 200, success = false, message = investmentCheckResponse.PreventionMessage, showKYC = false, requestAccess = investmentCheckResponse.PreventionMessage == _stringLocalizer["InvestmentPreventionNeedRequest"].Value }));
                    }

                    if (Math.Abs((Double.Parse(InvestmentGetAmountAfterExchange(model.UserId, IAADAfterExchange, model.CurrencyId,
                        "2", model.ProposalId))) - (investmentCheckResponse.AmountForInvest)) <=
                        (Double.Parse(InvestmentGetAmountAfterExchange(model.UserId, 1, model.CurrencyId, "2", model.ProposalId))))
                    {
                        if (investmentCheckResponse.IsAllowedInvestment)
                        {

                            isInvestmentCompleted = invest(dtUserInfo, dtPitchDetails, currencySymbol, IAADAfterExchange, model.ProposalId, model.CurrencyId, model.LangId, model.SendInvestmentEmails, investmentCheckResponse);

                            if (isInvestmentCompleted)
                            {
                                InvestmentSingleton.Instance.RemoveProposalFromMemory(model.ProposalId, _memoryCache);
                                return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, _stringLocalizer["Congratulations"].Value, _stringLocalizer["CongratulationsMessage"].Value + " " + currencySymbol + model.Amount + " " + _stringLocalizer["In"].Value + " " + dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString())));

                            }
                        }
                    }
                    else
                    {
                        InvestmentSingleton.Instance.RemoveProposalFromMemory(model.ProposalId, _memoryCache);

                        return Ok(new { code = 200, success = false, message = _stringLocalizer["InvestmentFrozen"].Value, showKYC = false, requestAccess = false });

                    }


                }

                if ((dtPitchDetails != null && dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "Early Access") || model.PreCommitProcess)
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["AnotherPreCommitTransactionText"].Value, showKYC = false, requestAccess = false });// another invest message
                else
                    return Ok(new { code = 200, success = false, message = _stringLocalizer["AnotherTransactionText"].Value, showKYC = false, requestAccess = false });// another invest message


            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                InvestmentSingleton.Instance.RemoveProposalFromMemory(model.ProposalId, _memoryCache);
                return StatusCode(500, "Internal server error");
            }

        }


        private InvestmentCheckResponseModel CheckInvestmentAmounts(string IAAD, int IAADAfterExchange, int userId, int langId, int pitchId, int currencyId, bool PreCommitProcess)
        {
            InvestmentCheckResponseModel investmentCheckResponse = new InvestmentCheckResponseModel();
            try
            {
                string preventionMessage = "";
                _pitch.PitchTestExpiration(langId, pitchId);

                DataTable dtUserInfo = _user.UserSelectById(userId);

                DataTable dtUserBalanceByCurrency = _user.UserIsAllowedInvestmentCurrency(userId, currencyId);

                double User_Balance_Currency = 0.0, user_Balance_USD_Result_By_Currency_PRate = 0.00;
                if (dtUserBalanceByCurrency.Rows.Count > 0)
                    User_Balance_Currency = double.Parse(dtUserBalanceByCurrency.Rows[0]["User_Balance"].ToString());

                DataTable DTPitchRateInitiate = _pitch.PitchGetPitchRate(pitchId, currencyId);
                if (DTPitchRateInitiate.Rows.Count > 0)
                {
                    investmentCheckResponse.PitchRate = DTPitchRateInitiate.Rows[0]["Pitch_rate"].ToString();
                    user_Balance_USD_Result_By_Currency_PRate = User_Balance_Currency / double.Parse(investmentCheckResponse.PitchRate);
                }

                if (user_Balance_USD_Result_By_Currency_PRate == 0.00 || User_Balance_Currency == 0.00 || User_Balance_Currency < IAADAfterExchange)
                {

                    investmentCheckResponse.PreventionMessage = _stringLocalizer["InsufficientFunds"].Value; investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "NOFUND";

                }
                else
                {
                    //investmentCheckResponse.IsAllowedInvestment = true;
                    DataTable dtPitchDetails = _pitch.PitchGetDedicatedPitchDetailsByLang(pitchId, (int)Languages.English);
                    if (dtPitchDetails.Rows.Count > 0)
                    {
                        if (bool.Parse(dtPitchDetails.Rows[0]["Pitch_Is_Investment_Frozen"].ToString()) && !_user.UserIsAdmin(userId))
                        { investmentCheckResponse.PreventionMessage = _stringLocalizer["InvestmentFrozen"].Value; investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "Investment_Frozen"; }
                        else if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() != "published" && dtPitchDetails.Rows[0]["Pitch_Status"].ToString() != "Overfunding" && dtPitchDetails.Rows[0]["Pitch_Status"].ToString() != "Early Access")
                        { investmentCheckResponse.PreventionMessage = _stringLocalizer["InvestmentPreventionCompletedProposal"].Value; investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                        else
                        {
                            #region Investment Prevention
                            if (_investment.InvestmentPrevention(pitchId, dtUserInfo.Rows[0]["User_Country"].ToString(), userId, out preventionMessage))
                            {
                                investmentCheckResponse.PreventionMessage = preventionMessage;
                                investmentCheckResponse.IsAllowedInvestment = false;
                                return investmentCheckResponse;
                            }
                            #endregion

                            string Currency_Symbol = "";
                            string Currency_App = "";
                            DataTable DTCurrency = _general.CurrencyGetCurrencyByID(currencyId);
                            if (DTCurrency.Rows.Count > 0)
                            {
                                Currency_Symbol = DTCurrency.Rows[0]["Currency_symbol"].ToString();
                                Currency_App = DTCurrency.Rows[0]["Currency_App"].ToString();
                            }

                            if (!Tools.IsValidNumber(IAAD))
                            { investmentCheckResponse.PreventionMessage = _stringLocalizer["OnlyIntegers"].Value; investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; return investmentCheckResponse; }
                            else
                            {
                                if (int.Parse(IAAD) <= 0)
                                { investmentCheckResponse.PreventionMessage = MinimumInvestmentAction(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; return investmentCheckResponse; }
                                else
                                {
                                    double SumPendingPreInvestmentsForUserByCurrency = 0;
                                    if (!PreCommitProcess)
                                        SumPendingPreInvestmentsForUserByCurrency = _pitch.PitchGetSumPendingPreInvestmentsForUserByCurrency(int.Parse(dtUserInfo.Rows[0]["User_ID"].ToString()), currencyId); //this is only in normal invest because in precommit process in the admin, the UB is already reserved

                                    var SumPendingOffersForUserByCurrency = _user.APIGetSumPendingOffersForUserByCurrency(int.Parse(dtUserInfo.Rows[0]["User_ID"].ToString()), currencyId);
                                    if (SumPendingOffersForUserByCurrency != null || true) // I set || true waiting what we will do with 2m
                                    {

                                        if (User_Balance_Currency < SumPendingPreInvestmentsForUserByCurrency + IAADAfterExchange + 0/*SumPendingOffersForUserByCurrency.SumPendingOffers*/)
                                        { investmentCheckResponse.PreventionMessage = _stringLocalizer["BalanceLTCommittedText1"].Value + " " + Currency_Symbol + (SumPendingPreInvestmentsForUserByCurrency + 0)/*SumPendingOffersForUserByCurrency.SumPendingOffers).ToString("#,##0")*/ + " " + _stringLocalizer["BalanceLTCommittedText2"].Value; investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                        else
                                        {
                                            int SumPendingPreInvestmentsAfterDiscount = 0;
                                            if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "Early Access")
                                                SumPendingPreInvestmentsAfterDiscount = _pitch.PitchGetSumPendingPreInvestmentsAfterDiscount(pitchId);

                                            investmentCheckResponse.PitchBalance = Int32.Parse(dtPitchDetails.Rows[0]["Pitch_Balance"].ToString()) + SumPendingPreInvestmentsAfterDiscount;

                                            //if the pitch has approved overfunding offers
                                            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["OverSubStatus"].ToString()) && int.Parse(dtPitchDetails.Rows[0]["OverSubStatus"].ToString()) == 2)
                                                investmentCheckResponse.PitchInvestmentRequired = int.Parse(dtPitchDetails.Rows[0]["OverSubAmount"].ToString());
                                            //if the pitch doesn't have approved overfunding offers
                                            else
                                            {
                                                if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "completed") //this only for the status if pitch was in overfunding mode then the user stopped overfunding and changed it's status to completed
                                                    investmentCheckResponse.PitchInvestmentRequired = Double.Parse(dtPitchDetails.Rows[0]["Pitch_Balance"].ToString());
                                                else
                                                    investmentCheckResponse.PitchInvestmentRequired = Double.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentRequired"].ToString());
                                            }
                                            investmentCheckResponse.RemainAllowedInv = (int)investmentCheckResponse.PitchInvestmentRequired - investmentCheckResponse.PitchBalance;

                                            if ((Double.Parse(IAAD) > Double.Parse(investmentCheckResponse.RemainAllowedInv.ToString())) && ((Double.Parse(IAAD) - Double.Parse(investmentCheckResponse.RemainAllowedInv.ToString())) <= (Double.Parse(InvestmentGetAmountAfterExchange(userId, 1, currencyId, "2", pitchId)))) && (currencyId.ToString() != "1"))
                                            { investmentCheckResponse.NewAmount = IAAD = investmentCheckResponse.RemainAllowedInv.ToString(); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "maxAllowedInvTextAfterExchange"; }
                                            else
                                            {
                                                if (Double.Parse(IAAD) > Double.Parse(investmentCheckResponse.RemainAllowedInv.ToString()))
                                                { investmentCheckResponse.PreventionMessage = _stringLocalizer["MaxAllowedInvText"].Value + " " + Currency_Symbol + double.Parse(InvestmentGetAmountAfterExchange(userId, investmentCheckResponse.RemainAllowedInv, currencyId, "1", int.Parse(dtPitchDetails.Rows[0]["Pitch_ID"].ToString()))).ToString("#,##0"); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                else if (!IsAllowedMalaysianUserInvestment(userId, dtUserInfo.Rows[0]["User_Country"].ToString(), dtUserInfo.Rows[0]["User_InvestorClassification"].ToString(), currencyId, pitchId, IAAD, out preventionMessage))
                                                { }
                                                else if (CheckMaxInvAmountExceeded(userId, pitchId, dtUserInfo.Rows[0]["User_Country"].ToString(), currencyId, IAADAfterExchange, out preventionMessage))
                                                { }
                                                else
                                                {
                                                    #region investment way work
                                                    if (!bool.Parse(dtPitchDetails.Rows[0]["Pitch_HasDiscount"].ToString())) //without-discount
                                                    {
                                                        if (int.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWay"].ToString()) == 1) //multiple of dollars
                                                            investmentCheckResponse.InvestmentWayFlag = 1;
                                                        else if (int.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWay"].ToString()) == 0) //minimum of dollars
                                                            investmentCheckResponse.InvestmentWayFlag = 2;
                                                    }
                                                    else //with-discount
                                                    {
                                                        if (int.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWay"].ToString()) == 1) //multiple of dollars
                                                            investmentCheckResponse.InvestmentWayFlag = 3;
                                                        else if (int.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWay"].ToString()) == 0) //minimum of dollars
                                                            investmentCheckResponse.InvestmentWayFlag = 4;
                                                    }
                                                    #endregion

                                                    if (bool.Parse(dtPitchDetails.Rows[0]["Pitch_HasMaxUserInvestmentAmount"].ToString()))
                                                    {
                                                        investmentCheckResponse.HasMaxUserInvAmount = true;
                                                        investmentCheckResponse.MaxInvAmount = int.Parse(dtPitchDetails.Rows[0]["Pitch_MaxUserInvestmentAmount"].ToString());
                                                    }
                                                    else
                                                        investmentCheckResponse.HasMaxUserInvAmount = false;

                                                    investmentCheckResponse.DollarsShares = _pitch.PitchCalcSharesOfDollars(int.Parse(IAAD), float.Parse(dtPitchDetails.Rows[0]["Pitch_Share_Price"].ToString()), investmentCheckResponse.PitchBalance, bool.Parse(dtPitchDetails.Rows[0]["Pitch_HasDiscount"].ToString()), String.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize1"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize1"].ToString()), String.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString()), String.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize2"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize2"].ToString()), String.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString()), String.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize3"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize3"].ToString()), String.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString()), String.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchSize4"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize4"].ToString()), String.IsNullOrWhiteSpace(dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString()) ? 0 : int.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString()));
                                                    investmentCheckResponse.TxtNumberShare = investmentCheckResponse.DollarsShares.ToString();
                                                    bool MoreMaxUserInvAmount = InvestmentCheckIsMoreMaxUserInvestmentAmount(userId, pitchId, long.Parse(IAAD), (int)Currencies.USD, investmentCheckResponse.MaxInvAmount);

                                                    if (investmentCheckResponse.InvestmentWayFlag == 1)
                                                    {
                                                        #region without-discount, multiple of dollars
                                                        if (investmentCheckResponse.RemainAllowedInv >= Double.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString())) //if the remain investment required to complete the pitch after discount >= Pitch_InvestmentWayAmount, the user is forced to invest at least Pitch_InvestmentWayAmount
                                                        {
                                                            if (Double.Parse(IAAD) < Double.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString())) //if the user enter investment amount before discount < Pitch_InvestmentWayAmount
                                                            { investmentCheckResponse.PreventionMessage = MinimumInvestmentAction(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                            else if (IAADAfterExchange % Double.Parse(InvestmentGetAmountAfterExchange(userId, (int.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString())), currencyId, "1", pitchId)) != 0 && Double.Parse(IAAD) < investmentCheckResponse.RemainAllowedInv) //if the user enter investment amount after discount multiples of Pitch_InvestmentWayAmount)
                                                            { investmentCheckResponse.PreventionMessage = MultipleInvestmentAction(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                            else if (investmentCheckResponse.HasMaxUserInvAmount && MoreMaxUserInvAmount)
                                                            { investmentCheckResponse.PreventionMessage = MaximumUserInvestmentAmount(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                            else
                                                            {
                                                                investmentCheckResponse.IsAllowedInvestment = true;
                                                                if (Double.Parse(IAAD) < investmentCheckResponse.RemainAllowedInv)
                                                                    investmentCheckResponse.AmountForInvest = Double.Parse(IAAD);
                                                                else
                                                                    investmentCheckResponse.AmountForInvest = investmentCheckResponse.RemainAllowedInv;
                                                            }
                                                        }
                                                        else //if the remain investment required != Pitch_InvestmentWayAmount, the user is forced to invest all this value to compplete the pitch investment
                                                        {
                                                            if (Double.Parse(IAAD) == investmentCheckResponse.RemainAllowedInv)
                                                                if (investmentCheckResponse.HasMaxUserInvAmount && MoreMaxUserInvAmount)
                                                                { investmentCheckResponse.PreventionMessage = MaximumUserInvestmentAmount(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                                else
                                                                { investmentCheckResponse.IsAllowedInvestment = true; investmentCheckResponse.AmountForInvest = Double.Parse(IAAD); }
                                                            else
                                                            { investmentCheckResponse.PreventionMessage = InvestRemainRequired(currencyId, Currency_Symbol, userId, investmentCheckResponse.RemainAllowedInv, pitchId); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                        }
                                                        #endregion
                                                    }
                                                    else if (investmentCheckResponse.InvestmentWayFlag == 2)
                                                    {
                                                        #region without-discount, minimum of dollars
                                                        if (investmentCheckResponse.RemainAllowedInv >= Double.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString())) //if the remain investment required to complete the pitch after discount >= Pitch_InvestmentWayAmount, the user is forced to invest at least Pitch_InvestmentWayAmount
                                                        {
                                                            if (Double.Parse(IAAD) < Double.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString())) //if the user enter investment amount before discount < Pitch_InvestmentWayAmount
                                                            { investmentCheckResponse.PreventionMessage = MinimumInvestmentAction(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                            else if (investmentCheckResponse.HasMaxUserInvAmount && MoreMaxUserInvAmount)
                                                            { investmentCheckResponse.PreventionMessage = MaximumUserInvestmentAmount(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                            else
                                                            {
                                                                investmentCheckResponse.IsAllowedInvestment = true;
                                                                if (Double.Parse(IAAD) < investmentCheckResponse.RemainAllowedInv)
                                                                    investmentCheckResponse.AmountForInvest = Double.Parse(IAAD);
                                                                else
                                                                    investmentCheckResponse.AmountForInvest = investmentCheckResponse.RemainAllowedInv;
                                                            }
                                                        }
                                                        else //if the remain investment required < Pitch_InvestmentWayAmount, the user is forced to invest all this value to complete the pitch investment
                                                        {
                                                            if (Double.Parse(IAAD) == investmentCheckResponse.RemainAllowedInv)
                                                            {
                                                                if (investmentCheckResponse.HasMaxUserInvAmount && MoreMaxUserInvAmount)
                                                                { investmentCheckResponse.PreventionMessage = MaximumUserInvestmentAmount(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                                else
                                                                { investmentCheckResponse.IsAllowedInvestment = true; investmentCheckResponse.AmountForInvest = Double.Parse(IAAD); }
                                                            }
                                                            else
                                                            { investmentCheckResponse.PreventionMessage = InvestRemainRequired(currencyId, Currency_Symbol, userId, investmentCheckResponse.RemainAllowedInv, pitchId); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                        }
                                                        #endregion
                                                    }
                                                    else if (investmentCheckResponse.InvestmentWayFlag == 3)
                                                    {
                                                        #region with-discount, multiple of dollars
                                                        if (investmentCheckResponse.DollarsShares != 0)//to return back if we entered an infinite loop and the returned value is 0
                                                        {
                                                            string txtamount = investmentCheckResponse.DollarsShares.ToString();
                                                            if (investmentCheckResponse.RemainAllowedInv >= Double.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString())) //if the remain investment required to complete the pitch after discount >= 2500$, the user is forced to invest at least 100$
                                                            {
                                                                if (Double.Parse(IAAD) < Double.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString())) //if the user enter investment amount before discount < Pitch_InvestmentWayAmount
                                                                { investmentCheckResponse.PreventionMessage = MinimumInvestmentAction(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                                else if (IAADAfterExchange % Double.Parse(InvestmentGetAmountAfterExchange(userId, (int.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString())), currencyId, "1", pitchId)) != 0 && Double.Parse(IAAD) != investmentCheckResponse.RemainAllowedInv) //if the user enter investment amount after discount multiples of Pitch_InvestmentWayAmount)
                                                                { investmentCheckResponse.PreventionMessage = MultipleInvestmentAction(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                                else
                                                                {

                                                                    if (investmentCheckResponse.HasMaxUserInvAmount && MoreMaxUserInvAmount)
                                                                    { investmentCheckResponse.PreventionMessage = MaximumUserInvestmentAmount(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                                    else
                                                                    {
                                                                        investmentCheckResponse.IsAllowedInvestment = true;
                                                                        if (Double.Parse(IAAD) < investmentCheckResponse.RemainAllowedInv)
                                                                            investmentCheckResponse.AmountForInvest = Double.Parse(IAAD);
                                                                        else
                                                                            investmentCheckResponse.AmountForInvest = investmentCheckResponse.RemainAllowedInv;
                                                                    }
                                                                }
                                                            }
                                                            else //if the remain investment required < 2500$, the user is forced to invest all this value to compplete the pitch investment
                                                            {
                                                                if (Double.Parse(IAAD) == investmentCheckResponse.RemainAllowedInv)
                                                                {

                                                                    if (investmentCheckResponse.HasMaxUserInvAmount && MoreMaxUserInvAmount)
                                                                    { investmentCheckResponse.PreventionMessage = MaximumUserInvestmentAmount(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                                    else
                                                                    { investmentCheckResponse.IsAllowedInvestment = true; investmentCheckResponse.AmountForInvest = Double.Parse(IAAD); }

                                                                }
                                                                else
                                                                { investmentCheckResponse.PreventionMessage = InvestRemainRequired(currencyId, Currency_Symbol, userId, investmentCheckResponse.RemainAllowedInv, pitchId); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                            }
                                                        }
                                                        else
                                                        { investmentCheckResponse.PreventionMessage = _stringLocalizer["InvestmentPreventionCompletedProposal"].Value; investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                        #endregion
                                                    }
                                                    else if (investmentCheckResponse.InvestmentWayFlag == 4)
                                                    {
                                                        string anotherTransactionMsgType = "";

                                                        #region with-discount, minimum of dollars
                                                        if (investmentCheckResponse.DollarsShares != 0)//to return back if we entered an infinite loop and the returned value is 0
                                                        {
                                                            string txtamount = investmentCheckResponse.DollarsShares.ToString();
                                                            if (investmentCheckResponse.RemainAllowedInv >= Double.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString())) //if the remain investment required to complete the pitch after discount >= Pitch_InvestmentWayAmount, the user is forced to invest at least Pitch_InvestmentWayAmount
                                                            {
                                                                if (Double.Parse(IAAD) < Double.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString())) //if the user enter investment amount before discount < Pitch_InvestmentWayAmount
                                                                { investmentCheckResponse.PreventionMessage = MinimumInvestmentAction(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                                else
                                                                {
                                                                    if (investmentCheckResponse.HasMaxUserInvAmount && MoreMaxUserInvAmount)
                                                                    { investmentCheckResponse.PreventionMessage = MaximumUserInvestmentAmount(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                                    else
                                                                    {
                                                                        investmentCheckResponse.IsAllowedInvestment = true;
                                                                        if (Double.Parse(IAAD) < investmentCheckResponse.RemainAllowedInv)
                                                                            investmentCheckResponse.AmountForInvest = Double.Parse(IAAD);
                                                                        else
                                                                            investmentCheckResponse.AmountForInvest = investmentCheckResponse.RemainAllowedInv;
                                                                    }

                                                                }
                                                            }
                                                            else //if the remain investment required < Pitch_InvestmentWayAmount, the user is forced to invest all this value to compplete the pitch investment
                                                            {
                                                                if (Double.Parse(IAAD) == investmentCheckResponse.RemainAllowedInv)
                                                                {

                                                                    if (investmentCheckResponse.HasMaxUserInvAmount && MoreMaxUserInvAmount)
                                                                    { investmentCheckResponse.PreventionMessage = MaximumUserInvestmentAmount(userId, currencyId, Currency_Symbol, dtPitchDetails); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                                    else
                                                                    { investmentCheckResponse.IsAllowedInvestment = true; investmentCheckResponse.AmountForInvest = Double.Parse(IAAD); }


                                                                }
                                                                else
                                                                { investmentCheckResponse.PreventionMessage = InvestRemainRequired(currencyId, Currency_Symbol, userId, investmentCheckResponse.RemainAllowedInv, pitchId); investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                            }
                                                        }
                                                        else
                                                        { investmentCheckResponse.PreventionMessage = _stringLocalizer["InvestmentPreventionCompletedProposal"].Value; investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR"; }
                                                        #endregion
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        investmentCheckResponse.PreventionMessage = _stringLocalizer["APIFailed"].Value; investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR";
                                        _errHandler.WriteError("API Failed : API_GetSumPendingOffersForUserByCurrency in the function CheckInvestmentAmounts() in InvestmentHandler.ashx" + "\n" + "Offer_BuyerID:" + dtUserInfo.Rows[0]["User_ID"].ToString() + "\n" + "Offer_CurrencyID:" + currencyId);
                                    }
                                }
                            }
                        }
                    }
                }
                return investmentCheckResponse;
            }
            catch (Exception ex)
            {
                investmentCheckResponse.PreventionMessage = ""; investmentCheckResponse.IsAllowedInvestment = false; investmentCheckResponse.MsgType = "ERROR";

                if (userId == 0)
                {
                    _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n" + "Session['Investor_ID']: NULL");
                }
                else
                {
                    _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n" + "Session['Investor_ID']: " + userId + " PID: " + pitchId);
                }

                return investmentCheckResponse;
            }
        }

        private bool invest(DataTable dtUserInfo, DataTable dtPitchDetails, string currencySymbol, int IAADAfterExchange, int PID, int currencyId, int langId, bool SendInvestmentEmails, InvestmentCheckResponseModel investmentCheckResponseModelcs)
        {
            try
            {
                /*if the invested amount you entered is less than (The Required investment minus the current invested amount)
                do the transaction process which is 
                decrease the amount user invested or entered from his original balance
                and move the amount to the pitch invested amount which lead to increase the invested percentage of the pitch
                */
                int userId = int.Parse(dtUserInfo.Rows[0]["User_ID"].ToString());
                double Shares_Sold_BD = Tools.Round2DP(investmentCheckResponseModelcs.AmountForInvest / double.Parse(dtPitchDetails.Rows[0]["Pitch_Share_Price"].ToString()));
                double Equity_Sold = Tools.Round2DP(((investmentCheckResponseModelcs.DollarsShares * double.Parse(dtPitchDetails.Rows[0]["Pitch_Share_Price"].ToString())) / double.Parse(dtPitchDetails.Rows[0]["Pitch_Post_Money_Val"].ToString())) * 100);
                int InvestorType = int.Parse(dtUserInfo.Rows[0]["User_InvestorType"].ToString());

                _investment.InvestmentUpdate(userId.ToString(), PID.ToString(), investmentCheckResponseModelcs.AmountForInvest.ToString(), Shares_Sold_BD, investmentCheckResponseModelcs.DollarsShares, Equity_Sold, InvestorType, "", currencyId, false, investmentCheckResponseModelcs.PitchRate.ToString(), IAADAfterExchange, userId);
                _user.UserUpdateUserScore(userId, 20);
                _user.UserupdateLastUpdateDate(userId);

                if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() != "Early Access")
                {
                    _account.AccountAddInvestment(dtUserInfo, currencyId, investmentCheckResponseModelcs.PitchRate.ToString(), PID, IAADAfterExchange.ToString(), dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString());
                }

                DataTable dtPitchOwnerDetails = _user.UserGetDetails(Int32.Parse(dtPitchDetails.Rows[0]["Pitch_UserID"].ToString()), (int)Languages.English);

                string fristName_Owner = dtPitchOwnerDetails.Rows[0]["Profile_FirstName"].ToString();

                string pitchTitle = dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString();
                DataRow drSystemAdmin = _user.UserGetSystemAdmin();

                if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "Overfunding")
                {
                    if (SendInvestmentEmails)
                    {
                        _message.MessageSendInvestmentEmail(drSystemAdmin, _user.UserGetAdmins(), dtPitchOwnerDetails.Rows[0], dtUserInfo.Rows[0], pitchTitle, PID, IAADAfterExchange, PitchAction.OverfundingForOwner, currencyId.ToString());
                        _message.MessageSendInvestmentEmail(drSystemAdmin, _user.UserGetAdmins(), dtUserInfo.Rows[0], dtUserInfo.Rows[0], pitchTitle, PID, IAADAfterExchange, PitchAction.OverfundingForInvestor, currencyId.ToString());
                    }
                    dtPitchDetails.Rows[0]["Pitch_Balance"].ToString();
                    if (investmentCheckResponseModelcs.PitchInvestmentRequired == investmentCheckResponseModelcs.PitchBalance + investmentCheckResponseModelcs.AmountForInvest)
                    {
                        _pitch.PitchUpdatePitchStatus(PID, "Overfunded");
                        _pitch.PitchStatusChanged(langId, PID, "Overfunding", "Overfunded", dtPitchDetails.Rows[0]);
                    }
                }
                else
                {
                    if (SendInvestmentEmails)
                    {
                        _message.MessageSendInvestmentEmail(drSystemAdmin, _user.UserGetAdmins(), dtPitchOwnerDetails.Rows[0], dtUserInfo.Rows[0], pitchTitle, PID, IAADAfterExchange, PitchAction.PublishedForOwner, currencyId.ToString());
                        _message.MessageSendInvestmentEmail(drSystemAdmin, _user.UserGetAdmins(), dtUserInfo.Rows[0], dtUserInfo.Rows[0], pitchTitle, PID, IAADAfterExchange, PitchAction.PublishedForInvestor, currencyId.ToString());
                    }
                    if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() != "Early Access")
                    {
                        if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["OverSubStatus"].ToString()) && int.Parse(dtPitchDetails.Rows[0]["OverSubStatus"].ToString()) == 2)
                        {
                            if (investmentCheckResponseModelcs.PitchInvestmentRequired == investmentCheckResponseModelcs.PitchBalance + investmentCheckResponseModelcs.AmountForInvest)
                            {
                                _pitch.PitchUpdatePitchStatus(PID, "Overfunded");
                                _pitch.PitchStatusChanged(langId, PID, "Overfunding", "Overfunded", dtPitchDetails.Rows[0]);
                            }
                            else if (double.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentRequired"].ToString()) <= investmentCheckResponseModelcs.PitchBalance + investmentCheckResponseModelcs.AmountForInvest)//issue
                            {
                                _pitch.PitchUpdatePitchStatus(PID, "Overfunding");
                                _pitch.PitchStatusChanged(langId, PID, "published", "Overfunding", dtPitchDetails.Rows[0]);
                            }
                        }
                        else
                        {
                            if (investmentCheckResponseModelcs.PitchInvestmentRequired == investmentCheckResponseModelcs.PitchBalance + investmentCheckResponseModelcs.AmountForInvest)
                            {
                                _pitch.PitchUpdatePitchStatus(PID, "completed");
                                _pitch.PitchStatusChanged(langId, PID, "published", "completed", dtPitchDetails.Rows[0]);
                            }
                        }
                    }
                }

                dtPitchDetails = _pitch.PitchGetDedicatedPitchDetailsByLang(PID, (int)Languages.English);

                double CurrentRemainingTrancheSize = 0, TranchDiscount = 0;


                if (Convert.ToBoolean(dtPitchDetails.Rows[0]["Pitch_HasDiscount"].ToString()))
                    _pitch.PitchGetCurrentTrancheDiscAndRemSizeByBalanceAfterDiscount(dtPitchDetails.Rows[0], float.Parse(dtPitchDetails.Rows[0]["Pitch_Balance"].ToString()), out TranchDiscount, out CurrentRemainingTrancheSize);

                if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() != "Early Access")
                {
                    PitchStatus Pitch_Status = PitchStatus.Published;

                    if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() != "published")
                        Pitch_Status = PitchStatus.OverFunding;
                    if (SendInvestmentEmails)
                    {
                        _message.MessageSendMessageForPitchUsers(_user.UserGetSystemAdmin(), _pitchLikeFollower.PitchGetFollowersAndInvestors(PID, langId),
                            dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString(), PID.ToString(), Math.Floor(decimal.Parse(dtPitchDetails.Rows[0]["Pitch_InvestedSoFar"].ToString())),
                            (int.Parse(dtPitchDetails.Rows[0]["Pitch_Balance"].ToString())).ToString("#,##0"), investmentCheckResponseModelcs.AmountForInvest.ToString("#,##0"), TranchDiscount, PitchAction.InvestmentForUsers,
                            currencyId.ToString(), Pitch_Status);

                        _message.MessageSendMessageForUserFollowers(_user.UserGetSystemAdmin(), _user.UserGetAllUserFollowersForUser(Int32.Parse(dtUserInfo.Rows[0]["User_ID"].ToString())), _user.UserSelectById(userId).Rows[0], dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString(), PID, "", 0, UserAction.PitchInvestment);
                        _message.MessageSendInvestmentNotificationForAdmins(_user.UserGetSystemAdmin(), dtUserInfo.Rows[0], dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString(), IAADAfterExchange.ToString(), currencySymbol);
                    }
                }
                else if (dtPitchDetails.Rows[0]["Pitch_Status"].ToString() == "Early Access")
                {
                    if (SendInvestmentEmails)
                    {
                        _message.MessageSendPreCommitmentNotificationForAdmins(_user.UserGetSystemAdmin(), dtUserInfo.Rows[0], dtPitchDetails.Rows[0]["Profile_PitchTitle"].ToString(), IAADAfterExchange.ToString(), currencySymbol);
                    }
                }
                return true;

            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n job: Invest_QInvest \n User ID: " + (int.Parse(dtUserInfo.Rows[0]["User_ID"].ToString())) + "\n PID: " + PID);
                return false;
            }
        }

        private bool CheckMaxInvAmountExceeded(int userId, int pitchId, string userCountry, int currencyId, int IAADAfterExchange, out string preventionMessage)
        {
            preventionMessage = "";

            try
            {
                int groupId = _countryBasedControl.CountryBasedCheckCountryRestrictedForControl(CountryBasedControls.PaymentInvestmentAmountsLimitations, int.Parse(userCountry));
                DataTable dtGroupData = _countryBasedControl.CountryBasedGetGroupData(groupId);

                if (dtGroupData.Rows.Count > 0 && bool.Parse(dtGroupData.Rows[0]["Is_Enabled"].ToString()))
                {
                    if (!String.IsNullOrEmpty(dtGroupData.Rows[0]["USDMaxAnnualInv"].ToString()))
                    {
                        int MaxAnnualUserIvestmentAmount = int.Parse(dtGroupData.Rows[0]["USDMaxAnnualInv"].ToString());
                        DataTable dtUserAnnualInvAndPreInv = _investment.InvestmentGetUserAnnualInvAndPreInv(userId, currencyId);

                        if ((IAADAfterExchange + Double.Parse(dtUserAnnualInvAndPreInv.Rows[0]["Total_Amount"].ToString())) > Double.Parse(InvestmentGetAmountAfterExchange(userId, MaxAnnualUserIvestmentAmount, currencyId, "1", pitchId)))
                        {
                            DataTable dtCurreny = _general.CurrencyGetCurrencyByID(currencyId);
                            string currencySymbol = dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$";

                            preventionMessage += _stringLocalizer["DIFCMaxInvestedAmount"].Value + " " + currencySymbol + int.Parse(InvestmentGetAmountAfterExchange(userId, MaxAnnualUserIvestmentAmount, currencyId, "1", pitchId)).ToString("#,##0") + " " + _stringLocalizer["InOneYear"].Value;
                            //if(!String.IsNullOrWhiteSpace(dtUserAnnualInvAndPreInv.Rows[0]["Available_Inv_Date"].ToString()))
                            //    txtMaxAnnualUserIvestmentAmount += txtAllowedDateIvestmentAnnual + dtUserAnnualInvAndPreInv.Rows[0]["Available_Inv_Date"].ToString();
                            return true;
                        }
                        else
                            return false;
                    }
                    else
                        return false;
                }
                else return false;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n job: Invest_QInvest \n User ID: " + (userId) + "\n PID: " + pitchId);
                return true;
            }
        }
        private bool IsAllowedMalaysianUserInvestment(int userId, string userCountry, string investorClassification, int currencyId, int pitchId, string IAADAfterExchange, out string preventionMessage)
        {
            preventionMessage = "";
            DataTable dtCurreny = _general.CurrencyGetCurrencyByID(currencyId);
            string currencySymbol = dtCurreny.Rows.Count > 0 ? dtCurreny.Rows[0]["Currency_Symbol"].ToString() : "$";
            if (int.Parse(userCountry) == 159)
            {
                //25 angel, 26 retail
                if (!String.IsNullOrEmpty(investorClassification) && (investorClassification == "25" /*Angel*/ || investorClassification == "26") /*Retail*/ )
                {
                    string AngelMalaysianAnnualMaxInvAmount = _config.GetValue<string>("AngelMalaysianAnnualMaxMYRInvAmount");
                    string RetailMalaysianAnnualMaxInvAmount = _config.GetValue<string>("RetailMalaysianAnnualMaxMYRInvAmount");
                    string RetailMalaysianMaxInvAmountPerProposal = _config.GetValue<string>("RetailMalaysianMaxMYRInvAmountPerProposal");

                    if (currencyId != (int)Currencies.MYR)
                    {
                        //this is in order no to change MYR to USD then USD another time to MYR in the next 
                        AngelMalaysianAnnualMaxInvAmount = InvestmentGetAmountAfterExchange(userId, double.Parse(InvestmentGetAmountAfterExchange(userId, double.Parse(AngelMalaysianAnnualMaxInvAmount), (int)Currencies.MYR, "2", pitchId)), currencyId, "1", pitchId);
                        RetailMalaysianAnnualMaxInvAmount = InvestmentGetAmountAfterExchange(userId, double.Parse(InvestmentGetAmountAfterExchange(userId, double.Parse(RetailMalaysianAnnualMaxInvAmount), (int)Currencies.MYR, "2", pitchId)), currencyId, "1", pitchId);
                        RetailMalaysianMaxInvAmountPerProposal = InvestmentGetAmountAfterExchange(userId, double.Parse(InvestmentGetAmountAfterExchange(userId, double.Parse(RetailMalaysianMaxInvAmountPerProposal), (int)Currencies.MYR, "2", pitchId)), currencyId, "1", pitchId);
                    }

                    DataTable dtUserAnnualInvAndPreInv = _investment.InvestmentGetUserAnnualInvAndPreInv(userId, currencyId);

                    if (investorClassification == "25" && (Double.Parse(IAADAfterExchange) + Double.Parse(dtUserAnnualInvAndPreInv.Rows[0]["Total_Amount"].ToString())) > Double.Parse(AngelMalaysianAnnualMaxInvAmount))
                    {
                        preventionMessage = _stringLocalizer["MaxAnnualUserIvestmentAmount"].Value + currencySymbol + int.Parse(AngelMalaysianAnnualMaxInvAmount).ToString("#,##0") + ". " + _stringLocalizer["MaxAnnualUserIvestmentAmount"].Value + dtUserAnnualInvAndPreInv.Rows[0]["Available_Inv_Date"].ToString();
                        return false;
                    }
                    else if (investorClassification == "26" && (Double.Parse(IAADAfterExchange) + Double.Parse(dtUserAnnualInvAndPreInv.Rows[0]["Total_Amount"].ToString())) > Double.Parse(RetailMalaysianAnnualMaxInvAmount))
                    {
                        preventionMessage = _stringLocalizer["MaxAnnualUserIvestmentAmount"].Value + currencySymbol + int.Parse(RetailMalaysianAnnualMaxInvAmount).ToString("#,##0") + ". " + _stringLocalizer["MaxAnnualUserIvestmentAmount"].Value + dtUserAnnualInvAndPreInv.Rows[0]["Available_Inv_Date"].ToString();
                        return false;
                    }
                    else if (investorClassification == "26" && (Double.Parse(IAADAfterExchange) + Double.Parse(_investment.InvestmentGetUserInvestmentAmountOnPitch(userId, pitchId, currencyId).ToString())) > Double.Parse(RetailMalaysianMaxInvAmountPerProposal))
                    {
                        preventionMessage = _stringLocalizer["MaxAnnualUserIvestmentAmount"].Value + currencySymbol + int.Parse(RetailMalaysianMaxInvAmountPerProposal).ToString("#,##0") + ".";
                        return false;
                    }
                    else
                        return true;
                }
                else
                    return true;
            }
            else
                return true;
        }
        private string InvestmentGetAmountAfterExchange(int userId, double amount, int currencyId, string type, int pitchId)
        {
            //rami
            DataTable DTRate = _pitch.PitchGetPitchRate(pitchId, currencyId);
            if (userId != 0)
            {

                if (DTRate.Rows.Count > 0)
                {
                    if (type == "1") //To Currency
                        return Convert.ToString(Math.Ceiling((double.Parse(DTRate.Rows[0]["Pitch_rate"].ToString()) * amount)));
                    else if (type == "2") //To USD
                        return Convert.ToString(Math.Floor((amount / double.Parse(DTRate.Rows[0]["Pitch_rate"].ToString()))));
                    else return ("-2");
                }
                else
                    return ("-3");

            }
            else
                return ResponseStatus.NullUserId.ToString();
        }

        protected Double GetCurrentTranchEdge(DataTable dtPitchDetails) //calculate the remain Inv. Amount Before discount to complete tranches edges
        {
            float pitchTranchEdge1;
            float pitchTranchEdge2;
            float pitchTranchEdge3;
            float pitchTranchEdge4;

            float tranchDiscount1 = 0;
            float tranchDiscount2 = 0;
            float tranchDiscount3 = 0;
            float tranchDiscount4 = 0;

            float tranchSize1 = 0;
            float tranchSize2 = 0;
            float tranchSize3 = 0;
            float tranchSize4 = 0;

            float pitchBalanceBeforeDiscount = float.Parse(dtPitchDetails.Rows[0]["Pitch_Balance"].ToString());
            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString()))
                tranchDiscount1 = float.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount1"].ToString()) / 100;

            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchSize1"].ToString()))
                tranchSize1 = float.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize1"].ToString());

            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString()))
                tranchDiscount2 = float.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount2"].ToString()) / 100;

            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchSize2"].ToString()))
                tranchSize2 = float.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize2"].ToString());

            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString()))
                tranchDiscount3 = float.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount3"].ToString()) / 100;

            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchSize3"].ToString()))
                tranchSize3 = float.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize3"].ToString());

            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString()))
                tranchDiscount4 = float.Parse(dtPitchDetails.Rows[0]["Pitch_TranchDiscount4"].ToString()) / 100;

            if (!String.IsNullOrEmpty(dtPitchDetails.Rows[0]["Pitch_TranchSize4"].ToString()))
                tranchSize4 = float.Parse(dtPitchDetails.Rows[0]["Pitch_TranchSize4"].ToString());

            pitchTranchEdge1 = tranchSize1;
            pitchTranchEdge2 = pitchTranchEdge1 + tranchSize2;
            pitchTranchEdge3 = pitchTranchEdge2 + tranchSize3;
            pitchTranchEdge4 = pitchTranchEdge3 + tranchSize4;

            if (pitchBalanceBeforeDiscount < pitchTranchEdge1)
                return pitchTranchEdge1 - pitchBalanceBeforeDiscount + tranchSize2 + tranchSize3 + tranchSize4;
            else if (pitchBalanceBeforeDiscount >= pitchTranchEdge1 && pitchBalanceBeforeDiscount < pitchTranchEdge2)
                return pitchTranchEdge2 - pitchBalanceBeforeDiscount + tranchSize3 + tranchSize4;
            else if (pitchBalanceBeforeDiscount >= pitchTranchEdge2 && pitchBalanceBeforeDiscount < pitchTranchEdge3)
                return pitchTranchEdge3 - pitchBalanceBeforeDiscount + tranchSize4;
            else if (pitchBalanceBeforeDiscount >= pitchTranchEdge3 && pitchBalanceBeforeDiscount < pitchTranchEdge4)
                return pitchTranchEdge4 - pitchBalanceBeforeDiscount;
            else //all tranches completed
                return 0;
        }

        private string InvestRemainRequired(int currencyId, string currencySymbol, int userId, double remainAllowedInv, int pitchId)
        {
            return _stringLocalizer["InvestRemainRequiredText"].Value + " " + currencySymbol + double.Parse(InvestmentGetAmountAfterExchange(userId, remainAllowedInv, currencyId, "1", pitchId)).ToString("#,##0");
        }

        private string MinimumInvestmentAction(int userId, int CurrencyID, string currencySymbol, DataTable dtPitchDetails)
        {
            return _stringLocalizer["MinInvText"].Value + currencySymbol + double.Parse(InvestmentGetAmountAfterExchange(userId, int.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString()), CurrencyID, "1", int.Parse(dtPitchDetails.Rows[0]["Pitch_ID"].ToString()))).ToString("#,##0") + " " + _stringLocalizer["ReviseInvAmount"].Value;
        }

        private string MultipleInvestmentAction(int userId, int CurrencyID, string Currency_Symbol, DataTable dtPitchDetails)
        {
            return _stringLocalizer["MulInvText"].Value + " " + Currency_Symbol + double.Parse(InvestmentGetAmountAfterExchange(userId, int.Parse(dtPitchDetails.Rows[0]["Pitch_InvestmentWayAmount"].ToString()), CurrencyID, "1", int.Parse(dtPitchDetails.Rows[0]["Pitch_ID"].ToString()))).ToString("#,##0") + " " + _stringLocalizer["MulInvText1"].Value;
        }
        private string MaximumUserInvestmentAmount(int userId, int CurrencyID, string Currency_Symbol, DataTable dtPitchDetails)
        {
            return _stringLocalizer["MaximumUserInvestmentAmount1"].Value + " " + Currency_Symbol + double.Parse(InvestmentGetAmountAfterExchange(userId, int.Parse(dtPitchDetails.Rows[0]["Pitch_MaxUserInvestmentAmount"].ToString()), CurrencyID, "1", int.Parse(dtPitchDetails.Rows[0]["Pitch_ID"].ToString()))).ToString("#,##0") + " " + _stringLocalizer["MaximumUserInvestmentAmount2"].Value;
        }

        private bool InvestmentCheckIsMoreMaxUserInvestmentAmount(int UID, int PID, long amount, int CurrencyID, int maxUserAmount)
        {
            bool value = false;
            try
            {
                if (_investment.InvestmentGetUserInvestmentAmountOnPitch(UID, PID, CurrencyID) + amount > maxUserAmount)
                    value = true;
                return value;
            }

            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return value;
            }
        }


    }
}
