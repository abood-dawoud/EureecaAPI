﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface.InboxInterface;
using Eureeca_API.Interface.PitchInterface;
using Eureeca_API.Interface.UserInterface;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.InboxModels.Dto;
using Eureeca_API.Models.InboxModels.ViewModels;
using Eureeca_API.Models.UserModels.ViewModesl;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;

namespace Eureeca_API.Controllers
{
    [Route("api/Inbox")]
    [ApiController]
    public class InboxController : ControllerBase
    {
        private string _subject = "", _msg = "", _subjectMessage = "", _messageBody  = "";
        private readonly IUser _user;
        private readonly IInternalMessage _internalMessage;
        private readonly IMessage _message;
        private readonly IPitch _pitch;
        private readonly IConfiguration _config;
        private readonly ErrHandler _errHandler;
        private readonly IStringLocalizer<Resources.InboxController> _stringLocalizer;


        public InboxController(IUser user, IInternalMessage internalMessage, IMessage message, IPitch pitch, IConfiguration config, IStringLocalizer<Resources.InboxController> stringLocalizer)
        {
            _user = user;
            _internalMessage = internalMessage;
            _message = message;
            _errHandler = new ErrHandler();
            _pitch = pitch;
            _config = config;
            _stringLocalizer = stringLocalizer;
        }

        [HttpPost("InboxSendMessage")]
        public bool InboxSendMessage([Required] int senderId, [Required] int receiverId, [Required] string subject, [Required] string message)
        {
            try
            {
                int senderAllowedToSend = 0;
                // Check if sender allowed to send Start.
                DataTable dtSenderBadges = _user.UserGetUserEnrollments(long.Parse(senderId.ToString()), (int)ObjectsGroups.Badges);
                int currentSenderBadge = 0;
                if (dtSenderBadges.Rows.Count > 0)
                    currentSenderBadge = int.Parse(dtSenderBadges.Rows[0]["Details_ObjectID"].ToString());

                DataTable dtSender = _user.UserSelectById(senderId);
                int senderType = int.Parse(dtSender.Rows[0]["User_UserFormType"].ToString());
                bool isSenderSme = senderType == (int)UserType.Enreprenuer || senderType == (int)UserType.InvestorAndEnreprenuer;

                DataTable dtReciver = _user.UserSelectById(receiverId);
                int reciverType = int.Parse(dtReciver.Rows[0]["User_UserFormType"].ToString());
                bool isReciverSme = reciverType == (int)UserType.Enreprenuer || reciverType == (int)UserType.InvestorAndEnreprenuer;

                if (senderType == (int)UserType.Admin || senderType == (int)UserType.SystemAdmin || senderType == (int)UserType.BIAdmin)
                { 
                    senderAllowedToSend = 1; 
                }
                else if (currentSenderBadge == (int)InvestorBadges.DiamondInvestor || currentSenderBadge == (int)InvestorBadges.GoldInvestor || currentSenderBadge == (int)InvestorBadges.PlatinumInvestor)
                {
                    // Any user with Gold/Platinum/Diamond badge can send unlimited messages for all users SMEs/Investors.
                    senderAllowedToSend = 1;
                }
                else if (isSenderSme && _pitch.PitchGetUserActiveLiveOpenedPitch(senderId).Rows.Count > 0)
                {
                    // Any SME with active proposal (Published/overfunding/comingsoon) can contact any user, otherwise they cannot send messages.
                    senderAllowedToSend = 1;
                }
                else if ((currentSenderBadge == 0 || currentSenderBadge == (int)InvestorBadges.SilverInvestor) && isReciverSme && _pitch.PitchGetUserActiveLiveOpenedPitch(receiverId).Rows.Count > 0)
                {
                    // Any user with Silver badge or has no badge, cannot contact any user except SMEs with active (published/overfunding/comingsoon) porposals.
                    senderAllowedToSend = 1;
                }
                else
                    senderAllowedToSend = 0;
                // Check If sender allowed to send End.



                if (senderAllowedToSend == 1)
                {
                    _subject = Tools.FilterHTML(subject);
                    _msg = Tools.FilterHTML(message).Replace("\n", "<br />");

                    int inboxId = 0;
                    int sentId = 0;
                    _internalMessage.InternalMessageAddMessage(senderId, receiverId, _subject, _msg, (int)InboxFlag.MessageNotRead, out inboxId, out sentId);

                    DataRow sender = _user.UserGetSystemAdmin();
                    DataRow receiver = _user.UserSelectById(receiverId).Rows[0];
                    DataRow from = _user.UserSelectById(senderId).Rows[0];
                    _subjectMessage = "You have received a Eureeca mail";
                    _messageBody = "Hello " + receiver["Profile_FirstName"].ToString()
                            + "<br /><br />You have received the following private message in your Eureeca.com inbox. Please go to <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/Login/login.aspx'>eureeca.com</a> account to view and reply to your messages."
                            + "<br /><br />-------------------------------"
                            + "<br /><br />From: <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/view-crowd-user.aspx?UID=" + from["User_ID"] + "'>" + from["User_Username"].ToString() + "</a>"
                            + "<br /><br />Subject: " + _subject
                            + "<br /><br />Message: " + _msg.Replace("\n", "<br />")
                            + "<br /><br />-------------------------------"
                            + "<br /><br />If you no longer wish to receive notifications, please click <a href='http://" + Tools.GetRoot() + "/Crowd-funding-pages/FrontEnd/User/unsubscribe.aspx?GUID=" + receiver["User_guid"] + "'>here</a> to change your notifications options. "
                            + "<br /><br />Thanks!<br /><br />The Eureeca Team";
                    _message.MessageAddOutgoingEmail(receiver["USer_Email"].ToString(), _subjectMessage, _messageBody, sender["USer_Email"].ToString());
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return false;
            }
        }
        [HttpGet("InboxSentMessages")]
        public async Task<ActionResult<List<SentMessages>>> InboxSentMessages([Required] int userId, [Required] int pageIndex, [Required] int pageSize, [Required] int langId, string? sentSubject)
        {
            try
            {
                DataTable dtSentMessages = _internalMessage.InternalMessageGetSentForUserN(userId, pageIndex, pageSize, sentSubject, langId);
                if (dtSentMessages.Rows.Count > 0)
                {
                    List<SentMessages> sentMessages = new List<SentMessages>();
                    foreach (DataRow dr in dtSentMessages.Rows)
                    {
                        SentMessages sentMessage = new SentMessages();
                        sentMessage.SentId = dr["Sent_ID"].ToString();
                        sentMessage.SentDate = dr["Sent_Date"].ToString();
                        sentMessage.SentReceiver = dr["Sent_Reciver"].ToString();
                        sentMessage.SentSubject = dr["Sent_Subject"].ToString();
                        sentMessage.SentFlag = dr["Sent_Flag"].ToString();
                        sentMessage.ProfileFirstName = dr["Profile_FirstName"].ToString();
                        sentMessage.ProfileLastName = dr["Profile_LastName"].ToString();
                        sentMessages.Add(sentMessage);
                    }
                    return (sentMessages);
                }
                else
                {
                    List<SentMessages> sentMessages = new List<SentMessages>();
                    return sentMessages;
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, ex.Message);
            }
        }
        [HttpPost("InboxInboxMessages")]
        public async Task<ActionResult<InboxMessagesResponse>> InboxInboxMessages(InboxMessagesRequestModel model)
        {
            try
            {
                bool hasMore = false;
                DataTable dtInboxMessages = _internalMessage.InternalMessageGetInboxForUserN(model.UserId, model.PageIndex, model.PageSize, model.InboxSubject, model.LangId);
                List<InboxMessages> inboxMessages = new List<InboxMessages>();
                if (dtInboxMessages.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtInboxMessages.Rows)
                    {
                        InboxMessages inboxMessage = new InboxMessages();
                        inboxMessage.InboxId = dr["Inbox_ID"].ToString();
                        inboxMessage.InboxDate = dr["Inbox_Date"].ToString();
                        inboxMessage.InboxSubject = dr["Inbox_Subject"].ToString();
                        inboxMessage.InboxFlag = dr["Inbox_Flag"].ToString();
                        inboxMessage.InboxSender = dr["Inbox_Sender"].ToString();
                        inboxMessage.Unread = dr["Unread"].ToString();
                        inboxMessage.ProfileFirstName = dr["Profile_FirstName"].ToString();
                        inboxMessage.ProfileLastName = dr["Profile_LastName"].ToString();
                        inboxMessages.Add(inboxMessage);
                    }
                    InboxMessagesResponse response = new InboxMessagesResponse(200, true,model.PageSize,false, model.PageIndex, inboxMessages);
                    return Ok(response);
                }
                else
                {
                    InboxMessagesResponse response = new InboxMessagesResponse(200, true,0,false, model.PageIndex, inboxMessages);
                    return Ok(response);
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, ex.Message);
            }
        }
        [HttpGet("InboxFindUser")]
        public async Task<ActionResult<List<UserForMessage>>> InboxFindUser(string userName, int startRow, int endRow, int langId)
        {
            try
            {
                DataTable dtUsers = _user.SearchUsersByPageAndUserNameLang(userName, startRow, endRow, langId);
                if (dtUsers.Rows.Count > 0)
                {
                    List<UserForMessage> usersForMessage = new List<UserForMessage>();
                    foreach (DataRow dr in dtUsers.Rows)
                    {
                        UserForMessage userForMessage = new UserForMessage();
                        userForMessage.UserId = int.Parse(dr["User_ID"].ToString());
                        if (string.IsNullOrEmpty(dr["User_Picture"].ToString()) || !System.IO.File.Exists(Path.Combine(_config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dr["User_Picture"].ToString())))
                            userForMessage.UserPicture = _config.GetValue<string>("EnvironmentURL") + "Images/v2/Default.jpg";
                        else
                            userForMessage.UserPicture = _config.GetValue<string>("AttachementsEnvironmentURL") + "User/Thumbs/Thumb_" + dr["User_Picture"].ToString();
                        userForMessage.UserName = dr["User_Username"].ToString();
                        userForMessage.UserPhone = dr["User_Phone"].ToString();
                        usersForMessage.Add(userForMessage);
                    }
                    return (usersForMessage);
                }
                else
                {
                    List<UserForMessage> usersForMessages = new List<UserForMessage>();
                    return usersForMessages;
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, ex.Message);
            }
        }
        [HttpPost("InboxDeleteMessage")]
        public async Task<ActionResult<GeneralResponseMessage>> InboxDeleteMessage (DeleteMessageRequestModel deleteMessageRequestModel)
        {
            try
            {
                Tools.SetThreadCulture(deleteMessageRequestModel.LangId);
                if (deleteMessageRequestModel.Pos == "inbox")
                {
                    DataTable dtMessageInfo = _message.MessageGetMessageInboxById(deleteMessageRequestModel.MessageId);
                    if (dtMessageInfo.Rows.Count > 0)
                    {
                        if (dtMessageInfo.Rows[0]["Inbox_Receiver"].ToString() == deleteMessageRequestModel.UserId.ToString())
                        {
                            _message.MessageDeleteMessageInbox(deleteMessageRequestModel.MessageId);
                            return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, "", _stringLocalizer["MessageDeleted"].Value)));
                        }
                        else
                        {
                            return await Task.FromResult(NotFound(new GeneralResponseMessage(404, false, "", _stringLocalizer["MessageNotFound"].Value)));
                        }
                    }
                    else
                    {
                        return await Task.FromResult(NotFound(new GeneralResponseMessage(404, false, "", _stringLocalizer["MessageNotFound"].Value)));
                    }
                }
                else if (deleteMessageRequestModel.Pos == "sent")
                {
                    DataTable dtMessageInfo = _message.MessageGetSentItemById(deleteMessageRequestModel.MessageId);

                    if (dtMessageInfo.Rows.Count > 0)
                    {
                        if (dtMessageInfo.Rows[0]["Sent_Sender"].ToString() == deleteMessageRequestModel.UserId.ToString())
                        {
                            _message.MessageDeleteMessageSentItem(deleteMessageRequestModel.MessageId);
                            return await Task.FromResult(Ok(new GeneralResponseMessage(200, true, "", _stringLocalizer["MessageDeleted"].Value)));
                        }
                        else
                        {
                            return await Task.FromResult(NotFound(new GeneralResponseMessage(404, false, "", _stringLocalizer["MessageNotFound"].Value)));
                        }
                    }
                    else
                    {
                        return await Task.FromResult(NotFound(new GeneralResponseMessage(404, false, "", _stringLocalizer["MessageNotFound"].Value)));
                    }
                }
                return await Task.FromResult(Ok(new GeneralResponseMessage(403, false, "", _stringLocalizer["OperationFailed"].Value)));
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPost("InboxShowInboxMessage")]
        public async Task<ActionResult<ShowSingleMessageModel>> InboxShowInboxMessage(SingleMessageRequestModel singleMessageRequestModel)
        {
            try
            {
                DataTable dtMessageInfo = _message.MessageGetMessageInboxById(singleMessageRequestModel.MessageId);
                ShowSingleMessageModel showInboxMessageModel = new ShowSingleMessageModel();

                if (dtMessageInfo.Rows.Count > 0)
                {
                    if (dtMessageInfo.Rows[0]["Inbox_Receiver"].ToString() == singleMessageRequestModel.UserId.ToString())
                    {
                        DataRow dr = dtMessageInfo.Rows[0];
                        _message.MessageUpdateMessageInboxFlag(singleMessageRequestModel.MessageId);
                        showInboxMessageModel.MessageId = dtMessageInfo.Rows[0]["Inbox_ID"].ToString();
                        showInboxMessageModel.Date = dtMessageInfo.Rows[0]["Inbox_Date"].ToString();
                        showInboxMessageModel.Sender = dtMessageInfo.Rows[0]["Inbox_Sender"].ToString();
                        showInboxMessageModel.Receiver = dtMessageInfo.Rows[0]["Inbox_Receiver"].ToString();
                        showInboxMessageModel.Message = dtMessageInfo.Rows[0]["Inbox_Message"].ToString();
                        showInboxMessageModel.Subject = dtMessageInfo.Rows[0]["Inbox_Subject"].ToString();
                        showInboxMessageModel.Flag = dtMessageInfo.Rows[0]["Inbox_Flag"].ToString();
                        showInboxMessageModel.UserName = dtMessageInfo.Rows[0]["User_Username"].ToString();
                        return showInboxMessageModel;
                    }
                    else
                    {
                        return showInboxMessageModel;
                    }
                }
                else
                {
                    return showInboxMessageModel;
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }
        [HttpPost("InboxShowSentMessage")]
        public async Task<ActionResult<ShowSingleMessageModel>> InboxShowSentMessage(SingleMessageRequestModel singleMessageRequestModel)
        {
            try
            {
                DataTable dtMessageInfo = _message.MessageGetSentItemById(singleMessageRequestModel.MessageId);
                ShowSingleMessageModel showInboxMessageModel = new ShowSingleMessageModel();

                if (dtMessageInfo.Rows.Count > 0)
                {
                    if (dtMessageInfo.Rows[0]["Sent_Sender"].ToString() == singleMessageRequestModel.UserId.ToString())
                    {
                        DataRow dr = dtMessageInfo.Rows[0];
                        _message.MessageUpdateSentReadFlag(singleMessageRequestModel.MessageId);
                        showInboxMessageModel.MessageId = dtMessageInfo.Rows[0]["Sent_ID"].ToString();
                        showInboxMessageModel.Date = dtMessageInfo.Rows[0]["Sent_Date"].ToString();
                        showInboxMessageModel.Sender = dtMessageInfo.Rows[0]["Sent_Sender"].ToString();
                        showInboxMessageModel.Receiver = dtMessageInfo.Rows[0]["Sent_Reciver"].ToString();
                        showInboxMessageModel.Message = dtMessageInfo.Rows[0]["Sent_Message"].ToString();
                        showInboxMessageModel.Subject = dtMessageInfo.Rows[0]["Sent_Subject"].ToString();
                        showInboxMessageModel.Flag = dtMessageInfo.Rows[0]["Sent_Flag"].ToString();
                        showInboxMessageModel.UserName = dtMessageInfo.Rows[0]["User_Username"].ToString();
                        return showInboxMessageModel;
                    }
                    else
                    {
                        return showInboxMessageModel;
                    }
                }
                else
                {
                    return showInboxMessageModel;
                }
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
