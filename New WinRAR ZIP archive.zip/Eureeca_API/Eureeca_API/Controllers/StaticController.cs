﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Models.PitchModels.ViewModels;
using Eureeca_API.Models.StaticModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using System.ComponentModel.DataAnnotations;

namespace Eureeca_API.Controllers
{
    [Route("Api/User/[action]")]
    [ApiController]
    public class StaticController : ControllerBase
    {
        private readonly IStringLocalizer<Resources.StaticController> _stringLocalizer;
        private readonly IStringLocalizer<Resources.FAQ> _stringLocalizerFAQ;
        private readonly ErrHandler _errHandler;
        private readonly IConfiguration _config;

        public StaticController(IStringLocalizer<Resources.StaticController> stringLocalizer,IStringLocalizer<Resources.FAQ> stringLocalizerFAQ, IConfiguration config)
        {
            _stringLocalizer = stringLocalizer;
            _stringLocalizerFAQ = stringLocalizerFAQ;
            _errHandler = new ErrHandler();
            _config = config;
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult StaticAboutUs([Required] int langId)
        {
            try
            {
                Tools.SetThreadCulture(langId);
                AboutUsResponse aboutUsResponse = new AboutUsResponse();
                aboutUsResponse.Content = _stringLocalizer["Content"].Value;
                aboutUsResponse.Subtitle= _stringLocalizer["Subtitle"].Value;
                aboutUsResponse.Title = _stringLocalizer["Title"].Value;
                aboutUsResponse.VideoId = "odeo117gco";
                return Ok(new { code = 200, success = true, aboutUsResponse });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }
        [AllowAnonymous]
        [HttpGet]
        public IActionResult StaticCaseStudies([Required] int langId)
        {
            try
            {
                Tools.SetThreadCulture((int)langId);
                CaseStudiesResponse caseStudiesResponse = new CaseStudiesResponse();
                caseStudiesResponse.Title = _stringLocalizer["CaseStudiesTitle"].Value;
                caseStudiesResponse.Subtitle = _stringLocalizer["CaseStudiesSubtitle"].Value;
                List<object> imageDetails = new List<object>();
                if (langId == (int)Languages.Arabic)
                {
                    imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/Homes%20or%20Houses%20-%20Eureeca.png", Detail = _stringLocalizer["HomesOrHouses"].Value });
                    imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/Jobedu-New-Logo.png", Detail = _stringLocalizer["Jobedu"].Value });
                    imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/LOGO-poupee-LARGER.png", Detail = _stringLocalizer["PoupeeCouture"].Value });
                    imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/Cabture_Logo.png", Detail = _stringLocalizer["Cabture"].Value });
                    caseStudiesResponse.ImageDetails = imageDetails;
                    return Ok(new { code = 200, success = true, caseStudiesResponse });

                }
                imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/ElGrocer.png", Detail = _stringLocalizer["ElGrocer"].Value });
                imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/Homes%20or%20Houses%20-%20Eureeca.png", Detail = _stringLocalizer["HomesOrHouses"].Value });
                imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/Savortex.png", Detail = _stringLocalizer["Savortex"].Value });
                imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/Enerwhere.png", Detail = _stringLocalizer["Enerwhere"].Value });
                imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/Dukkaani.png", Detail = _stringLocalizer["Dukkaani"].Value });
                imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/Jobedu-New-Logo.png", Detail = _stringLocalizer["Jobedu"].Value });
                imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/Peerwith.png", Detail = _stringLocalizer["Peerwith"].Value });
                imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/GulfMeteor.png", Detail = _stringLocalizer["GulfMeteor"].Value });
                imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/SugarMoo.png", Detail = _stringLocalizer["SugarMoo"].Value });
                imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/LOGO-poupee-LARGER.png", Detail = _stringLocalizer["PoupeeCouture"].Value });
                imageDetails.Add(new { ImageUrl = _config.GetValue<string>("AssetsEnvironmentURL") + "images/Cabture_Logo.png", Detail = _stringLocalizer["Cabture"].Value });
                caseStudiesResponse.ImageDetails = imageDetails;
                return Ok(new { code = 200, success = true, caseStudiesResponse });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }
        }
        [AllowAnonymous]
        [HttpGet]
        public IActionResult StaticFAQ([Required] int langId)
        {
            try
            {
                Tools.SetThreadCulture(langId);
                List<object> genFAQs = new List<object>();
                genFAQs.Add(new { Question = _stringLocalizerFAQ["GenQ1"].Value, Answer = _stringLocalizerFAQ["GenQ1_A"].Value });
                genFAQs.Add(new { Question = _stringLocalizerFAQ["GenQ2"].Value, Answer = _stringLocalizerFAQ["GenQ2_A"].Value });
                genFAQs.Add(new { Question = _stringLocalizerFAQ["GenQ3"].Value, Answer = _stringLocalizerFAQ["GenQ3_A"].Value });
                genFAQs.Add(new { Question = _stringLocalizerFAQ["GenQ4"].Value, Answer = _stringLocalizerFAQ["GenQ4_A"].Value });
                genFAQs.Add(new { Question = _stringLocalizerFAQ["GenQ5"].Value, Answer = _stringLocalizerFAQ["GenQ5_A"].Value });

                List<object> sMEFAQs = new List<object>();
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ1"].Value, Answer = _stringLocalizerFAQ["SMEQ1_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ2"].Value, Answer = _stringLocalizerFAQ["SMEQ2_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ3"].Value, Answer = _stringLocalizerFAQ["SMEQ3_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ4"].Value, Answer = _stringLocalizerFAQ["SMEQ4_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ5"].Value, Answer = _stringLocalizerFAQ["SMEQ5_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ6"].Value, Answer = _stringLocalizerFAQ["SMEQ6_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ7"].Value, Answer = _stringLocalizerFAQ["SMEQ7_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ8"].Value, Answer = _stringLocalizerFAQ["SMEQ8_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ9"].Value, Answer = _stringLocalizerFAQ["SMEQ9_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ10"].Value, Answer = _stringLocalizerFAQ["SMEQ10_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ11"].Value, Answer = _stringLocalizerFAQ["SMEQ11_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ12"].Value, Answer = _stringLocalizerFAQ["SMEQ12_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ13"].Value, Answer = _stringLocalizerFAQ["SMEQ13_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ14"].Value, Answer = _stringLocalizerFAQ["SMEQ14_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ15"].Value, Answer = _stringLocalizerFAQ["SMEQ15_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ16"].Value, Answer = _stringLocalizerFAQ["SMEQ16_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ17"].Value, Answer = _stringLocalizerFAQ["SMEQ17_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ18"].Value, Answer = _stringLocalizerFAQ["SMEQ18_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ19"].Value, Answer = _stringLocalizerFAQ["SMEQ19_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ20"].Value, Answer = _stringLocalizerFAQ["SMEQ20_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ21"].Value, Answer = _stringLocalizerFAQ["SMEQ21_A"].Value });
                sMEFAQs.Add(new { Question = _stringLocalizerFAQ["SMEQ22"].Value, Answer = _stringLocalizerFAQ["SMEQ22_A"].Value });

                List<object> investorFAQs = new List<object>();
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ1"].Value, Answer = _stringLocalizerFAQ["INVQ1_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ2"].Value, Answer = _stringLocalizerFAQ["INVQ2_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ3"].Value, Answer = _stringLocalizerFAQ["INVQ3_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ4"].Value, Answer = _stringLocalizerFAQ["INVQ4_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ5"].Value, Answer = _stringLocalizerFAQ["INVQ5_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ6"].Value, Answer = _stringLocalizerFAQ["INVQ6_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ7"].Value, Answer = _stringLocalizerFAQ["INVQ7_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ8"].Value, Answer = _stringLocalizerFAQ["INVQ8_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ9"].Value, Answer = _stringLocalizerFAQ["INVQ9_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ10"].Value, Answer = _stringLocalizerFAQ["INVQ10_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ11"].Value, Answer = _stringLocalizerFAQ["INVQ11_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ12"].Value, Answer = _stringLocalizerFAQ["INVQ12_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ13"].Value, Answer = _stringLocalizerFAQ["INVQ13_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ14"].Value, Answer = _stringLocalizerFAQ["INVQ14_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ15"].Value, Answer = _stringLocalizerFAQ["INVQ15_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ16"].Value, Answer = _stringLocalizerFAQ["INVQ16_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ17"].Value, Answer = _stringLocalizerFAQ["INVQ17_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ18"].Value, Answer = _stringLocalizerFAQ["INVQ18_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ19"].Value, Answer = _stringLocalizerFAQ["INVQ19_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ20"].Value, Answer = _stringLocalizerFAQ["INVQ20_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ21"].Value, Answer = _stringLocalizerFAQ["INVQ21_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ22"].Value, Answer = _stringLocalizerFAQ["INVQ22_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ23"].Value, Answer = _stringLocalizerFAQ["INVQ23_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ24"].Value, Answer = _stringLocalizerFAQ["INVQ24_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ25"].Value, Answer = _stringLocalizerFAQ["INVQ25_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ26"].Value, Answer = _stringLocalizerFAQ["INVQ26_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ27"].Value, Answer = _stringLocalizerFAQ["INVQ27_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ28"].Value, Answer = _stringLocalizerFAQ["INVQ28_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ29"].Value, Answer = _stringLocalizerFAQ["INVQ29_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ30"].Value, Answer = _stringLocalizerFAQ["INVQ30_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ31"].Value, Answer = _stringLocalizerFAQ["INVQ31_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ32"].Value, Answer = _stringLocalizerFAQ["INVQ32_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ33"].Value, Answer = _stringLocalizerFAQ["INVQ33_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ34"].Value, Answer = _stringLocalizerFAQ["INVQ34_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ35"].Value, Answer = _stringLocalizerFAQ["INVQ35_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ36"].Value, Answer = _stringLocalizerFAQ["INVQ36_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ37"].Value, Answer = _stringLocalizerFAQ["INVQ37_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ38"].Value, Answer = _stringLocalizerFAQ["INVQ38_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ39"].Value, Answer = _stringLocalizerFAQ["INVQ39_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ40"].Value, Answer = _stringLocalizerFAQ["INVQ40_A"].Value });
                investorFAQs.Add(new { Question = _stringLocalizerFAQ["INVQ41"].Value, Answer = _stringLocalizerFAQ["INVQ41_A"].Value });
                
                FAQsResponse fAQsResponse= new FAQsResponse();
                fAQsResponse.FAQTitle = _stringLocalizerFAQ["FAQTitle"].Value;
                fAQsResponse.General = _stringLocalizerFAQ["General"].Value;
                fAQsResponse.Entrepreneurs = _stringLocalizerFAQ["Entrepreneurs"].Value;
                fAQsResponse.Investors = _stringLocalizerFAQ["Investors"].Value;
                fAQsResponse.FAQSearchPlaceholder = _stringLocalizerFAQ["FAQSearch.placeholder"].Value;
                fAQsResponse.CategoryBrowse = _stringLocalizerFAQ["CategoryBrowse"].Value;
                fAQsResponse.GeneralFAQs = genFAQs;
                fAQsResponse.EntrepreneurFAQs= sMEFAQs;
                fAQsResponse.InvestorFAQs= investorFAQs;
                return Ok(new { code = 200, success = true, fAQsResponse });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }
    }
}
