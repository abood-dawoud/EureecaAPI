﻿using Eureeca_API.Enums;
using Eureeca_API.General;
using Eureeca_API.Interface;
using Eureeca_API.Models.GeneralModels.Dto;
using Microsoft.AspNetCore.Mvc;

namespace Eureeca_API.Controllers
{
    [Route("api/mainImages/[action]")]
    [ApiController]

    public class MainImagesController : ControllerBase
    {
        private readonly IMainImages _mainImages;
        private readonly ErrHandler _errHandler;

        public MainImagesController(IMainImages mainImages)
        {
            _mainImages = mainImages;
            _errHandler = new ErrHandler();
        }

        [HttpPost]
        public async Task<ActionResult> MainBannerGetImages(Banner banner)
        {
            try
            {
                banner.LangId = Enum.IsDefined(typeof(Languages), banner.LangId) ? banner.LangId : Languages.English;
                banner.CurrencyId = Enum.IsDefined(typeof(Currencies), banner.CurrencyId) ? banner.CurrencyId : Currencies.USD;

                var proposalBanner = await Task.FromResult(_mainImages.MainImagesGetBannerProposal(banner.UserId, (int)banner.LangId, banner.CountryId, (int)banner.CurrencyId));
                var imagesBanner = await Task.FromResult(_mainImages.MainImagesBindImagesWithButton((int)banner.LangId, banner.CountryId));
                return Ok(new { code = 200, success = true, proposalBanner, imagesBanner });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }



    }
}
