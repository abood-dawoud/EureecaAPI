﻿using Eureeca_API.General;
using Eureeca_API.Interface.CountryBasedInterface;
using Eureeca_API.Models.GeneralModels.Dto;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace Eureeca_API.Controllers
{
    [Route("api/agreement")]
    [ApiController]

    public class AgreementController : ControllerBase
    {
        private readonly IAgreement _agreement;
        private readonly ErrHandler _errHandler;

        public AgreementController(IAgreement agreement)
        {
            _agreement = agreement;
            _errHandler = new ErrHandler();
        }

        [HttpGet("AgreementGetRiskAgreement")]
        public async Task<ActionResult> AgreementGetRiskAgreement([FromQuery] AgreementRequestModel requestModel)
        {
            try
            {
                var response = await Task.FromResult(_agreement.AgreementGetRiskAgreement(requestModel.CountryId, (int)requestModel.LangId));
                if (response == null) { return NotFound(); }
                return Ok(new { code = 200, success = true, agreement = new [] { response }  });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpGet("AgreementGetEureecaPrivacyPolicy")]
        public async Task<ActionResult> AgreementGetEureecaPrivacyPolicy([FromQuery] AgreementRequestModel requestModel)
        {
            try
            {
                var response = await Task.FromResult(_agreement.AgreementGetEureecaPrivacyPolicy(requestModel.CountryId,(int) requestModel.LangId));
                if (response == null) { return NotFound(); }
                return Ok(new { code = 200, success = true, agreement = new[] { response } });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpGet("AgreementGetEureecaTermsOfUse")]
        public async Task<ActionResult> AgreementGetEureecaTermsOfUse([FromQuery] AgreementRequestModel requestModel)
        {
            try
            {
                var response = await Task.FromResult(_agreement.AgreementGetEureecaTermsOfUse(requestModel.CountryId, (int)requestModel.LangId));
                if (response == null) { return NotFound(); }
                return Ok(new { code = 200, success = true, agreement = new[] { response } });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpGet("AgreementGetEureecaInvestorTermsOfUse")]
        public async Task<ActionResult> AgreementGetEureecaInvestorTermsOfUse([FromQuery] AgreementRequestModel requestModel)
        {
            try
            {
                var response = await Task.FromResult(_agreement.AgreementGetEureecaTermsOfBusiness(requestModel.CountryId, (int)requestModel.LangId));
                if (response == null) { return NotFound(); }
                return Ok(new { code = 200, success = true, agreement = new[] { response } });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpGet("AgreementGetEureecaUSTerms")]
        public async Task<ActionResult> AgreementGetEureecaUSTerms( [Required] int langId)
        {
            try
            {
                var response = await Task.FromResult(_agreement.AgreementGetEureecaUSTerms(langId));
                if (response == null) { return NotFound(); }
                return Ok(new { code = 200, success = true, agreement = new[] { response } });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

        [HttpGet("AgreementGetExposedPerson")]
        public async Task<ActionResult> AgreementGetExposedPerson([Required] int langId)
        {
            try
            {
                var response = await Task.FromResult(_agreement.AgreementGetExposedPerson(langId));
                if (response == null) { return NotFound(); }
                return Ok(new { code = 200, success = true, agreement = new[] { response } });
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace);
                return StatusCode(500, "Internal server error");
            }

        }

    }
}
