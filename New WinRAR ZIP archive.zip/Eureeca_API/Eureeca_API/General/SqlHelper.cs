﻿using Microsoft.Data.SqlClient;
using System;
using System.Data;
using System.Data.SqlClient;

namespace Eureeca_API.General
{
    public class SqlHelper
    {
        /*
         Connections are pooled by .NET, so re-creating them generally isn't an expensive operation. 
         Keeping connections open for long periods of time, however, can cause issues.
         Most "best practices" tell us to open connections as late as possible (right before executing any SQL) 
         and closing them as soon as possible (right after the last bit of data has been extracted).
         An effective way of doing this automatically is with using statements:
         That way, the resources are closed and disposed of even if an exception is thrown.
         In short, opening a connection when the app opens or when each form opens is probably not the best approach.
         */
        ErrHandler _errHandler;
        private SqlConnection con;
        public SqlHelper()
        {
            _errHandler = new ErrHandler();
            try
            {
                con = new SqlConnection();
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n con is NULL: " + (con == null));
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
        }

        //~ SqlHelper()
        //{
        //    con.Close();
        //    con.Dispose();
        //}

        /// Author : Mohammed
        /// Date : 22/02/2017
        /// <summary>thid method is used to return data table</summary>
        /// <param>String connectionString: this is the string used to open a SQL Server database</param>
        /// <param>String commandText: this is to set the Transact - SQL statement, table name or stored procedure to execute at the data source</param>
        /// <param>params SqlParameter[]: this is the array of sql parameters values for the sql command</param>
        public DataTable GetDataTable(String connectionString, String commandText, params SqlParameter[] parameters)
        {
            try
            {
                con.ConnectionString = connectionString;
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand(commandText, con);
                cmd.CommandType = CommandType.StoredProcedure;
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataTable DT = new DataTable();
                DA.Fill(DT);
                return DT;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n connectionString: " + connectionString + "\n commandText: " + commandText + "\n parameters length: " + parameters.Length + "\n con is NULL: " + (con == null));
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        /// Author : Mohammed
        /// Date : 22/02/2017
        /// <summary>thid method is used to return data table</summary>
        /// <param>String connectionString: this is the string used to open a SQL Server database</param>
        /// <param>String commandText: this is to set the Transact - SQL statement, table name or stored procedure to execute at the data source</param>
        /// <param>out int RecordCount: this is the output returned value from the executed sql command</param>
        /// <param>params SqlParameter[]: this is the array of sql parameters values for the sql command</param>
        public DataTable GetDataTable(String connectionString, String commandText, out int RecordCount, params SqlParameter[] parameters)
        {
            try
            {
                con.ConnectionString = connectionString;
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand(commandText, con);
                cmd.CommandType = CommandType.StoredProcedure;
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataTable DT = new DataTable();
                DA.Fill(DT);
                RecordCount = int.Parse(cmd.Parameters["@RecordCount"].Value.ToString());
                return DT;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n connectionString: " + connectionString + "\n commandText: " + commandText + "\n parameters length: " + parameters.Length + "\n con is NULL: " + (con == null));
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        /// Author : Mohammed
        /// Date : 22/02/2017
        /// <summary>thid method is used to return data table</summary>
        /// <param>String connectionString: this is the string used to open a SQL Server database</param>
        /// <param>String commandText: this is to set the Transact - SQL statement, table name or stored procedure to execute at the data source</param>
        /// <param>int CommandTimeout: this is to set the wait time before terminating the attempt to execute the command</param>
        /// <param>params SqlParameter[]: this is the array of sql parameters values for the sql command</param>
        public DataTable GetDataTable(String connectionString, String commandText, int CommandTimeout, params SqlParameter[] parameters)
        {
            try
            {
                con.ConnectionString = connectionString;
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand(commandText, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = CommandTimeout;
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);

                SqlDataAdapter DA = new SqlDataAdapter(cmd);
                DataTable DT = new DataTable();
                DA.Fill(DT);
                return DT;
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n connectionString: " + connectionString + "\n commandText: " + commandText + "\n CommandTimeout: " + CommandTimeout + "\n parameters length: " + parameters.Length + "\n con is NULL: " + (con == null));
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        /// Author : Mohammed
        /// Date : 22/02/2017
        /// <summary>thid method is used to execute a Transact-SQL statement against the connection</summary>
        /// <param>String connectionString: this is the string used to open a SQL Server database</param>
        /// <param>String commandText: this is to set the Transact - SQL statement, table name or stored procedure to execute at the data source</param>
        /// <param>params SqlParameter[]: this is the array of sql parameters values for the sql command</param>
        /// Returns: The number of rows affected.
        public int ExecuteNonQuery(String connectionString, String commandText, params SqlParameter[] parameters)
        {
            try
            {
                con.ConnectionString = connectionString;
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand(commandText, con);
                cmd.CommandType = CommandType.StoredProcedure;
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);

                return cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n connectionString: " + connectionString + "\n commandText: " + commandText + "\n parameters length: " + parameters.Length + "\n con is NULL: " + (con == null));
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        /// Author : Mohammed
        /// Date : 22/02/2017
        /// <summary>thid method is used to execute the query, and returns the first column of the first row in the result set returned by the query. Additional columns or rows are ignored.</summary>
        /// <param>String connectionString: this is the string used to open a SQL Server database</param>
        /// <param>String commandText: this is to set the Transact - SQL statement, table name or stored procedure to execute at the data source</param>
        /// <param>params SqlParameter[]: this is the array of sql parameters values for the sql command</param>
        /// Returns: The first column of the first row in the result set, or a null reference if the result set is empty. Returns a maximum of 2033 characters.
        public int ExecuteScalar(String connectionString, String commandText, params SqlParameter[] parameters)
        {
            try
            {
                con.ConnectionString = connectionString;
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand(commandText, con);
                cmd.CommandType = CommandType.StoredProcedure;
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n connectionString: " + connectionString + "\n commandText: " + commandText + "\n parameters length: " + parameters.Length + "\n con is NULL: " + (con == null));
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }

        /// Author : Mohammed
        /// Date : 22/02/2017
        /// <summary>thid method is used to send the CommandText to the Connection, and builds a SqlDataReader using one of the CommandBehavior values.</summary>
        /// <param>String connectionString: this is the string used to open a SQL Server database</param>
        /// <param>String commandText: this is to set the Transact - SQL statement, table name or stored procedure to execute at the data source</param>
        /// <param>params SqlParameter[]: this is the array of sql parameters values for the sql command</param>
        /// Returns: the returned value from the SQL SP.
        public int ExecuteReader(String connectionString, String commandText, params SqlParameter[] parameters)
        {
            try
            {
                con.ConnectionString = connectionString;
                if (con.State == ConnectionState.Closed)
                    con.Open();
                SqlCommand cmd = new SqlCommand(commandText, con);
                cmd.CommandType = CommandType.StoredProcedure;
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);

                SqlParameter parameterReturnValue = new SqlParameter("ReturnValue", SqlDbType.Int, 4);
                parameterReturnValue.Direction = ParameterDirection.ReturnValue;

                cmd.Parameters.Add(parameterReturnValue);

                SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);

                return (int)parameterReturnValue.Value;

                //using (SqlDataReader reader = cmd.ExecuteReader())
                //{
                //    if (reader.HasRows)
                //    {
                //        while (reader.Read())
                //        {
                //            return reader;
                //        }
                //    }
                //}
            }
            catch (Exception ex)
            {
                _errHandler.WriteError(ex.Message + "\n" + ex.StackTrace + "\n connectionString: " + connectionString + "\n commandText: " + commandText + "\n parameters length: " + parameters.Length + "\n con is NULL: " + (con == null));
                throw new Exception(ex.Message + "\n" + ex.StackTrace);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }
        }


    }
}
