﻿using Eureeca_API.Enums;
using Eureeca_API.Interface;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Logging;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Globalization;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Reflection;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace Eureeca_API.General
{
	public class Tools
	{
		public static List<T> DataReaderMapToList<T>(IDataReader dr)
		{
			List<T> list = new List<T>();
			T obj = default;
			while (dr.Read())
			{
				obj = Activator.CreateInstance<T>();
				foreach (PropertyInfo prop in obj.GetType().GetProperties())
				{
					if (!Equals(dr[prop.Name], DBNull.Value))
					{
						prop.SetValue(obj, dr[prop.Name], null);
					}
				}

				list.Add(obj);
			}

			return list;
		}

		public static List<T> ConvertDataTable<T>(DataTable dt)
		{
			List<T> data = new List<T>();
			foreach (DataRow row in dt.Rows)
			{
				T item = GetItem<T>(row);
				data.Add(item);
			}

			return data;
		}

		private static T GetItem<T>(DataRow dr)
		{
			Type temp = typeof(T);
			T obj = Activator.CreateInstance<T>();

			foreach (DataColumn column in dr.Table.Columns)
			{
				foreach (PropertyInfo pro in temp.GetProperties())
				{
					if (pro.Name == column.ColumnName)
					{
						if (dr[column.ColumnName] == null || dr[column.ColumnName] == DBNull.Value)
						{
							pro.SetValue(obj, default(T), null); // returns the default value for the type
						}
						else
							pro.SetValue(obj, dr[column.ColumnName], null);

					}

					else
						continue;
				}
			}

			return obj;
		}

		public static string FilterHTML(string htmlString)
		{
			StringBuilder sb = new StringBuilder(htmlString);
			sb.Replace("<script", "&lt;script");
			sb.Replace("</script", "&lt;/script");
			return sb.ToString();
		}

		public static string GetRoot()
		{
			return "";
			//if (!HttpContext.Current.Request.IsLocal)
			//    return HttpContext.Current.Request.ServerVariables["HTTP_HOST"].ToString();
			//else
			//    return HttpContext.Current.Request.Url.Authority + HttpContext.Current.Request.ApplicationPath;
		}

		public static bool IsValidEmail(string email)
		{
			// Return true if strIn is in valid e-mail format.
			return Regex.IsMatch(email,
				       @"^(?("")("".+?(?<!\\)""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
				       @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-0-9a-z]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$",
				       RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250)) &
			       new EmailAddressAttribute().IsValid(email);
		}

		public static bool IsValidUserName(string text)
		{
			string pattern = @"^(?=[a-zA-Z]){7,23}([a-zA-Z0-9\\_.-])+$";
			Regex regex = new Regex(pattern);
			return regex.IsMatch(text);
		}

		public static bool IsValidPassword(string Password)
		{
			string pattern = @"^.*(?=.{10,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*=(<+>'|/?.{:;})_,-]).*$";
			Regex regex = new Regex(pattern);
			return regex.IsMatch(Password);
			/*
                At least one lower case letter,
                At least one upper case letter,
                At least special character,
                At least one number
                At least 10 characters length
             */
		}

		public static string Format2DP(double val)
		{
			return string.Format("{0:#,##0.##}", Math.Floor(val * 100) / 100);
		}

		//register 
		public static bool IsValidNumber(string text)
		{
			string pattern = @"^[0-9]+$";
			Regex regex = new Regex(pattern);
			return regex.IsMatch(text);
		}

		public static bool IsValidDateTime(string txtDate)
		{

			DateTime tempDate;
			return DateTime.TryParse(txtDate, out tempDate);
		}

		public static int CompareDates(string srcDate, string targetDate)
		{
			System.Globalization.DateTimeFormatInfo dtfi = new System.Globalization.DateTimeFormatInfo();
			dtfi.ShortDatePattern = "MM/dd/yyyy";
			dtfi.DateSeparator = "/";

			DateTime src = Convert.ToDateTime(srcDate, dtfi);
			DateTime target = Convert.ToDateTime(targetDate, dtfi);

			if (src == target)
				return 0;
			else if (src > target)
				return 1;
			else
				return -1;
		}

		public static string DataTableToJSON(DataTable table)
		{
			return JsonConvert.SerializeObject(table);
		}

		public static string FileTypeImageMapping(string eviorenmentURL, string type)
		{
			string img = "";
			switch (type)
			{
				case ".txt":
					img = eviorenmentURL + "Images/txt1.png";
					break;
				case ".docx":
					img = eviorenmentURL + "Images/doc1.png";
					break;
				case ".doc":
					img = eviorenmentURL + "Images/doc1.png";
					break;
				case ".xlsx":
					img = eviorenmentURL + "Images/xls1.png";
					break;
				case ".xls":
					img = eviorenmentURL + "Images/xls1.png";
					break;
				case ".pptx":
					img = eviorenmentURL + "Images/ppt1.png";
					break;
				case ".ppt":
					img = eviorenmentURL + "Images/ppt1.png";
					break;
				case ".pps":
					img = eviorenmentURL + "Images/ppt1.png";
					break;
				case ".pdf":
					img = eviorenmentURL + "Images/pdf1.png";
					break;
				default:
					img = eviorenmentURL + "Images/file1.png";
					break;
			}

			return img;
		}

		public static bool IsValidFormula(string text, string lang)
		{
			string execludedPattern;
			if (lang == "AR")
				execludedPattern = @"^[a-z A-Z]+$";
			else
				execludedPattern = @"^[\u0600-\u06FF]+$";

			System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(execludedPattern);
			return !(regex.IsMatch(text));
		}

		public static string UrlGet()
		{
			string baseUrl = "https://ap3dev.eureeca.com";
			return baseUrl;
		}


		/// <summary>
		/// This method is used to round the float number to two decimal points
		/// </summary>
		/// <param name="val"></param>
		/// <returns></returns>
		public static float Round2DP(double val)
		{
			return (float)Math.Round(val, 2);
		}

		public static void SetThreadCulture(int langId)
		{
			if (langId == (int)Languages.Arabic)
			{
				var cultureInfo = CultureInfo.GetCultureInfo("ar-SA");
				Thread.CurrentThread.CurrentCulture = Thread.CurrentThread.CurrentUICulture = cultureInfo;

				var clone = Thread.CurrentThread.CurrentCulture.Clone() as CultureInfo;
				clone.DateTimeFormat = CultureInfo.GetCultureInfo("en-US").DateTimeFormat;
				clone.NumberFormat = CultureInfo.GetCultureInfo("en-US").NumberFormat;

				Thread.CurrentThread.CurrentCulture = clone;
				Thread.CurrentThread.CurrentUICulture = clone;

			}

		}

		public static string CallingAPI(IConfiguration config, string APIName, string postData)
		{

			string username = config.GetValue<string>("EureecaAPI_UserName");
			string password = config.GetValue<string>("EureecaAPI_Password");
			string encoded = Convert.ToBase64String(Encoding.ASCII.GetBytes(username + ":" + password));
			var request =
				(HttpWebRequest)WebRequest.Create("" + config.GetValue<string>("Eureeca2MBaseAPIUrl") + APIName);
			var data = Encoding.ASCII.GetBytes(postData);
			request.Method = "POST";
			request.ContentType = "application/x-www-form-urlencoded";
			request.ContentLength = data.Length;
			request.Headers.Add("Authorization", "Basic " + encoded);
			request.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;
			using (var stream = request.GetRequestStream())
			{
				stream.Write(data, 0, data.Length);
			}

			var response = (HttpWebResponse)request.GetResponse();
			return new StreamReader(response.GetResponseStream()).ReadToEnd();

		}

		public static string FormatNumberWithCurrency(int langId, string currencySymbol, string amount)
		{
			if (langId == (int)Languages.Arabic)
				return amount + currencySymbol;
			else
				return currencySymbol + amount;

		}




		public static string GetEnumDescription(Enum value)
		{
			FieldInfo? fi = value.GetType().GetField(value.ToString());

			DescriptionAttribute[]? attributes =
				fi?.GetCustomAttributes(typeof(DescriptionAttribute), false) as DescriptionAttribute[];

			if (attributes != null && attributes.Any())
			{
				return attributes.First().Description;
			}

			return value.ToString();
		}

		/***********************************************************************************************/
	

		private static readonly string EncryptionKey = "Kb@R=d)CI%5oQPaY";

		public static string Encrypt(string? clearText)
		{
			if (string.IsNullOrEmpty(clearText))
				return "";

			byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
			using (Aes encryptor = Aes.Create())
			{
				Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
				encryptor.Key = pdb.GetBytes(32);
				encryptor.IV = pdb.GetBytes(16);
				using (MemoryStream ms = new MemoryStream())
				{
					using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
					{
						cs.Write(clearBytes, 0, clearBytes.Length);
						cs.Close();
					}
					clearText = Convert.ToBase64String(ms.ToArray());
				}
			}
			return clearText;
		}


		public static string Decrypt(string? cipherText)
		{
			if (string.IsNullOrEmpty(cipherText))
				return "";

			byte[] cipherBytes = Convert.FromBase64String(cipherText);
			using (Aes encryptor = Aes.Create())
			{
				Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
				encryptor.Key = pdb.GetBytes(32);
				encryptor.IV = pdb.GetBytes(16);
				using (MemoryStream ms = new MemoryStream())
				{
					using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
					{
						cs.Write(cipherBytes, 0, cipherBytes.Length);
						cs.Close();
					}
					cipherText = Encoding.Unicode.GetString(ms.ToArray());
				}
			}
			return cipherText;
		}

	}
}
