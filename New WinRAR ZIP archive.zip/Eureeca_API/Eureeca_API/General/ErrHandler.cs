﻿using System;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;

namespace Eureeca_API.General
{
    /// <summary>
    /// Summary description for ErrHandler
    /// </summary>
    public class ErrHandler
    {
        public ErrHandler()
        {
        }

        public string WriteError(string errorMessage)
        {
            try
            {
                if (errorMessage.ToLower().Contains("thread was being aborted") || errorMessage.ToLower().Contains("validation of viewstate mac failed"))
                    return "";

                if (errorMessage.Contains("connectionString:") && errorMessage.Contains("commandText:"))
                    errorMessage = errorMessage.Substring(0, errorMessage.LastIndexOf("connectionString:")) + errorMessage.Substring(errorMessage.LastIndexOf("commandText:"));

                string path = "Error/" + "ErrorLog.txt"; //DateTime.Today.ToString("dd-mm-yy") + ".txt";

                if (!File.Exists(Path.Combine(path)))
                {
                    File.Create(Path.Combine(path)).Close();
                }
                using (StreamWriter w = File.AppendText(Path.Combine(path)))
                {
                    w.WriteLine("\r\nLog Entry : ");
                    w.WriteLine("{0}", DateTime.Now.ToString(CultureInfo.InvariantCulture));
                    string err = "Error Message:" + errorMessage;
                    w.WriteLine(err);
                    w.WriteLine("__________________________");
                    w.Flush();
                    w.Close();
                }
                return "Fatal error : " + errorMessage.Split('\n')[0] + ", error has been logged";
            }
            catch (Exception ex)
            {
                WriteError(ex.Message);
                return "";
            }
        }

        public void AddNotification(string NotificationMessage)
        {
            try
            {
                string path = "Error/" + "Notifications.txt";

                if (!File.Exists(Path.Combine(path)))
                {
                    File.Create(Path.Combine(path)).Close();
                }
                using (StreamWriter w = File.AppendText(Path.Combine(path)))
                {
                    w.WriteLine("\r\nLog Entry: ");
                    w.WriteLine("{0}", DateTime.Now.ToString(CultureInfo.InvariantCulture));
                    w.WriteLine("Notification Message: " + NotificationMessage);
                    w.WriteLine("__________________________");
                    w.Flush();
                    w.Close();
                }
            }
            catch (Exception ex)
            {
                WriteError(ex.Message);
            }
        }

    }


}
