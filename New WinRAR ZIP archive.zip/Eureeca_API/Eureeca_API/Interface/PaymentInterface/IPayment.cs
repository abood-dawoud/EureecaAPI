﻿using System.Data;

namespace Eureeca_API.Interface
{
    public interface IPayment
    {
        public DataTable PaymentGetUserAnnualPayments(int userId);

    }
}
