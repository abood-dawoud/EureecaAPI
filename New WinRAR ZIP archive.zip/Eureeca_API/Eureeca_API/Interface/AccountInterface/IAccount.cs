﻿using System.Data;

namespace Eureeca_API.Interface.AccountInterface
{
    public interface IAccount
    {
        public void AccountCreateUserAccount(string userName, string firstName, string lastName, int userId);
        public void AccountAddInvestment(DataTable dtUserDetails, int transactionCurrencyId, string pitchRate, int proposalId, string IAADAfterExchange, string profilePitchTitle);
        public void AccountEditUserAccount(string userName, string firstName, string lastName, int userId);


    }
}
