﻿using System.Data;

namespace Eureeca_API.Interface.UserInterface
{
    public interface ICustomForumUser
    {
        public void ForumUpdateUserDetails(int userId, string userFirstName, string userLastName, int userLanguage);

        public int ForumAddUser(string userFirstName, string userLastName, string userPicture, int userWallId, int userLanguageId);
        public DataTable ForumGetUserDetails(int userId, int langId);
        public void ForumUpdateUserPicture(string userPicture, int userId);



    }
}
