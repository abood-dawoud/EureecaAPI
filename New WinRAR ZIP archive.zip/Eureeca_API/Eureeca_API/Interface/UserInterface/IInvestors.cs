﻿using Eureeca_API.Models.UserModels.ViewModesl;
using System.Data;

namespace Eureeca_API.Interface.UserInterface
{
    public interface IInvestors
    {
        InvestorsResponse InvestorsGetInvestorsList(string listInvestorShowFilter, string sortFilterId,int CountryId, int badgeId, string investorName, int langId, int pageNo, int pageSize, string userId, int currencyId);
    }
}
