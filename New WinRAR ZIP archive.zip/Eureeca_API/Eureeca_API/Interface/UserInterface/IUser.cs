﻿using Eureeca_API.Enums;
using Eureeca_API.Models.SuitabilityModels.Dto;
using Eureeca_API.Models.SuitabilityModels.ViewModels;
using Eureeca_API.Models.UserModels.ViewModesl;
using System.Data;

namespace Eureeca_API.Interface.UserInterface
{
    public interface IUser
    {
        public bool UserIsAdmin(long userId);
        public bool UserIsBIAdmin(long userId);
        public DataTable UserGetUserRequest(int requestType, int userId, int requestPitchId);
        public DataTable UserSelectById(int userId);
        public DataRow UserGetSystemAdmin();
        public DataTable UserGetAdmins();
        public DataTable UserGetAllPitchFollower(string proposalId);
        public int UserAddNotification(string userNotificationFromUserId, string userNotificationToUserId, string userNotificationNotes, NotificationType userNotificationType);
        public DataTable UserGetDetails(int userId, int langId);
        public DataTable UserGetUserEnrollmentsByLang(long userId, int LangId, int masterGroupId);
        public DataTable UserGetLastFollowedProposals(int userId, int count);
        public DataTable UserCheckInvestorContactableBySME(string email, int pitchId);
        public DataTable UserGetAllUserFollowersForUser(int userId);
        public int UserGetPitchUserID(string pitchId);
        public DataTable SelectByUserName(string username);
        public DataTable SelectUserByEmail(string userEmail);
        public DataTable UserGetUserInfo(string username, string password);
        public bool UserIsCategorizationAllowedForUser(DataRow drUser);
        public DataTable UserSelectByUserGuid(string userGuid);
        public string UserGetLastTabsByDataTable(DataTable dtUser);
        public int UserIsSuitabilityTestAllowedForUser(DataRow drUser);
        public List<SuitabilityTest> SuitabilityTestGetSuitabilityTest(int langId, string countryId, int userId);
        public KYCModel KYCGetRequiredFiles(int userId, int countryId);
        public int UserGetUserConnectionId(string sourceUserID, string destinationUserId);
        public bool UserIsExpert(int userId);
        public DataTable UserGetInvestorsList(string listInvestorShowFilter, string filterCountryId, int countryId, int badgeId, string investorName, int langId, int lFirstRec, int lLastRec);
        public DataTable UserGetInvestorsListOffest(string listInvestorShowFilter, string sortFilterId, int countryId, int badgeId, string investorName, int langId, int lFirstRec, int lLastRec, out int recordCount);
        DataTable UserGetEntrepreneursList(string listEntrepreneurShowFilter, int filterCountryId, int langId, int lFirstRec, int lLastRec);
        public DataTable UserGetEntrepreneursListOffest(string listEntrepreneurShowFilter, string filterCountryId, int langId, int lFirstRec, int lLastRec, out int recordCount);
        public DataTable UserGetRecentlyInvested(int userId, int langId, int CurrencyId);
        public DataTable UserGetRecentlyFollowed(int userConnectionSourceUserId, int langId);
        public int UserGetTotalFollowing(int userId);
        public LoginResponse UserAuthenticateUser(DataTable dtUserInfo, out RedirectType redirect);
        public RequestAccessStatus UserGetRequestStatus(int userId, int pitchId, int requestType);
        public int UserUpdateInvestorCategory(int userId, int investorClassification);
        public UploadKYCResponseModel KYCUploadFile(int userId, int countryId, int docType, string docName, IFormFile file);
        public int UserUpdateLastLoginDate(long userId);
        public DataTable UserGetUserEnrollments(long userId, int groupId);
        public void UserUpdateUserScore(int userId, int userScoreAdded);
        public void UserupdateLastUpdateDate(int userId);
        public int AddRequest(int userId, int pitchID, string requestDesc, int requestType);
        public SuitabilityTestSubmitAnswerResponse SuitabilityTestSubmitAnswers(int userId, int countryId, List<SuitabilityAnswer> answers, int langId);
        public string UserGetSystemAdminEmail();
        public int UserCheckUserStatus(string userId);
        public DataTable UserGetBalanceForCurrency(int userId);
        public DataTable UserGetFollowedPitches(int userId, int languageId, int sortBy, int pageNo, int pageSize, out int RecordCount);
        public DataTable UserGetPitchRemindMints(int Pitch_ID);
        public int UserAddUser(int userType, string username, string profileFirstName, string profileLastName,
        int userCountry, string profilePostalCode, string userPhone, string profileState, string profileCity,
        string userPassword, string userEmail, string userDateOFBirth, string profileStreetAddress,
        string userGuid, int profileLanguageId, bool isPartner, string refferedByRef, int userNationality, bool userIsPEP);
        public bool UserCheckAndUpdateUKAgreementFlag(string username);
        public int UserAddPromotionCode(int userPromotionCodeUserId, string userPromotionCodeValue);
        public void UserUpdateFormType(int userId, int userFormType);
        public void UserUpdateUserStatus(int userId, UserStatus userStatus);
        public void UserUpdateUTMData(int userId, string userUtmCampaign, string userUtmSource);
        public void UserUpdateForumUserID(int eureecaUserID, int customForumTopicID, int customForumUserID);
        public void AddUserToGoogleSheet(int id, string userName, string firstName, string lastName, string userType, string userFormType, string dateBirth, string signUpDate, string email, string gender, string phoneNumber, string city, string state, string country, string countryCode, string userBadge, string preferredLanguage);
        public void UserUpdateUserInfo(int userId, int customForumUserId, string oldUsername, string username,
       string password, string profileFirstName, string profileLastName, int gender, int userType, int userFormType, string profileStreetAddress,
       int country, string profileState, string profileCity, string profilePostalCode, string phone, string email,
       string profileBankName, string userAccountNumber, string userSwiftIbanNumber, string profileBankAddress, int userBankCountry,
       string userStatus, string userDateOFBirth, int userLanguageId, bool isProfileHidden, int profileLanguageId, string profileSummary,
       string userPicture);
        public DataTable UserGetAllInvestmentCurrency(int langId, int userId);
        public DataTable UserIsAllowedInvestmentCurrency(int userId, int currencyId);
        public PendingOffers APIGetSumPendingOffersForUserByCurrency(int offerBuyerID, int offerCurrencyId);
        public DataTable UserGetNotRefundedInvestments(int userId, int languageId, int mode, int pageNo, int pageSize, out int recordCount);
        public RequestAccessStatus UserGetRequestStatusByRequestId(int requestId);
        public void UserUpdateRequestRejectFlag(int requestId);
        public void UserUpdateUserRequestFlag(int requestId);
        public DataTable UserGetProposalRequests(int pitchId, int langId, int requestType);
        public int UserGetTotalFollowersCount(int userID);
        public DataTable UserGetAllFollowersByPage(int userID, int languageID, int pageNo, int pageSize);
        public DataTable UserGetAllUserFollowingByPage(int userID, int languageID, int pageNo, int pageSize, out int RecordCount);
        public DataTable UserGetAllContactsByPage(int userID, int languageID, int pageNo, int pageSize);
        public int UserUpdateBankCountry(int userId, int userBankCountry);
        public DataTable SearchUsersByPageAndUserNameLang(string userName, int startRow, int endRow, int langId);
        public DataTable UserGetMembersToFollow(int userID, int languageID, int pageNo, int pageSize);
        public DataTable UserCommunityGetUserDataByID(int currentUserID, int destinationUserID, int languageID);
        public string UserGetUserTypeName(int userType, int investorType, int languageID);
        public int UserCheckUserFollow(int follower, int followedBy);
        public int UserAddFollower(int userConnectionSourceUserId, int userConnectionDestinationUserId);
        public void UserUnfollowUserFollower(string userConnectionId);
        public int UserSMEContactAdd(string email, int pitchId, bool investorContactableBySME);
        public DataTable UserGetAvaliableCurrency(int userId, int langId);
        public bool UserCheckProfileVisible(long profileUserId, int profileLanguageId);
        public void UserAddContact(int contactSrcUserId, int contactTargUserId);
        public bool UserCheckUsersContact(int contactSrcUserId, int contactTargUserId);
        public void UserChangePreferredCurrency(string currencyCode, int userId);
        public DataTable UserGetInvestmentsForProfile(int userId, int languageId, int currencyId);
    }
}