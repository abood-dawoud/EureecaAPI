﻿using System.Data;

namespace Eureeca_API.Interface.UserInterface
{
    public interface ILead
    {
        public void LeadUserCheckIfEureecaUpdateEureecaId(string leadEmail);
        public int LeadUsersAddNewLead(int leadId, int leadType, string leadEmail, string leadFirstName, string leadLastName, int leadSource, string[] proposals, string leadNotes, string leadOwer, int leadCountry, string leadPhone, string leadAddress1, string leadAddress2, string leadAnticipatedCommitment, int eureecaUserId, bool leadComingSoonAccessRequest);
        public DataTable LeadUsersGetLeadByEmail(string leadEmail);


    }
}
