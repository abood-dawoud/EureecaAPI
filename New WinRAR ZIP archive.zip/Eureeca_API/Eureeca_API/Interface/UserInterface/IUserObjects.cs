﻿using System.Data;

namespace Eureeca_API.Interface.UserInterface
{
    public interface IUserObjects
    {
        public DataTable UserObjectsGetUserEnrollmentsByLang(int detailsUserID, int profileLanguageID, int masterGroupID);
    }
}