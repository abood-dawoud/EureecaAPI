﻿using System.Data;

namespace Eureeca_API.Interface.UserInterface
{
    public interface IKYC
    {
        public int[] KYCGetRequiredDocs(int userId, int countryKYCTire);
        public DataTable KYCGetUserDocs(float userId);
        public int KYCManageUserAutomation(int userId, int overAllStatus, string personalPhoto, string personalPhotoUploadingDate, int personalPhotoStatus, string personalPhotoNotes, string passport, string passportUploadingDate, string passportName, int passportStatus, string passportExpire, string passportNotes, string utility, string utilityUploadingDate, int utilityStatus, string paymentConfirmation, string paymentConfirmationUploadingDate, int paymentConfirmationStatus,
         string proofOfAddress, string proofOfAddressUploadingDate, string proofOfAddressAddress, int proofOfAddressStatus, string proofOfAddressExpire, string proofOfAddressNotes, string sourceOfWealth, string sourceOfWealthUploadingDate, int sourceOfWealthStatus, string sourceOfWealthNotes, string certefiedCopies, string certefiedCopiesUploadingDate, int certefiedCopiesStatus, string certefiedCopiesNotes,
         string PEPDoc, int PEPStatus, string PEPNotes, string PEPUploadingDate);




    }
}
