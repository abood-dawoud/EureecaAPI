﻿using Eureeca_API.Models.UserModels.ViewModesl;
using System.Data;

namespace Eureeca_API.Interface.UserInterface
{
    public interface IEntrepreneurs
    {
        EntrepreneursResponse EntrepreneursGetEntrepreneurs(string listEntrepreneurShowFilter, string filterCountryId, int lFirstRec, int lLastRec, string userId, int langId, int currencyId);
    }
}
