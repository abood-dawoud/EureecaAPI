﻿using Eureeca_API.Enums;
using System.Data;

namespace Eureeca_API.Interface.PitchInterface
{
    public interface IPitchAttachements
    {
        public DataTable PitchGetAttachementDetails(int pitchAttachmentId);
        public DataTable PitchGetPitchAttachmentsByLangID(int pitchAttachmentPitchId, int profileLanguageId, PitchAttachmentType attachType);
        public DataTable PitchGetPitchAttachmentDocs(int pitchID, int langId, PitchAttachmentDocument mode);
        public DataTable PitchAttachmentGetDetails(int pitchAttachmentId);

    }
}
