﻿using System.Data;

namespace Eureeca_API.Interface.PitchInterface
{
    public interface IPitchLikeFollower
    {
        public DataTable PitchGetFollowersExceptInvestors(int proposalId, int languageId);
        public DataTable PitchGetAllInvestors(int proposalId, int languageId);
        public DataTable PitchGetFollowersAndInvestors(int proposalId, int languageId);
        public DataTable PitchgetUserIsLikeFollower(int userId, int pitchId);
        public void PitchUpdateUserFollowing(int userID, int proposalId, bool followType);





    }
}
