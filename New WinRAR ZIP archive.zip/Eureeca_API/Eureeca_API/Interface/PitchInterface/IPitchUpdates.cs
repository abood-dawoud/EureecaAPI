﻿using Eureeca_API.Enums;
using System.Data;

namespace Eureeca_API.Interface.PitchInterface
{
    public interface IPitchUpdates
    {
        public DataTable PitchGetUpdates(int pitchID, int lang, PitchUpdateStatus status);

    }
}
