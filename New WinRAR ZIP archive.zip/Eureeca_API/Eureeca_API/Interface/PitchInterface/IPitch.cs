﻿using Eureeca_API.Enums;
using Eureeca_API.Models.PitchModels.ViewModels;
using System.Data;

namespace Eureeca_API.Interface.PitchInterface
{

    public interface IPitch
    {
        public Pitch PitchGetPitchById(long pitchId);
        public bool PitchIsProposalViewPrevented(DataRow drProposal, int countryId, string userId);
        public DataTable PitchGetHomeLiveProposals(int langId, int currencyId);
        public DataTable PitchGetHomeEAProposals(int langId, int currencyId);
        public string ProposalFollow(string proposalId, string userId, int langId);
        public DataTable PitchGetTopThreeInvestment(int pitchId, int langId, int currencyId);
        public DataTable PitchGetUpdates(int proposalId, int lang, PitchUpdateStatus status);
        public DataTable PitchGetDedicatedPitchDetailsByLang(int proposalId, int langId, int? currencyId = 0);
        public DataTable PitchGetPitchSecondaryCountryLocation(int proposalId, int languageID, string mode);
        public DataTable PitchGetTags(int proposalId);
        public DataTable PitchGetCategoryDeatils(int categoryId);
        public DataTable PitchBadgesAssignedGetAll(int pageNo, int pageSize, int langId, int pitchID, out int recordCount);
        public DataTable PitchBusenissProfileGetAll(int proposalID, int langId);
        public void PitchGetCurrentTrancheDiscAndRemSizeByBalanceAfterDiscount(DataRow drPitchDetails, float balanceAfterDiscount, out double tranchDiscount, out double currentRemainingTrancheSize);
        public int PitchGetSumPendingPreInvestmentsAfterDiscount(int preComInvestmentProposalId);
        public double PitchGetExactAmountAfterExchange(double amount, int currencyID, string type, int proposalId);
        public DataTable PitchGetInvestorsByPage(int pitchId, int currencyId, int fund, int langId, int pageIndex, int pageSize, out int recordCount);
        public DataTable PitchGetFollowersByPage(int userId, int pageIndex, int pageSize, out int recordCount);
        public DataTable PitchGetTeamProfile(int teamProfileID, int lang);
        public DataTable PitchGetTeamsForPitch(int proposalId, int lang);
        public DataTable PitchGetSortPitchHomePageSlider(int langId, int currencyId);
        public DataTable PitchGetCounter(int pitchId);
        public DataTable PitchGetAllEOIProposals(int langId, string searchText, bool allActiveNotActiveProposals);
        public DataRow PitchGetPitchOwner(int proposalId);
        public DataTable PitchTheNumbersGetAll(int proposalId);
        public DataTable PitchNumberTextGetAll(int proposalId, int numberTextLangId);
        public DataTable PitchGetInvestorsForPitchByFund(int proposalId, int fund, int lang, int currencyID);
        public void PitchViewProposalPrevention(bool pitchPreventExeption, int countryId, int pitchCountry, int userId, int pitchOwnerId, int pitchId, out string preventionFlag1, out string preventionFlag2, out string preventionFlag3, out string preventionFlag4);
        public string PitchViewProposalPreventionByProposal(bool pitchPreventExeption, int countryId, int userId, int pitchOwnerId, int pitchId);
        public string PitchCheckProposalViewingPreventionByUserKYC(bool pitchPreventExeption, int countryId, int pitchCountry, int userId, int pitchOwnerId, int pitchId, string pitchStatus, int userFormType);
        public bool PitchCheckProfileVisible(long pitchId, int langId);
        public void PitchTestExpiration(int langId, int PID);
        public void PitchUpdatePitchViewed(int pitchId);
        public double PitchGetPitchRateAsDouble(int proposalId, int currencyId);
        public DataTable PitchDetailsForQuickInvest(int pitchId, int langId, int currencyId);
        public float PitchCalcSharesOfDollars(int dollarsAmount, float sharePrice, int proposalBalanceAD, bool hasDiscount, int tranch1Size, int tranch1Discount, int tranch2Size, int tranch2Discount, int tranch3Size, int tranch3Discount, int tranch4Size, int tranch4Discount);
        public int PitchGetSumPendingPreInvestmentsForUserByCurrency(int userId, int currencyId);
        public DataTable PitchGetPitchRate(int pitchId, int currencyId);
        public DataTable PitchGetDedicatedPitchDetails(int proposalId, int langId);
        public void PitchUpdatePitchStatus(int pitchId, string pitchStatus);
        public void PitchStatusChanged(int langId, int proposalId, string currentPitchStatus, string newPitchStatus, DataRow drProposal);
        public int PitchAddPitchUpdate(string title, int pitchId, string text, int langId);
        public void PitchAddPitchUpdateAttachment(int pitchUpdateId, string fileName, string description, string pitchUpdateAttachmentThumbnail);
        public DataTable PitchGetUserActiveLiveOpenedPitch(int userId);
        public DataTable PitchGetUserActivePitch(int userId);
        public DataTable PitchGetCheckListApplication(int userId);
        public DataTable PitchGetMostRecentInvestment(int proposalId, int langId);
        public DataTable PitchGetLeadInvestment(int proposalId, int langId, int currencyId);
        public string PitchGetPublicDaysLeft(DateTime DateConverted);
        public int PitchGetStatusNumber(string pitchStatus);
        public DataTable PitchGetAllPendingPreInvestmentsPaging(int proposalId, int langId, int currencyId, int pageNo, int pageSize, out int recordCount);
        public DataTable PitchGetProposalRequestsPaging(int proposalId, int langId, int requestType, int pageNo, int PageSize, out int recordCount);
        public DataTable PitchGetActivePitchesForPayment(int LangId);
        public DataTable PitchGetPitchNotLocalizedDetails(int proposalId);
        public DataTable PitchGetTop6InvestorsForSlider(int pitchId);

        public List<Pitch> PitchGetCompletedPitchsList(int langId, int currencyId, int countryId, int userId, int categoryID, string sorting, int tagID, int pageNo, int pageSize, string currencySymbol, out int recordCount);
        public List<Pitch> PitchGetLivePitchsList(int langId, int currencyId, int countryId, int userId, int categoryID, string sorting, int tagID, int pageNo, int pageSize, string currencySymbol, bool isPublished, out int recordCount);
        public DataTable PitchGetAllPitchCategories(int languageID);
        public DataTable PitchGetUserActivePitchAndValid(int userId);


    }
}
