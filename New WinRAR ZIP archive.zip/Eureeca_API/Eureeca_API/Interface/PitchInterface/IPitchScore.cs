﻿using Eureeca_API.Models.PitchModels.ViewModels;
using System.Data;

namespace Eureeca_API.Interface.PitchInterface
{
    public interface IPitchScore
    {
        public int PitchScoreAddEdit(int pitchId, int hasPitchDeckRank, int financialsHasHistoricalsAndProjectionsRank,
            int countryRank, int isReligiouslyPoliticallySexuallyAffiliatedRank, int problemsInThePastRank, int recognizableBuisnessRank,
            int howComplicatedRank, int isBadRank, int yearsInOperationRank, int ideaRank, int teamViewRank,
            int succeedingRank, int scalabilityRank, int businessIsAlreadyRevenueRank, int websiteRank, int howMuchCompanyRaisingRank, float score, string BDNotes, string prefferedLinks, string RM);

        public List<PitchScore> PitchScoreGetData(int? pitchId);

        public DataTable PitchScoreProposalList(int langId, int pageNo, int pageSize, out int recordCount);


    }
}
