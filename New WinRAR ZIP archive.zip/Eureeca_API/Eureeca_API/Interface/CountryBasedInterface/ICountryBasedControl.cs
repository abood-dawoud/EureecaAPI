﻿using Eureeca_API.Enums;
using Eureeca_API.Repository;
using System.Data;

namespace Eureeca_API.Interface.CountryBasedInterface
{
    public interface ICountryBasedControl
    {
        public int CountryBasedCheckCountryRestrictedForControl(CountryBasedControls controlId, int countryId);
        public int CountryBasedCheckCountryRestrictedForControl(CountryBasedControls controlId, int userCountryId, int proposalCountryId);
        public DataTable CountryBasedGetGroupDataProfile(int groupId, int languageId);
        public int CountryBasedCheckCountryRestrictedForControlbyPage(CountryBasedControls controlId, int pitchId, int proposalCountryId);
        public DataTable CountryBasedGetGroupData(int groupId);
        public int CountryBasedGetCountryDetailsByID(string countryID);
        public DataTable CountryBasedGetQuestionnaireCategoryGroupDetails(int groupId);
        public DataTable CountryBasedGetCurrencyCheckQuestion(int controlId, string countryCode);
        public DataTable CountryBasedGetCountryDetails(int countryId, int langId);
        public DataTable CountryBasedGetGroupDataMinimumAgeAllowed(int groupId);



    }
}
