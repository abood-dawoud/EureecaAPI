﻿using System.Data;

namespace Eureeca_API.Interface.CountryBasedInterface
{
    public interface ICountryBasedBankDetails
    {
        public DataTable CountryBasedControlGetGroupDataBankDetailst(int groupId, int currencyLangId);
        public DataTable CountryBasedControlGetAllBankInfoByCurrencyLang(int currencyId, int langId, int groupId);

    }
}
