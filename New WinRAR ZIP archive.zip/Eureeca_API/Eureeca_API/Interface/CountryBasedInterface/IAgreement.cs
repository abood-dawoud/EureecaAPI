﻿using Eureeca_API.Models.GeneralModels.ViewModels;

namespace Eureeca_API.Interface.CountryBasedInterface
{
    public interface IAgreement
    {
        public Agreement AgreementGetRiskAgreement(int countryId, int langId);
        public Agreement AgreementGetEureecaPrivacyPolicy(int countryId, int langId);
        public Agreement AgreementGetEureecaTermsOfUse(int countryId, int langId);
        public Agreement AgreementGetEureecaTermsOfBusiness(int countryId, int langId);
        public Agreement AgreementGetEureecaUSTerms(int langId);
        public Agreement AgreementGetExposedPerson(int langId);
        public Agreement AgreementGetRegistrationRegulatorsAgreement(int countryId, int langId);
        public Agreement AgreementGetRegistrationPrevention(int countryId, int langId);
        public Agreement AgreementGetRegistrationWarning(int countryId, int langId);
        public int GetMinimunAge(int countryId);


    }
}
