﻿using System.Data;

namespace Eureeca_API.Interface.CountryBasedInterface
{
    public interface IPaymentSelector
    {
        public DataTable PaymentSelectorGetTextDetailsDataPayment(int controlId, string countryCode);
        public int PaymentSelectorCheckCountryPayment(int controlId, string countryCode);
        public DataTable PaymentSelectorGetCridetTransfae(int controlId, string countryCode);



    }
}
