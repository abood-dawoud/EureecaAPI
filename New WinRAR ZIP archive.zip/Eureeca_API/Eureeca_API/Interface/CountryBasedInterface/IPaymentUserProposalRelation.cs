﻿using System.Data;

namespace Eureeca_API.Interface.CountryBasedInterface
{
    public interface IPaymentUserProposalRelation
    {
        public DataTable PaymentUserProposalRelationGetGroupData(int groupId);

    }
}
