﻿using Eureeca_API.Enums;
using System.Data;

namespace Eureeca_API.Interface.InboxInterface
{
    public interface IMessage
    {
        public void MessageSendProposalActionsEmail(DataRow sender, DataTable dtAdmins, DataRow proposal, DataRow owner, string customBody, PitchAction action);
        public void MessageSendPithStatusChangesEmail(DataRow sender, DataTable dtAdmins, DataRow owner, DataRow proposal, PitchStatus currentStatus, PitchStatus newStatus);
        public void MessageSendMessageForPitchUsers(DataRow sender, DataTable dtUsers, string pitchTitle, string proposalId, string ownerFirstName, PitchAction action);
        public void MessageSendMessageForUserFollowers(DataRow sender, DataTable dtFollowers, DataRow user, string actionPitchTitle, int actionProposalId, string actionUserName, int actionUserId, UserAction action);
        public void MessageAddOutgoingEmail(string outGouingTo, string outGouingSubject, string outGouingBody, string outGouingReplyTo);
        public void MessageSendAccountVerificationEmail(string from, string to, string firstName, string guid);
        public void MessageSendContactsEmail(DataRow sender, DataTable admins, string subject, string name, string email, string phone, string details, UserAction action);
        public void MessageSendExternalMessage(string replyTo, string to, string subject, string body);
        public string MessageSendMessage(DataRow sender, string subject, string body, DataTable receivers);
        public void MessageSendMessageWhenUserRequestToContactProposalOwner(DataRow sender, DataTable admins, DataRow receiver, DataRow owner, string pitchTitle, RequestType requestType);
        public void MessageSendCustomForumEmailsToOwner(DataRow sender, DataRow receiver, string firstName, string pitchId, string pitchTitle, string userId, string comment, string GUID, UserAction action);
        public void MessageSendMessageWhenUserRequest(DataRow sender, DataTable admins, DataRow receiver, DataRow owner, string pitchTitle, RequestType requestType);
        public void MessageSendSignupNotification(string sender, string receiver, string username, string userPhone, string email, string previous);
        public void MessageSendKYCUploadedEmailToInvestor(DataRow sender, DataRow User);
        public void MessageSendKYCUploadedEmailToKYCTeam(DataRow sender, DataRow user, string objectTitle, string imageName);
        public void MessageSendKYCUploadedEmailToKYCAdmin(DataRow sender, DataRow user, string objectTitle, string uploadedDocs);
        public void MessageSendInvestmentEmail(DataRow sender, DataTable admins, DataRow receiver, DataRow drInvestor, string pitchTitle, int pitchId, double investmentAmount, PitchAction action, string currencyId);
        public void MessageSendInvestmentNotificationForAdmins(DataRow sender, DataRow User, string proposalName, string investmentAmount, string currencySymbol);
        public void MessageSendPreCommitmentNotificationForAdmins(DataRow sender, DataRow user, string proposalName, string preCommitAmount, string currencySymbol);
        public void MessageSendMessageForPitchUsers(DataRow sender, DataTable dtUsers, string pitchTitle, string pitchId, decimal soFar, string pitchBalance, string investmentAmount, double discount, PitchAction action, string currencyId, PitchStatus pitchStatus);
        public void MessageSendAddProposalUpdateEmail(DataRow sender, DataTable admins, DataRow proposal);
        public void MessageSendRequestRejectionEmail(DataRow sender, DataTable admins, DataRow investor, DataRow pitch, RequestType type);
        public void MessageSendUserRequestWhenAcceptance(DataRow sender, DataTable admins, DataRow Investor, DataRow pitch, int type);
        //public DataTable MessageGetMessageInboxById(int messageId);
        //public DataTable MessageGetMessageInboxByID(int messageId);
        public void MessageSendMessageForUserFollowedBy(DataRow sender, DataRow drFollower, DataRow receiver);
        public DataTable MessageGetMessageInboxById(int messageId);
        public void MessageDeleteMessageInbox(int messageId);
        public DataTable MessageGetSentItemById(int messageId);
        public void MessageDeleteMessageSentItem(int messageId);
        public void MessageUpdateMessageInboxFlag(int messageId);
        public void MessageUpdateSentReadFlag(int messageId);

    }
}
