﻿using System.Data;

namespace Eureeca_API.Interface.InboxInterface
{
    public interface IInternalMessage
    {
        public void InternalMessageAddMessage(int senderId, int receiverId, string subject, string message, int flag, out int inboxId, out int sentId);
        public void InternalMessageUpdateInternalMessage(int inboxId, int sentId, string inboxMessage, string inboxSubject);
        public DataTable InternalMessageGetSentForUserN(int userId, int pageIndex, int pageSize, string sentSubject, int langId);
        public DataTable InternalMessageGetInboxForUserN(int userId, int pageIndex, int pageSize, string inboxSubject, int langId);

    }
}
