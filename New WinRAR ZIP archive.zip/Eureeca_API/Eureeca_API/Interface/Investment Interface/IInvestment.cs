﻿using Eureeca_API.Models.InvestmentModels.ViewModels;
using System.Data;

namespace Eureeca_API.Interface
{
    public interface IInvestment
    {
        public InvestmentInfoResponseModel InvestmentGetData(int pitchId, int userId, int currencyId, int langId);
        public DataTable InvestmentGetUserAnnualInvAndPreInv(int userId, int currencyId);
        public int InvestmentGetUserInvestmentAmountOnPitch(int userId, int pitchId, int currencyId);
        public void InvestmentUpdate(String userId, String proposalId, String investAmountAfterDiscount, double sharesSoldBD, double sharesSoldAD, double equitySold, int investmentType,
        string investmentSpecialNotes, int transactionCurrencyId, bool investmentBackEnd, String pitchRate, int investAmountAfterDiscountAfterExchange, int investmentLoggedInUserId);
        public string GetMoneyAfterExchange(int userId, int pitchId, int currencyId, string amount, string type);
        public bool InvestmentPrevention(int pitchId, string userCountry, int userId, out string preventionReason);
        public int InvestmentGetAllTotalUserInvesments(int userId, int currencyId);
        public DataTable InvestmentGetPendingInvestmentsPercentage(int userId, int pitchLanguageId, int pageNo, int pageSize, out int recordCount);
        public DataTable InvestmentGetAllUserPreCommitments(int userId, int preComInvestmentStatus, int languageId, int currencyId);
        public DataTable InvestmentGetInvestmentsSectors(int userId, int languageId);
        public DataTable InvestmentGetInvestmentsBreakdown(int userId, int languageId, int currencyId);
        public DataTable InvestmentGetInvestmentActiveClosed(int userId);
    }
}
