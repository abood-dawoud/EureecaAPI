﻿namespace Eureeca_API.Interface
{
    public interface ICurrency
    {
        string Name { get; }
    }
}
