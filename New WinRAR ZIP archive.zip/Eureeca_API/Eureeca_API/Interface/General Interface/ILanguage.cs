﻿namespace Eureeca_API.Interface
{
    public interface ILanguage
    {
    }
}
