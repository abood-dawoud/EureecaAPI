﻿using System.Data;

namespace Eureeca_API.Interface
{
    public interface ISuitabilityTest
    {
        public DataTable SuitabilityTestGetQuestionsByForm(int formId);

        public DataTable SuitabilityTestGetUserAnswers(int formId, int questionnaireRepUserId);

        public DataTable SuitabilityTestGetAnswers(int qestionId);

        public DataTable SuitabilityTestGetCurrencyCheckQuestion(int controlId, string countryCode);
        public int SuitabilityTestGetCountQuestionsByForm(int formId);
        public void SuitabilityTestReportDeleteUser(int repUserId);
        public DataTable SuitabilityTestGetQuestion(int questionId);
        public void SuitabilityTestQuestionsAddAnswersTest(int repUserId, int repQuestionId, int repAnswerId, bool repStatue, int groupId, int repLanguage);

        public Boolean SuitabilityTestQuestionsCheckForStatue(int questionId, int answerRight);


    }

}
