﻿namespace Eureeca_API.Interface
{
    public interface IGeoIP
    {
        public int GeoGetCountryId(string userIP);

    }
}
