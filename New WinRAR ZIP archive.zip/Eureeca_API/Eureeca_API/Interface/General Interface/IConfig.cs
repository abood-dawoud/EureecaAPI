﻿using Eureeca_API.Enums;
using System.Data;

namespace Eureeca_API.Interface
{
    public interface IConfig
    {
        public DataTable ConfigsGetConfigValue(ConfigurationsEnum configVariable);

    }
}
