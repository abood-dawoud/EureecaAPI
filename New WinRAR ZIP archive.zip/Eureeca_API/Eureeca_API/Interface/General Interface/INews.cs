﻿using Eureeca_API.Models.GeneralModels.ViewModels;
using System.Data;

namespace Eureeca_API.Interface
{
    public interface INews
    {
        public List<News> NewsGetHomeNews(int langId);
        public List<News> NewsGetNews(int newsProfileLanguageId, string newsId);

    }
}
