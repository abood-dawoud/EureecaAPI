﻿using System.Data;

namespace Eureeca_API.Interface
{
    public interface ISurvey
    {
        public DataTable SurveyCheckSurveysOnLogin(int userId);
    }
}
