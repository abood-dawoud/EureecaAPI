﻿using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.PitchModels.ViewModels;

namespace Eureeca_API.Interface
{
    public interface IMainImages
    {
        public List<MainImage> MainImagesBindImagesWithButton(int langId, int countryId);
        public List<PitchBanner> MainImagesGetBannerProposal(int userId, int langId, int countryId, int currencyId);

    }
}
