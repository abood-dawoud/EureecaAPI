﻿using System.Data;

namespace Eureeca_API.Interface
{
    public interface IAlert
    {
        public DataTable AlertGetAllShowInLogin();
        public void AlertUserAddAcceptUser(int alertId, int userId, bool accept);
        public DataTable AlertCheckAlertOnLogin(int userId);



    }
}
