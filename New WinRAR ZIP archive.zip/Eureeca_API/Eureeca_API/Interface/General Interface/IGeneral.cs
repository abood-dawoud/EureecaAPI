﻿using Eureeca_API.Enums;
using Eureeca_API.Models.GeneralModels.ViewModels;
using Eureeca_API.Models.UserModels.ViewModesl;
using System.Data;

namespace Eureeca_API.Interface
{
    public interface IGeneral
    {
        public Statistics StatsGetAll(string statsId, int currencyId);

        public float CurrencyGetGlobalRate(int currencyId);

        public List<CurrencyModel> CONSTGetCurrencies(int langId);
        public List<Country> CONSTGetCountries(int langId, string countryName);
        public List<Language> CONSTGetLanguages(int? langId = 0);
        public List<KeyInvestor> HomeGetTop10Investor(int? langId, int currencyId, int countryId, string userId);
        public List<Testimonials> HomeGetTestimonials(int langId, int countryId);
        public DefaultPageCustomModel HomeGetNewsTestimonialsKeyInvestor(int langId, int countryId, int currencyId, string userId);
        public int SubscribeByEmail(string email, int countryId);
        public DataTable CurrencyGetCurrencyByID(int currencyId);
        public string CurrencyGetCurrencySymbol(Currencies currency);



    }
}
