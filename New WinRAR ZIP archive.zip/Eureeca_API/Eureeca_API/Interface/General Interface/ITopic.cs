﻿using Microsoft.Data.SqlClient;
using System.Data;
using System.Data.Common;

namespace Eureeca_API.Interface
{
    public interface ITopic
    {
        public DataTable TopicGetAcceptedQuestionsOfTopic(int questionTopicId, int questionLanguageId);
        public DataTable TopicGetAcceptedAnswersOfQuestion(int questionId);
        public List<String> TopicGetQuestionsAffiliationDisclosure(int langId);
        public int TopicAddTopic(int topicTypeId, string topicName, int topicUserId, string topicCreationDate);
        public DataTable TopicGetTopicTypeDetailsByName(string topicTypeName);
        public DataTable TopicGetTopicTypeDetails(int topicTypeId);
        public DataTable TopicGetTopicDetails(int topicId);
        public int TopicAddQuestion(string questionText, string date, int questionerId, int topicId, string acceptance, int langId, int relationshipToSME, string relationshipToSMEWhenOther);
        public void TopicAddAnswer(int topicId, string answertext, string answerDate, int userId, int questionId, string answerAcceptance);

    }
}
